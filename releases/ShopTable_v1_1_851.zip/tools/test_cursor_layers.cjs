const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const d=JSON.parse(fs.readFileSync(path.join(__dirname,'../resource_pack/ui/data_driven_container_screen.json')));
const root=d.desktop_panel.controls.find(x=>x['root_panel@common.root_panel'])['root_panel@common.root_panel'];const c=root.controls.find(x=>x['inventory_selected_icon_button@common.inventory_selected_icon_button'])['inventory_selected_icon_button@common.inventory_selected_icon_button'];
assert.equal(c.layer,55000);assert.equal(c.always_handle_pointer,false);assert.equal(c.consume_hover_events,false);assert.equal(c.controls.length,5);
for(const row of c.controls.slice(0,3)){const s=Object.values(row)[0];assert.deepEqual(s.controls[0],{'selected_item_icon@common.inventory_selected_icon':{}});assert.deepEqual(s.controls[1],{'selected_stack_size_text@common.inventory_selected_stack_size_text':{offset:[-10000,-10000]}});assert.deepEqual(s.controls[2],{'selected_item_lock_overlay@common.inventory_selected_item_lock_overlay':{}});}
assert.deepEqual(c.controls[3],{'durability_bar_grabbed@common.durability_bar_grabbed':{}});assert.deepEqual(c.controls[4],{'storage_bar_grabbed@common.storage_bar_grabbed':{}});
console.log('PASS cursor: uploaded v848 image/input preserved; only carried-count labels moved offscreen in normal/pressed/hover states');
