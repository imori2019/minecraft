const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');const{run,prep,ctx,Container}=require('./test_smelt_sales.cjs');const ui=require('./read_price_ui.cjs')();const raw=JSON.parse(fs.readFileSync(path.join(__dirname,'../resource_pack/ui/shop_layout_price.json'),'utf8'));const ctl=x=>Object.assign({},...(x.controls??[]));let n=0;function test(name,f){f();n++;console.log('PASS RESTORE '+name)}
test('one native catalogue viewport includes descriptions and all original 27 row pairs',()=>{
 const page=ctl(ui.shop_page).shop_vis,parts=ctl(page);assert.ok(parts.sh_catalog_view);assert.ok(!Object.keys(parts).some(k=>/^sh_scroll_mode_[1-4]$/.test(k)));let productScrolls=0;
 function visit(x){if(!x||typeof x!=='object')return;if(x.$scrolling_content==='shop_layout_price.sh_catalog_content')productScrolls++;for(const y of Object.values(x))visit(y)}visit(page);assert.equal(productScrolls,1);
 const stack=ui.sh_catalog_content;assert.equal(stack.type,'stack_panel');assert.ok(ctl(stack)['products@shop_layout_price.sh_content']);
 for(let r=0;r<27;r++){assert.ok(ctl(ui.sh_content)['sh_row'+r]);assert.ok(ctl(ui.sh_content)['sh_row'+r+'_continuation'])}
});
test('description modes keep the original initial description, divider and product coordinates',()=>{
 const headers=ctl(ui.sh_catalog_content);for(let mode=1;mode<=4;mode++){
  const h=headers['description_'+mode],desc=ctl(h).description,sep=ctl(h).separator;assert.equal(h.collection_index,78);assert.equal(h.size[1],12*mode+11);assert.deepEqual(desc.offset,[4,0]);assert.deepEqual(desc.size,[168,12*mode]);assert.equal(60+h.size[1],83+12*(mode-1));assert.equal(60+sep.offset[1],80+12*(mode-1));
  const bind=h.bindings.find(b=>b.target_property_name==='#visible');assert.ok(bind.source_property_name.includes("'"+(2+4*(mode-1))+"'"));assert.ok(bind.source_property_name.includes("'"+(3+4*(mode-1))+"'"));assert.ok(h.bindings.some(b=>b.target_property_name==='#ignored'));
 }
});
test('ordinary inheritance references resolve without new expression variables or lazy grids',()=>{
 assert.ok(fs.statSync(path.join(__dirname,'../resource_pack/ui/shop_layout_price.json')).size<9_000_000);let refs=0;
 function visit(x){if(!x||typeof x!=='object')return;for(const[k,v]of Object.entries(x)){
  assert.ok(!k.startsWith('$u_'));if(k.includes('@shop_layout_price.shared_buyer_')){refs++;assert.ok(raw[k.split('.')[1]]);assert.ok(Object.keys(v).every(n=>n==='offset'));}
  assert.ok(!(k==='grid_item_template'&&String(v).includes('lazy_')));visit(v);
 }}visit(raw);assert.ok(refs>1000);
});
test('all products and prices are published with the v750 slot protocol, including 27 genres',()=>{
 ctx.shopInv=new Container(640);prep();run(`block.typeId='shopuilook2:panel';registry.stores.s1.pricePointSystem=normalizePricePointSystemSettings({});const list=Array.from({length:27},(_,i)=>{const p=base('p'+(100+i),'minecraft:apple');p.settings.shop_product_genre='分類'+i;return p});putProducts(list);globalThis.restored={};enterShopMode(player,restored,block,shopInv)`);assert.equal(run('restored.shopMode.cells.size'),27);
 for(let r=0;r<27;r++){assert.ok(run(`shopInv.getItem(shSlots(${r}).price[0])?.nameTag.length>0`));assert.equal(run(`shopInv.getItem(shSlots(${r}).prev)`),undefined);assert.equal(run(`shopInv.getItem(shSlots(${r}).next)`),undefined)}
});
console.log(n+' buyer restoration groups passed (native rendering and opening latency unmeasured)');
