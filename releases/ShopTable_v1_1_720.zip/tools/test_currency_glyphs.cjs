const assert=require('node:assert/strict');const fs=require('node:fs'),path=require('node:path');
const env=require('./test_smelt_sales.cjs');const {run}=env;let count=0;
function test(name,fn){fn();count++;console.log('PASS CURRENCY '+name);}
const reg=JSON.parse(fs.readFileSync(path.join(__dirname,'currency_glyph_registry.json'),'utf8'));
const priceUI=JSON.parse(fs.readFileSync(path.join(__dirname,'../resource_pack/ui/shop_layout_price.json'),'utf8'));
function walk(node,fn){if(!node||typeof node!=='object')return;fn(node);for(const v of Object.values(node))walk(v,fn);}
function subtract(expr,vars){const tokens=expr.match(/'[^']*'|#[A-Za-z0-9_]+/g)||[];const value=t=>t.startsWith("'")?t.slice(1,-1):(vars[t]??'');let result=value(tokens[0]??"''");for(const t of tokens.slice(1))result=result.split(value(t)).join('');return result;}
function update(label,payload,vars,visibleChanged){
 for(const b of label.bindings??[]){
  const active=['always','always_when_visible'].includes(b.binding_condition)||b.binding_condition==='visibility_changed'&&visibleChanged;
  if(!active)continue;
  if(b.binding_type==='collection'&&b.binding_name==='#hover_text')vars[b.binding_name_override]=payload;
  if(b.binding_type==='view'&&b.target_property_name!=='#visible'&&b.source_property_name?.includes(' - '))vars[b.target_property_name]=subtract(b.source_property_name,vars);
 }
}
test('new normal currency glyphs and icon references resolve for eggs, dyes, stone shapes and the upgrade template',()=>{
 for(const id of ['minecraft:cow_spawn_egg','minecraft:white_dye','minecraft:red_dye','minecraft:andesite_slab','minecraft:andesite_stairs','minecraft:netherite_upgrade_smithing_template','minecraft:command_block_minecart']){
  assert.ok(run(`SHOP_GLYPHS[${JSON.stringify(id)}]`),id);assert.notEqual(run(`itemIconPath(${JSON.stringify(id)})`),run(`SHOP_ICON_UNKNOWN`),id);
 }
 for(const id of Object.keys(reg.additions))assert.equal(run(`SHOP_GLYPHS[${JSON.stringify(id)}].codePointAt(0)`),parseInt(reg.additions[id].codepoint,16),id);
});
test('new ED glyphs retain small tooltip and block-price forms while normal-only overflow keeps the existing name fallback',()=>{
 const id=Object.keys(reg.additions).find(k=>reg.additions[k].codepoint.startsWith('ED'));assert.ok(id);
 const cp=parseInt(reg.additions[id].codepoint,16);assert.equal(run(`tipSmallGlyph(SHOP_GLYPHS[${JSON.stringify(id)}]).codePointAt(0)`),0xEF00+cp-0xED00);
 // Force block classification only for this shape variant, then restore it.
 const b=run(`SHOP_PRICE_BLOCK_CACHE.get(${JSON.stringify(id)})`);run(`SHOP_PRICE_BLOCK_CACHE.set(${JSON.stringify(id)},true)`);
 const out=run(`shopPriceSizedGlyphText({k:'item',id:${JSON.stringify(id)},n:12,n2:12},true,'light')`);assert.equal(out.codePointAt(0),0xEE00+cp-0xED00);
 run(`SHOP_PRICE_BLOCK_CACHE.${b===undefined?'delete':'set'}(${JSON.stringify(id)}${b===undefined?'':','+b})`);
});
test('visible buyer prices react when slot text arrives after the initial visibility event or changes while open',()=>{
 const labels=[];
 for(const key of ['sh_content','sh_rp_content'])walk(priceUI[key],node=>{
  if(node.controls?.[0]?.glyph&&node.controls?.[1]?.native)labels.push(node.controls[0].glyph);
 });
 assert.equal(labels.length,208,'cover both buyer lists and every primary width/point variant');
 const entries=[{k:'item',id:'minecraft:emerald',n:123,n2:123},{k:'item',id:'minecraft:white_dye',n:2500,n2:2000},{k:'pt',id:'minecraft:gold_ingot',n:60,n2:60}];
 for(const label of labels){
  const state={};update(label,'',state,true);
  for(const entry of entries){
   const raw=run(`shopPriceSizedGlyphText(${JSON.stringify(entry)},true,'light')`);update(label,raw,state,false);
   // The text must be refreshed without the card being hidden/reopened.
   assert.ok(state['#text']?.length,'numeric label is no longer frozen empty');
   assert.ok([...state['#text']].some(ch=>ch.codePointAt(0)>=0xF700&&ch.codePointAt(0)<=0xF7FF),'price digits survive icon extraction');
  }
 }
});
console.log(count+' currency glyph/price UI tests passed (API and binding simulation; not Minecraft rendering)');
