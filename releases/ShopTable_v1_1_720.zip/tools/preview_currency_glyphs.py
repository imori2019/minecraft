#!/usr/bin/env python3
"""Render added currency glyphs from the actual packaged font cells (Pillow)."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import json,argparse,math
R=Path(__file__).resolve().parents[1];ap=argparse.ArgumentParser();ap.add_argument('--labels',type=Path);ap.add_argument('--output',type=Path,required=True);args=ap.parse_args();args.output.mkdir(parents=True,exist_ok=True)
reg=json.loads((R/'tools/currency_glyph_registry.json').read_text())['additions'];labels=json.loads(args.labels.read_text()) if args.labels else {};cache={}
fontpath=next(iter(Path('/usr/share/fonts/opentype/noto').glob('NotoSansCJK-Regular.ttc')),None) or next(iter(Path('/usr/share/fonts/opentype/noto').glob('NotoSerifCJK-Regular.ttc')))
font=ImageFont.truetype(str(fontpath),18);small=ImageFont.truetype(str(fontpath),12);heading=ImageFont.truetype(str(fontpath),28)
def icon(id):
 cp=int(reg[id]['codepoint'],16);page=cp>>8
 if page not in cache:cache[page]=Image.open(R/f'resource_pack/font/glyph_{page:02X}.png').convert('RGBA')
 i=cp&255;return cache[page].crop((i%16*32,i//16*32,i%16*32+32,i//16*32+32))
def sheet(ids,title,cols=10):
 width=cols*132;rows=math.ceil(len(ids)/cols);im=Image.new('RGB',(width,96+rows*110),'#202833');draw=ImageDraw.Draw(im);draw.text((20,15),title,font=heading,fill='white');draw.text((20,55),'同梱フォントの実データから表示した一覧（ゲーム画面ではありません）',font=font,fill='#c2cad6')
 for j,id in enumerate(ids):
  x=j%cols*132;y=96+j//cols*110;draw.rounded_rectangle((x+4,y+4,x+128,y+106),radius=5,fill='#303c4b')
  sprite=icon(id).resize((48,48),Image.Resampling.NEAREST);im.paste(sprite,(x+42,y+6),sprite)
  name=labels.get(id,id.split(':')[-1]);name=name if len(name)<=10 else name[:9]+'…';draw.text((x+8,y+57),name,font=font,fill='white')
  sid=id.split(':')[-1];sid=sid if len(sid)<=19 else sid[:18]+'…';draw.text((x+7,y+82),sid,font=small,fill='#becadd')
 return im
all_ids=sorted(reg);pages=[]
for i in range(0,len(all_ids),80):
 im=sheet(all_ids[i:i+80],f'追加した通貨絵文字 {i//80+1} ／ {math.ceil(len(all_ids)/80)}');im.save(args.output/f'currency_glyphs_{i//80+1:02}.png');pages.append(im)
examples=['white_dye','red_dye','blue_dye','black_dye','cyan_dye','lime_dye','cow_spawn_egg','pig_spawn_egg','creeper_spawn_egg','allay_spawn_egg','axolotl_spawn_egg','frog_spawn_egg','andesite_slab','andesite_stairs','cobblestone_slab','blackstone_stairs','netherite_upgrade_smithing_template','diamond_spear','empty_map','filled_map','command_block','chain_command_block','end_portal_frame','farmland','music_disc_bounce','brick_stairs','gray_dye','yellow_dye','golden_rail','creeper_banner_pattern']
ids=['minecraft:'+x for x in examples if 'minecraft:'+x in reg];preview=sheet(ids,'追加した通貨絵文字の一部',cols=6);preview.save(args.output/'currency_glyphs_preview.png')
pages[0].save(args.output/'currency_glyphs_all.pdf',save_all=True,append_images=pages[1:],resolution=130)
print('Preview glyph IDs:',len(all_ids),'pages:',len(pages))
