const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
require('./test_heart_shop.cjs');
const {run}=require('./test_smelt_sales.cjs');
const ui=JSON.parse(fs.readFileSync(path.join(__dirname,'../resource_pack/ui/data_driven_container_screen.json'),'utf8'));
let count=0;
function test(name,fn){fn();count++;console.log('PASS HEART UI '+name);}
function visit(value,fn,parent=null,key=''){
 if(Array.isArray(value)){for(const x of value)visit(x,fn,parent,key);return;}
 if(!value||typeof value!=='object')return;
 fn(value,parent,key);
 for(const [k,x]of Object.entries(value)){
  if(k==='controls'){for(const entry of x)for(const [name,node]of Object.entries(entry))visit(node,fn,value,name);}
 }
}
const root=ui.heart_type_dd_unit;
const stack=ui.settings_scroll_content.controls[0].settings_scroll_stack.controls;
const heart=stack.find(x=>x.heart_payment).heart_payment;
test('every dropdown state and native click gets a fresh container collection scope',()=>{
 let indices=0;
 visit(root,(node,parent)=>{
  if(node.collection_index===undefined)return;
  assert.equal(parent?.collection_name,'container_items',`index ${node.collection_index} must be a direct collection child`);indices++;
 });
 assert.equal(indices,32); // 12 labels + header + open state + 3 pages + 15 native rows
});
test('all twelve choices and next-page clicks use independent momentary auto-place buttons',()=>{
 for(let page=0;page<3;page++)for(let row=0;row<5;row++){
  const b=ui[`heart_type_choice_${page}_${row}@common.radio_toggle`];assert.equal(b.$radio_toggle_group,false);
  for(const input of ['button.menu_select','button.menu_ok','button.controller_select'])assert.ok(b.button_mappings.some(x=>x.from_button_id===input&&x.to_button_id==='button.container_auto_place'));
 }
});
test('dropdown click rows cover the following input bars and use the shared choice slots',()=>{
 const source=root.controls.find(x=>x.dropdown_state).dropdown_state;assert.ok(source.layer>=160);
 const opened=source.controls[0].opened;
 for(let p=0;p<3;p++){
  const page=opened.controls[p][`page_source_${p}`].controls[0].page;
  const rows=page.controls.filter(x=>/^row_/.test(Object.keys(x)[0]));assert.equal(rows.length,5);
  for(let row=0;row<5;row++){
   const n=rows[row][`row_${row}`];assert.equal(n.collection_name,'container_items');assert.ok(n.layer>=220);
   assert.deepEqual(n.offset,[2,2+row*24]);assert.equal(n.controls[0]['slot@common.container_item'].collection_index,27+row);
  }
 }
});
test('closed input labels read their own named headers continuously, never shared weekday slots',()=>{
 const found=new Set();
 visit(heart,(node,parent,key)=>{
  if(!key.endsWith('_saved_overlay_text'))return;
  assert.ok(key.startsWith('heart_'));
  const field=key.startsWith('heart_duration')?'heart_duration':'heart_level';found.add(field);
  assert.equal(node.collection_index,field==='heart_duration'?200:199);
  for(const b of node.bindings)assert.equal(b.binding_condition,'always');
 });
 assert.deepEqual([...found].sort(),['heart_duration','heart_level']);
});
test('duration input and the opened keypad both use the four-digit clock renderer',()=>{
 let inline=0,pads=0;
 visit(heart,(_,parent,key)=>{
  if(key.startsWith('digits@data_driven_container.heart_clock_digit_text'))inline++;
  if(key==='kp_open_heart_duration@data_driven_container.heart_clock_pad_open')pads++;
 });
 assert.equal(inline,1);assert.equal(pads,1);
 let clockDigits=0;visit(ui.heart_clock_digit_text,node=>{if([214,215,216,217].includes(node.collection_index))clockDigits++;});assert.equal(clockDigits,40);
 assert.deepEqual(ui.heart_clock_pad_open.size,[150,'100%c']);
});
test('visible and clicked field headers always have the formatted value as their item name',()=>{
 run(`saveDropdownChoice(block,DROPDOWN_BY_ID.get('heart_type'),5);setStringProp(block,'heart_level','2');setStringProp(block,'heart_duration','1530');kpReset(rec);kpWriteAll(shopInv,block,rec,player);`);
 assert.equal(run(`shopInv.getItem(199).nameTag`),'2');assert.equal(run(`shopInv.getItem(200).nameTag`),'15:30');
 run(`kpOpen(rec,block,KP_BY_ID.get('heart_duration'));rec.kpBuf='3000';kpStore(rec,block);kpWriteAll(shopInv,block,rec,player)`);
 assert.equal(run(`shopInv.getItem(200).nameTag`),'30:00');assert.equal(run(`shopInv.getItem(200).amount`),2);
 run(`kpClose(player,rec,block,shopInv);finishHeartVisual();`);
 assert.equal(run(`shopInv.getItem(200).nameTag`),'30:00');assert.equal(run(`shopInv.getItem(200).amount`),3);
});
test('UI control inheritance resolves for every new heart component',()=>{
 const definitions=new Set(Object.keys(ui).map(k=>k.split('@')[0]));
 visit(heart,(node,_,key)=>{
  if(key.includes('@data_driven_container.'))assert.ok(definitions.has(key.split('@data_driven_container.')[1]),key);
 });
});
console.log(`${count} heart UI test groups passed; ${104+count} total test groups passed (API simulation and UI structure; Minecraft rendering not executed)`);
