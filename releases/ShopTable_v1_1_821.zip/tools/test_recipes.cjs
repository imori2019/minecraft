// v1.1.796 ショップテーブルのレシピ：上 ガラス・ドロッパー・ガラス／中 ガラス・オブサーバー・ガラス／下 そのブロック×3
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');const {run}=require('./test_smelt_sales.cjs');
const dir=path.join(__dirname,'../behavior_pack/recipes');let n=0;
const items=fs.readdirSync(path.join(__dirname,'../behavior_pack/items')).filter(f=>f.startsWith('panel')).map(f=>'shopuilook2:'+f.replace('.json',''));
const recs=fs.readdirSync(dir).map(f=>JSON.parse(fs.readFileSync(path.join(dir,f),'utf8'))['minecraft:recipe_shaped']).filter(r=>r&&String(r.result.item).startsWith('shopuilook2:panel'));
for(const id of items){const r=recs.filter(x=>x.result.item===id);assert.equal(r.length,1,'one recipe for '+id);const x=r[0];
 assert.deepEqual(x.pattern,['GDG','GOG','XXX']);assert.equal(x.key.G.item,'minecraft:glass');assert.equal(x.key.D.item,'minecraft:dropper');assert.equal(x.key.O.item,'minecraft:observer');
 assert.ok(/^minecraft:/.test(x.key.X.item));assert.deepEqual(x.tags,['crafting_table']);n++;}
const std=JSON.parse(run('JSON.stringify(SH_STANDARD_SHOPS.map(s=>[s.id,s.source]))'));
for(const [id,src] of std)assert.equal(recs.find(r=>r.result.item===id).key.X.item,src,'standard shop uses its own block '+id);
const bottoms=recs.map(r=>r.key.X.item);assert.equal(new Set(bottoms).size,bottoms.length,'every shop has a different bottom block');
assert.equal(recs.find(r=>r.result.item==='shopuilook2:panel_fletch').key.X.item,'minecraft:cauldron');
console.log('PASS RECIPES '+n+' shop recipes (glass / dropper / observer + the shop block x3)');
