// v1.1.780 大釜（前の矢細工台）：種類ごとの欄・前のデータの並べ直し・無限の弓・見た目
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');const {run,prep}=require('./test_smelt_sales.cjs');
let n=0;const test=(name,fn)=>{fn();n++;console.log('PASS CAULDRON '+name);};
const J=f=>JSON.parse(fs.readFileSync(path.join(__dirname,'..',f),'utf8'));
const mats=()=>JSON.parse(run('JSON.stringify(crState(registry.stores.s1,"fletch").mats)'));
test('v817: water 4, arrows 4 at 4-7, bottles 9 at 27-35, unused 8, blaze 9, materials 54',()=>{
 for(let i=0;i<81;i++){const water=i<4,bottle=i>=27&&i<36,blaze=i>=9&&i<18,arrow=i>=4&&i<8,free=i!==8&&!water&&!bottle&&!blaze&&!arrow;
  assert.equal(run(`flSlotOk(${i},'minecraft:water_bucket')`),water||free,'water '+i);
  assert.equal(run(`flSlotOk(${i},'minecraft:glass_bottle')`),bottle||free,'bottle '+i);
  assert.equal(run(`flSlotOk(${i},'minecraft:blaze_powder')`),blaze||free,'blaze '+i);
  assert.equal(run(`flSlotOk(${i},'minecraft:arrow')`),arrow||free,'arrow '+i);
  assert.equal(run(`flSlotOk(${i},'minecraft:feather')`),free,'feather '+i);}
 assert.equal(JSON.parse(run('JSON.stringify([...Array(81).keys()].filter(flIsMat))')).length,54);
});
test('opening the screen moves things out of slots that no longer take them (into free material slots)',()=>{
 prep();run(`block.typeId='shopuilook2:panel_fletch';const m=Array(81).fill(null);m[0]={id:'minecraft:sugar',n:3};m[5]={id:'minecraft:glass_bottle',n:16};m[1]={id:'minecraft:water_bucket',n:1};
  registry.stores.s1.fletch={auto:true,flv:2,mats:m,made:0};globalThis.smx={storeId:'s1',fzKind:'fletch',block};crEnter(player,smx,shopInv,registry.stores.s1);`);
 const m=mats();const at=id=>m.findIndex(x=>x?.id===id);
 assert.equal(at('minecraft:water_bucket'),1);assert.ok(run(`flIsMat(${at('minecraft:sugar')})`));
 const b=at('minecraft:glass_bottle');assert.ok(b>=27&&b<36,'v817: glass bottles move to the lower bottle slots');assert.equal(m.filter(Boolean).length,3,'nothing lost');
});
test('old fletching data is re-sorted into the groups without losing anything',()=>{
 prep();run(`const m=Array(81).fill(null);m[0]={id:'minecraft:glass_bottle',n:16};m[1]={id:'minecraft:nether_wart',n:20};m[2]={id:'minecraft:water_bucket',n:1};m[3]={id:'minecraft:water_bucket',n:1};
  m[54]={id:'minecraft:arrow',n:64};m[55]={id:'minecraft:feather',n:10};m[10]={id:'minecraft:sugar',n:5};registry.stores.s1.fletch={auto:true,mats:m,made:0};`);
 const c=JSON.parse(run(`JSON.stringify(crState(registry.stores.s1,'fletch'))`));
 assert.equal(c.flv,3);
 const at=id=>c.mats.findIndex(x=>x?.id===id);
 for(const id of ['minecraft:water_bucket','minecraft:glass_bottle','minecraft:nether_wart'])assert.ok(at(id)>=0&&!(at(id)>=4&&at(id)<8),id);
 assert.ok(at('minecraft:arrow')>=4&&at('minecraft:arrow')<8);assert.ok(!(at('minecraft:feather')>=4&&at('minecraft:feather')<8));
 assert.equal(c.mats.filter(Boolean).length,7,'nothing lost');
 assert.equal(JSON.stringify(JSON.parse(run(`JSON.stringify(crState({fletch:${JSON.stringify(c)}},'fletch'))`)).mats),JSON.stringify(c.mats),'already sorted data is kept as is');
});
test('an infinity bow keeps the arrow slots full; arrow products are stocked from them',()=>{
 prep();run(`block.typeId='shopuilook2:panel_fletch';saveProductIndex(block,['a1']);
  saveProduct(block,{id:'a1',savedOnce:true,settings:{shop_sale_type:0},items:[{id:'minecraft:arrow',key:'minecraft:arrow',role:'sample',slot:17,count:1}],stock:[{slot:0,item:{id:'minecraft:arrow',amount:1}}]});
  const m=Array(81).fill(null);m[40]={id:'minecraft:bow',n:1,snap:{id:'minecraft:bow',amount:1,enchantments:[{id:'minecraft:infinity',level:1}]}};
  registry.stores.s1.fletch={auto:true,flv:2,mats:m,made:0};crCraft(block);`);
 assert.equal(run(`fzStockCountPlain(loadProduct(block,'a1'),'minecraft:arrow')`),64,'arrow product filled to 64 from the arrow slots');
 const m=mats();for(let i=4;i<8;i++)assert.deepEqual(m[i],{id:'minecraft:arrow',n:64},'arrow slot '+i+' refilled');
 assert.equal(m[40].id,'minecraft:bow','the bow stays');
 // 弓が無ければ、使った分は減ったまま
 run(`registry.stores.s1.fletch.mats[40]=null;(()=>{const r=loadProduct(block,'a1');r.stock=[];saveProduct(block,r)})();crCraft(block);`);
 const total=mats().slice(4,8).reduce((a,x)=>a+(x?.n??0),0);assert.equal(total,4*64-64);
 assert.equal(run(`flHasInfinity({mats:[{id:'minecraft:bow',n:1,snap:{enchantments:[{id:'minecraft:power',level:5}]}}]})`),false);
});
test('the owner screen shows the groups on the right side with faint item pictures, inside the screen',()=>{
 const ui=J('resource_pack/ui/shop_proceeds_screen.json');
 const find=(o,k)=>{if(!o||typeof o!=='object')return;for(const[kk,v]of Object.entries(o)){if(kk.split('@')[0]===k)return v;const r=find(v,k);if(r)return r;}};
 const pen=find(ui,'fletch_pen');const by=Object.assign({},...pen.controls);
 const SL=JSON.parse(run('JSON.stringify(crSlots("fletch"))'));
 for(let i=0;i<81;i++){const v=by['fl_m'+i];if(i===8){assert.equal(v,undefined,'unused slot is hidden');continue;}assert.ok(v,'slot '+i);const item=Object.entries(Object.assign({},...v.controls)).find(([k])=>k.includes('container_item'))[1];assert.equal(item.collection_index,SL[i]);
  assert.ok(v.offset[0]>=189&&v.offset[0]+18<=358&&v.offset[1]+18<=252);
  /* v793: no ghost pictures; v816: numbered placeholders only */assert.ok(!JSON.stringify(v.controls).includes('ghost'),'no picture '+i);}
 assert.equal(by.cr_title.text,'大釜');
 assert.equal(by.fl_l_water.text,'水バケツ');assert.equal(by.fl_l_bottle.text,'ガラス瓶');assert.equal(by.fl_l_blaze.text,'ブレイズパウダー');assert.equal(by.fl_l_arrow.text,'矢');for(let i=0;i<8;i++)assert.equal(by['fl_m'+i].offset[1],54);for(let i=9;i<18;i++)assert.equal(by['fl_m'+i].offset[1],81);for(let i=27;i<36;i++)assert.equal(by['fl_m'+i].offset[1],108);
});
test('the liquid is its own see-through material (blend) with a non-water colour; only the liquid uses it',()=>{
 const b=J('behavior_pack/blocks/panel_fletch.json')['minecraft:block'].components;
 assert.equal(b['minecraft:material_instances'].liquid.render_method,'blend');assert.equal(b['minecraft:material_instances']['*'].render_method,'alpha_test');
 const g=J('resource_pack/models/blocks/cauldron_shop.geo.json')['minecraft:geometry'].find(x=>x.description.identifier.endsWith('_lower'));
 const liq=g.bones.flatMap(b=>b.cubes).flatMap(c=>Object.values(c.uv)).filter(u=>u.material_instance==='liquid');assert.equal(liq.length,2);
 assert.equal(J('behavior_pack/blocks/panel_fletch.json')['minecraft:block'].components['minecraft:display_name'],'ショップテーブル（大釜）');
});
test('an infinity bow placed in an "other" slot is kept with its enchantment; in an arrow slot it is returned',()=>{
 prep();run(`block.typeId='shopuilook2:panel_fletch';registry.stores.s1.fletch={auto:true,flv:2,mats:Array(81).fill(null),made:0};
  globalThis.cont={slots:new Map(),getItem(i){return this.slots.get(i);},setItem(i,v){if(v)this.slots.set(i,v);else this.slots.delete(i);}};
  globalThis.mkBow=()=>{const b=new ItemStack('minecraft:bow',1);b.getComponent('minecraft:enchantable').addEnchantment({type:{id:'minecraft:infinity'},level:1});return b;};
  cont.setItem(crSlots('fletch')[40],mkBow());cont.setItem(crSlots('fletch')[5],mkBow());
  globalThis.smf={storeId:'s1',fzKind:'fletch',crKey:''};crSync(player,smf,cont);`);
 const m=mats();assert.equal(m[40].id,'minecraft:bow');assert.equal(m[5],null);
 assert.equal(run(`flHasInfinity(registry.stores.s1.fletch)`),true);
});
console.log(n+' cauldron test groups passed (API simulation; Minecraft renderer not executed)');
