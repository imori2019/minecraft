"""Asset integrity checks; Minecraft rendering/audio playback are not simulated."""
from pathlib import Path
import json,hashlib
r=Path(__file__).resolve().parents[1]
d=json.loads((r/'tools/shop_assets728.json').read_text())
overrides=json.loads((r/'tools/shop_assets743.json').read_text())
expected_assets={**d['asset_sha256'],**overrides['asset_sha256']}
for name,expected in expected_assets.items():
 assert hashlib.sha256((r/name).read_bytes()).hexdigest()==expected,name
assert len(d['models'])==27
sounds=json.loads((r/'resource_pack/sounds/sound_definitions.json').read_text())['sound_definitions']
assert len(sounds)==21
for key,path in d['music'].items():
 event=sounds['shopuilook2.music.'+key]
 assert event['category']=='music'
 assert len(event['sounds'])==1
 assert event['sounds'][0]['name']=='sounds/music/'+path
 assert event['sounds'][0]['stream'] is True
for variant in ['bulb','bulb_exposed','bulb_weathered','bulb_oxidized']:
 for suffix in ['', '_case']:
  b=json.loads((r/f'behavior_pack/blocks/panel_{variant}{suffix}.json').read_text())['minecraft:block']
  assert b['description']['states']['shopuilook2:lit']==[False,True]
  assert any('shopuilook2:lit' in p['condition'] and p['components']['minecraft:material_instances']['*']['texture']==f'shopuilook2_{variant}_shop_lit' for p in b['permutations'])
print('PASS model/texture assets match the original and v743 replacement hashes; 21 supplied inventory icons are unchanged')
print('PASS 21 exact-track music definitions and all copper lit/off block/case permutations')
