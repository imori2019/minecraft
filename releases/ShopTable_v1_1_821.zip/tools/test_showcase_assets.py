#!/usr/bin/env python3
"""Tests packaged block images, fixed UVs and sprite extrusion silhouettes; requires Pillow."""
from pathlib import Path
import json,re
from PIL import Image
R=Path(__file__).resolve().parents[1];s=(R/'behavior_pack/scripts/showcase_visuals.js').read_text()
def data(name):return json.loads(re.search(r'export const '+name+r' = (.*?);',s).group(1))
blocks=data('SC_BLOCK_VISUALS');info=data('SC_DISPLAY_INFO')
entity=json.loads((R/'resource_pack/entity/showcase_display.entity.json').read_text())['minecraft:client_entity']['description']
rc=json.loads((R/'resource_pack/render_controllers/showcase_item.render_controllers.json').read_text())['render_controllers']['controller.render.shopuilook2.showcase_model']
assert 'uv_anim' not in rc
assert not (R/'resource_pack/textures/shopuilook2/showcase/blocks.png').exists()
paths=[entity['textures'][n.replace('Texture.','')] for n in rc['arrays']['textures']['Array.images']]
images={}
for index in {b[0] for b in blocks.values()}:
 p=R/'resource_pack'/(paths[index]+'.png');im=Image.open(p).convert('RGBA');assert im.size==(64,64);images[index]=im
assert len(images)==info['block_textures']
print('PASS ASSETS every block references a standalone 64x64 image, with no atlas crop')
faces=['north','south','east','west','up','down']
def face(id,f):
 im=images[blocks['minecraft:'+id][0]];i=faces.index(f);x=3+i%3*20;y=3+i//3*20;return im.crop((x,y,x+16,y+16))
for f in faces:assert face('grass_block',f).getchannel('A').getextrema()==(255,255)
r,g,b,a=face('grass_block','north').getpixel((5,12));assert r>g>b and a==255
r,g,b,a=face('grass_block','up').getpixel((5,12));assert g>r and g>b
print('PASS ASSETS grass sides include opaque soil and a green top')
assert face('oak_log','up').tobytes()!=face('oak_log','north').tobytes()
assert face('furnace','south').tobytes()!=face('furnace','north').tobytes()
assert face('stone','up').tobytes()==face('stone','north').tobytes()
print('PASS ASSETS logs, furnaces and stone preserve their correct face assignments')
for im in images.values():
 for i in range(6):
  x=2+i%3*20;y=2+i//3*20
  for n in range(16):
   assert im.getpixel((x+1+n,y))==im.getpixel((x+1+n,y+1))
   assert im.getpixel((x+1+n,y+17))==im.getpixel((x+1+n,y+16))
   assert im.getpixel((x,y+1+n))==im.getpixel((x+1,y+1+n))
   assert im.getpixel((x+17,y+1+n))==im.getpixel((x+16,y+1+n))
print('PASS ASSETS standalone face images have matching edge gutters')
geos=json.loads((R/'resource_pack/models/entity/showcase_item.geo.json').read_text())['minecraft:geometry']
for g in geos:
 for bone in g['bones']:
  for cube in bone.get('cubes',[]):
   for uv in cube['uv'].values():
    for i,limit in [(0,g['description']['texture_width']),(1,g['description']['texture_height'])]:
     a=uv['uv'][i];b=a+uv['uv_size'][i];assert 0<=min(a,b)<=max(a,b)<=limit
print('PASS ASSETS all fixed UVs stay within the actual texture dimensions')
# Trace an exactly side-on ray through the authored west-facing walls. It must
# hit the first opaque sprite column, and miss rows outside the sprite entirely.
flat=geos[0];cubes=next(b for b in flat['bones'] if b['name']=='display')['cubes'];grid=info['extrusion_grid'];unit=10/grid
walls=sorted((c for c in cubes if 'west' in c['uv']),key=lambda c:c['origin'][0])
assert len(walls)==grid
for name in ['apple','diamond_sword','raw_porkchop','lava_bucket']:
 icon=Image.open(R/'resource_pack/textures/shop_icons'/(name+'.png')).convert('RGBA');mask=icon.resize((grid,grid),Image.Resampling.NEAREST)
 for row in range(grid):
  columns=[col for col in range(grid) if mask.getpixel((col,row))[3]>0]
  hit=None
  for wall in walls:
   uv=wall['uv']['west'];u=uv['uv'][0]+uv['uv_size'][0]/2
   v=uv['uv'][1]+uv['uv_size'][1]*(row+.5)/grid
   x=min(icon.width-1,int(u/16*icon.width));y=min(icon.height-1,int(v/16*icon.height))
   if icon.getpixel((x,y))[3]>0:hit=wall['origin'][0];break
  if columns:assert hit is not None and abs(hit-(-5+columns[0]*unit))<1e-9,(name,row)
  else:assert hit is None,(name,row,'transparent sprite row became a solid side')
print('PASS ASSETS side-on item silhouettes follow opaque pixels and preserve transparent gaps')
print('6 showcase asset checks passed (pixels, geometry and side-ray simulation; no Minecraft rendering)')
