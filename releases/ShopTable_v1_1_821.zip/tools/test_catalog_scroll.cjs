const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const env=require('./test_smelt_sales.cjs');const {run,ctx,Container,prep}=env;
const read=p=>String(p).endsWith('shop_layout_price.json')?require('./read_price_ui.cjs')():(JSON.parse(fs.readFileSync(path.join(__dirname,'..',p),'utf8')));
let n=0;function test(name,fn){fn();n++;console.log('PASS CATALOG '+name);}
function reset(count,genres=1){ctx.shopInv=new Container(640);prep();run(`block.typeId='shopuilook2:panel';SHOP_BAKE_ON.clear();active.clear();PANEL_OCCUPANTS.clear();
 registry.stores.s1.departments=[{id:'d1',name:'商品売り場'},{id:'d2',name:'別の売り場'}];
 const list=Array.from({length:${count}},(_,i)=>{const p=base('catalog'+i,'minecraft:apple');p.settings.shop_product_genre='ジャンル'+(i%${genres});return p;});putProducts(list);
 globalThis.catalogMode={player,floorId:'d1',history:false,bakeOn:false,rowWindowIndex:0};`);}
test('27 products in one or many genres fit in one uninterrupted scroll window',()=>{
 for(const genres of [1,3,9,27]){
  reset(27,genres);run('globalThis.catalogModel=shopModel(catalogMode,block,registry.stores.s1)');
  assert.equal(run('catalogModel.rows.flatMap(r=>r.ids).length'),27);assert.equal(run('catalogModel.rowWindowCount'),1);assert.equal(run('catalogModel.hasMoreRows'),false);
 }
});
test('actual buyer rendering publishes every product and both price rows, including slots above 255',()=>{
 reset(27,27);run(`globalThis.catalogRec={};enterShopMode(player,catalogRec,block,shopInv)`);
 assert.equal(run('catalogRec.shopMode.cells.size'),27);
 assert.equal(run('shopInv.getItem(89)'),undefined);assert.equal(run('shopInv.getItem(90)'),undefined,'ordinary catalogue has no continuation control');
 assert.ok(run('[...catalogRec.shopMode.cells.keys()].some(slot=>slot>255)'));
 for(let row=0;row<27;row++){
  assert.equal(run(`catalogRec.shopMode.cells.get(shSlots(${row}).cell[0])`),'catalog'+row);
  assert.ok(run(`shopInv.getItem(shSlots(${row}).price[0])?.nameTag.length>0`));
 }
});
test('an expanded-row product opens its own purchase confirmation',()=>{
 reset(27,27);run(`globalThis.catalogRec={};enterShopMode(player,catalogRec,block,shopInv);system.currentTick+=30;
  catalogRec.pendingVisual=null;catalogRec.shopMode.initialTextRebindTick=0;
  shopInv.setItem(shSlots(26).cell[0],undefined);tickShopMode(player,catalogRec,block,shopInv);`);
 assert.equal(run('catalogRec.shopMode.confirm?.id'),'catalog26');
});
test('an exceptionally large catalogue keeps every product reachable via the bottom continuation controls',()=>{
 reset(82,1);run(`globalThis.one=shopModel(catalogMode,block,registry.stores.s1);catalogMode.rowWindowIndex=1;globalThis.two=shopModel(catalogMode,block,registry.stores.s1)`);
 assert.equal(run('one.rows.flatMap(r=>r.ids).length'),81);assert.equal(run('two.rows.flatMap(r=>r.ids).length'),1);
 assert.equal(new Set(JSON.parse(run('JSON.stringify([...one.rows,...two.rows].flatMap(r=>r.ids))'))).size,82);
});
test('native UI rows use their own slots and variables; product-list angle arrows are absent',()=>{
 const ui=read('resource_pack/ui/shop_layout_price.json'),content=ui.sh_content.controls;
 const framework=new Set(['#text','#font_type','#hover_text','#inventory_stack_count','#visible','#ignored','#enabled','#is_selected']);const all=new Set();
 for(let row=0;row<27;row++)for(const suffix of ['', '_continuation']){
  const k='sh_row'+row+suffix,g=content.find(x=>x[k])[k];assert.equal(g.collection_index,run(`shSlots(${row}).title`));
  assert.ok(g.controls.every(x=>!('prev'in x)&&!('next'in x)));
  for(let c=0;c<3;c++){
   const box=g.controls.find(x=>x[`pbox_${row}_${c}`])[`pbox_${row}_${c}`];
   const first=Object.values(box.controls[0])[0],second=Object.values(box.controls[1])[0];
   const labels=[];function walk(o){if(!o||typeof o!=='object')return;if(o.type==='label'&&o.bindings?.some(b=>b.binding_name==='#hover_text'))labels.push(o);Object.values(o).forEach(walk);}walk(first);
   assert.ok(labels.some(x=>x.collection_index===run(`shSlots(${row}).price[${c}]`)));
   const secondLabels=[];const expected=run(`[shSlots(${row}).price[3],shSlots(${row}).cell[3],shSlots(${row}).set[3]][${c}]`);function slots(o){if(!o||typeof o!=='object')return;if(o.type==='label')secondLabels.push(o.collection_index);Object.values(o).forEach(slots);}slots(second);assert.ok(secondLabels.includes(expected));
  }
  if(!suffix){const vars=new Set((JSON.stringify(g).match(/#[A-Za-z_][A-Za-z0-9_]*/g)||[]).filter(v=>!framework.has(v)));for(const v of vars){assert.ok(!all.has(v),'shared cross-row property '+v);all.add(v);}}
 }
 assert.ok(content.some(x=>x.catalog_more));
 assert.equal(read('behavior_pack/entities/panel_ui.json')['minecraft:entity'].components['minecraft:inventory'].inventory_size,640);
});
test('legacy actors retain a bounded working catalogue until their inventory can be grown',()=>{
 reset(27,27);ctx.shopInv=new Container(256);run('globalThis.legacyModel=shopModel(catalogMode,block,registry.stores.s1)');assert.equal(run('legacyModel.rows.length'),5);assert.equal(run('legacyModel.rowWindowCount'),6);
});
console.log(n+' catalogue scroll tests passed (API and UI simulation; no Minecraft runtime)');
