// Test-only evaluator of JSON UI string subtraction, preserving parentheses.
module.exports=function evaluate(expression,state={}){
 const tokens=expression.match(/'(?:\\.|[^'\\])*'|#[A-Za-z_][A-Za-z0-9_]*|[()\-]/g)||[];let i=0;
 function atom(){const token=tokens[i++];if(token==='('){const result=expr();if(tokens[i++]!==')')throw Error('unbalanced price expression');return result;}if(token?.startsWith("'"))return token.slice(1,-1).replace(/\\u([0-9a-f]{4})/gi,(_,hex)=>String.fromCharCode(parseInt(hex,16)));if(token?.startsWith('#'))return String(state[token]??'');throw Error('unsupported price token '+token);}
 function expr(){let value=atom();while(tokens[i]==='-'){i++;const remove=atom();if(remove)value=value.split(remove).join('');}return value;}
 const result=expr();if(i!==tokens.length)throw Error('unconsumed price expression');return result;
};
