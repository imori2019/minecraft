#!/usr/bin/env python3
"""Build centered showcase meshes and independent block textures from a pinned bedrock-samples checkout.
Usage: python tools/build_showcase_assets.py --vanilla-root /path/to/bedrock-samples
Requires Pillow. No hand rendering or native held-item transforms are used.
"""
from pathlib import Path
import argparse,json,re,hashlib,subprocess
from PIL import Image
ROOT=Path(__file__).resolve().parents[1]
PARSER=argparse.ArgumentParser();PARSER.add_argument('--vanilla-root',type=Path,required=True);args=PARSER.parse_args();V=args.vanilla_root
PIN='15701fa9c13923f12662984c32c124327e40e3d3'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=V,text=True).strip()==PIN, 'Check out the pinned bedrock-samples commit first'
def pixels(im):
 return im.get_flattened_data() if hasattr(im,'get_flattened_data') else im.getdata()
def read(p):return json.loads(re.sub(r'^\s*//.*$','',p.read_text(encoding='utf-8-sig'),flags=re.M))
def write(p,d):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
blocks=read(V/'resource_pack/blocks.json');terrain=read(V/'resource_pack/textures/terrain_texture.json')['texture_data'];items=read(V/'resource_pack/textures/item_texture.json')['texture_data'];meta=read(V/'metadata/vanilladata_modules/mojang-items.json')['data_items']
# Only known solid families are cubes; plants and special models never become arbitrary cubes.
SOLIDS=set('stone granite diorite andesite deepslate cobbled_deepslate tuff calcite dripstone_block dirt coarse_dirt rooted_dirt grass grass_block podzol mycelium sand red_sand gravel clay mud packed_mud bedrock obsidian crying_obsidian netherrack soul_sand soul_soil end_stone cobblestone mossy_cobblestone blackstone basalt smooth_basalt polished_basalt terracotta hardened_clay glass tinted_glass ice packed_ice blue_ice snow snow_block sponge wet_sponge melon_block melon pumpkin carved_pumpkin lit_pumpkin jack_o_lantern hay_block dried_kelp_block moss_block pale_moss_block honey_block honeycomb_block slime slime_block glowstone sea_lantern shroomlight pearlescent_froglight ochre_froglight verdant_froglight prismarine dark_prismarine prismarine_bricks bookshelf chiseled_bookshelf furnace lit_furnace blast_furnace lit_blast_furnace smoker lit_smoker dispenser dropper observer crafting_table fletching_table cartography_table smithing_table loom barrel jukebox noteblock note_block target redstone_lamp lit_redstone_lamp respawn_anchor lodestone enchanting_table enchantment_table crafter reinforced_deepslate cactus dried_ghast'.split())
# Non-full shapes listed in SOLIDS by accident would be wrong; render their inventory image instead.
SOLIDS-={'enchanting_table','enchantment_table','cactus','dried_ghast'}
SOLIDS.update('ancient_debris gilded_blackstone purpur_pillar quartz_pillar bricks magma magma_block sculk tnt mob_spawner spawner beehive bee_nest jigsaw muddy_mangrove_roots mangrove_roots frosted_ice suspicious_sand suspicious_gravel dirt_with_roots azalea_leaves_flowered'.split())
FAMILY=re.compile(r'(?:_log|_wood|_planks|_stem|_hyphae|_ore|_block|_bricks|_brick|_sandstone|_basalt|_nylium|_wool|_concrete|_concrete_powder|_terracotta|_shulker_box|_leaves|_stained_glass|_stone|_copper|_grate|_bulb)$')
PREFIX=re.compile(r'^(?:smooth_|polished_|chiseled_|cracked_|mossy_|infested_|waxed_|exposed_|weathered_|oxidized_|cut_)+')
def shape(n):
 if n.endswith('_double_slab'):return 1
 if n.endswith('_stairs'):return 3
 if n.endswith('_slab'):return 2
 if n.endswith('_carpet') or n=='carpet':return 4
 if n.endswith('_trapdoor') or n=='trapdoor':return 5
 if n in SOLIDS or FAMILY.search(n) or PREFIX.sub('',n) in SOLIDS:return 1
 return 0
FACES=['north','south','east','west','up','down'];FACE_POS={f:(2+20*(i%3),2+20*(i//3)) for i,f in enumerate(FACES)}
def tex_path(spec):
 while isinstance(spec,list):spec=spec[0]
 if isinstance(spec,str):return spec,None
 if isinstance(spec,dict):return spec.get('path'),spec.get('overlay_color') or spec.get('tint_color')
 return None,None
cache={}
def face_image(key,block):
 desc=terrain.get(key,{});p,col=tex_path(desc.get('textures'))
 if not p:raise ValueError(key)
 # grass_side.tga uses alpha as a tint mask for the engine's terrain shader.
 # A normal entity shader needs the complete, opaque carried-side image instead.
 if p=='textures/blocks/grass_side':p='textures/blocks/grass_side_carried';col=None
 cachekey=(p,col,'leaves' in block)
 if cachekey in cache:return cache[cachekey].copy()
 path=V/'resource_pack'/p
 path=next((path.with_suffix(e) for e in ['.png','.tga'] if path.with_suffix(e).exists()),None)
 if path is None:raise FileNotFoundError(p)
 im=Image.open(path).convert('RGBA');w,h=im.size
 if h>w:im=im.crop((0,0,w,w)) # first animation frame
 im=im.resize((16,16),Image.Resampling.NEAREST)
 # Carried leaf/grass textures have biome-colored grayscale portions.
 tint=col or ('#79a950' if 'leaves' in block else None)
 if tint:
  try:rgb=tuple(int(tint.lstrip('#')[-6:][i:i+2],16) for i in [0,2,4])
  except ValueError:rgb=None
  if rgb:
   data=[]
   for rr,gg,bb,aa in pixels(im):
    if max(rr,gg,bb)-min(rr,gg,bb)<14:data.append((rr*rgb[0]//255,gg*rgb[1]//255,bb*rgb[2]//255,aa))
    else:data.append((rr,gg,bb,aa))
   im.putdata(data)
 cache[cachekey]=im.copy();return im
entries=[];skipped=[]
for name,d in sorted(blocks.items()):
 sh=shape(name)
 if not sh:continue
 ts=d.get('carried_textures',d.get('textures'))
 if not ts:continue
 try:
  faces={f:face_image(ts if isinstance(ts,str) else ts.get(f,ts.get('side')),name) for f in FACES}
  alpha=int(any(any(0<a<255 for a in pixels(im.getchannel('A'))) for im in faces.values()))
  entries.append((name,sh,alpha,faces))
 except (ValueError,FileNotFoundError,KeyError,TypeError) as e:skipped.append([name,str(e)])
# Each renderer samples a standalone 64x64 block image with fixed face UVs.
# Dynamic uv_anim transforms are intentionally not used: the normal entity shader
# did not apply that crop reliably in-game (v713 showed unrelated atlas cells).
blockmap={};block_images=[];image_index={}
output_dir=ROOT/'resource_pack/textures/shopuilook2/showcase/blocks'
output_dir.mkdir(parents=True,exist_ok=True)
# These are generated assets only. Clear files left by earlier generator runs.
for old in output_dir.glob('b[0-9][0-9][0-9][0-9].png'):old.unlink()
for name,sh,alpha,faces in entries:
 image=Image.new('RGBA',(64,64))
 for f,im in faces.items():
  x,y=FACE_POS[f];image.paste(im,(x+1,y+1))
  image.paste(im.crop((0,0,16,1)),(x+1,y));image.paste(im.crop((0,15,16,16)),(x+1,y+17))
  image.paste(im.crop((0,0,1,16)),(x,y+1));image.paste(im.crop((15,0,16,16)),(x+17,y+1))
 digest=hashlib.sha256(image.tobytes()).hexdigest()
 if digest not in image_index:
  i=len(block_images);image_index[digest]=i
  path='textures/shopuilook2/showcase/blocks/b'+str(i).zfill(4)
  image.save(ROOT/'resource_pack'/(path+'.png'),optimize=True)
  block_images.append(path)
 blockmap['minecraft:'+name]=[image_index[digest],sh,alpha]
for alias,original in {'grass_block':'grass','oak_trapdoor':'trapdoor','dirt_with_roots':'rooted_dirt'}.items():
 if 'minecraft:'+original in blockmap:blockmap['minecraft:'+alias]=blockmap['minecraft:'+original]
old_atlas=ROOT/'resource_pack/textures/shopuilook2/showcase/blocks.png'
if old_atlas.exists():old_atlas.unlink()
# Inventory icons and official item textures are already upright. Their texture paths are reusable.
icons={p.stem:'textures/shop_icons/'+p.stem for p in (ROOT/'resource_pack/textures/shop_icons').glob('*.png')}
ALIASES={'beef':'raw_beef','porkchop':'raw_porkchop','chicken':'raw_chicken','mutton':'raw_mutton','rabbit':'raw_rabbit','salmon':'raw_salmon','cod':'raw_cod','fish':'raw_cod','cooked_fish':'cooked_cod','experience_bottle':'bottle_o_enchanting','empty_map':'map','filled_map':'map','chain':'iron_chain','totem':'totem_of_undying','wooden_door':'oak_door','boat':'oak_boat','chest_boat':'oak_boat_with_chest','reeds':'sugar_cane','carrot_on_a_stick':'carrot_on_a_stick','gold_sword':'golden_sword','gold_axe':'golden_axe','gold_pickaxe':'golden_pickaxe','gold_shovel':'golden_shovel','gold_hoe':'golden_hoe','golden_rail':'powered_rail'}
ALIASES.update({'banner':'white_banner','candle':'white_candle','deadbush':'dead_bush','fence_gate':'oak_fence_gate','frame':'item_frame','glow_frame':'glow_item_frame','frog_spawn':'frogspawn','grass_path':'dirt_path','vine':'vines','waterlily':'lily_pad','web':'cobweb','wooden_button':'oak_button','wooden_pressure_plate':'oak_pressure_plate','chest_minecart':'minecart_with_chest','hopper_minecart':'minecart_with_hopper','tnt_minecart':'minecart_with_tnt','lodestone_compass':'compass','player_head':'steve_head','potion':'water_bottle','splash_potion':'splash_water_bottle','lingering_potion':'lingering_water_bottle','zombie_pigman_spawn_egg':'zombified_piglin_spawn_egg'})
flat={};paths=set(icons.values())
for entry in meta:
 name=entry['name'].split(':',1)[1];path=None
 key=ALIASES.get(name,name)
 if name.endswith('_chest_boat'):key=name[:-11]+'_boat_with_chest'
 if name=='bamboo_chest_raft':key='bamboo_raft_with_chest'
 if key.startswith('waxed_'):key=key[6:]
 if key not in icons and 'itemsprite_'+key in icons:key='itemsprite_'+key
 if key in icons:path=icons[key]
 else:
  native=items.get(name)
  if name.endswith('_spawn_egg'):
   egg=name[:-10];egg={'tropical_fish':'tropicalfish','zombie_pigman':'zombified_piglin'}.get(egg,egg);native=items.get('spawn_egg_'+egg,native)
  if native:path,_=tex_path(native.get('textures'))
 if path:flat[entry['name']]=path;paths.add(path)
# Include the sixteen dye paths already used by the shop UI.
main=(ROOT/'behavior_pack/scripts/main.js').read_text()
dyes=re.search(r'const DYE_TEXTURES = \{(.*?)\};',main,re.S)
if dyes:
 for name,path in re.findall(r'(\w+): "([^"]+)"',dyes.group(1)):
  path='textures/items/'+path;flat['minecraft:'+name]=path;paths.add(path)
# Current pack's custom item icons, including effect rewards and shop blocks.
custom_atlas=read(ROOT/'resource_pack/textures/item_texture.json')['texture_data']
for p in (ROOT/'behavior_pack/items').glob('*.json'):
 try:
  item=read(p)['minecraft:item'];comp=item.get('components',{});icon=comp.get('minecraft:icon');icon=icon.get('textures',{}).get('default',icon.get('texture')) if isinstance(icon,dict) else icon
  path,_=tex_path(custom_atlas.get(icon,{}).get('textures'))
  if path:flat[item['description']['identifier']]=path;paths.add(path)
 except (KeyError,TypeError):pass
# Include every custom/vanilla referenced effect texture for typed buff tokens as well.
for spec in custom_atlas.values():
 p,_=tex_path(spec.get('textures'))
 if p:paths.add(p)
paths=sorted(paths);texture_index={p:i+len(block_images) for i,p in enumerate(paths)}
for entity_file in ['showcase_item.json','showcase_display.json']:
 bp_path=ROOT/'behavior_pack/entities'/entity_file
 if not bp_path.exists():continue
 bp=read(bp_path)
 properties=bp['minecraft:entity']['description']['properties']
 if 'shopuilook2:texture' in properties:
  properties['shopuilook2:texture']['default']=texture_index['textures/shop_icons/_unknown']
  properties['shopuilook2:texture']['range']=[0,4095]
  properties.pop('shopuilook2:tile',None)
  write(bp_path,bp)
flatmap={name:texture_index[path] for name,path in sorted(flat.items())}
textures={**{'b'+str(i):p for i,p in enumerate(block_images)},**{'t'+str(i):p for i,p in enumerate(paths)}}
# Cube UVs use a dedicated 64x64 image. Every model has a common center [0,8,0].
def transform_bones():return [{'name':'root','pivot':[0,0,0]},{'name':'spin','parent':'root','pivot':[0,8,0]},{'name':'offset','parent':'spin','pivot':[0,8,0]},{'name':'roll','parent':'offset','pivot':[0,8,0]},{'name':'tilt','parent':'roll','pivot':[0,8,0]}]
def cuboid(origin,size):
 uv={}
 for f in FACES:
  x,y=FACE_POS[f]
  # Reuse the same face image for slabs and stair segments; preserve the crop in Y.
  h=size[1]*16/10
  uv[f]={'uv':[x+1,y+1+(16-h if f not in ['up','down'] else 0)],'uv_size':[16,16 if f in ['up','down'] else h]}
 return {'origin':origin,'size':size,'uv':uv}
models=[];shapes=['flat','cube','slab','stairs','carpet','trapdoor']
boxes={1:[([-5,3,-5],[10,10,10])],2:[([-5,5.5,-5],[10,5,10])],3:[([-5,3,-5],[10,5,10]),([-5,8,0],[10,5,5])],4:[([-5,7.6875,-5],[10,.625,10])],5:[([-5,7.0625,-5],[10,1.875,10])]}
for i,name in enumerate(shapes):
 bones=transform_bones()
 if i==0:
  depth=.625
  cubes=[{'origin':[-5,3,-depth/2],'size':[10,10,depth],'uv':{'north':{'uv':[0,0],'uv_size':[16,16]},'south':{'uv':[16,0],'uv_size':[-16,16]}}}]
  # Shared 32-pixel extrusion grid: transparent texels discard the corresponding
  # side fragments, so all sprites obtain colored silhouette walls without
  # making the transparent rectangle into a solid box. No per-item mesh needed.
  grid=32;step=16/grid;unit=10/grid
  for edge in range(grid+1):
   vertical={};horizontal={}
   if edge<grid:
    vertical['west']={'uv':[edge*step,0],'uv_size':[step,16]}
    horizontal['up']={'uv':[0,edge*step],'uv_size':[16,step]}
   if edge>0:
    vertical['east']={'uv':[(edge-1)*step,0],'uv_size':[step,16]}
    horizontal['down']={'uv':[0,(edge-1)*step],'uv_size':[16,step]}
   cubes.append({'origin':[-5+edge*unit,3,-depth/2],'size':[0,10,depth],'uv':vertical})
   cubes.append({'origin':[-5,13-edge*unit,-depth/2],'size':[10,0,depth],'uv':horizontal})

 else:cubes=[cuboid(o,s) for o,s in boxes[i]]
 bones.append({'name':'display','parent':'tilt','pivot':[0,8,0],'cubes':cubes})
 models.append({'description':{'identifier':'geometry.shopuilook2.showcase_'+name,'texture_width':16 if i==0 else 64,'texture_height':16 if i==0 else 64,'visible_bounds_width':2,'visible_bounds_height':2,'visible_bounds_offset':[0,.5,0]},'bones':bones})
write(ROOT/'resource_pack/models/entity/showcase_item.geo.json',{'format_version':'1.12.0','minecraft:geometry':models})
for entity_file in ['showcase_item.entity.json','showcase_display.entity.json']:
 client_path=ROOT/'resource_pack/entity'/entity_file
 if not client_path.exists():continue
 entity=read(client_path);d=entity['minecraft:client_entity']['description'];d['materials']={'solid':'entity_alphatest','translucent':'entity_alphablend'};d['textures']=textures;d['geometry']={name:'geometry.shopuilook2.showcase_'+name for name in shapes};d.pop('enable_attachables',None);d['render_controllers']=['controller.render.shopuilook2.showcase_model'];write(client_path,entity)
controller={'arrays':{'geometries':{'Array.models':['Geometry.'+s for s in shapes]},'textures':{'Array.images':['Texture.b'+str(i) for i in range(len(block_images))]+['Texture.t'+str(i) for i in range(len(paths))]},'materials':{'Array.materials':['Material.solid','Material.translucent']}},'geometry':"Array.models[q.property('shopuilook2:shape')]",'materials':[{'*':"Array.materials[q.property('shopuilook2:alpha')]"}],'textures':["Array.images[q.property('shopuilook2:texture')]" ]}

write(ROOT/'resource_pack/render_controllers/showcase_item.render_controllers.json',{'format_version':'1.8.0','render_controllers':{'controller.render.shopuilook2.showcase_model':controller}})
js='// Generated by tools/build_showcase_assets.py from Mojang bedrock-samples '+PIN+'.\n'
for name,data in [('SC_BLOCK_VISUALS',blockmap),('SC_FLAT_VISUALS',flatmap),('SC_TEXTURE_INDEX',texture_index),('SC_DISPLAY_INFO',{'block_textures':len(block_images),'block_ids':len(blockmap),'textures':len(paths)+len(block_images),'extrusion_grid':32})]:js+='export const '+name+' = '+json.dumps(data,ensure_ascii=False,separators=(',',':'))+';\n'
(ROOT/'behavior_pack/scripts/showcase_visuals.js').write_text(js)
unknown=[e['name'] for e in meta if e['name'] not in blockmap and e['name'] not in flatmap and e['name'].split(':',1)[1] not in icons]
write(ROOT/'tools/showcase_asset_report.json',{'unknown_item_ids':unknown,'source_commit':PIN,'block_models':len(blockmap),'flat_item_ids':len(flatmap),'textures':len(paths)+len(block_images),'block_textures':len(block_images),'block_texture_size':[64,64],'extrusion_grid':32,'skipped_blocks':skipped,'shape_names':shapes})
print('models:',len(blockmap),'flat IDs:',len(flatmap),'textures:',len(paths)+len(block_images),'block images:',len(block_images),'skipped:',len(skipped))
