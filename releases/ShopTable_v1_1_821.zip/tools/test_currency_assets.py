from pathlib import Path
import json,re
from PIL import Image
R=Path(__file__).resolve().parents[1];reg=json.loads((R/'tools/currency_glyph_registry.json').read_text());s=(R/'behavior_pack/scripts/main.js').read_text();mapping=json.loads(re.search(r'const SHOP_GLYPHS = (\{[^\n]+\});',s).group(1));cache={}
def cell(cp,size=32):
 page=cp>>8
 if page not in cache:cache[page]=Image.open(R/f'resource_pack/font/glyph_{page:02X}.png').convert('RGBA')
 image=cache[page];assert image.size==(size*16,size*16);i=cp&255;return image.crop((i%16*size,i//16*size,i%16*size+size,i//16*size+size))
for id,e in reg['additions'].items():
 cp=int(e['codepoint'],16);assert ord(mapping[id])==cp;assert cell(cp).getbbox(),id
 path=e['texture'];assert (R/'resource_pack'/(path+'.png')).exists() or path.startswith('textures/items/') or path.startswith('textures/blocks/')
 if e['new_cell'] and not 0xF000<=cp<=0xF0FF:
  small=cp+0x800 if cp>=0xF100 else cp+0x200;large=cp-0xB00 if cp>=0xF100 else cp+0x100
  assert cell(small,16).getbbox();assert cell(large).getbbox()
print(len(reg['additions']),'currency glyph cells checked; normal/small/block variants are not empty')
