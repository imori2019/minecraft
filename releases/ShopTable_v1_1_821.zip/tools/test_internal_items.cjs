const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');const {run,prep,ctx,Container,ItemStack}=require('./test_smelt_sales.cjs');
let n=0;const test=(name,fn)=>{fn();n++;console.log('PASS INTERNAL '+name);};
test('internal items are hidden from the creative menu and from command autocomplete',()=>{
 const dir=path.join(__dirname,'../behavior_pack/items');const internal=/^shopuilook2:(decision_probe(_b|_unknown)?|slot_zero_guard|set_icon|cartography_map_.+|creative_icon_.+)$/;let seen=0;
 for(const f of fs.readdirSync(dir)){const it=JSON.parse(fs.readFileSync(path.join(dir,f),'utf8'))['minecraft:item'];const id=it.description.identifier;if(!internal.test(id))continue;seen++;
  assert.equal(it.description.menu_category?.category,'none',id);assert.equal(it.description.menu_category?.is_hidden_in_commands,true,id);}
 assert.ok(seen>=30);
 const bdir=path.join(__dirname,'../behavior_pack/blocks');for(const f of fs.readdirSync(bdir).filter(f=>f.endsWith('_case.json'))){const d=JSON.parse(fs.readFileSync(path.join(bdir,f),'utf8'))['minecraft:block'].description;assert.equal(d.menu_category.category,'none',f);assert.equal(d.menu_category.is_hidden_in_commands,true,f);}
});
test('placeholder maps and arrows are recognised; plain ones and other items are not',()=>{
 prep();
 assert.equal(run(`placeholderKind(cgMapItem('village_plains'))`),'map');
 assert.equal(run(`placeholderKind(new ItemStack('minecraft:empty_map',1))`),undefined);
 assert.equal(run(`(()=>{const a=new ItemStack('minecraft:arrow',1);a.setLore(['§7x',FL_ARROW_TAG+'minecraft:long_poison']);return placeholderKind(a)})()`),'arrow');
 assert.equal(run(`placeholderKind(new ItemStack('minecraft:arrow',1))`),undefined);
 assert.equal(run(`placeholderKind(new ItemStack('minecraft:apple',1))`),undefined);
});
test('giving a placeholder runs the loot conversion instead of handing over the tagged item',()=>{
 prep();
 run(`globalThis.__cmds=[];globalThis.__given=[];player.runCommand=c=>{__cmds.push(c);return {successCount:1}};`);
 run(`giveOrDropNow(player,cgMapItem('village_plains',2))`);
 assert.deepEqual(JSON.parse(run('JSON.stringify(__cmds)')),['loot give @s loot "shopuilook2/map/village_plains"','loot give @s loot "shopuilook2/map/village_plains"']);
 run(`__cmds.length=0;(()=>{const a=new ItemStack('minecraft:arrow',3);a.setLore(['§7x',FL_ARROW_TAG+'minecraft:long_poison']);giveOrDropNow(player,a)})()`);
 assert.equal(run('__cmds.length'),3);assert.ok(run('__cmds[0]').includes('shopuilook2/tipped/'));
});
test('the inventory sweep removes internal-only items and converts placeholders',()=>{
 prep();
 run(`globalThis.__cmds=[];player.runCommand=c=>{__cmds.push(c);return {successCount:1}};`);
 run(`(()=>{const inv=player.getComponent('minecraft:inventory').container;inv.setItem(3,new ItemStack('shopuilook2:set_icon',1));inv.setItem(4,new ItemStack('shopuilook2:cartography_map_mansion',1));inv.setItem(5,cgMapItem('mansion'));inv.setItem(6,new ItemStack('minecraft:apple',2));})()`);
 run(`clearProbeFromPlayer(player,true)`);
 const at=i=>run(`player.getComponent('minecraft:inventory').container.getItem(${i})?.typeId`);
 assert.equal(at(3),undefined);assert.equal(at(4),undefined);assert.equal(at(5),undefined);assert.equal(at(6),'minecraft:apple');
 assert.deepEqual(JSON.parse(run('JSON.stringify(__cmds)')),['loot give @s loot "shopuilook2/map/mansion"']);
 assert.ok(run(`isInternalOnly(new ItemStack('shopuilook2:creative_icon_copper',1))`));assert.ok(!run(`isInternalOnly(new ItemStack('shopuilook2:panel',1))`));
});
console.log(n+' internal item tests passed (API simulation; no Minecraft runtime)');
