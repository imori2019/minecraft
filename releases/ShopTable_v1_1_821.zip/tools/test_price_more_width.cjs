const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {run}=require('./test_smelt_sales.cjs');
const ui=require('./read_price_ui.cjs')();
// v768: one mark placed by a horizontal stack of binary-width gaps; hidden gaps take no width.
const row=ui.sh_price_more_by_width.controls[0].row;
const shown=(node,code)=>{const b=node.bindings?.find(x=>x.target_property_name==='#visible');return !b||[...b.source_property_name.matchAll(/= '(\d+)'/g)].some(m=>Number(m[1])===code);};
function mark(code){if(!shown(row,code))return undefined;let x=0;for(const c of row.controls){const [k,n]=Object.entries(c)[0];if(!shown(n,code))continue;if(k==='mark')return {offset:[x,row.offset[1]],size:n.size,texture:n.texture};x+=n.size[0];}}
const variants=new Proxy({},{get:(_,k)=>mark(Number(String(k).slice(1)))});let checks=0;
for(const [old,fresh,sp,mid]of [[1,1],[10,10],[12,5],[125,5],[125,25],[9999,9999],[10000,5000],[123456,10000],[999999999,1234567],[100,20,true,40]]){
 const entry={k:'item',id:'minecraft:emerald',n:old,n2:fresh,sp,mid};
 const text=run(`shopPriceSizedGlyphText(${JSON.stringify(entry)},true,'dark')`);
 const code=2+run(`shopPriceMoreClass(${JSON.stringify(text)})`);const image=variants['w'+code];assert.ok(image,'width variant for '+old+'/'+fresh);
 const normal=run(`shopNum(${fresh})`);const crossed=sp&&mid!==old?String(mid):String(old);
 const count=old===fresh?normal.length:crossed.length+normal.length;const hasGap=old!==fresh;
 const expectedInkWidth=(16*count-1+(hasGap?2:0))*0.36;
 assert.ok(Math.abs(image.offset[0]+image.size[0]/2-expectedInkWidth/2)<0.00001,'center matches bitmap ink, '+old+'/'+fresh);
 checks++;
}
for(let c=0;c<70;c++)assert.equal(!!mark(c),c>=4&&c<64,'mark shown only for codes 4..63: '+c);
for(let c=4;c<64;c++)assert.ok(Math.abs(mark(c).offset[0]-(0.2+2.88*Math.floor((c-4)/2)+0.36*(c%2)))<1e-9,'same place as the v767 image for '+c);
console.log('PASS '+checks+' price widths: one/two/many digits, crossed-out prices, popular discounts and k/M/+ use their own exact center');
