// v1.1.807 欄は234番（受け取り枠の最後のマス。受け取り枠は11マスに）。v1.1.806 購入画面の「クーポン」の欄（ポイントカードの横）。この店のクーポンだけ入る。閉じたら本人へ返す
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {run,prep,shopInv,playerInv}=require('./test_smelt_sales.cjs');
let n=0;const test=(name,fn)=>{fn();n++;console.log('PASS COUPON SLOT '+name);};
test('the coupon slot (234) sits right of the point card slot, shows count, no picture when empty (v1.1.809)',()=>{
 const d=JSON.parse(fs.readFileSync(path.join(__dirname,'../resource_pack/ui/shop_layout_price.json'),'utf8'));
 const v=d.shop_side_page.controls.find(c=>c.shop_side_vis).shop_side_vis.controls;
 const card=v.find(c=>c.sh_card_slot).sh_card_slot,cp=v.find(c=>c.sh_coupon_slot).sh_coupon_slot;
 assert.deepEqual(card.offset,[8,108]);assert.deepEqual(cp.offset,[26,108]);
 const s=cp.controls[0]['slot@common.container_item'];assert.equal(s.collection_index,234);assert.equal(s.$stack_count_required,true);
 assert.equal(s.$cell_overlay_ref,'common.empty_panel');assert.equal(d.sh_coupon_empty_icon,undefined);
 // 234番は受け取り枠の最後のマスだった（実際のアイテムが入るマス）。受け取り枠は223〜233の11マス、画面からも12個目を消した
 assert.equal(run('SH_COUPON_SLOT'),234);assert.deepEqual(JSON.parse(run('JSON.stringify(SH_BOX_SLOTS)')),[223,224,225,226,227,228,229,230,231,232,233]);
 const sf=v[0].sh_side_full_cp.controls[0].sh_side_full.controls.map(c=>Object.keys(c)[0]);assert.ok(!sf.includes('sh_box_11')&&sf.includes('sh_box_10'));
 // 購入画面で234番を使うのはクーポンの欄だけ
 const hits=[];(function w(o,p){if(o&&typeof o==='object'){if(o.collection_index===234)hits.push(p);for(const [k,x] of Object.entries(o))w(x,p+'/'+k);}})(Object.fromEntries(Object.entries(d).filter(([k])=>!k.startsWith('pp_'))),'');
 assert.deepEqual(hits.filter(h=>!h.includes('sh_coupon_slot')),[],'234 only in the coupon slot: '+hits.join(' '));
 for(let r=0;r<run('SH_ROWS');r++){const o=JSON.parse(run(`JSON.stringify(shSlots(${r}))`));assert.ok(![o.title,o.prev,o.next,...o.cell,...o.price,...o.set].includes(234),'row '+r);}
 assert.ok(!run('SH_REAL_SLOTS.has(138)'),'138 (a price cell) is no longer a real slot');assert.ok(run('SH_REAL_SLOTS.has(SH_COUPON_SLOT)'));
});
prep();shopInv.size=640;
const st='loadStores().stores.s1';
test('only this store\'s coupons stay; anything else goes back to the player',()=>{
 run(`globalThis.msgs=[];tell=(p,m)=>msgs.push(m);`);
 run(`getContainer(block).setItem(SH_COUPON_SLOT,shopMakeCoupon(${st},10,{},3));shopCouponEjectInvalid(player,getContainer(block),${st});`);
 assert.equal(shopInv.items.get(234)?.amount,3,'own coupon stays');
 run(`getContainer(block).setItem(SH_COUPON_SLOT,shopMakeCoupon({id:'other',name:'X'},10,{},2));shopCouponEjectInvalid(player,getContainer(block),${st});`);
 assert.equal(shopInv.items.has(234),false);assert.ok([...playerInv.items.values()].some(i=>i.typeId==='shopuilook2:coupon'&&i.amount===2));
 assert.match(run('msgs.join()'),/ほかのお店のクーポン/);
 run(`getContainer(block).setItem(SH_COUPON_SLOT,new ItemStack('minecraft:dirt',5));shopCouponEjectInvalid(player,getContainer(block),${st});`);
 assert.equal(shopInv.items.has(234),false);assert.ok([...playerInv.items.values()].some(i=>i.typeId==='minecraft:dirt'));
});
test('closing returns the coupons to the player (stacking onto the same coupon); owner-screen calls only take coupons',()=>{
 run(`playerInv.setItem?0:0;`);
 run(`getContainer(block).setItem(SH_COUPON_SLOT,shopMakeCoupon(${st},15,{},4));getContainer(block).setItem(9,null);`);
 run(`{const inv=player.getComponent('minecraft:inventory').container;inv.setItem(5,shopMakeCoupon(${st},15,{},2));}`);
 run(`shopCouponReturn(player,getContainer(block),true);`);
 assert.equal(shopInv.items.has(234),false);
 const stacks=[...playerInv.items.values()].filter(i=>i.typeId==='shopuilook2:coupon'&&run('1')&&i.amount===6);
 assert.equal(stacks.length,1,'4 stacked onto the 2 in the inventory');
 run(`getContainer(block).setItem(SH_COUPON_SLOT,new ItemStack('minecraft:stone',1));shopCouponReturn(player,getContainer(block),true);`);
 assert.equal(shopInv.items.get(234)?.typeId,'minecraft:stone','owner-screen path leaves non-coupons alone');
 shopInv.items.delete(234);
});
test('a coupon in the slot lowers the list price; the slot signature changes so the screen rewrites',()=>{
 run(`globalThis.cpC={size:640,items:new Map(),getItem(i){return this.items.get(i)},setItem(i,v){v?this.items.set(i,v):this.items.delete(i)}};shopCouponContainer=()=>cpC;
  globalThis.recP={id:'p1',settings:{coupon_max_rate:'50',coupon_max_count:'2'}};`);
 const price=()=>JSON.parse(run(`(()=>{const st=loadStores().stores.s1;const pp=pricePointSettingsForStore(st);const r={...loadProduct(block,'p1'),settings:{...loadProduct(block,'p1').settings,coupon_max_rate:'50',coupon_max_count:'2'}};const rd={store:st,prices:new Map(),buyer:player};const base=shopRenderPrice(rd,r,pp.currencies,pp,'d1',shopNow()).entries;globalThis.dealSame=JSON.stringify(base)===JSON.stringify(shopRenderPrice({store:st,prices:new Map()},r,pp.currencies,pp,'d1',shopNow()).entries);return JSON.stringify(shopApplyCouponToList(rd,r,'d1',base).map(e=>[e.n,e.n2]))})()`));
 const before=price();assert.ok(before.length>0);assert.deepEqual(before.map(x=>x[0]),before.map(x=>x[1]),'no coupon: no discount');
 assert.equal(run('shopCouponSlotSig(cpC)'),'');
 run(`cpC.setItem(SH_COUPON_SLOT,shopMakeCoupon(loadStores().stores.s1,20,{},1))`);
 const after=price();assert.deepEqual(after.map(x=>x[1]),before.map(x=>Math.ceil(x[1]*0.8)),'20% coupon applied in the list');
 assert.match(run('shopCouponSlotSig(cpC)'),/\|20\|/);
 assert.equal(run('dealSame'),true,'the cached price (used for the deals panel and affordability) ignores the coupon');
 run(`cpC.setItem(SH_COUPON_SLOT,shopMakeCoupon({id:'zz',name:'Z'},20,{},1))`);assert.deepEqual(price(),before,'another store\'s coupon does nothing');
});
console.log(n+' coupon slot test groups passed (API simulation; no Minecraft runtime)');
