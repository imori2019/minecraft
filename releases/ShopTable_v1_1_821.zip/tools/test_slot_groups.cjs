// v1.1.814 専用スロット：決まった欄には決まった物だけ。前の版の中身は合う欄へ並べ直す。画面の欄には種類の番号の仮の絵
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {run}=require('./test_smelt_sales.cjs');
let n=0;const test=(name,fn)=>{fn();n++;console.log('PASS SLOTS '+name);};
const J=s=>JSON.parse(run(`JSON.stringify(${s})`));
test('types accept only their items; numbers 1-9 match the picture files',()=>{
 const ok=(t,id)=>run(`SLOT_TYPES.${t}.ok(${JSON.stringify(id)})`);
 assert.ok(ok('disc','minecraft:music_disc_cat'));assert.ok(!ok('disc','minecraft:paper'));
 assert.ok(ok('book','minecraft:book')&&!ok('book','minecraft:enchanted_book'));assert.ok(ok('lapis','minecraft:lapis_lazuli'));
 assert.ok(ok('fullBucket','minecraft:water_bucket')&&ok('fullBucket','minecraft:lava_bucket')&&!ok('fullBucket','minecraft:bucket'));
 assert.ok(ok('emptyBucket','minecraft:bucket'));assert.ok(ok('ground','minecraft:dirt')&&ok('ground','minecraft:sand')&&ok('ground','minecraft:warped_nylium'));
 assert.ok(ok('bone','minecraft:bone_meal'));assert.ok(ok('paper','minecraft:paper')&&!ok('paper','minecraft:compass'));assert.ok(ok('compass','minecraft:compass'));
 for(const [k,no] of Object.entries(J(`Object.fromEntries(Object.entries(SLOT_TYPES).map(([k,v])=>[k,v.no]))`)))
  assert.ok(fs.existsSync(path.join(__dirname,`../resource_pack/textures/ui/shoptable_slot_type_${no}.png`)),k);
});
test('layouts: composter 4/5/18, barrel 5/4, enchant lapis 18 + books 18, cartography paper 54 > compass 27, note records 27',()=>{
 const g=J('SLOT_GROUPS');
 assert.deepEqual(g.composter,[['fullBucket',0,4],['bone',4,5],['ground',9,18]]);assert.equal(run('CP_MAT_SLOTS.length'),27);
 assert.deepEqual(g.barrel,[['ground',0,5],['bone',5,4]]);assert.equal(run('BL_MAT_SLOTS.length'),9);
 assert.deepEqual(g.enchant,[['lapis',0,18],['book',18,18]]);assert.ok(36<=run('EN_MAT_N'));
 assert.deepEqual(g.cartography,[['paper',0,54],['compass',54,27]]);assert.equal(run('CR_WIDE_SLOTS.length'),81);
 assert.deepEqual(g.note,[['disc',54,27]]);
 assert.equal(run(`slotGroupOk('composter',0,'minecraft:bone_meal')`),false);assert.equal(run(`slotGroupOk('composter',4,'minecraft:bone_meal')`),true);
 assert.equal(run(`slotGroupOk('enchant',40,'minecraft:dirt')`),true,'the rest of the enchant storage stays free');
});
test('old contents move to their own slots; what does not fit is returned',()=>{
 const r=J(`(()=>{const m=Array(27).fill(null);m[0]={id:'minecraft:dirt',n:10};m[1]={id:'minecraft:bone_meal',n:5};m[12]={id:'minecraft:water_bucket',n:1};const f=slotGroupFix('composter',m);return {m,f}})()`);
 assert.equal(r.m[0]?.id,'minecraft:water_bucket');assert.equal(r.m[4]?.id,'minecraft:bone_meal');assert.equal(r.m[9]?.id,'minecraft:dirt');
 assert.equal(r.m[1],null);assert.equal(r.m[12],null);assert.deepEqual(r.f.give,[]);
 const full=J(`(()=>{const m=Array(9).fill(null);for(let i=0;i<5;i++)m[i]={id:'minecraft:sand',n:64};m[0]={id:'minecraft:bone_meal',n:3};for(let i=5;i<9;i++)m[i]={id:'minecraft:bone_meal',n:64};return slotGroupFix('barrel',m)})()`);
 assert.deepEqual(full.give,[{id:'minecraft:bone_meal',n:3}],'no room: given back');
 const en=J(`(()=>{const m=Array(54).fill(null);m[0]={id:'minecraft:book',n:3};const f=slotGroupFix('enchant',m,k=>k<EN_MAT_N);return m.findIndex(x=>x)})()`);
 assert.equal(en,18,'books go to the book slots');
});
test('every grouped slot shows its numbered picture (only when empty) in that shop\'s storage screen',()=>{
 const d=JSON.parse(fs.readFileSync(path.join(__dirname,'../resource_pack/ui/shop_proceeds_screen.json'),'utf8'));
 for(let no=1;no<=9;no++){const t=d['slot_type_icon_'+no];assert.equal(t.texture,'textures/ui/shoptable_slot_type_'+no);assert.equal(t.bindings[0].binding_name,'#empty_image_visible');}
 const find=(o,name)=>{if(!o||typeof o!=='object')return;for(const [k,v] of Object.entries(o)){if(k.split('@')[0]===name)return v;const r=find(v,name);if(r)return r;}};
 const overlays=root=>{const m={};(function w(o){if(!o||typeof o!=='object')return;for(const [k,v] of Object.entries(o)){if(k.includes('@common.container_item')&&v?.$cell_overlay_ref?.includes('slot_type_icon_'))m[v.collection_index]=+v.$cell_overlay_ref.split('_').pop();w(v);}})(root);return m;};
 const T=J(`Object.fromEntries(Object.entries(SLOT_TYPES).map(([k,v])=>[k,v.no]))`),G=J('SLOT_GROUPS');
 const expect=(key,slots)=>{const m={};for(const [t,f,c] of G[key]??[])for(let i=f;i<f+c;i++)m[slots[i]]=T[t];return m;};
 assert.deepEqual(overlays(find(d,'composter_pen')),expect('composter',J('CP_MAT_SLOTS')));
 const bl={...expect('barrel',J('BL_MAT_SLOTS'))};for(const s of J('BL_WATER_SLOTS'))bl[s]=4;for(const s of J('BL_BUCKET_SLOTS'))bl[s]=5;
 assert.deepEqual(overlays(find(d,'barrel_pen')),bl);
 {const e=expect('enchant',J('CR_MAT_SLOTS'));for(const i of J('EN_TPL'))e[J('CR_MAT_SLOTS')[i]]=2;assert.deepEqual(overlays(find(d,'enchant_pen')),e,'lapis 3, books 2 (incl. the 5 template books)');}
 assert.deepEqual(overlays(find(d,'cartography_pen')),expect('cartography',J('CR_WIDE_SLOTS')));
 assert.deepEqual(overlays(find(d,'note_pen')),expect('note',J('CR_WIDE_SLOTS')));
 {const w=J('CR_WIDE_SLOTS'),e={};for(let i=0;i<4;i++)e[w[i]]=4;for(let i=4;i<8;i++)e[w[i]]=10;for(let i=9;i<18;i++)e[w[i]]=11;for(let i=27;i<36;i++)e[w[i]]=12;assert.deepEqual(overlays(find(d,'fletch_pen')),e,'cauldron: water 4, bottles 10, blaze 11');}
 for(let no=10;no<=12;no++)assert.ok(fs.existsSync(path.join(__dirname,`../resource_pack/textures/ui/shoptable_slot_type_${no}.png`)));
});
 test('cauldron: water 4 / arrows 4 / blaze powder 9 / bottles 9 / anything 54; all 80 usable slots are on screen',()=>{
  assert.equal(run(`flSlotOk(27,'minecraft:glass_bottle')`),true);assert.equal(run(`flSlotOk(27,'minecraft:dirt')`),false);
  assert.equal(run(`flSlotOk(9,'minecraft:blaze_powder')`),true);assert.equal(run(`flSlotOk(9,'minecraft:glass_bottle')`),false);
  assert.equal(run(`flSlotOk(20,'minecraft:dirt')`),true);assert.equal(run('Array.from({length:81},(_,i)=>i).filter(i=>flIsMat(i)).length'),54);
  const d=JSON.parse(fs.readFileSync(path.join(__dirname,'../resource_pack/ui/shop_proceeds_screen.json'),'utf8'));
  const find=(o,name)=>{if(!o||typeof o!=='object')return;for(const [k,v] of Object.entries(o)){if(k.split('@')[0]===name)return v;const r=find(v,name);if(r)return r;}};
  const pen=find(d,'fletch_pen'),cells=[];for(const c of pen.controls)for(const v of Object.values(c))if(JSON.stringify(v.size)==='[18,18]')cells.push(v);
  const w=J('CR_WIDE_SLOTS');const idx=new Set(cells.map(v=>Object.values(v.controls[0])[0].collection_index));assert.deepEqual(w.filter((s,i)=>i!==8&&!idx.has(s)),[]);
  for(let i=0;i<cells.length;i++)for(let j=i+1;j<cells.length;j++){const a=cells[i].offset,b=cells[j].offset;assert.ok(Math.abs(a[0]-b[0])>=18||Math.abs(a[1]-b[1])>=18,'overlap');}
  for(const v of cells)assert.ok(v.offset[1]+18<=252&&v.offset[0]+18<=358);
 });
console.log(n+' slot group tests passed (API simulation; no Minecraft runtime)');
