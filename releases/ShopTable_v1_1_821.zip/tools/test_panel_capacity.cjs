const assert=require('node:assert/strict');const {run,ctx,Container,ItemStack}=require('./test_smelt_sales.cjs');let n=0;
const test=(name,fn)=>{fn();n++;console.log('PASS PANEL CAPACITY '+name);};
function setup({size=640,failSlot=null,removeFail=false}={}){
 const source=new Container(256),target=new Container(size);target.clearAll=()=>target.items.clear();target.failSlot=failSlot;
 source.setItem(0,new ItemStack('minecraft:diamond',3));source.setItem(223,new ItemStack('minecraft:emerald',17));
 const props=new Map([['shopuilook2:home','0,64,0'],['private-test','kept']]);let spawnCount=0;
 const old={id:'old-'+n,valid:true,get isValid(){return this.valid;},nameTag:'existing-title',getComponent:()=>({container:source}),getDynamicPropertyIds:()=>[...props.keys()],getDynamicProperty:k=>props.get(k),getTags:()=>['preserve-tag'],remove(){if(removeFail)throw Error('remove failed');this.valid=false;}};
 const nextProps=new Map(),tags=[];const next={id:'new-'+n,valid:true,get isValid(){return this.valid;},getComponent:()=>({container:target}),setDynamicProperty:(k,v)=>nextProps.set(k,v),addTag:t=>tags.push(t),remove(){this.valid=false;}};
 const block={typeId:'shopuilook2:panel',location:{x:0,y:64,z:0},dimension:{id:'minecraft:overworld',spawnEntity:()=>{spawnCount++;return next;}}};
 ctx.capacityBlock=block;ctx.oldActor=old;run('PANEL_OCCUPANTS.clear();panelCapacityFailed.clear();panelEntityCache.clear();');
 return {source,target,old,next,nextProps,tags,block,spawnCount:()=>spawnCount};
}
test('growth copies every item, metadata property and tag before removing the old actor',()=>{
 const t=setup();assert.equal(run('upgradePanelEntityCapacity(capacityBlock,oldActor)'),t.next);assert.equal(t.old.valid,false);assert.equal(t.target.getItem(0).amount,3);assert.equal(t.target.getItem(223).amount,17);assert.equal(t.nextProps.get('private-test'),'kept');assert.deepEqual(t.tags,['preserve-tag']);assert.equal(t.next.nameTag,'existing-title');
});
test('a copy failure keeps all original items and discards the incomplete replacement',()=>{
 const t=setup({failSlot:223});assert.equal(run('upgradePanelEntityCapacity(capacityBlock,oldActor)'),t.old);assert.equal(t.old.valid,true);assert.equal(t.next.valid,false);assert.equal(t.source.getItem(0).amount,3);assert.equal(t.source.getItem(223).amount,17);assert.equal(t.target.items.size,0);
});
test('an unavailable larger inventory leaves the working old actor in place and does not retry continuously',()=>{
 const t=setup({size:256});assert.equal(run('upgradePanelEntityCapacity(capacityBlock,oldActor)'),t.old);assert.equal(run('upgradePanelEntityCapacity(capacityBlock,oldActor)'),t.old);assert.equal(t.spawnCount(),1);assert.equal(t.old.valid,true);assert.equal(t.source.getItem(223).amount,17);
});
test('a failed final removal rolls back the replacement without clearing the original',()=>{
 const t=setup({removeFail:true});assert.equal(run('upgradePanelEntityCapacity(capacityBlock,oldActor)'),t.old);assert.equal(t.old.valid,true);assert.equal(t.next.valid,false);assert.equal(t.target.items.size,0);
});
test('an actively used shop is never replaced underneath its open screen',()=>{
 const t=setup();run(`PANEL_OCCUPANTS.set(blockKey(capacityBlock),{pid:'using-it'});`);assert.equal(run('upgradePanelEntityCapacity(capacityBlock,oldActor)'),t.old);assert.equal(t.spawnCount(),0);
});
console.log(n+' panel capacity migration tests passed (API simulation; native inventory limit not executed)');
