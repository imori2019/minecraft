const assert=require('node:assert/strict'),fs=require('fs'),path=require('path');const{run}=require('./test_smelt_sales.cjs');
const d=JSON.parse(fs.readFileSync(path.join(__dirname,'../resource_pack/ui/data_driven_container_screen.json'),'utf8'));
const name='スポーンエッグの売り場';run(`setStringProp(block,'shop_product_genre',${JSON.stringify(name)})`);
assert.equal(run(`channelText(block,TEXT_CHANNELS.find(c=>c.slot===10),new Set(['shop_product_genre']))`),name);
assert.equal(run(`NARROW_TEXT_WIDTH.shop_product_genre`),36);assert.equal(run(`displayWidth('あ')`),2);
let n=0;function walk(o,p=''){if(Array.isArray(o))return o.forEach(x=>walk(x,p));if(!o||typeof o!=='object')return;
if(o.type==='label'&&(p.includes('/product_genre_group/')||p.includes('/genre_popup/')||p.includes('/genre_option_hover_'))&&o.bindings){const b=o.bindings.find(b=>b.target_property_name==='#text');const closed=p.includes('/product_genre_group/'),code=closed?'§0':'§f';assert.deepEqual(o.color,closed?[0,0,0]:[1,1,1]);assert.ok(b.source_property_name.startsWith("('"+code+"' + "));let raw='§r§f'+name+'§r';for(const m of b.source_property_name.matchAll(/ - '([^']*)'/g))raw=raw.split(m[1]).join('');assert.equal(code+raw,code+name);n++;}
for(const[k,v]of Object.entries(o))walk(v,p+'/'+k);}
walk(d);assert.equal(n,18);console.log('PASS full genre caption reaches slot 10; closed caption uses black and open/hover options use white, independently of native formatting (API/UI simulation)');
