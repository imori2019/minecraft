const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {run,prep,ctx}=require('./test_smelt_sales.cjs');let count=0;
const root=path.resolve(__dirname,'..'),read=p=>JSON.parse(fs.readFileSync(path.join(root,p),'utf8'));
const plain=x=>JSON.parse(JSON.stringify(x));
function test(name,fn){fn();count++;console.log('PASS CARTOGRAPHY '+name);}
function setup(){prep();run(`block.typeId='shopuilook2:panel_cartography';saveProductIndex(block,[]);registry.stores.s1.departments=[];registry.stores.s1.cartography={auto:false,mats:[],made:0};
 globalThis.oldMap=(id,d,n=3)=>{const it=cgMapItem(d,n);const r=base(id,'minecraft:empty_map');r.settings={price:'37',shop_product_name:'旧地図',shop_payment_method:0};r.items=[{id:it.typeId,key:itemKey(cgMapItem(d)),role:'sample',slot:17,count:1}];r.stock=[{slot:0,item:snapshotItemStack(it)}];r.keepUnits=1;return r;};`);}
test('all 23 destinations have matching real exploration_map loot tables; obsolete tables are absent',()=>{
 const dests=plain(run(`CG_DESTS`));assert.equal(dests.length,23);assert.equal(new Set(dests.map(d=>d[0])).size,23);
 const dir='behavior_pack/loot_tables/shopuilook2/map';assert.deepEqual(fs.readdirSync(path.join(root,dir)).sort(),dests.map(d=>d[0]+'.json').sort());
 for(const [dest]of dests){const e=read(dir+'/'+dest+'.json').pools[0].entries[0];assert.equal(e.name,'minecraft:map');assert.equal(e.functions[0].function,'exploration_map');assert.equal(e.functions[0].destination,dest);}
});
test('five legacy aliases migrate without materials or auto-crafting, preserving price and stock and remaining idempotent',()=>{
 for(const [old,dest]of [['village','village_plains'],['temple','jungle_temple'],['mineshaft','buried_mineshaft'],['ruins','warm_ocean_ruins'],['ancient_city','buried_ancient_city']]){
  setup();run(`putProducts([oldMap('p1',${JSON.stringify(old)})]);crCraft(block);`);
  assert.equal(run(`cgDestOfKey(loadProduct(block,'p1').items[0].key)`),dest);assert.equal(run(`cgCount(loadProduct(block,'p1'),${JSON.stringify(dest)})`),3);
  assert.equal(run(`loadProduct(block,'p1').settings.price`),'37');const before=run(`JSON.stringify(loadProduct(block,'p1'))`);run(`crCraft(block);`);assert.equal(run(`JSON.stringify(loadProduct(block,'p1'))`),before);assert.equal(run(`loadProductIndex(block).length`),1);
 }
});
test('an unchanged destination still updates its old automatic product name',()=>{
 setup();run(`putProducts([oldMap('p1','mansion')]);crCraft(block);`);
 assert.equal(run(`loadProduct(block,'p1').settings.shop_product_name`),'森の洋館の地図');assert.equal(run(`cgCount(loadProduct(block,'p1'),'mansion')`),3);
});
test('unsupported destinations refund only two crafted maps, never the free sample, exactly once',()=>{
 setup();run(`putProducts([oldMap('p1','stronghold')]);crCraft(block);`);
 assert.equal(run(`loadProductIndex(block).length`),0);assert.equal(run(`registry.stores.s1.cartography.mats.find(m=>m?.id==='minecraft:compass').n`),2);assert.equal(run(`registry.stores.s1.cartography.mats.find(m=>m?.id==='minecraft:paper').n`),16);
 const before=run(`JSON.stringify(registry.stores.s1.cartography.mats)`);run(`crCraft(block)`);assert.equal(run(`JSON.stringify(registry.stores.s1.cartography.mats)`),before);
});
test('a full materials store or failed refund save retains the original stock',()=>{
 setup();run(`putProducts([oldMap('p1','stronghold')]);registry.stores.s1.cartography.mats=Array.from({length:crSlots('cartography').length},()=>({id:'minecraft:stone',n:64}));crCraft(block);`);assert.equal(run(`cgCount(loadProduct(block,'p1'),'stronghold')`),3);
 setup();run(`putProducts([oldMap('p1','stronghold')]);failSaveStores=true;crCraft(block);`);assert.equal(run(`cgCount(loadProduct(block,'p1'),'stronghold')`),3);assert.equal(run(`registry.stores.s1.cartography.mats.length`),0);
});
test('all map cards use destination-specific display clones, with vanilla stock untouched and flat showcase support',()=>{
 setup();const atlas=read('resource_pack/textures/item_texture.json').texture_data;const paths=new Set();
 for(const [dest,ja]of plain(run(`CG_DESTS`))){
  const id='shopuilook2:cartography_map_'+dest;run(`globalThis.rec=oldMap('p1',${JSON.stringify(dest)});globalThis.before=JSON.stringify(rec);globalThis.card=makeLandingDisplayItem(rec,true);`);
  assert.equal(ctx.card.typeId,id);assert.equal(run(`isDisplayClone(card)`),true);assert.equal(run(`JSON.stringify(rec)`),ctx.before);assert.equal(run(`rec.stock[0].item.id`),'minecraft:empty_map');
  const item=read('behavior_pack/items/cartography_map_'+dest+'.json')['minecraft:item'];assert.equal(item.description.identifier,id);assert.equal(item.description.menu_category.category,'none');assert.equal(item.components['minecraft:display_name'].value,ja+'の地図');
  const icon=atlas[item.components['minecraft:icon']].textures;assert.equal(run(`itemIconPath(${JSON.stringify(id)})`),icon);assert.ok(fs.existsSync(path.join(root,'resource_pack',icon+'.png')));paths.add(icon);
  assert.equal(run(`scVisual(${JSON.stringify(id)}).shape`),0);assert.equal(run(`scVisual(${JSON.stringify(id)}).texture`),run(`SC_TEXTURE_INDEX[${JSON.stringify(icon)}]`));
 }
 assert.equal(paths.size,16,'eight abandoned camps share the official campsite icon');
 run(`globalThis.plain=base('p1','minecraft:empty_map');globalThis.p=makeLandingDisplayItem(plain);`);assert.equal(ctx.p.typeId,'minecraft:empty_map','ordinary blank maps keep their normal icon');
});
test('every purchased destination executes its corresponding real-map loot command, never gives the display proxy',()=>{
 setup();run(`globalThis.commands=[];player.runCommand=c=>{commands.push(c);return{successCount:1};};`);
 try{for(const [dest]of plain(run(`CG_DESTS`)))run(`cgGiveMaps(player,[cgMapItem(${JSON.stringify(dest)},2)]);`);
  const expected=plain(run(`CG_DESTS`)).flatMap(([d])=>Array(2).fill('loot give @s loot "shopuilook2/map/'+d+'"'));assert.deepEqual(plain(ctx.commands),expected);
 }finally{run(`delete player.runCommand`);}
});
console.log(count+' cartography test groups passed (API and asset checks; no Minecraft rendering)');
