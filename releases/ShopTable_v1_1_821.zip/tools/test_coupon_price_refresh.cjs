const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const evalText=require('./eval_price_binding.cjs'),{run,prep,ctx,Container}=require('./test_smelt_sales.cjs');
const root=path.resolve(__dirname,'..'),ui=require('./read_price_ui.cjs')();const pairs=[];
(function walk(o){if(!o||typeof o!=='object')return;if(['panel','stack_panel'].includes(o.type)&&o.controls?.length===2&&o.controls[0].e&&o.controls[1].o)pairs.push(o);for(const x of Object.values(o))walk(x)})(ui.sh_content);
assert.ok(pairs.length>300);
const legacy=JSON.parse(fs.readFileSync(path.join(__dirname,'fixtures/price812_numeric.json'),'utf8'));const legacyHover=legacy.bindings.find(b=>b.binding_name==='#hover_text'),legacyFinal=legacy.bindings.find(b=>b.target_property_name==='#text');
const rawFor=(n,n2)=>run(`shopCardPriceLines([{k:'item',id:'minecraft:emerald',n:${n},n2:${n2}}],true,'light')[0]`);
const raw=rawFor(125,100),icon=raw[0];
assert.ok(evalText(legacyFinal.source_property_name,{[legacyHover.binding_name_override]:raw}).includes(icon),'v812 reproduces the extra currency icon when the final view runs before the intermediate view');
console.log('PASS regression reproduces v812 currency leakage when binding calculations arrive out of order');
let checks=0;
for(const pair of pairs)for(const label of [pair.controls[0].e,pair.controls[1].o]){
 const read=label.bindings.find(b=>b.binding_name==='#hover_text'),final=label.bindings.find(b=>b.target_property_name==='#text');
 const refs=[...new Set((final.source_property_name.match(/'[^']*'|#[A-Za-z_][A-Za-z0-9_]*/g)||[]).filter(s=>s[0]==='#'))];assert.deepEqual(refs,[read.binding_name_override]);
 // Foreign/stale intermediates cannot affect this label, regardless of update order.
 for(const [old,fresh] of [[5,5],[5,4],[8,7],[125,100],[125,0],[123456,100000]]){
  const price=rawFor(old,fresh),state={[read.binding_name_override]:price};const expected=evalText(final.source_property_name,state);state['#p0_0a_i_k1']='wrong old icon';state['#p0_0a_n_k1']='old price';assert.equal(evalText(final.source_property_name,state),expected);
  if(final.source_property_name.includes(" - ("))assert.ok(!expected.includes(icon),'numeric or point-only labels must never leak currency artwork');checks++;
 }
}
console.log(`PASS ${checks} label updates preserve currency/number separation across coupon insertion, removal, 100% and width changes`);
ctx.shopInv=new Container(640);prep();
run(`active.clear();PANEL_OCCUPANTS.clear();block.typeId='shopuilook2:panel';registry.stores.s1.pricePointSystem=normalizePricePointSystemSettings({});const p=base('p901','minecraft:apple');p.settings.price='125';putProducts([p]);globalThis.R={};enterShopMode(player,R,block,shopInv);globalThis.priceSlot=shSlots(0).price[0];globalThis.before=shopInv.getItem(priceSlot);shopInv.setItem(SH_COUPON_SLOT,shopMakeCoupon(registry.stores.s1,20));writeShopUI(shopInv,R,block);globalThis.after=shopInv.getItem(priceSlot);`);
assert.notEqual(run('before.nameTag'),run('after.nameTag'));assert.notEqual(run('before.amount%2'),run('after.amount%2'));
const numerical=pairs.flatMap(p=>[p.controls[0].e,p.controls[1].o]).find(l=>l.collection_index===run('priceSlot')&&l.size?.[0]==='default'&&l.bindings.find(b=>b.target_property_name==='#text').source_property_name.includes(' - ('));
assert.ok(numerical);const payload=numerical.bindings.find(b=>b.binding_name==='#hover_text').binding_name_override,expr=numerical.bindings.find(b=>b.target_property_name==='#text').source_property_name;
assert.equal(evalText(expr,{[payload]:run('after.nameTag')}),rawFor(125,100).replace(icon,'').replace(/§[or]/g,''));
run(`shopInv.setItem(SH_COUPON_SLOT,undefined);writeShopUI(shopInv,R,block);globalThis.removed=shopInv.getItem(priceSlot);`);assert.equal(run('removed.nameTag'),run('before.nameTag'));assert.notEqual(run('removed.amount%2'),run('after.amount%2'));
console.log('PASS actual shop renderer flips generations and restores original price when the coupon is removed; API simulation only');
