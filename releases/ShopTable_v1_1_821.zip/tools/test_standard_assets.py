from pathlib import Path
from PIL import Image
import json,hashlib,base64,io
r=Path(__file__).resolve().parents[1]
report=json.loads((r/'tools/standard_shops757.json').read_text());source=(r/'tools/standard_shop_source.bbmodel').read_bytes();assert hashlib.sha256(source).hexdigest()==report['source_sha256'];src=json.loads(source);original=Image.open(io.BytesIO(base64.b64decode(src['textures'][0]['source'].split(',')[1]))).convert('RGBA')
geos=json.loads((r/'resource_pack/models/blocks/standard_shop.geo.json').read_text())['minecraft:geometry'];assert [len(g['bones'][0]['cubes']) for g in geos]==[5,9]
for i,g in enumerate(geos):
 authored=[e for e in src['elements'] if (e['to'][1]<=8)==(i==0)]
 assert len(authored)==len(g['bones'][0]['cubes'])
 for e,c in zip(authored,g['bones'][0]['cubes']):
  a,b=e['from'],e['to'];assert c['origin']==[-b[0],a[1]+8-16*i,a[2]];assert c['size']==[b[j]-a[j] for j in range(3)]
  assert set(c['uv'])=={f for f,v in e['faces'].items() if v.get('texture') is not None}
  for f,v in c['uv'].items():
   u0,v0,u1,v1=e['faces'][f]['uv'];expected=([u1,v1],[u0-u1,v0-v1]) if f in ['up','down'] else ([u0,v0],[u1-u0,v1-v0]);assert (v['uv'],v['uv_size'])==expected
for row in report['shops']:
 im=Image.open(r/f'resource_pack/textures/shopuilook2/blocks/{row["asset"]}.png').convert('RGBA');assert im.size==(64,32);assert im.crop((32,16,64,32)).tobytes()==original.crop((32,16,64,32)).tobytes()
 icon=Image.open(r/f'resource_pack/textures/shopuilook2/items/{row["asset"]}.png').convert('RGBA');assert icon.size==(64,64) and icon.getbbox();assert not any(icon.getpixel((0,y))[3] or icon.getpixel((63,y))[3] for y in range(64))
assert len(report['shops'])==20
print('PASS 20 texture atlases and inventory icons; original glass and transparency match all pixels')
print('PASS supplied model origin, size and every textured/removed UV face preserved by Bedrock conversion')
