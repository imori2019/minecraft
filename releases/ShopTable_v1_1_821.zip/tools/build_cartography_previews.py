#!/usr/bin/env python3
"""Bind cartography preview items to Mojang's destination-specific map icons.
Append display texture indices without changing any existing actor index or property schema.
"""
from pathlib import Path
import argparse,json,re,shutil
R=Path(__file__).resolve().parents[1];ap=argparse.ArgumentParser();ap.add_argument('--vanilla-root',type=Path);args=ap.parse_args()
def read(p):return json.loads(p.read_text())
def write(p,d):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
p=R/'behavior_pack/scripts/main.js';s=p.read_text();dests=json.loads(re.search(r'const CG_DESTS = (\[.*?\]);',s,re.S).group(1))
icons={'village_plains':'map_plains_village','village_desert':'map_desert_village','village_savanna':'map_savanna_village','village_snowy':'map_snowy_village','village_taiga':'map_taiga_village','jungle_temple':'map_jungle_temple','desert_pyramid':'map_desert_pyramid','swamp_hut':'map_swamp_hut','monument':'map_monument','mansion':'map_mansion','buriedtreasure':'map_nautilus','trial_chambers':'map_trial_chambers','buried_ancient_city':'map_ancient_city','buried_mineshaft':'map_mineshaft','warm_ocean_ruins':'map_warm_ocean_ruins'}
for dest,ja in dests:
 if dest.startswith('abandoned_camp_'):icons[dest]='map_abandoned_campsite'
assert {dest for dest,ja in dests}==set(icons)
paths={dest:'textures/shopuilook2/cartography/'+name for dest,name in icons.items()}
for name in sorted(set(icons.values())):
 target=R/'resource_pack/textures/shopuilook2/cartography'/(name+'.png');target.parent.mkdir(parents=True,exist_ok=True)
 if args.vanilla_root:shutil.copyfile(args.vanilla_root/'resource_pack/textures/items'/(name+'.png'),target)
 assert target.is_file(),target
atlaspath=R/'resource_pack/textures/item_texture.json';atlas=read(atlaspath)
for dest,ja in dests:
 id='shopuilook2:cartography_map_'+dest
 atlas['texture_data'][id]={'textures':paths[dest]}
 write(R/'behavior_pack/items'/('cartography_map_'+dest+'.json'),{'format_version':'1.26.50','minecraft:item':{'description':{'identifier':id,'menu_category':{'category':'none'}},'components':{'minecraft:display_name':{'value':ja+'の地図'},'minecraft:icon':id,'minecraft:max_stack_size':64}}})
write(atlaspath,atlas)
line='const CG_MAP_ICONS = '+json.dumps(paths,ensure_ascii=False,separators=(',',':'))+';'
if 'const CG_MAP_ICONS =' in s:s=re.sub(r'const CG_MAP_ICONS = \{[^\n]+\};',lambda _:line,s)
else:s=s.replace('const CG_TAG = ',line+'\nconst CG_TAG = ')
needle='function itemIconPath(typeId) {'
if 'CG_MAP_ICONS[dest]' not in s:s=s.replace(needle,needle+'\n    if (String(typeId).startsWith("shopuilook2:cartography_map_")) {\n        const dest = String(typeId).slice("shopuilook2:cartography_map_".length);\n        if (CG_MAP_ICONS[dest]) return CG_MAP_ICONS[dest];\n    }')
p.write_text(s)
# Append only; old texture indices and client property schemas remain identical.
vpath=R/'behavior_pack/scripts/showcase_visuals.js';v=vpath.read_text()
def const(name):return json.loads(re.search(r'export const '+name+r' = (.*?);',v).group(1))
flat=const('SC_FLAT_VISUALS');indices=const('SC_TEXTURE_INDEX');info=const('SC_DISPLAY_INFO')
rcpath=R/'resource_pack/render_controllers/showcase_item.render_controllers.json';rc=read(rcpath);array=rc['render_controllers']['controller.render.shopuilook2.showcase_model']['arrays']['textures']['Array.images']
clients=[R/'resource_pack/entity'/n for n in ['showcase_item.entity.json','showcase_display.entity.json']];entities=[read(p) for p in clients]
for dest,path in sorted(paths.items()):
 if path not in indices:
  index=len(array);assert index<4096;key='cm_'+icons[dest]
  for entity in entities:entity['minecraft:client_entity']['description']['textures'][key]=path
  array.append('Texture.'+key);indices[path]=index
 flat['shopuilook2:cartography_map_'+dest]=indices[path]
info['textures']=len(array)
for name,data in [('SC_FLAT_VISUALS',flat),('SC_TEXTURE_INDEX',indices),('SC_DISPLAY_INFO',info)]:v=re.sub(r'export const '+name+r' = .*?;',lambda _:'export const '+name+' = '+json.dumps(data,ensure_ascii=False,separators=(',',':'))+';',v)
vpath.write_text(v);write(rcpath,rc)
for path,entity in zip(clients,entities):write(path,entity)
reportpath=R/'tools/showcase_asset_report.json';report=read(reportpath);report['flat_item_ids']=len(flat);report['textures']=len(array);write(reportpath,report)
print('Preview maps:',len(dests),'official icon textures:',len(set(icons.values())),'display textures:',len(array))
