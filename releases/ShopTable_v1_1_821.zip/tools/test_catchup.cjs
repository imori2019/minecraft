// v1.1.799 チャンクを読み込ませ続けない代わりに、留守の間の分を戻ってきた時に進める
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');const {run}=require('./test_smelt_sales.cjs');
let n=0;const test=(name,fn)=>{fn();n++;console.log('PASS CATCHUP '+name);};
run(`globalThis.mkEnt=()=>{const p=new Map();return {getDynamicProperty:k=>p.get(k),setDynamicProperty:(k,v)=>p.set(k,v),p};};
 globalThis.calls=[];globalThis._fns={fzSmokerBreed,fzSpawnerGrow,fzBarrelGrow,cpGrow};
 fzSmokerBreed=(b,dt)=>calls.push(['smoker',dt]);fzSpawnerGrow=(b,dt)=>calls.push(['spawner',dt]);fzBarrelGrow=(b,dt)=>calls.push(['barrel',dt]);cpGrow=(b,dt)=>calls.push(['cp',dt]);
 WORLD_OFFLINE={from:0,to:0};`);
const J=s=>JSON.parse(run(`JSON.stringify(${s})`));
test('no chunk loading any more: the patrol always turns keep-loaded off',()=>{
 const src=fs.readFileSync(path.join(__dirname,'../behavior_pack/scripts/main.js'),'utf8');
 assert.ok(src.includes('const want = false;'));
});
test('a shop that was away for 10 minutes catches up 600 s, 30 s at a time, at most 20 steps per second',()=>{
 run(`calls.length=0;globalThis.e1=mkEnt();shopCatchUp(e1,{},false,1000000);`);assert.equal(run('calls.length'),0,'first visit: nothing owed');
 run(`calls.length=0;globalThis.done=shopCatchUp(e1,{},false,1000000+600000);`);
 assert.equal(run('done'),600);assert.equal(run('calls.length'),80,'20 steps x 4 growers');assert.ok(J('calls').every(c=>c[1]===30));
 assert.equal(run(`e1.getDynamicProperty(CATCHUP_LEFT_PROP)`),0);
});
test('regular 1-second patrols owe nothing; a long absence is capped at one day and drained over later patrols',()=>{
 run(`calls.length=0;globalThis.e2=mkEnt();shopCatchUp(e2,{},false,0+5);shopCatchUp(e2,{},false,1005);shopCatchUp(e2,{},false,2005);`);assert.equal(run('calls.length'),0);
 run(`calls.length=0;shopCatchUp(e2,{},false,2005+3*86400000);`);
 assert.equal(run(`e2.getDynamicProperty(CATCHUP_LEFT_PROP)`),86400-600);
 run(`calls.length=0;shopCatchUp(e2,{},false,2005+3*86400000+1000);`);assert.equal(run(`e2.getDynamicProperty(CATCHUP_LEFT_PROP)`),86400-1200);
});
test('while the shop screen is open, the owed time waits; time with the world closed does not count',()=>{
 run(`calls.length=0;globalThis.e3=mkEnt();shopCatchUp(e3,{},false,1000);shopCatchUp(e3,{},true,1000+120000);`);
 assert.equal(run('calls.length'),0);assert.equal(run(`e3.getDynamicProperty(CATCHUP_LEFT_PROP)`),120);
 run(`WORLD_OFFLINE={from:10000,to:3610000};`);   // 1時間閉じていた
 assert.equal(run('shopAwaySeconds(5000,3620000)'),15);
 run(`WORLD_OFFLINE={from:0,to:0};`);
});
test('only time-based shops (smoker, spawner, barrel, composter) use catch-up',()=>{
 assert.deepEqual(J('[...SHOP_CATCHUP_KINDS].sort()'),['barrel','composter','smoker','spawner']);
});
run(`Object.assign(globalThis,{});fzSmokerBreed=_fns.fzSmokerBreed;fzSpawnerGrow=_fns.fzSpawnerGrow;fzBarrelGrow=_fns.fzBarrelGrow;cpGrow=_fns.cpGrow;`);
console.log(n+' catch-up test groups passed (API simulation; Minecraft runtime not executed)');
