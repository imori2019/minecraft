// Simulated Bedrock API checks; not a Minecraft runtime test.
const assert=require('node:assert/strict');
const {run}=require('./test_smelt_sales.cjs');
let n=0;
function test(name,fn){fn();n++;console.log('PASS shop-music '+name);}
run(`globalThis.songLog=[];globalThis.musicBlocks=new Map();
 globalThis.MP={id:'music-test',dimension:{id:'minecraft:overworld',getBlock:pos=>musicBlocks.get(pos.x)},
 playMusic:(id,opt)=>songLog.push({id,opt}),queueMusic:()=>{},stopMusic:()=>songLog.push({stop:true})};
 shopBgmStoreRegistry=()=>({});shopBgmNearbyKey=()=>globalThis.musicKey;
 shopBgmNoteParticle=()=>{};
 globalThis.musicSet=(x,type)=>musicBlocks.set(x,{typeId:'shopuilook2:panel'+(type?'_'+type:'' )});
 globalThis.musicTick=(x)=>{musicKey='minecraft:overworld|'+x+',64,0';shopBgmPatrol([MP]);};`);
const value=s=>JSON.parse(run('JSON.stringify('+s+')'));
test('all 21 profiles resolve to the matching exact-track event',()=>{
 for(const [block,kind] of Object.entries({furnace:'furnace',blast_furnace:'blast',smoker:'smoker',spawner:'spawner',barrel:'barrel',composter:'composter',crafter:'crafter',smith:'smith',bulb:'bulb',bulb_exposed:'bulb_exposed',bulb_weathered:'bulb_weathered',bulb_oxidized:'bulb_oxidized',anchor:'anchor',lodestone:'lodestone',heart:'heart',fletch:'fletch',note:'note',endframe:'endframe',cartography:'cartography',enchant:'enchant',vault:'vault'})) {
  run(`musicSet(0,${JSON.stringify(block)});`);
  assert.equal(run(`shopBgmProfile(MP,'minecraft:overworld|0,64,0')`),'shopuilook2.music.'+(kind==='bulb_oxidized'?'bulb_weathered':kind));
 }
});
test('same assigned track continues; different shop switches exactly once and loops',()=>{
 run(`SH_BGM_LISTENERS.clear();SH_BGM_OFF.clear();songLog.length=0;musicSet(0,'heart');musicSet(1,'heart');musicSet(2,'furnace');musicTick(0);musicTick(1);musicTick(2);musicTick(2);`);
 assert.deepEqual(value('songLog.map(x=>x.id||"stop")'),['shopuilook2.music.heart','stop','shopuilook2.music.furnace']);
 assert.equal(value('songLog[0].opt.loop'),true);
});
test('the two nightly copper variants keep one song playing',()=>{
 run(`songLog.length=0;musicSet(4,'bulb_weathered');musicSet(5,'bulb_oxidized');musicTick(4);songLog.length=0;musicTick(5);`);
 assert.equal(value('songLog.length'),0);
});
test('OFF remains off across different shop profiles',()=>{
 run(`SH_BGM_OFF.add(MP.id);SH_BGM_LISTENERS.get(MP.id).bgmOn=false;songLog.length=0;musicTick(0);musicTick(2);`);
 assert.equal(value('songLog.length'),0);
});
test('returning to basic shop restores playlist; unreadable shop keeps playing',()=>{
 run(`SH_BGM_OFF.clear();SH_BGM_LISTENERS.clear();songLog.length=0;musicSet(3,'');musicTick(0);musicTick(9);musicTick(3);`);
 assert.equal(value('songLog.filter(x=>x.stop).length'),1);
 assert.equal(value('songLog.filter(x=>x.id).at(-1).id'),'record.chirp');
});
test('copper variants use the existing shop behavior and matching upper case',()=>{
 for(const variant of ['bulb_exposed','bulb_weathered','bulb_oxidized']){
  assert.equal(run(`fzKindOf({typeId:'shopuilook2:panel_${variant}'})`),'bulb');
  assert.equal(run(`isPanelType('shopuilook2:panel_${variant}')`),true);
  assert.equal(run(`isPanelUpperPart({typeId:'shopuilook2:panel_${variant}_case'})`),true);
 }
});
test('each copper variant places its own case and night lighting preserves both parts',()=>{
 run(`BlockPermutation.resolve=(id,states)=>({typeId:id,states});
   for (const variant of SH_BULB_VARIANTS) {
     let placed;
     const upper={typeId:'minecraft:air',setPermutation:p=>placed=p};
     const base={typeId:'shopuilook2:panel_'+variant,permutation:{getState:()=> 'west'},above:()=>upper};
     fzPlaceCase(base);
     if(placed?.typeId!==base.typeId+'_case'||placed.states['minecraft:cardinal_direction']!=='west') throw Error('wrong case');
     let upperLit=false,baseLit=false;
     upper.typeId=base.typeId+'_case';
     upper.permutation={getState:()=>false,withState:(k,v)=>({lit:v})};
     upper.setPermutation=p=>upperLit=p.lit;
     base.permutation={getState:()=>false,withState:(k,v)=>({lit:v})};
     base.setPermutation=p=>baseLit=p.lit;
     spIsDay=()=>false;fzUpdateLit(base,new Map());
     if(!upperLit||!baseLit)throw Error('night lighting failed');
   }`);
});
console.log(n+' shop-music groups passed');
