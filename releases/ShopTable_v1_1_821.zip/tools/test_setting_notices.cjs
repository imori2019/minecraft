const assert=require('node:assert/strict');
const {run,prep}=require('./test_smelt_sales.cjs');
(async()=>{
 prep();run(`globalThis.notices=[];globalThis.bars=[];player.sendMessage=t=>notices.push(t);player.onScreenDisplay={setActionBar:t=>bars.push(t)};SP_AUTO_BUY=null;
 ModalFormData=class{title(){return this}textField(){return this}toggle(){return this}submitButton(){return this}};
 canManageStore=()=>true;storeFormDone=()=>{};globalThis.formValues=['変更後の名前','説明',true];showFormWithRetry=async()=>({formValues});`);
 await run(`showStoreInfoForm(player,block.dimension,block.location,'s1')`);
 assert.equal(run('registry.stores.s1.name'),'変更後の名前');assert.equal(run('notices.length'),0);
 run(`formValues=['','説明',true]`);await run(`showStoreInfoForm(player,block.dimension,block.location,'s1')`);
 assert.equal(run('registry.stores.s1.name'),'変更後の名前');assert.equal(run('notices.length'),1);assert.match(run('notices[0]'),/店舗名を入力してください/);
 console.log('PASS successful store-name saving is silent while validation errors still reach chat');
 run(`notices=[];for(const text of ['§a[価格] 全体割引を保存しました','§7[店舗] この商品を店舗から外しました','§a[銅電球] パスワードを「1234」にしました'])tell(player,text);`);assert.equal(run('notices.length'),0);
 run(`for(const text of ['§c[店舗] 保存に失敗しました','§e[商品] 在庫が足りません','§a[文字入力] 反映しました。保存ボタンで確定してください','§a[文字入力] 設定を反映しました。自動保存できませんでした','§a[宝物庫] 入札しました','§a[ショップ] 商品とショップブロックを回収しました','§b[診断] 操作ログON'])tell(player,text);`);assert.equal(run('notices.length'),7);
 console.log('PASS settings completion notices are silent; errors, follow-up instructions, transactions and diagnostics remain');
 run(`shopActionBar(player,'§a[店舗] 基本情報を保存しました');shopActionBar(player,'§e下の段を押すと開きます');`);assert.equal(run('bars.length'),1);assert.match(run('bars[0]'),/下の段/);
 console.log('PASS action bars follow the same settings-notice rule without hiding interaction guidance');
})().catch(e=>{console.error(e);process.exitCode=1});
