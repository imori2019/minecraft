const assert=require('node:assert/strict'),fs=require('fs'),path=require('path');
const{run,prep,ctx,ItemStack}=require('./test_smelt_sales.cjs');let n=0;
function test(name,f){f();n++;console.log('PASS HELP '+name);}
const read=p=>JSON.parse(fs.readFileSync(path.join(__dirname,'..',p),'utf8'));
const visible=s=>s.replace(/§./g,'');const width=s=>[...visible(s)].reduce((a,c)=>a+(c.codePointAt(0)<=127?1:2),0);
function walk(o,f,p=''){if(Array.isArray(o))o.forEach(v=>walk(v,f,p));else if(o&&typeof o==='object'){f(o,p);for(const[k,v]of Object.entries(o))walk(v,f,p+'/'+k);}}
test('bullets remove parentheses, wrap at Japanese character boundaries and preserve all description content',()=>{
 const raw='§7材料庫を開いている間（全ての系列店が対象）は自動補充を停止します。説明の最後まで省略せず表示します。';
 const lines=JSON.parse(run(`JSON.stringify(shopHelpLines(${JSON.stringify(raw)},38))`));assert.ok(lines.length>1);assert.match(visible(lines[0]),/^・/);
 for(const line of lines){assert.ok(width(line)<=38);assert.doesNotMatch(line,/[()（）…]/u);}
 assert.equal(lines.map(visible).join('').replace(/[・　]/g,''),visible(run(`shopHelpPlain(${JSON.stringify(raw)})`)).replace(/[・　]/g,''));
});
test('real help slots retain text beyond 70 characters and use the existing 2/3 refresh protocol',()=>{
 prep();run(`globalThis.helpState={};globalThis.helpRec={extraMode:helpState};globalThis.originalHelpCommit=deferVisualCommit;deferVisualCommit=(p,r,apply)=>apply(block,shopInv);`);
 const long='§7'+('材料は同じ系列の倉庫から補充します。'.repeat(5))+'説明末尾';
 run(`fzPutText(shopInv,helpState,FZ_STAT_SLOTS[0],${JSON.stringify(long)})`);const text=run('shopInv.getItem(FZ_STAT_SLOTS[0]).nameTag');assert.ok(text.length>70);assert.match(text,/説明末尾$/);assert.doesNotMatch(text,/[()（）…]/u);
 const before=run('shopInv.getItem(FZ_STAT_SLOTS[0]).amount');run('fzCommitText(player,helpRec)');assert.equal(run('shopInv.getItem(FZ_STAT_SLOTS[0]).amount'),before===2?3:2);assert.equal(run('shopInv.getItem(FZ_STAT_SLOTS[0]).nameTag'),text);
 run('shopInv.setItem(FZ_STAT_SLOTS[1],new ItemStack("minecraft:diamond",7));fzPutText(shopInv,helpState,FZ_STAT_SLOTS[1],"説明");deferVisualCommit=originalHelpCommit;');assert.equal(run('shopInv.getItem(FZ_STAT_SLOTS[1]).typeId'),'minecraft:diamond');assert.equal(run('shopInv.getItem(FZ_STAT_SLOTS[1]).amount'),7);
});
test('function pages use fixed essential status labels without description scroll panes',()=>{
 const u=read('resource_pack/ui/shop_proceeds_screen.json');assert.equal(Object.keys(u).filter(k=>k.startsWith('shop_help_content_')).length,0);let labels=0,fields=0;
 walk(u,(o,p)=>{assert.ok(!p.endsWith('/shop_help_scroll@common.scrolling_panel'));if(p.endsWith('/minimal_status')){fields++;assert.deepEqual(o.size,[166,14]);assert.ok(o.offset[1]+o.size[1]<=244);walk(o,x=>{if(x.type==='label'){labels++;assert.deepEqual(x.size,[166,14]);assert.equal(x.bindings.find(b=>b.binding_name==='#hover_text').binding_condition,'visibility_changed');}});}});assert.equal(fields,6);assert.equal(labels,12);
});
test('authored UI explanations contain no parentheses; tooltips use bullet lines and no truncating ellipsis',()=>{
 let tips=0;for(const file of fs.readdirSync(path.join(__dirname,'../resource_pack/ui')).filter(p=>p.endsWith('.json'))){const d=read('resource_pack/ui/'+file);walk(d,o=>{if(typeof o.text==='string'&&/[ぁ-んァ-ヶ一-龯]/u.test(o.text))assert.doesNotMatch(o.text,/[()（）]/u);const tip=o.property_bag?.['#hover_text'];if(typeof tip==='string'){assert.doesNotMatch(tip,/[()（）]/u);if(tip.includes('\n')){tips++;for(const line of tip.split('\n').slice(1)){assert.match(line,/^[・　]/u);assert.ok(width(line)<=44);}}}});}assert.ok(tips>=10);
});
test('shop-item descriptions use bounded bullet lines and leave custom item data untouched',()=>{
 const catalog=JSON.parse(run('JSON.stringify(SHOP_BLOCK_LORE)'));for(const lines of Object.values(catalog))for(const line of lines){assert.doesNotMatch(line,/[()（）…]/u);assert.ok(width(line)<=40);assert.match(visible(line),/^[・　]/u);}
});
console.log(n+' description/visibility test groups passed (API/UI layout checks; native rendering not executed)');
