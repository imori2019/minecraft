// v1.1.701 鍛冶台：鍛冶型の欄 27マス・各マスの最後の1個は残す・材料で複製して売る
const assert=require('node:assert/strict');
const env=require('./test_smelt_sales.cjs');
const {run,prep}=env;
let count=0;
function test(name,fn){fn();count++;console.log('PASS SMITH '+name);}
const T='minecraft:sentry_armor_trim_smithing_template';
function setup(slots){ // slots: {index: {id,n}}
 prep();
 run(`block.typeId='shopuilook2:panel_smith';const m=Array(81).fill(null);for(const [i,x] of Object.entries(${JSON.stringify(slots)}))m[i]=x;
  registry.stores.s1.smith={smv:3,mats:m,made:0};
  saveProductIndex(block,['t1']);saveProduct(block,{id:'t1',savedOnce:true,settings:{shop_sale_type:0},items:[{id:'${T}',key:'${T}',role:'sample',slot:17,count:1}],stock:[]});`);
}
const stock=()=>run(`fzStockCountPlain(loadProduct(block,'t1'),'${T}')`);
const mats=()=>JSON.parse(run(`JSON.stringify(registry.stores.s1.smith.mats)`));
test('a template slot with only one template is kept: nothing is sold (sold out) without materials',()=>{
 setup({27:{id:T,n:1}});run(`crCraft(block)`);
 assert.equal(stock(),0);assert.equal(mats()[27].n,1);
 assert.equal(run(`shopPurchaseRemaining(loadProduct(block,'t1'))`),0);
});
test('extra templates in a slot (all but the last one) go to the product stock',()=>{
 setup({27:{id:T,n:5},39:{id:T,n:3}});run(`crCraft(block)`);
 assert.equal(stock(),6);assert.equal(mats()[27].n,1);assert.equal(mats()[39].n,1);
});
test('with 7 diamonds + cobblestone one template is duplicated from the kept master (master stays)',()=>{
 setup({0:{id:'minecraft:diamond',n:14},1:{id:'minecraft:cobblestone',n:2},27:{id:T,n:1}});run(`crCraft(block)`);
 assert.equal(stock(),1);assert.equal(mats()[27].n,1);assert.equal(mats()[0].n,7);assert.equal(mats()[1].n,1);
 run(`crCraft(block)`);assert.equal(stock(),2);assert.equal(mats()[0],null);
 run(`crCraft(block)`);assert.equal(stock(),2,'no more diamonds');
});
test('no template in the template slots means no duplication even with materials',()=>{
 setup({0:{id:'minecraft:diamond',n:14},1:{id:'minecraft:cobblestone',n:2}});run(`crCraft(block)`);
 assert.equal(stock(),0);
});
test('trim and netherite upgrade never use the last template in a slot',()=>{
 setup({27:{id:T,n:1},28:{id:'minecraft:netherite_upgrade_smithing_template',n:1}});
 assert.equal(run(`smUse(registry.stores.s1.smith.mats,'${T}')`),undefined);
 run(`registry.stores.s1.smith.mats[27].n=2;`);
 assert.equal(run(`smUse(registry.stores.s1.smith.mats,'${T}')[27].n`),1);
 assert.equal(run(`JSON.stringify(crPlan(registry.stores.s1.smith.mats,[['i','minecraft:netherite_upgrade_smithing_template',1]],smReserve(registry.stores.s1.smith.mats)))`),undefined);
});
test('old layouts are moved to the v1.1.762 layout when read (materials 0-26, templates 27-53, trim 54-80)',()=>{
 prep();
 run(`const m=Array(36).fill(null);m[0]={id:'minecraft:iron_ingot',n:5};m[20]={id:'${T}',n:2};m[27]={id:'minecraft:diamond',n:3};m[35]={id:'minecraft:redstone',n:4};
  registry.stores.s1.smith={mats:m,made:0};globalThis.cs=crState(registry.stores.s1,'smith');`);
 const m=JSON.parse(run(`JSON.stringify(cs.mats)`));
 assert.equal(m.length,81);assert.equal(m[0].n,5);assert.equal(m[29].id,T,'v1 template slot 20 -> 29');
 assert.equal(m[54].id,'minecraft:diamond');assert.equal(m[62].id,'minecraft:redstone');
 assert.equal(run(`cs.smv`),3);
 run(`const m2=Array(54).fill(null);m2[3]={id:'minecraft:iron_ingot',n:1};m2[18]={id:'${T}',n:2};m2[44]={id:'${T}',n:1};m2[45]={id:'minecraft:diamond',n:3};globalThis.c2=crState({smith:{smv:2,mats:m2}},'smith');`);
 const m2=JSON.parse(run(`JSON.stringify(c2.mats)`));
 assert.equal(m2[3].id,'minecraft:iron_ingot');assert.equal(m2[27].id,T);assert.equal(m2[53].id,T);assert.equal(m2[54].id,'minecraft:diamond');
 assert.equal(run(`crState({smith:{smv:3,mats:cs.mats}},'smith').mats[54].id`),'minecraft:diamond','already-new data is not moved again');
});
test('slot rules: 27-53 templates only, 54-80 trim materials only',()=>{
 assert.equal(run(`smSlotOk(53,'${T}')`),true);assert.equal(run(`smSlotOk(53,'minecraft:diamond')`),false);
 assert.equal(run(`smSlotOk(54,'minecraft:diamond')`),true);assert.equal(run(`smSlotOk(54,'${T}')`),false);
 assert.equal(run(`smSlotOk(26,'minecraft:iron_ingot')`),true);
 assert.equal(run(`SM_MAT_SLOTS.length`),81);assert.equal(new Set(JSON.parse(run(`JSON.stringify(SM_MAT_SLOTS)`))).size,81);
});
function setupGear(id,slots){
 prep();
 run(`block.typeId='shopuilook2:panel_smith';const m=Array(81).fill(null);for(const [i,x] of Object.entries(${JSON.stringify(slots)}))m[i]=x;
  registry.stores.s1.smith={smv:3,mats:m,made:0};
  saveProductIndex(block,['g1']);saveProduct(block,{id:'g1',savedOnce:true,settings:{shop_sale_type:0},items:[{id:'${'${id}'}',key:'${'${id}'}',role:'sample',slot:17,count:1}],stock:[]});`.replaceAll('${id}',id));
}
const gear=id=>run(`fzStockCountPlain(loadProduct(block,'g1'),'${'${id}'}')`.replaceAll('${id}',id));
test('plain weapons and armor are no longer crafted at the smithing table (left to the blast furnace)',()=>{
 setupGear('minecraft:diamond_sword',{0:{id:'minecraft:diamond',n:64},1:{id:'minecraft:stick',n:64}});run(`crCraft(block)`);
 assert.equal(gear('minecraft:diamond_sword'),0);
 setupGear('minecraft:iron_chestplate',{0:{id:'minecraft:iron_ingot',n:64}});run(`crCraft(block)`);
 assert.equal(gear('minecraft:iron_chestplate'),0);
});
test('netherite upgrade still works and keeps the last upgrade template in its slot',()=>{
 setupGear('minecraft:netherite_sword',{0:{id:'minecraft:diamond_sword',n:1},1:{id:'minecraft:netherite_ingot',n:2},27:{id:'minecraft:netherite_upgrade_smithing_template',n:2}});
 run(`crCraft(block)`);assert.equal(gear('minecraft:netherite_sword'),1);
 assert.equal(run(`registry.stores.s1.smith.mats[27].n`),1);
 run(`registry.stores.s1.smith.mats[0]={id:'minecraft:diamond_sword',n:1};crCraft(block)`);
 assert.equal(gear('minecraft:netherite_sword'),1,'only one template left: kept, no more upgrades');
});
console.log(count+' smith template test groups passed');
