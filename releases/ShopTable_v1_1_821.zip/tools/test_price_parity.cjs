// Price payloads are read on generation changes; their computed text uses one expression.
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const d=JSON.parse(fs.readFileSync(path.join(__dirname,'../resource_pack/ui/shop_layout_price.json'),'utf8'));
let pairs=0,auto=0;
(function w(o){if(!o||typeof o!=='object')return;
 if(['panel','stack_panel'].includes(o.type)&&o.controls?.length===2&&o.controls[0].e&&o.controls[1].o){
  pairs++;const labels=[o.controls[0].e,o.controls[1].o],payloads=[];
  for(const c of labels){
   assert.equal(c.type,'label');const hv=c.bindings.filter(b=>b.binding_name==='#hover_text');assert.equal(hv.length,1);assert.equal(hv[0].binding_condition,'visibility_changed');payloads.push(hv[0].binding_name_override);
   const final=c.bindings.filter(b=>b.target_property_name==='#text');assert.equal(final.length,1);assert.notEqual(final[0].binding_condition,'visibility_changed');
   const props=[...new Set((final[0].source_property_name.match(/'[^']*'|#[A-Za-z_][A-Za-z0-9_]*/g)||[]).filter(t=>t.startsWith('#')))];assert.deepEqual(props,[hv[0].binding_name_override],'final text must depend only on its own raw payload');
   assert.ok(!c.bindings.some(b=>b.binding_type==='view'&&!['#text','#visible','#font_type'].includes(b.target_property_name)),'no computed intermediate properties');
  }
  assert.notEqual(payloads[0],payloads[1],'even and odd payloads are independent');
  if(Array.isArray(labels[0].size)&&labels[0].size.includes('default')){auto++;assert.equal(o.type,'stack_panel');assert.equal(o.size[0],'100%c');}
 }
 for(const v of Object.values(o))w(v);})(d);
assert.equal(pairs,612);assert.ok(auto>=150);
console.log(`PASS PRICE PARITY ${pairs} independent even/odd pairs (${auto} auto-width): latched reads and direct text expressions`);
