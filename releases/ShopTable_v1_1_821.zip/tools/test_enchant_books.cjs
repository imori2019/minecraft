// v1.1.774 エンチャントテーブル：ランダムなエンチャント本を5つまで作って売る（最初は最大レベル、売れたら完全ランダムで補充）
const assert=require('node:assert/strict');
const {run,prep}=require('./test_smelt_sales.cjs');
let count=0;function test(name,fn){fn();count++;console.log('PASS BOOKS '+name);}
function setup(mats,levels){prep();run(`block.typeId='shopuilook2:panel_enchant';const m=Array(54).fill(null);for(const [i,x] of Object.entries(${mats}))m[i]=x;
 registry.stores.s1.enchant={auto:false,levels:${levels},mats:m,made:0};
 EnchantmentTypes.getAll=()=>[{id:'minecraft:sharpness',maxLevel:5},{id:'minecraft:unbreaking',maxLevel:3},{id:'minecraft:mending',maxLevel:1},{id:'minecraft:binding',maxLevel:1},{id:'minecraft:vanishing',maxLevel:1}];`);}
const rbList=()=>JSON.parse(run(`JSON.stringify(registry.stores.s1.enchant.rb?.[panelKeyOf(block.dimension,block.location)]??[])`));
const listings=()=>JSON.parse(run(`JSON.stringify((registry.stores.s1.enchant.rb?.[panelKeyOf(block.dimension,block.location)]??[]).map(e=>({e,r:loadProduct(block,e.pid)})).map(({e,r})=>({id:r.id,name:r.settings.shop_product_name,n:String(e.n),sellAll:r.sellAll,stock:(r.stock??[]).reduce((a,x)=>a+x.item.amount,0),ench:(r.stock?.[0]?.item?.enchantments??null),key:r.items[0]?.key,price:r.settings.shop_payment_method})))`));
const ench=id=>JSON.parse(run(`JSON.stringify((()=>{const r=loadProduct(block,${JSON.stringify(id)});const it=restoreItemStack(r.stock[0].item);return it.getComponent('minecraft:enchantable').getEnchantments().map(e=>[e.type.id??e.type,e.level])})())`));
test('with plain books, five listings are made, each with one max-level book; never curses; nothing is made without books',()=>{
 for(let r=0;r<10;r++){
  setup(`{0:{id:'minecraft:book',n:10},1:{id:'minecraft:lapis_lazuli',n:64}}`,100);
  run('crCraft(block)');
  const L=listings();assert.equal(L.length,5);
  for(const l of L){assert.equal(l.stock,1);assert.equal(l.n,'1');assert.equal(l.price,0,'no price until the owner sets one');
   const e=ench(l.id);assert.equal(e.length,1);const [id,lv]=e[0];
   assert.ok(!['minecraft:binding','minecraft:vanishing'].includes(id));
   assert.equal(lv,{"minecraft:sharpness":5,"minecraft:unbreaking":3,"minecraft:mending":1}[id],'first book is max level');}
  const c=JSON.parse(run('JSON.stringify(registry.stores.s1.enchant)'));
  const sum=L.reduce((a,l)=>a+ench(l.id)[0][1],0);
  assert.equal(c.mats[0].n,5,'one plain book per listing');assert.equal(c.mats[1].n,64-sum);assert.equal(c.levels,100-L.reduce((a,l)=>a+Math.ceil(ench(l.id)[0][1]/2),0));
  run('crCraft(block)');assert.equal(listings().length,5,'no more than five; full listings are left alone');assert.equal(JSON.parse(run('JSON.stringify(registry.stores.s1.enchant)')).mats[0].n,5);
 }
 setup(`{1:{id:'minecraft:lapis_lazuli',n:64}}`,100);run('crCraft(block)');assert.equal(listings().length,0);
});
test('a sold listing gets a new, completely random book (any type, any level), keeping its price settings',()=>{
 const levels=new Set();
 for(let r=0;r<40;r++){
  setup(`{0:{id:'minecraft:book',n:64},1:{id:'minecraft:lapis_lazuli',n:64},2:{id:'minecraft:lapis_lazuli',n:64}}`,500);
  run('crCraft(block)');const L=listings();const id=L[0].id;
  run(`(()=>{const r=loadProduct(block,${JSON.stringify(id)});r.settings.shop_payment_method=1;r.settings.price='7';r.stock=[];saveProduct(block,r)})()`);
  run('crCraft(block)');
  const after=listings().find(l=>l.id===id);assert.equal(after.stock,1);assert.equal(after.n,'2');
  const p=JSON.parse(run(`JSON.stringify(loadProduct(block,${JSON.stringify(id)}).settings)`));assert.equal(p.price,'7');assert.equal(p.shop_payment_method,1);
  const [[eid,lv]]=ench(id);assert.ok(lv>=1&&lv<={"minecraft:sharpness":5,"minecraft:unbreaking":3,"minecraft:mending":1}[eid]);levels.add(eid+lv);
  assert.equal(after.name.length>0,true);
 }
 assert.ok(levels.size>=4,'replacements vary in type and level');
});
test('short lapis or levels: the first book picks an affordable max-level type, or waits',()=>{
 setup(`{0:{id:'minecraft:book',n:5},1:{id:'minecraft:lapis_lazuli',n:1}}`,1);
 run('crCraft(block)');const L=listings();
 assert.equal(L.length,1,'only mending I (1 lapis, 1 level) is affordable');assert.deepEqual(ench(L[0].id),[['minecraft:mending',1]]);
 setup(`{0:{id:'minecraft:book',n:5}}`,10);run('crCraft(block)');assert.equal(listings().length,0);
});
test('the listing sells the real enchanted book: sample key matches the stocked book',()=>{
 setup(`{0:{id:'minecraft:book',n:2},1:{id:'minecraft:lapis_lazuli',n:64}}`,50);run('crCraft(block)');
 for(const l of listings()){assert.equal(run(`itemKey(restoreItemStack(loadProduct(block,${JSON.stringify(l.id)}).stock[0].item))`),l.key);assert.ok(l.key.startsWith('minecraft:enchanted_book'));}
});
test('end to end: a buyer gets the real book and the listing is refilled with a new random book at once',()=>{
 setup(`{0:{id:'minecraft:book',n:10},1:{id:'minecraft:lapis_lazuli',n:64}}`,100);
 run(`globalThis.p1=loadProduct(block,'p1');`);run('crCraft(block)');const id=listings()[0].id;const before=ench(id);
 run(`(()=>{const r=loadProduct(block,${JSON.stringify(id)});const keep={shop_product_name:r.settings.shop_product_name,shop_product_genre:r.settings.shop_product_genre};
  r.settings={...p1.settings,...keep,shop_sale_type:0};saveProduct(block,r)})()`);
 run(`globalThis.result=shopPurchaseCommit(player,block,${JSON.stringify(id)},1)`);
 assert.equal(run('result.ok'),true,run('result.message'));
 const got=JSON.parse(run(`JSON.stringify([...playerInv.items.values(),...shopInv.items.values()].filter(i=>i.typeId==='minecraft:enchanted_book'&&!isDisplayClone(i)).map(i=>i.getComponent('minecraft:enchantable').getEnchantments().map(e=>[e.type.id??e.type,e.level])))`));
 assert.deepEqual(got,[before],'the buyer receives exactly the listed book');
 const after=listings().find(l=>l.id===id);assert.equal(after.stock,1,'refilled right after the sale');assert.equal(after.n,'2');
});
test('v775: the owner opening the listing in the product editor and saving (to set a price) keeps it a random-book listing',()=>{
 setup(`{0:{id:'minecraft:book',n:10},1:{id:'minecraft:lapis_lazuli',n:64}}`,100);run('crCraft(block)');const id=listings()[0].id;const book=ench(id);
 const edit=()=>run(`props.set(LAYOUT_MIGRATION_PROP,1);active.clear();globalThis.editor=makeRecord(player,block,shopInv);editor.landing=true;active.set(player.id,editor);enterProduct(player,editor,block,shopInv,${JSON.stringify(id)});globalThis.editor=active.get(player.id);setStringProp(block,'price','5');globalThis.res=runProductExit(player,editor,block,shopInv,'save');`);
 edit();
 let l=listings().find(x=>x.id===id);assert.equal(l.sellAll,true,'sellAll survives the editor save');assert.equal(l.stock,1,'the book is still in stock');assert.deepEqual(ench(id),book);
 assert.equal(run(`shopKeepPairSplit(loadProduct(block,${JSON.stringify(id)}))`),undefined,'the last book is sellable');
 assert.equal(run(`shopPurchaseStockPlan(loadProduct(block,${JSON.stringify(id)}),1).ok`),true);
 // 売り切れ・材料なしの時に店主が保存しても、本が入ったら同じ商品に次の本が並ぶ
 run(`registry.stores.s1.enchant.mats=registry.stores.s1.enchant.mats.map((m,i)=>i===0?null:m);(()=>{const r=loadProduct(block,${JSON.stringify(id)});r.stock=[];saveProduct(block,r)})();crCraft(block)`);
 assert.equal(listings().find(x=>x.id===id).stock,0);edit();
 run(`registry.stores.s1.enchant.mats[0]={id:'minecraft:book',n:3};crCraft(block)`);
 l=listings().find(x=>x.id===id);assert.equal(l.stock,1);assert.equal(l.n,'2');assert.equal(l.sellAll,true);assert.equal(listings().length,5,'still five listings, no duplicates');
});
test('a listing the owner deletes is forgotten and a new one takes its place',()=>{
 setup(`{0:{id:'minecraft:book',n:10},1:{id:'minecraft:lapis_lazuli',n:64}}`,100);run('crCraft(block)');const id=listings()[0].id;
 run(`saveProductIndex(block,loadProductIndex(block).filter(x=>x!==${JSON.stringify(id)}))`);run('crCraft(block)');
 const L=listings();assert.equal(L.length,5);assert.ok(!L.some(x=>x.id===id));
});
console.log(count+' random enchanted book tests passed (API simulation; no Minecraft runtime)');
