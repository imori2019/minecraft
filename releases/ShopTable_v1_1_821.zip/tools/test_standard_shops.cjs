const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {run,prep,ctx,Container}=require('./test_smelt_sales.cjs');
const root=path.resolve(__dirname,'..'),read=p=>JSON.parse(fs.readFileSync(path.join(root,p),'utf8'));
const shops=read('tools/standard_shops757.json').shops;let count=0;
function test(n,f){f();count++;console.log('PASS STANDARD '+n)}
test('all 20 ordinary shop blocks, cases, items, geometry and texture references resolve',()=>{
 assert.equal(shops.length,20);assert.equal(new Set(shops.map(s=>s.id)).size,20);assert.equal(shops.filter(s=>s.id==='shopuilook2:panel').length,1);
 const terrain=read('resource_pack/textures/terrain_texture.json').texture_data,itemAtlas=read('resource_pack/textures/item_texture.json').texture_data;
 for(const shop of shops){
  assert.ok(!/bookshelf|infested/.test(shop.id));const stem=shop.id.split(':')[1];
  for(const upper of [false,true]){
   const b=read('behavior_pack/blocks/'+stem+(upper?'_case':'')+'.json')['minecraft:block'];assert.equal(b.description.identifier,shop.id+(upper?'_case':''));assert.equal(b.components['minecraft:geometry'],'geometry.shopuilook2.standard_shop_'+(upper?'upper':'lower'));assert.equal(b.description.states,undefined);assert.ok(!b.permutations.some(p=>p.condition.includes('lit')));
   assert.equal(b.components['minecraft:material_instances']['*'].texture,'shopuilook2_'+shop.asset);
   if(upper){assert.equal(b.description.menu_category.category,'none');assert.equal(b.components['minecraft:loot'],'loot_tables/empty.json')}else assert.equal(b.components['minecraft:item_visual'].geometry,'geometry.shopuilook2.standard_shop_upper');
  }
  const item=read('behavior_pack/items/'+stem+'.json')['minecraft:item'];assert.equal(item.components['minecraft:block_placer'].block,shop.id);assert.equal(item.components['minecraft:block_placer'].replace_block_item,true);
  for(const [atlas,key] of [[terrain,'shopuilook2_'+shop.asset],[itemAtlas,item.components['minecraft:icon'].textures.default]])assert.ok(fs.existsSync(path.join(root,'resource_pack',atlas[key].textures+'.png')));
 }
 assert.ok(!JSON.stringify(read('behavior_pack/blocks/panel.json')).includes('full_block'));assert.ok(!JSON.stringify(terrain.shopuilook2_panel).includes('crafting_table'));
});
test('ordinary shop registration has no fuel, processing settings or special BGM',()=>{
 prep();run(`globalThis.standardDim={id:block.dimension.id,getBlock:()=>block};player.dimension=standardDim;`);
 for(const shop of shops){ctx.standardId=shop.id;run(`block.typeId=standardId;`);assert.equal(run('isPanelType(standardId)'),true);assert.equal(run('fzKindOf(block)'),undefined);assert.equal(run('isFurnaceShop(block)'),false);assert.equal(run('lxExtraBtnCount(block)'),2);assert.equal(run('shopCaseId(block)'),shop.id+'_case');assert.equal(run('shopCaseBaseId(standardId+"_case")'),shop.id);assert.equal(run('shopBgmProfile(player,block.dimension.id+"|0,64,0")'),'default');}
});
test('placing any standard shop adds its matching case and respects occupied space',()=>{
 run(`BlockPermutation.resolve=(typeId,states)=>({typeId,states});globalThis.placed=[];globalThis.upperType='minecraft:air';block.permutation={getState:()=> 'east'};block.above=()=>({typeId:upperType,setPermutation:p=>placed.push(p)});`);
 for(const shop of shops){ctx.standardId=shop.id;run(`placed=[];block.typeId=standardId;upperType='minecraft:air';fzPlaceCase(block)`);assert.equal(run('placed.length'),1);assert.equal(run('placed[0].typeId'),shop.id+'_case');assert.equal(run('placed[0].states["minecraft:cardinal_direction"]'),'east');run(`placed=[];upperType='minecraft:stone';fzPlaceCase(block)`);assert.equal(run('placed.length'),0);}
});
test('all variants keep existing saved products, show all 27 listings, and execute ordinary purchases',()=>{
 for(const shop of shops){ctx.shopInv=new Container(640);prep();ctx.standardId=shop.id;run(`block.typeId='shopuilook2:panel';active.clear();PANEL_OCCUPANTS.clear();registry.stores.s1.pricePointSystem=normalizePricePointSystemSettings({});putProducts(Array.from({length:27},(_,i)=>base('std'+i,'minecraft:apple')));globalThis.originalStore=getBlockStoreId(block);block.typeId=standardId;globalThis.stdRec={};enterShopMode(player,stdRec,block,shopInv);`);assert.equal(run('getBlockStoreId(block)'),run('originalStore'));assert.equal(run('stdRec.shopMode.cells.size'),27);assert.equal(run('[...stdRec.shopMode.model.records.keys()].some(id=>id.startsWith("baked:"))'),false);run(`globalThis.stockBefore=loadProduct(block,'std0').stock[0].item.amount;globalThis.purchase=shopPurchaseCommit(player,block,'std0',1);`);assert.equal(run('purchase.ok'),true,shop.id);assert.equal(run('loadProduct(block,"std0").stock[0].item.amount'),run('stockBefore')-1);}
});
console.log(count+' standard shop groups passed; Bedrock API simulation, no native rendering');
