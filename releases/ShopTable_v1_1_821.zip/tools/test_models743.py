from pathlib import Path
from PIL import Image
import json,base64,hashlib,io
r=Path(__file__).resolve().parents[1];report=json.loads((r/'tools/shop_assets743.json').read_text())
for row in report['models']:
 kind=row['kind'];raw=(r/row['source']).read_bytes();assert hashlib.sha256(raw).hexdigest()==row['source_sha256'];src=json.loads(raw);texture=src['textures'][0];image=base64.b64decode(texture['source'].split(',')[1]);assert (r/f'resource_pack/textures/shopuilook2/blocks/{kind}_shop.png').read_bytes()==image
 im=Image.open(io.BytesIO(image));geo=json.loads((r/f'resource_pack/models/blocks/{kind}_shop.geo.json').read_text())['minecraft:geometry'];assert [len(g['bones'][0]['cubes']) for g in geo]==[5,9]
 groups=[[e for e in src['elements'] if e['to'][1]<=8],[e for e in src['elements'] if e['to'][1]>8]];faces=0
 for i,g in enumerate(geo):
  assert [g['description']['texture_width'],g['description']['texture_height']]==list(im.size)
  assert g['description']['identifier']==f'geometry.shopuilook2.{kind}_shop_'+['lower','upper'][i]
  for authored,cube in zip(groups[i],g['bones'][0]['cubes']):
   a,b=authored['from'],authored['to'];assert cube['origin']==[-b[0],a[1]+8-16*i,a[2]];assert cube['size']==[b[j]-a[j] for j in range(3)]
   assert set(cube['uv'])=={face for face,v in authored['faces'].items() if v.get('texture') is not None},'do not render faces deliberately removed in Blockbench'
   for face,v in cube['uv'].items():
    faces+=1;u0,v0= v['uv'];du,dv=v['uv_size'];assert 0<=min(u0,u0+du)<=max(u0,u0+du)<=im.width;assert 0<=min(v0,v0+dv)<=max(v0,v0+dv)<=im.height
    # Compare UV endpoints in normalized texture space, including reversed
    # up/down coordinates and the barrel's 32-unit UVs over a 16px PNG.
    a0,b0,a1,b1=authored['faces'][face]['uv'];expected=[a0/texture['uv_width'],b0/texture['uv_height'],a1/texture['uv_width'],b1/texture['uv_height']]
    if face in ['up','down']:expected=expected[2:]+expected[:2]
    assert [u0/im.width,v0/im.height,(u0+du)/im.width,(v0+dv)/im.height]==expected
 assert faces==60
 for suffix,index in [('',0),('_case',1)]:
  block=json.loads((r/f'behavior_pack/blocks/panel_{kind}{suffix}.json').read_text())['minecraft:block']['components'];assert block['minecraft:geometry']==geo[index]['description']['identifier'];assert block['minecraft:material_instances']['*']['texture']==f'shopuilook2_{kind}_shop'
  if not suffix:assert block['minecraft:item_visual']['geometry']==geo[1]['description']['identifier']
 print('PASS',kind,'matches supplied Blockbench geometry, embedded PNG, all 60 textured faces and inventory upper model')
print('PASS barrel UV scale is normalized without resampling or replacing the supplied PNG; native rendering not executed')
