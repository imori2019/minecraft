// v1.1.797 スポナー・宝物庫・エンドポータルフレームを手に入れられる／置いたフレームではエンドポータルを作れない
const assert=require('node:assert/strict');const {run}=require('./test_smelt_sales.cjs');
let n=0;const test=(name,fn)=>{fn();n++;console.log('PASS OBTAIN '+name);};
run(`globalThis.drops=[];globalThis.mkDim=()=>({id:'minecraft:overworld',spawnItem:(it,l)=>{drops.push([it.typeId,it.amount,l]);}});
 globalThis.mkTool=(id,eff=0)=>id?{typeId:id,getComponent:k=>k==='minecraft:enchantable'?{getEnchantment:e=>e==='efficiency'&&eff?{level:eff}:undefined}:undefined}:undefined;
 globalThis.mkPlayer=(mode,hand)=>({id:'pp',typeId:'minecraft:player',getGameMode:()=>mode,bar:'',onScreenDisplay:{setActionBar(t){this.last=t;}},playSound(){},getComponent:k=>k==='minecraft:equippable'?{getEquipment:()=>hand}:undefined});
 globalThis.brk=(id,mode,tool)=>{drops.length=0;obtainOnBreak({player:mkPlayer(mode),itemStackBeforeBreak:tool,brokenBlockPermutation:{type:{id}},dimension:mkDim(),block:{location:{x:3,y:64,z:-2}}});return drops.map(d=>d[0]);};`);
const J=s=>JSON.parse(run(`JSON.stringify(${s})`));
test('spawner drops with any pickaxe; vault only with diamond/netherite (like obsidian); never in creative or by hand',()=>{
 assert.deepEqual(J(`brk('minecraft:mob_spawner','Survival',mkTool('minecraft:wooden_pickaxe'))`),['minecraft:mob_spawner']);
 assert.deepEqual(J(`brk('minecraft:vault','Survival',mkTool('minecraft:iron_pickaxe'))`),[]);
 assert.deepEqual(J(`brk('minecraft:vault','Survival',mkTool('minecraft:diamond_pickaxe'))`),['minecraft:vault']);
 assert.deepEqual(J(`brk('minecraft:vault','Survival',mkTool('minecraft:netherite_pickaxe'))`),['minecraft:vault']);
 assert.deepEqual(J(`brk('minecraft:vault','Creative',mkTool('minecraft:diamond_pickaxe'))`),[]);
 assert.deepEqual(J(`brk('minecraft:mob_spawner','Survival',undefined)`),[]);
 assert.deepEqual(J(`brk('minecraft:stone','Survival',mkTool('minecraft:diamond_pickaxe'))`),[]);
});
test('obsidian timing: 188 ticks (diamond), 167 (netherite), efficiency speeds it up; lower tiers cannot',()=>{
 assert.equal(run(`obsidianTicks(mkTool('minecraft:diamond_pickaxe'))`),188);assert.equal(run(`obsidianTicks(mkTool('minecraft:netherite_pickaxe'))`),167);
 assert.equal(run(`obsidianTicks(mkTool('minecraft:diamond_pickaxe',5))`),45);assert.equal(run(`obsidianTicks(mkTool('minecraft:iron_pickaxe'))===Infinity`),true);
});
const hitFor=(ticks,step,tool,eye=true)=>run(`(()=>{drops.length=0;EPF_HITS.clear();globalThis.frame={typeId:'minecraft:end_portal_frame',dimension:mkDim(),location:{x:1,y:2,z:3},permutation:{getState:k=>k==='end_portal_eye_bit'&&${eye}},setType(t){this.typeId=t;}};
 const pl=mkPlayer('Survival',${tool});let broke=false;const t0=system.currentTick;for(let t=0;t<=${ticks}&&!broke;t+=${step}){system.currentTick=t0+t;broke=epfOnHit({damagingEntity:pl,hitBlock:frame});}system.currentTick=t0;return broke;})()`);
test('end portal frame breaks after obsidian time of continuous hitting, dropping itself and its eye',()=>{
 assert.equal(hitFor(180,10,"mkTool('minecraft:diamond_pickaxe')"),false,'not yet at 180 ticks');
 assert.equal(hitFor(200,10,"mkTool('minecraft:diamond_pickaxe')"),true);
 assert.deepEqual(J('drops.map(d=>d[0])'),['minecraft:end_portal_frame','minecraft:ender_eye']);
 assert.equal(hitFor(400,30,"mkTool('minecraft:diamond_pickaxe')"),false,'gaps over 1 second restart the count');
 assert.equal(hitFor(400,5,"mkTool('minecraft:iron_pickaxe')"),false,'iron pickaxe never breaks it');
});
test('a player-placed frame refuses ender eyes; natural frames still take them; breaking forgets the place',()=>{
 run(`world.setDynamicProperty(EPF_PLACED_PROP,undefined);globalThis.pf={typeId:'minecraft:end_portal_frame',dimension:{id:'minecraft:overworld'},location:{x:10,y:20,z:30}};epfOnPlace({block:pf});`);
 const ev=run(`(()=>{const e={block:pf,itemStack:{typeId:'minecraft:ender_eye'},player:mkPlayer('Survival'),cancel:false};epfBlockEye(e);return e.cancel;})()`);
 assert.equal(ev,true,'eye refused in a placed frame');
 assert.equal(run(`(()=>{const e={block:{typeId:'minecraft:end_portal_frame',dimension:{id:'minecraft:overworld'},location:{x:0,y:30,z:0}},itemStack:{typeId:'minecraft:ender_eye'},cancel:false};epfBlockEye(e);return e.cancel;})()`),false,'natural frame ok');
 assert.equal(run(`(()=>{const e={block:pf,itemStack:{typeId:'minecraft:stone'},cancel:false};epfBlockEye(e);return e.cancel;})()`),false,'other items untouched');
 run(`EPF_HITS.clear();pf.permutation={getState:()=>false};pf.setType=function(t){this.typeId=t};pf.dimension=mkDim();const pl=mkPlayer('Survival',mkTool('minecraft:netherite_pickaxe',5));const t0=system.currentTick;for(let t=0;t<100;t+=5){system.currentTick=t0+t;if(epfOnHit({damagingEntity:pl,hitBlock:pf}))break;}system.currentTick=t0;`);
 assert.equal(run(`epfPlaced().has('minecraft:overworld|10,20,30')`),false);
});
console.log(n+' obtain-block test groups passed (API simulation; Minecraft runtime not executed)');
