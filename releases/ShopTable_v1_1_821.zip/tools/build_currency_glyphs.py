#!/usr/bin/env python3
"""Append currency glyphs without renumbering existing glyphs. Requires Pillow.
Uses the same pinned Mojang resource checkout as build_showcase_assets.py.
"""
from pathlib import Path
from PIL import Image
import argparse,json,re,hashlib,math,subprocess
R=Path(__file__).resolve().parents[1];ap=argparse.ArgumentParser();ap.add_argument('--vanilla-root',type=Path,required=True);V=ap.parse_args().vanilla_root
PIN='15701fa9c13923f12662984c32c124327e40e3d3';assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=V,text=True).strip()==PIN
FONTS=R/'resource_pack/font';MAIN=R/'behavior_pack/scripts/main.js';REG=R/'tools/currency_glyph_registry.json'
def read(p):return json.loads(re.sub(r'^\s*//.*$','',p.read_text(encoding='utf-8-sig'),flags=re.M))
def dump(p,d):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
s=MAIN.read_text();m=re.search(r'const SHOP_GLYPHS = (\{[^\n]+\});',s);current=json.loads(m.group(1));prior=read(REG) if REG.exists() else {'additions':{}}
excluded_blocks=set(prior.get('excluded_blocks',[]))
wiki_path=R/'tools/wiki_block_glyph_sources.json'
wiki=read(wiki_path) if wiki_path.exists() else {'images':{},'shared':{}}
base={k:v for k,v in current.items() if k not in prior['additions'] and k not in excluded_blocks};glyphs=dict(base)
def const(name,text):return json.loads(re.search(r'export const '+name+r' = (.*?);',text).group(1))
visual=(R/'behavior_pack/scripts/showcase_visuals.js').read_text();block_visual=const('SC_BLOCK_VISUALS',visual);flat_visual=const('SC_FLAT_VISUALS',visual);texture_index=const('SC_TEXTURE_INDEX',visual);reverse={v:k for k,v in texture_index.items()}
entity=read(R/'resource_pack/entity/showcase_display.entity.json')['minecraft:client_entity']['description'];rc=read(R/'resource_pack/render_controllers/showcase_item.render_controllers.json')['render_controllers']['controller.render.shopuilook2.showcase_model'];paths=[entity['textures'][x.replace('Texture.','')] for x in rc['arrays']['textures']['Array.images']]
geos=read(R/'resource_pack/models/entity/showcase_item.geo.json')['minecraft:geometry'];meshes=[next(b for b in g['bones'] if b['name']=='display')['cubes'] for g in geos]
meta=read(V/'metadata/vanilladata_modules/mojang-items.json')['data_items'];native_items=read(V/'resource_pack/textures/item_texture.json')['texture_data'];native_blocks=read(V/'resource_pack/blocks.json');terrain=read(V/'resource_pack/textures/terrain_texture.json')['texture_data']
icons={p.stem:'textures/shop_icons/'+p.stem for p in (R/'resource_pack/textures/shop_icons').glob('*.png')}
ALIASES={'empty_map':'map','filled_map':'map','experience_bottle':'bottle_o_enchanting','chain':'iron_chain','grass_block':'grass_block','azalea_leaves_flowered':'flowering_azalea_leaves','dirt_with_roots':'rooted_dirt','hardened_clay':'terracotta','hay_block':'hay_bale','end_bricks':'end_stone_bricks','end_brick_stairs':'end_stone_brick_stairs','brick_block':'bricks','noteblock':'note_block','melon_block':'melon','slime':'slime_block','lit_pumpkin':'jack_o_lantern','golden_rail':'powered_rail','wooden_button':'oak_button','wooden_pressure_plate':'oak_pressure_plate','fence_gate':'oak_fence_gate','frame':'item_frame','glow_frame':'glow_item_frame','frog_spawn':'frogspawn','deadbush':'dead_bush','grass_path':'dirt_path','web':'cobweb','waterlily':'lily_pad','vine':'vines','banner':'white_banner','candle':'white_candle','turtle_helmet':'turtle_shell','netherite_upgrade_smithing_template':'netherite_upgrade','creeper_banner_pattern':'itemsprite_creeper_charge_banner_pattern','flower_banner_pattern':'itemsprite_flower_charge_banner_pattern','skull_banner_pattern':'itemsprite_skull_charge_banner_pattern','mojang_banner_pattern':'itemsprite_thing_banner_pattern','piglin_banner_pattern':'itemsprite_snout_banner_pattern','potion':'water_bottle','splash_potion':'splash_water_bottle','lingering_potion':'lingering_water_bottle','fireworks':'firework_rocket','fireworkscharge':'gray_firework_star','skull':'skeleton_skull','player_head':'steve_head','chest_minecart':'minecart_with_chest','hopper_minecart':'minecart_with_hopper','tnt_minecart':'minecart_with_tnt'}
def alias_name(n):
 n=ALIASES.get(n,n)
 if n.startswith('record_'):n='music_disc_'+n[7:]
 if n.endswith('_chest_boat'):n=n[:-11]+'_boat_with_chest'
 if n=='bamboo_chest_raft':n='bamboo_raft_with_chest'
 if n.startswith('waxed_'):n=n[6:]
 if n not in icons and 'itemsprite_'+n in icons:n='itemsprite_'+n
 return n
pages={}
def page(code,cell=32):
 key=code>>8
 if key not in pages:
  p=FONTS/f'glyph_{key:02X}.png';pages[key]=Image.open(p).convert('RGBA') if p.exists() else Image.new('RGBA',(cell*16,cell*16))
 return pages[key]
def cell_image(code):
 im=page(code);i=code&255;return im.crop((i%16*32,i//16*32,i%16*32+32,i//16*32+32))
def pixhash(im):
 im=im.convert('RGBA');data=im.get_flattened_data() if hasattr(im,'get_flattened_data') else im.getdata();return hashlib.sha256(bytes(v for p in data for v in (p if p[3] else (0,0,0,0)))).hexdigest()
def load_texture(path):
 for root in [R/'resource_pack',V/'resource_pack']:
  for ext in ['.png','.tga']:
   p=root/(path+ext)
   if p.exists():
    im=Image.open(p).convert('RGBA')
    if im.height>im.width:im=im.crop((0,0,im.width,im.width))
    return im
 return None
def tex_path(v):
 while isinstance(v,list):v=v[0]
 return v if isinstance(v,str) else v.get('path') if isinstance(v,dict) else None
FACES=['north','south','east','west','up','down']
def native_face(key):
 v=terrain.get(key,{}).get('textures');path=tex_path(v)
 if path=='textures/blocks/grass_side':path='textures/blocks/grass_side_carried'
 return load_texture(path) if path else None
# Isometric orthographic ray tracing of the actual authored showcase boxes.
# This also gives slabs/stairs their proper silhouette instead of using a full block.
E=(1/math.sqrt(3),1/math.sqrt(3),-1/math.sqrt(3));D=tuple(-v for v in E);U=(1/math.sqrt(2),0,1/math.sqrt(2));W=(-1/math.sqrt(6),2/math.sqrt(6),1/math.sqrt(6))
def render_boxes(boxes,texture):
 pts=[]
 for c in boxes:
  for a in [0,1]:
   for b in [0,1]:
    for z in [0,1]:pts.append([c['origin'][0]+c['size'][0]*a,c['origin'][1]-8+c['size'][1]*b,c['origin'][2]+c['size'][2]*z])
 us=[sum(p[i]*U[i] for i in range(3)) for p in pts];vs=[sum(p[i]*W[i] for i in range(3)) for p in pts]
 midu=(min(us)+max(us))/2;midv=(min(vs)+max(vs))/2;scale=28/max(max(us)-min(us),max(vs)-min(vs));out=Image.new('RGBA',(32,32));pixels=texture.load()
 prepared=[]
 for box in boxes:
  low=[box['origin'][0],box['origin'][1]-8,box['origin'][2]];high=[low[i]+box['size'][i] for i in range(3)];prepared.append((box,low,high))
 for row in range(32):
  for col in range(32):
   u=(col+.5-16)/scale+midu;v=(16-row-.5)/scale+midv;origin=[U[i]*u+W[i]*v+E[i]*50 for i in range(3)];hits=[]
   for box,lo,hi in prepared:
    for axis,side,f in [(0,0,'west'),(0,1,'east'),(1,0,'down'),(1,1,'up'),(2,0,'north'),(2,1,'south')]:
     if f not in box['uv']:continue
     t=((hi if side else lo)[axis]-origin[axis])/D[axis];q=[origin[i]+t*D[i] for i in range(3)]
     if any(q[i]<lo[i]-1e-6 or q[i]>hi[i]+1e-6 for i in range(3)):continue
     if axis==2:uu=(q[0]-lo[0])/(hi[0]-lo[0]);vv=(hi[1]-q[1])/(hi[1]-lo[1])
     elif axis==0:uu=(q[2]-lo[2])/(hi[2]-lo[2]);vv=(hi[1]-q[1])/(hi[1]-lo[1])
     else:uu=(q[0]-lo[0])/(hi[0]-lo[0]);vv=(q[2]-lo[2])/(hi[2]-lo[2])
     uv=box['uv'][f];x=max(0,min(63,int(uv['uv'][0]+max(0,min(.999999,uu))*uv['uv_size'][0])));y=max(0,min(63,int(uv['uv'][1]+max(0,min(.999999,vv))*uv['uv_size'][1])))
     color=pixels[x,y]
     if color[3]==0:continue
     shade=1 if f=='up' else .8 if f in ['north','south'] else .65
     hits.append((t,(int(color[0]*shade),int(color[1]*shade),int(color[2]*shade),color[3])))
   result=(0,0,0,0)
   for t,color in sorted(hits,reverse=True):
    aa=color[3]/255;ba=result[3]/255;alpha=aa+ba*(1-aa)
    if alpha:result=tuple(round((color[i]*aa+result[i]*ba*(1-aa))/alpha) for i in range(3))+(round(alpha*255),)
   out.putpixel((col,row),result)
 return out
render_cache={}
def block_icon(id):
 b=block_visual.get(id)
 if b:
  key=(b[0],b[1])
  if key not in render_cache:render_cache[key]=render_boxes(meshes[b[1]],load_texture(paths[b[0]]))
  return render_cache[key].copy(),'showcase:'+id
 name=id.split(':',1)[1];definition=native_blocks.get(name)
 # Only infer regular cube shapes here. Unknown special shapes are reported.
 if not definition or any(w in name for w in ['cushion','wall','fence','flower','sapling','spike','vines','bars','pane','icicle','shelf']):return None,None
 ts=definition.get('carried_textures',definition.get('textures'))
 if not ts:return None,None
 tex=Image.new('RGBA',(64,64))
 for i,f in enumerate(FACES):
  im=native_face(ts if isinstance(ts,str) else ts.get(f,ts.get('side')))
  if im is None:return None,None
  tex.paste(im.resize((16,16),Image.Resampling.NEAREST),(3+i%3*20,3+i//3*20))
 return render_boxes(meshes[1],tex),'native_block:'+name
custom={}
for p in (R/'behavior_pack/items').glob('*.json'):
 item=read(p).get('minecraft:item',{});id=item.get('description',{}).get('identifier','')
 if id and not re.search(r':(?:buff_|pay_|cartography_map_|decision_probe|landing_unknown|slot_zero_guard|set_icon)',id):custom[id]=item
heart_ids=set(re.findall(r'"(shopuilook2:(?:pay_|buff_)[^"]+)"',s));targets=sorted({e['name'] for e in meta}|set(custom))
custom_atlas=read(R/'resource_pack/textures/item_texture.json')['texture_data']
def source_for(id):
 if id in wiki['images']:
  entry=wiki['images'][id];path=entry['texture'];return load_texture(path),path,'wiki_upload:'+entry['upload_path'],None
 if id in wiki['shared']:
  target=wiki['shared'][id]['reuse_id'];path=prior['additions'][id]['texture'];return cell_image(ord(base[target])),path,'wiki_shared:'+target,base[target]
 name=id.split(':',1)[1];a=alias_name(name);alias='minecraft:'+a
 if alias in base:return cell_image(ord(base[alias])),icons.get(a),'alias:'+alias,base[alias]
 if a in icons:
  p=icons[a];return load_texture(p),p,'icon:'+a,None
 if id in base:return cell_image(ord(base[id])),None,'existing:'+id,base[id]
 p=reverse.get(flat_visual.get(id));im=load_texture(p) if p else None
 if im is not None:return im,p,'native_icon:'+p,None
 if id in custom:
  icon=custom[id].get('components',{}).get('minecraft:icon');key=icon.get('textures',{}).get('default',icon.get('texture')) if isinstance(icon,dict) else icon
  p=tex_path(custom_atlas.get(key,{}).get('textures'));im=load_texture(p) if p else None
  if im is not None:return im,p,'custom:'+id,None
 native=native_items.get(name,{})
 if name.endswith('_spawn_egg'):
  egg=name[:-10];egg={'tropical_fish':'tropicalfish','zombie_pigman':'zombified_piglin'}.get(egg,egg);native=native_items.get('spawn_egg_'+egg,native)
 p=tex_path(native.get('textures'));im=load_texture(p) if p else None
 if im is not None:return im,p,'native_icon:'+p,None
 for candidate in [name,{'command_block_minecart':'minecart_command_block','sulfur_cube_bucket':'bucket_sulfur_cube'}.get(name,name)]:
  path='textures/items/'+candidate;im=load_texture(path)
  if im is not None:return im,path,'native_file:'+path,None
 im,src=block_icon(id)
 return im,None,src,None
# Existing coordinates are immutable. Only empty F6 cells and the new ED page
# may receive new images. EE=90% block variant; EF=small tooltip variant.
owned={int(e['codepoint'],16) for e in prior['additions'].values() if e.get('new_cell')};available=[]
for cp in list(range(0xF600,0xF700))+list(range(0xED00,0xEE00))+list(range(0xF020,0xF100)):
 if cp in owned or cell_image(cp).getbbox() is None:available.append(cp)
known_hash={pixhash(cell_image(ord(ch))):ch for ch in base.values()};images={};patches={};entries={};unknown=[];claimed=set();new_unique={}
for id in targets:
 # Supplied Wiki icons are compiled, including all three sizes, by the dedicated importer.
 # Keep those coordinates and the user's shared-image aliases intact on general rebuilds.
 if (id in wiki['images'] or id in wiki['shared']) and id in current and id in prior['additions']:
  glyphs[id]=current[id];patches[id]=prior['additions'][id]['texture'];entries[id]=prior['additions'][id];continue
 if id in heart_ids:continue
 im,path,source,reuse=source_for(id)
 if im is None:
  if id not in base and id not in excluded_blocks:unknown.append(id)
  continue
 im=im.convert('RGBA').resize((32,32),Image.Resampling.NEAREST)
 if path is None:
  path='textures/shop_glyphs/'+id.replace(':','_').replace('/','_');dest=R/'resource_pack'/(path+'.png');dest.parent.mkdir(parents=True,exist_ok=True);im.save(dest,optimize=True)
 patches[id]=path
 if id in base or id in excluded_blocks:continue
 digest=pixhash(im);char=reuse or known_hash.get(digest) or new_unique.get(digest)
 new_cell=False
 if not char:
  old=prior['additions'].get(id,{});cp=int(old['codepoint'],16) if old.get('new_cell') else next((c for c in available if c not in claimed and c not in owned),None)
  if cp is None:raise RuntimeError('No free glyph cells; do not overwrite any existing cell')
  claimed.add(cp);char=chr(cp);new_unique[digest]=char;images[cp]=im;new_cell=True
 elif ord(char) in images:new_cell=True
 glyphs[id]=char;entries[id]={'codepoint':f'{ord(char):04X}','source':source,'texture':path,'new_cell':new_cell}
# Update all three font sizes for each newly assigned coordinate, preserving old cells.
def put(cp,im,cell):
 p=page(cp,cell);i=cp&255;p.paste(im,(i%16*cell,i//16*cell))
for cp,im in images.items():
 put(cp,im,32)
 if 0xF000<=cp<=0xF0FF:continue # overflow uses normal price size; tooltip keeps its name fallback
 small=im.resize((16,16),Image.Resampling.NEAREST);scaled=Image.new('RGBA',(32,32));scaled.paste(im.resize((29,29),Image.Resampling.NEAREST),(1,1))
 put(cp+0x800 if 0xF100<=cp<=0xF6FF else 0xEF00+(cp-0xED00),small,16);put(cp-0xB00 if cp>=0xF100 else 0xEE00+(cp-0xED00),scaled,32)
changed_pages=set()
for cp in images:
 changed_pages.add(cp>>8)
 if 0xF000<=cp<=0xF0FF:continue
 changed_pages.update([((cp+0x800) if cp>=0xF100 else (0xEF00+cp-0xED00))>>8,((cp-0xB00) if cp>=0xF100 else (0xEE00+cp-0xED00))>>8])
for p in changed_pages:pages[p].save(FONTS/f'glyph_{p:02X}.png',optimize=True)
s=s[:m.start(1)]+json.dumps(glyphs,ensure_ascii=True,separators=(',',':'))+s[m.end(1):]
patch='const SHOP_ICON_PATCHES = '+json.dumps(patches,ensure_ascii=False,separators=(',',':'))+';'
if 'const SHOP_ICON_PATCHES =' in s:s=re.sub(r'const SHOP_ICON_PATCHES = \{[^\n]+\};',lambda m:patch,s)
else:s=s.replace('function itemIconPath(typeId) {',patch+'\nfunction itemIconPath(typeId) {')
if 'if (SHOP_ICON_PATCHES[typeId])' not in s:s=s.replace('    if (HEART_ICON_TEXTURES[typeId]) return HEART_ICON_TEXTURES[typeId];','    if (HEART_ICON_TEXTURES[typeId]) return HEART_ICON_TEXTURES[typeId];\n    if (SHOP_ICON_PATCHES[typeId]) return SHOP_ICON_PATCHES[typeId];')
MAIN.write_text(s)
dump(REG,{'source_commit':PIN,'additions':entries,'new_cells':len({x['codepoint'] for x in entries.values() if x['new_cell']}),'aliases':sum(not x['new_cell'] for x in entries.values()),'unresolved':unknown,'excluded_blocks':sorted(excluded_blocks),**({'wiki_source_manifest':prior['wiki_source_manifest']} if 'wiki_source_manifest' in prior else {})})
print('Added glyph IDs:',len(entries),'new images:',len(images),'unresolved:',len(unknown),'changed font pages:',[f'{p:02X}' for p in sorted(changed_pages)])
print('Unresolved:',unknown)
