from pathlib import Path
from PIL import Image
import json,re,hashlib
R=Path(__file__).resolve().parents[1];src=json.loads((R/'tools/wiki_block_glyph_sources.json').read_text());reg=json.loads((R/'tools/currency_glyph_registry.json').read_text());main=(R/'behavior_pack/scripts/main.js').read_text();mapping=json.loads(re.search(r'const SHOP_GLYPHS = (\{[^\n]+\});',main).group(1));patches=json.loads(re.search(r'const SHOP_ICON_PATCHES = (\{[^\n]+\});',main).group(1));pages={}
def cell(cp,size=32):
 key=cp>>8
 if key not in pages:pages[key]=Image.open(R/f'resource_pack/font/glyph_{key:02X}.png').convert('RGBA')
 im=pages[key];assert im.size==(size*16,size*16);i=cp&255;return im.crop((i%16*size,i//16*size,(i%16+1)*size,(i//16+1)*size))
def visual(im):
 b=bytearray(im.convert('RGBA').tobytes())
 for i in range(0,len(b),4):
  if not b[i+3]:b[i:i+3]=b'\0\0\0'
 return bytes(b)
assert len(src['images'])==212 and len(src['shared'])==84 and len(src['missing'])==3
for id,entry in src['images'].items():
 p=R/'resource_pack'/(entry['texture']+'.png');assert hashlib.sha256(p.read_bytes()).hexdigest()==entry['sha256'],id
 original=Image.open(p).convert('RGBA').resize((32,32),Image.Resampling.NEAREST);cp=ord(mapping[id]);assert reg['additions'][id]['codepoint']==f'{cp:04X}';assert patches[id]==entry['texture']
 assert visual(cell(cp))==visual(original),(id,'normal')
 small=cp+0x800 if cp>=0xF100 else cp+0x200;block=cp-0xB00 if cp>=0xF100 else cp+0x100
 expected=Image.new('RGBA',(32,32));expected.paste(original.resize((29,29),Image.Resampling.NEAREST),(1,1))
 assert visual(cell(small,16))==visual(original.resize((16,16),Image.Resampling.NEAREST)),(id,'tooltip')
 assert visual(cell(block))==visual(expected),(id,'block price')
for id,entry in src['shared'].items():
 assert mapping[id]==mapping[entry['reuse_id']],id
 assert (R/'resource_pack'/(patches[id]+'.png')).is_file(),id
for e in src['missing']:assert e['id'] not in mapping
assert set(reg['excluded_blocks'])=={e['id'] for e in src['missing']}
print('PASS WIKI 212 supplied PNGs match source hashes and exact 32/29/16px glyph conventions')
print('PASS WIKI 84 shared IDs reuse existing glyph coordinates; only three missing IDs remain excluded')
# Native heart images do not depend on font pages, numeric labels or ASCII/fullwidth font settings.
ui=json.loads((R/'resource_pack/ui/shop_layout_price.json').read_text());marks=ui['sh_heart_price_marks'];assert len(marks['controls'])==12
for wrapped in marks['controls']:
 ref=next(iter(wrapped));name=ref.split('@')[1].split('.')[1];node=ui[name];assert node['type']=='image' and 'font_type' not in node
 icon=Image.open(R/'resource_pack'/(node['texture']+'.png')).convert('RGBA');assert icon.getchannel('A').getbbox()
print('PASS WIKI all twelve heart price markers reference real nonempty effect textures, independent of fonts')
