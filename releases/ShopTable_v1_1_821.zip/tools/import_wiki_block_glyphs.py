#!/usr/bin/env python3
"""Compile the supplied Wiki icons using the existing 32/29/16px font conventions.
Uses only unoccupied normal/block/tooltip cells; never renumbers existing glyphs.
"""
from pathlib import Path
from PIL import Image
import json,re,hashlib
R=Path(__file__).resolve().parents[1];F=R/'resource_pack/font'
p=R/'behavior_pack/scripts/main.js';s=p.read_text();regpath=R/'tools/currency_glyph_registry.json';reg=json.loads(regpath.read_text());source=json.loads((R/'tools/wiki_block_glyph_sources.json').read_text())
m=re.search(r'const SHOP_GLYPHS = (\{[^\n]+\});',s);glyphs=json.loads(m.group(1));patchmatch=re.search(r'const SHOP_ICON_PATCHES = (\{[^\n]+\});',s);patches=json.loads(patchmatch.group(1));pages={};changed=set()
def page(cp,size):
 key=cp>>8
 if key not in pages:
  path=F/f'glyph_{key:02X}.png';pages[key]=Image.open(path).convert('RGBA') if path.exists() else Image.new('RGBA',(16*size,16*size))
 assert pages[key].size==(16*size,16*size)
 return pages[key]
def cell(cp,size=32):
 i=cp&255;return page(cp,size).crop((i%16*size,i//16*size,(i%16+1)*size,(i//16+1)*size))
def coords(cp):return [(cp,32),(cp-0xB00 if cp>=0xF100 else cp+0x100,32),(cp+0x800 if cp>=0xF100 else cp+0x200,16)]
def digest(im):
 # Ignore RGB in fully transparent pixels when comparing visual duplicates.
 data=im.convert('RGBA').tobytes();data=bytearray(data)
 for i in range(0,len(data),4):
  if data[i+3]==0:data[i:i+3]=b'\0\0\0'
 return hashlib.sha256(data).hexdigest()
def put(cp,im,size):
 pg=page(cp,size);i=cp&255;pos=(i%16*size,i//16*size)
 if cell(cp,size).tobytes()!=im.tobytes():pg.paste(im,pos);changed.add(cp>>8)
# Full glyphs and their two derivatives must all be vacant before assignment.
used={ord(c) for c in glyphs.values()}
known={digest(cell(cp)):cp for cp in sorted(used) if 0xF100<=cp<=0xF6FF or 0xED00<=cp<=0xEDFF}
available=[cp for cp in list(range(0xF600,0xF700))+list(range(0xED00,0xEE00)) if cp not in used and all(not cell(c,size).getchannel('A').getbbox() for c,size in coords(cp))]
for id,entry in sorted(source['images'].items()):
 path=R/'resource_pack'/(entry['texture']+'.png');data=path.read_bytes();assert hashlib.sha256(data).hexdigest()==entry['sha256'],id
 with Image.open(path) as original:im=original.convert('RGBA').resize((32,32),Image.Resampling.NEAREST)
 assert im.getchannel('A').getbbox(),id
 key=digest(im)
 small=im.resize((16,16),Image.Resampling.NEAREST);block=Image.new('RGBA',(32,32));block.paste(im.resize((29,29),Image.Resampling.NEAREST),(1,1))
 def matches(cp):
  return digest(cell(cp))==key and digest(cell(cp+0x800 if cp>=0xF100 else cp+0x200,16))==digest(small) and digest(cell(cp-0xB00 if cp>=0xF100 else cp+0x100))==digest(block)
 previous_cp=ord(glyphs[id]) if id in glyphs else None
 if id in glyphs and matches(ord(glyphs[id])):
  cp=ord(glyphs[id]);assert digest(cell(cp))==key,('Existing glyph does not match Wiki source',id)
 elif key in known and matches(known[key]):cp=known[key]
 else:
  if not available:raise RuntimeError('No free triple-size glyph cells. Existing glyphs will not be overwritten.')
  cp=available.pop(0);small=im.resize((16,16),Image.Resampling.NEAREST);block=Image.new('RGBA',(32,32));block.paste(im.resize((29,29),Image.Resampling.NEAREST),(1,1))
  put(cp,im,32);put(cp-0xB00 if cp>=0xF100 else cp+0x100,block,32);put(cp+0x800 if cp>=0xF100 else cp+0x200,small,16);known[key]=cp
 glyphs[id]=chr(cp);patches[id]=entry['texture']
 prior=reg['additions'].get(id,{})
 owner=not any(k!=id and v==chr(cp) and k not in source['images'] for k,v in glyphs.items())
 reg['additions'][id]={'codepoint':f'{cp:04X}','source':'wiki_upload:'+entry['upload_path'],'texture':entry['texture'],'new_cell':prior.get('new_cell',owner) if previous_cp==cp else owner}
for id,entry in sorted(source['shared'].items()):
 target=entry['reuse_id'];cp=ord(glyphs[target]);glyphs[id]=glyphs[target]
 texture=patches.get(target)
 if texture is None:
  texture='textures/shop_glyphs/wiki_shared/'+target.replace(':','_');path=R/'resource_pack'/(texture+'.png');path.parent.mkdir(parents=True,exist_ok=True)
  cell(cp).save(path,optimize=True)
 patches[id]=texture
 reg['additions'][id]={'codepoint':f'{cp:04X}','source':'wiki_shared:'+target,'texture':texture,'new_cell':False}
for key in changed:pages[key].save(F/f'glyph_{key:02X}.png',optimize=True)
s=s[:m.start(1)]+json.dumps(glyphs,ensure_ascii=True,separators=(',',':'))+s[m.end(1):]
s=re.sub(r'const SHOP_ICON_PATCHES = \{[^\n]+\};',lambda _:'const SHOP_ICON_PATCHES = '+json.dumps(patches,ensure_ascii=False,separators=(',',':'))+';',s);p.write_text(s)
reg['excluded_blocks']=[e['id'] for e in source['missing']]
reg['new_cells']=len({e['codepoint'] for e in reg['additions'].values() if e['new_cell']});reg['aliases']=sum(not e['new_cell'] for e in reg['additions'].values())
reg['wiki_source_manifest']='tools/wiki_block_glyph_sources.json';regpath.write_text(json.dumps(reg,ensure_ascii=False,indent=2)+'\n')
print('Wiki images:',len(source['images']),'shared IDs:',len(source['shared']),'remaining:',len(source['missing']),'changed font pages:',len(changed))
