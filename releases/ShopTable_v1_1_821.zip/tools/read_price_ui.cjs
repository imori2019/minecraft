// Test-only expansion of ordinary native UI inheritance. No binding strings are
// evaluated or constructed: they must remain literal copies of v1.1.750.
const fs=require('node:fs'),path=require('node:path');
module.exports=function readPriceUi(file){
 const ui=JSON.parse(fs.readFileSync(file||path.join(__dirname,'../resource_pack/ui/shop_layout_price.json'),'utf8'));
 function walk(x,stack=[]){
  if(Array.isArray(x))return x.map(y=>walk(y,stack));
  if(!x||typeof x!=='object')return x;
  const out={};for(const[k,v]of Object.entries(x)){
   if(k.includes('@shop_layout_price.shared_buyer_')){
    const name=k.split('@')[0],ref=k.split('.')[1];if(stack.includes(ref))throw Error('cyclic '+ref);if(!ui[ref])throw Error('missing '+ref);
    out[name]=walk({...ui[ref],...v},[...stack,ref]);
   }else out[k]=walk(v,stack);
  }return out;
 }
 return walk(Object.fromEntries(Object.entries(ui).filter(([k])=>!k.startsWith('shared_buyer_'))));
};
