const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {run,prep,ctx,Container}=require('./test_smelt_sales.cjs');
function setup(){ctx.shopInv=new Container(640);prep();run(`block.typeId='shopuilook2:panel_enchant';globalThis.returned=[];giveOrDrop=(p,it)=>returned.push(it.clone());registry.stores.s1.enchant={auto:false,mats:Array(54).fill(null),levels:0,made:0};globalThis.S={storeId:'s1',fzKind:'enchant',crKey:''};globalThis.special=()=>{const it=new ItemStack('minecraft:enchanted_book');it.nameTag='大切な本';it.setLore(['保持する説明']);it.getComponent('minecraft:enchantable').addEnchantment({type:{id:'minecraft:sharpness'},level:5});return it;};`);}
for(let i=0;i<45;i++){
 setup();run(`shopInv.setItem(crSlots('enchant')[${i}],special());crSync(player,S,shopInv);`);
 assert.equal(run(`shopInv.getItem(crSlots('enchant')[${i}])`),undefined,'material slot '+i);assert.equal(run('returned.length'),1);assert.equal(run('returned[0].nameTag'),'大切な本');assert.deepEqual(JSON.parse(run('JSON.stringify(returned[0].getLore())')),['保持する説明']);assert.equal(run('returned[0].getComponent("minecraft:enchantable").getEnchantments()[0].level'),5);assert.equal(run('registry.stores.s1.enchant.mats.some(m=>m?.id==="minecraft:enchanted_book")'),false);
}
console.log('PASS every material slot rejects and returns enchanted books with their name, lore and enchantments intact');
for(let i=45;i<50;i++){
 setup();run(`shopInv.setItem(crSlots('enchant')[${i}],special());crSync(player,S,shopInv);`);assert.equal(run('returned.length'),0);assert.equal(run(`registry.stores.s1.enchant.mats[${i}].snap.enchantments[0].level`),5);
}
setup();run(`shopInv.setItem(crSlots('enchant')[18],new ItemStack('minecraft:book',16));crSync(player,S,shopInv);`);assert.equal(run('returned.length'),0);assert.equal(run('registry.stores.s1.enchant.mats[18].n'),16);
console.log('PASS all five template slots still accept enchanted books, and plain books still enter their materials slots');
setup();run(`const snap=snapshotItemStack(special());for(const i of [0,18,36,45])registry.stores.s1.enchant.mats[i]={id:'minecraft:enchanted_book',n:1,snap};crEnter(player,S,shopInv,registry.stores.s1);`);assert.equal(run('returned.length'),3);assert.equal(run('registry.stores.s1.enchant.mats.filter(m=>m?.id==="minecraft:enchanted_book").length'),1);assert.ok(run('registry.stores.s1.enchant.mats[45]'));run(`crEnter(player,S,shopInv,registry.stores.s1)`);assert.equal(run('returned.length'),3,'existing books are returned only once');
console.log('PASS legacy materials are returned once while the template book stays in place');
const ui=JSON.parse(fs.readFileSync(path.join(__dirname,'../resource_pack/ui/shop_proceeds_screen.json'),'utf8'));
function find(o,k){if(!o||typeof o!=='object')return;for(const [key,v]of Object.entries(o)){if(key===k)return v;const r=find(v,k);if(r)return r;}}
const pen=find(ui,'cartography_pen');assert.ok(pen);assert.ok(!pen.controls.some(c=>c.cr_head));const indices=new Set();(function walk(o){if(!o||typeof o!=='object')return;if(Number.isInteger(o.collection_index))indices.add(o.collection_index);for(const v of Object.values(o))walk(v)})(pen);for(const slot of JSON.parse(run('JSON.stringify(CR_WIDE_SLOTS)')))assert.ok(indices.has(slot),'cartography slot '+slot);
console.log('PASS cartography materials heading removed, all 81 paper/compass slots preserved; API and layout checks only');
