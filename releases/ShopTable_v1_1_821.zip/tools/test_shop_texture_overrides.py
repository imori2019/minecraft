"""Verify supplied shop art is used by terrain, inventory and text-icon routes."""
from pathlib import Path
from PIL import Image
import json,re
r=Path(__file__).resolve().parents[1]
reg=json.loads((r/'tools/currency_glyph_registry.json').read_text())
glyphs=json.loads(re.search(r'const SHOP_GLYPHS = (\{[^\n]+\});',(r/'behavior_pack/scripts/main.js').read_text()).group(1))
font={}
def cell(cp,size):
 k=cp>>8
 if k not in font:font[k]=Image.open(r/f'resource_pack/font/glyph_{k:02X}.png').convert('RGBA')
 i=cp&255;return font[k].crop((i%16*size,i//16*size,(i%16+1)*size,(i//16+1)*size))
count=0
for id,e in reg['additions'].items():
 if not id.startswith('shopuilook2:panel_'):continue
 cp=int(e['codepoint'],16);assert ord(glyphs[id])==cp
 im=Image.open(r/'resource_pack'/(e['texture']+'.png')).convert('RGBA').resize((32,32),Image.Resampling.NEAREST)
 assert cell(cp,32).tobytes()==im.tobytes(),id+' normal text icon is stale'
 if not 0xF000<=cp<=0xF0FF:
  block=Image.new('RGBA',(32,32));block.paste(im.resize((29,29),Image.Resampling.NEAREST),(1,1))
  assert cell(cp-0xB00 if cp>=0xF100 else cp+0x100,32).tobytes()==block.tobytes(),id+' block-price icon is stale'
  assert cell(cp+0x800 if cp>=0xF100 else cp+0x200,16).tobytes()==im.resize((16,16),Image.Resampling.NEAREST).tobytes(),id+' tooltip icon is stale'
 count+=1
assert count==21
print('PASS all 21 shop text icons use the supplied inventory art; every supported size matches pixel-for-pixel')
manifest=json.loads((r/'tools/shop_assets728.json').read_text())
authored={'shopuilook2_'+v['geometry'] for v in manifest['models']}
flipbooks=json.loads((r/'resource_pack/textures/flipbook_textures.json').read_text())
assert not any(v['atlas_tile'] in authored for v in flipbooks),'A stale animation overrides supplied model art'
terrain=json.loads((r/'resource_pack/textures/terrain_texture.json').read_text())['texture_data']
assert terrain['shopuilook2_anchor_shop']['textures']=='textures/shopuilook2/blocks/anchor_shop'
g=json.loads((r/'resource_pack/models/blocks/anchor_shop.geo.json').read_text())['minecraft:geometry']
assert all(v['description']['texture_width']==64 and v['description']['texture_height']==16 for v in g)
print('PASS supplied model tiles are not overridden by old flipbooks; anchor uses its own 64x16 atlas')
