const assert=require('node:assert/strict');const {run,prep}=require('./test_smelt_sales.cjs');
(async()=>{
 prep();run(`globalThis.shopAt={dimension:{id:'minecraft:overworld'},location:{x:-23,y:72,z:245}};player.location={x:900,y:20,z:900};registry.stores.s1.name='中央ショップ';globalThis.c1=shopMakeCoupon(registry.stores.s1,15,{floor:'d1',floorName:'食品',genre:'果物'},3,shopAt);`);
 const lore=JSON.parse(run('JSON.stringify(c1.getLore())'));assert.match(run('c1.nameTag'),/中央ショップ/);assert.match(lore[0],/店名：中央ショップ/);assert.match(lore.join('\n'),/オーバーワールド/);assert.match(lore.join('\n'),/X -23  Y 72  Z 245/);assert.ok(!lore.join('\n').includes('900'));assert.match(lore[2],/食品/);assert.match(lore[2],/果物/);
 assert.deepEqual(JSON.parse(run('JSON.stringify(shopCouponInfo(c1))')),{store:'s1',rate:15,floor:'d1',genre:'果物'});assert.equal(run('c1.amount'),3);
 console.log('PASS coupon shows store name and issuing block coordinates, preserving its discount scope');
 for(const [dimension,label] of [['minecraft:nether','ネザー'],['minecraft:the_end','ジ・エンド']]){run(`shopAt.dimension.id=${JSON.stringify(dimension)};globalThis.other=shopMakeCoupon(registry.stores.s1,10,{},1,shopAt)`);assert.match(run('other.getLore().join()'),new RegExp(label));}
 run(`shopAt.dimension.id='minecraft:overworld';globalThis.c2=shopMakeCoupon(registry.stores.s1,15,{floor:'d1',floorName:'食品',genre:'果物'},1,shopAt);`);assert.equal(run('c1.isStackableWith(c2)'),true);
 run(`globalThis.old=shopMakeCoupon(registry.stores.s1,15,{floor:'d1',floorName:'食品',genre:'果物'});`);assert.deepEqual(JSON.parse(run('JSON.stringify(shopCouponInfo(old))')),JSON.parse(run('JSON.stringify(shopCouponInfo(c1))')));
 console.log('PASS dimension labels, deterministic stacking, and old coupon identity remain compatible');
 run(`globalThis.given=[];giveOrDrop=(p,it)=>given.push(it);player.playSound=()=>{};ppIssueCoupons(player,'s1',10,{},65,shopAt);`);assert.equal(run('given.length'),2);assert.equal(run('given.reduce((n,it)=>n+it.amount,0)'),65);assert.equal(run('given.every(it=>it.getLore().join().includes("X -23  Y 72  Z 245"))'),true);
 run(`ModalFormData=class{title(){return this}slider(){return this}};showFormWithRetry=async()=>({formValues:[20,2]});given=[];`);await run(`showCouponIssueForm(player,registry.stores.s1,shopCouponOrigin(shopAt))`);assert.equal(run('given.length'),1);assert.match(run('given[0].getLore().join()'),/X -23  Y 72  Z 245/);assert.equal(run('shopCouponInfo(given[0]).rate'),20);
 console.log('PASS sale issuance across multiple stacks and the store-menu form both include the issuing location');
 assert.equal(run(`shopCouponOrigin({dimensionId:'minecraft:overworld',x:NaN,y:64,z:0})`),null);assert.equal(run(`shopCouponLocationLines(undefined).length`),0);
 console.log('PASS unavailable locations are omitted rather than inventing coordinates; API simulation only');
})().catch(e=>{console.error(e);process.exitCode=1});
