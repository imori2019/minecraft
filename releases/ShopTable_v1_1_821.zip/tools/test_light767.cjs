const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');const {run}=require('./test_smelt_sales.cjs');
let n=0;const test=(name,fn)=>{fn();n++;console.log('PASS '+name);};
const ui=f=>JSON.parse(fs.readFileSync(path.join(__dirname,'../resource_pack/ui',f),'utf8'));
test('non-heart shops get the no-heart buyer title; heart shops keep the plain one',()=>{
 assert.equal(run('panelBuyerTitle(true)'),run('PANEL_UI_TITLE_BUYER'));
 assert.equal(run('panelBuyerTitle(false)'),run('PANEL_UI_TITLE_BUYER')+'§n§h§r');
 assert.ok(run('isPanelTitle(PANEL_UI_TITLE_BUYER_NH)'));assert.ok(run('panelTitleFits(PANEL_UI_TITLE_BUYER_NH,true)'));assert.ok(!run('panelTitleFits(PANEL_UI_TITLE_BUYER_NH,false)'));
});
test('chest screen raises $shop_no_heart only for the no-heart mark and heart parts honour it',()=>{
 const chest=ui('chest_screen.json');for(const k of ['small_chest_screen','large_chest_screen']){const v=chest[k].modifications[0].value.find(x=>x.$shop_no_heart);assert.ok(v.requires.includes("'§n§h§r'"));}
 const dd=ui('data_driven_container_screen.json');const holder=Object.values(dd).find(v=>v&&v['$shop_buyer_light|default']===false);assert.equal(holder['$shop_no_heart|default'],false);
 const price=ui('shop_layout_price.json');let hearts=0;
 (function visit(x){if(!x||typeof x!=='object')return;for(const[k,v]of Object.entries(x)){if(v&&typeof v==='object'&&(k.startsWith('heart_marks@')||k.startsWith('heart_price_native'))){assert.equal(v.ignored,'$shop_no_heart');hearts++;}visit(v);}})(price);
 assert.ok(hearts>100);
});
test('merged price variants show for every count the a/b pair used to cover',()=>{
 const price=ui('shop_layout_price.json');const vis=v=>v.bindings.find(b=>b.target_property_name==='#visible').source_property_name;
 const vals=s=>[...s.matchAll(/= '(\d+)'/g)].map(m=>Number(m[1]));
 assert.deepEqual(vals(vis(price.shared_buyer_2033_m)),[2,3,4,5,6,7,8,9,18,19,20,21,22,23,24,25]);
 assert.deepEqual(vals(vis(price.shared_buyer_41_m)),[10,11,12,13,14,15,16,17,26,27,28,29,30,31,32,33]);
 assert.ok(!JSON.stringify(price).includes('"gp0_0b"'));
});
test('v768: non-heart shops build one merged price part instead of normal + point parts',()=>{
 const chest=ui('chest_screen.json');for(const k of ['small_chest_screen','large_chest_screen']){const v=chest[k].modifications[0].value.find(x=>x.$shop_heart_split);assert.equal(v.requires,"(($shop_panel_title - '§n§h§r') = $shop_panel_title)");}
 const price=ui('shop_layout_price.json');const vals=n=>{const b=n.bindings.find(x=>x.target_property_name==='#visible');return [...b.source_property_name.matchAll(/= '(\d+)'/g)].map(m=>Number(m[1]));};
 const inner=n=>{const [k,v]=Object.entries(n.controls[0])[0];return k==='v'?v:price[k.split('.')[1]];};let groups=0;
 (function visit(x){if(!x||typeof x!=='object')return;if(Array.isArray(x.controls)){const by=Object.assign({},...x.controls.filter(c=>c&&typeof c==='object'));
  for(const[k,v]of Object.entries(by)){if(!k.endsWith('a_any'))continue;const a=by[k.slice(0,-4)],pt=by[k.slice(0,-4)+'_pt'];
   assert.equal(v.ignored,'$shop_heart_split');assert.equal(a.ignored,'$shop_no_heart');assert.equal(pt.ignored,'$shop_no_heart');
   assert.deepEqual(vals(inner(v)),[...new Set([...vals(inner(a)),...vals(inner(pt))])].sort((p,q)=>p-q));groups++;}}
  Object.values(x).forEach(visit);})(price);
 assert.ok(groups>150);
});
test('v769: deal groups build one 6-card stack; lower row and title follow the old 3/6-card codes',()=>{
 const price=ui('shop_layout_price.json');const rp=price.sh_rp_content.controls.map(c=>Object.keys(c)[0]);
 assert.ok(!rp.some(k=>/b_grp\d_(compact|four)/.test(k)));
 const vals=b=>[...b.source_property_name.matchAll(/= '(\d+)'/g)].map(m=>m[1]).join(',');
 for(let g=0;g<2;g++){const st=price.sh_rp_content.controls.find(c=>c['b_grp'+g])['b_grp'+g];
  const bind=(n,t)=>n.bindings.find(b=>b.target_property_name===t);
  assert.equal(vals(bind(st,'#visible')),'2,3,4,5');const more=st.controls[1].more;assert.equal(vals(bind(more,'#visible')),'4,5');assert.equal(vals(bind(more,'#ignored')),'4,5');
  const offs=more.controls.map(c=>Object.values(c)[0].offset[1]);assert.deepEqual(offs,[0,32,0,32,0,32]);
  const t=JSON.stringify(st.controls[0].top.controls[0]);assert.ok(t.includes("= '2') or (")&&t.includes("= '4'))")&&t.includes("= '3') or (")&&t.includes("= '5'))"));}
 const row=price.sh_price_more_by_width.controls[0].row;for(const n of [row,...row.controls.map(c=>Object.values(c)[0]).filter(n=>n.bindings)])assert.ok(n.bindings.some(b=>b.target_property_name==='#ignored'));
});
test('v772: every reference to our own UI definitions resolves (deal cards 5/6 had no button)',()=>{
 const dir=path.join(__dirname,'../resource_pack/ui');const files=fs.readdirSync(dir).filter(f=>f.endsWith('.json'));const defs=new Set(),own=new Set();let text='';
 for(const f of files){const t=fs.readFileSync(path.join(dir,f),'utf8');text+=t;const d=JSON.parse(t);if(!d.namespace)continue;own.add(d.namespace);for(const k of Object.keys(d))if(k!=='namespace')defs.add(d.namespace+'.'+k.split('@')[0]);}
 const vanilla=new Set(['chest.chest_grid_item','chest.chest_grid_item_button','data_driven_container.item_grid']);
 const missing=[...new Set([...text.matchAll(/\b(shop_[a-z_]+|data_driven_container|chest)\.([A-Za-z0-9_]+)\b/g)].map(m=>m[0]))].filter(r=>own.has(r.split('.')[0])&&!r.endsWith('.json')&&!defs.has(r)&&!vanilla.has(r));
 assert.deepEqual(missing,[]);
});
console.log(n+' v767-772 lightening tests passed (node counts only; native load time unmeasured)');
