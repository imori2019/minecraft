ShopTable v1.1.760 - クリエイティブ分類アイコン
元になったファイル: ShopTable v1.1.759 クリエイティブ分類
分類の見出しアイコンに「category_icons_3groups.zip」の3枚を使用。

・銅系統 -> creative_icon_copper
・普通系統 -> creative_icon_normal
・効果あり系統 -> creative_icon_special
・効果アイテム -> 以前の既存アイコン buff_strength を維持（追加画像なし）

分類用アイテムはクリエイティブ一覧には表示されません。
既存ショップ・効果アイテム・ポイントカードの定義は変更していません。
Minecraft内での動作確認は行っていません。
