"""ショップのモデルを左右反転して、Blockbench の見た目と同じにする（v1.1.693）。
Blockbench は Bedrock に書き出す時に X を反転する（origin.x = -(from.x + size.x)）。
今までのモデル（Shop Showcase v2.0 から取り込んだ物）は反転せずに書き出されていたので、ゲームでは左右が逆に見えていた。
炎のアニメ（animated_front）の正面の絵は、部品の位置で決まるので、反転した後の位置の物を付け直す。"""
import json, glob, os, sys
W = sys.argv[1]
for p in sorted(glob.glob(os.path.join(W, 'resource_pack/models/blocks/*_shop.geo.json'))):
    d = json.load(open(p, encoding='utf-8'))
    for g in d['minecraft:geometry']:
        for b in g['bones']:
            if 'pivot' in b: b['pivot'][0] = -b['pivot'][0]
            if 'rotation' in b: b['rotation'] = [-b['rotation'][0], -b['rotation'][1], b['rotation'][2]]
            old = {(tuple(c['origin']), tuple(c['size'])): c['uv'].get('north') for c in b.get('cubes', [])
                   if isinstance(c.get('uv'), dict) and c['uv'].get('north', {}).get('material_instance') == 'animated_front'}
            for c in b.get('cubes', []):
                c['origin'][0] = -(c['origin'][0] + c['size'][0])
                if 'pivot' in c: c['pivot'][0] = -c['pivot'][0]
                if 'rotation' in c: c['rotation'] = [-c['rotation'][0], -c['rotation'][1], c['rotation'][2]]
            for c in b.get('cubes', []):
                k = (tuple(c['origin']), tuple(c['size']))
                if k in old: c['uv']['north'] = json.loads(json.dumps(old[k]))
                elif c.get('uv', {}).get('north', {}).get('material_instance') == 'animated_front': raise SystemExit(f'no animated uv for {k} in {p}')
    json.dump(d, open(p, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
    print('mirrored', os.path.basename(p))
