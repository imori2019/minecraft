#!/usr/bin/env python3
"""Checks actual packaged atlas pixels and model UVs. Requires Pillow; no Minecraft runtime."""
from pathlib import Path
import json,re
from PIL import Image
R=Path(__file__).resolve().parents[1]
s=(R/'behavior_pack/scripts/showcase_visuals.js').read_text()
def data(name):return json.loads(re.search(r'export const '+name+r' = (.*?);',s).group(1))
blocks=data('SC_BLOCK_VISUALS');info=data('SC_ATLAS_INFO');atlas=Image.open(R/'resource_pack/textures/shopuilook2/showcase/blocks.png').convert('RGBA')
assert atlas.size==(info['columns']*64,info['rows']*64)
faces=['north','south','east','west','up','down']
def tile(id,face):
 i=blocks['minecraft:'+id][0];f=faces.index(face);x=i%info['columns']*64+3+(f%3)*20;y=i//info['columns']*64+3+(f//3)*20
 return atlas.crop((x,y,x+16,y+16))
# A previous build accidentally used grass's terrain tint-mask alpha as transparency.
for face in faces:assert tile('grass_block',face).getchannel('A').getextrema()==(255,255),face
r,g,b,a=tile('grass_block','north').getpixel((5,12));assert r>g>b and a==255,'grass side includes opaque brown soil'
r,g,b,a=tile('grass_block','up').getpixel((5,12));assert g>r and g>b,'grass top retains its green carried texture'
print('PASS ASSETS grass uses complete opaque carried faces, not terrain tint-mask alpha')
# Logs and directional machines must not become six copies of a single texture.
assert tile('oak_log','up').tobytes()!=tile('oak_log','north').tobytes()
assert tile('furnace','south').tobytes()!=tile('furnace','north').tobytes()
assert tile('stone','up').tobytes()==tile('stone','north').tobytes()
print('PASS ASSETS logs and furnace fronts retain distinct face textures')
for i in {v[0] for v in blocks.values()}:
 ox=i%info['columns']*64;oy=i//info['columns']*64
 for f in range(6):
  x=ox+2+(f%3)*20;y=oy+2+(f//3)*20
  for n in range(16):
   assert atlas.getpixel((x+1+n,y))==atlas.getpixel((x+1+n,y+1))
   assert atlas.getpixel((x+1+n,y+17))==atlas.getpixel((x+1+n,y+16))
   assert atlas.getpixel((x,y+1+n))==atlas.getpixel((x+1,y+1+n))
   assert atlas.getpixel((x+17,y+1+n))==atlas.getpixel((x+16,y+1+n))
print('PASS ASSETS all six faces of every atlas cell have correct edge gutters')
geo=json.loads((R/'resource_pack/models/entity/showcase_item.geo.json').read_text())['minecraft:geometry']
for g in geo:
 width=g['description']['texture_width'];height=g['description']['texture_height']
 for bone in g['bones']:
  for cube in bone.get('cubes',[]):
   for face in cube['uv'].values():
    for i,limit in [(0,width),(1,height)]:
     a=face['uv'][i];b=a+face['uv_size'][i];assert 0<=min(a,b)<=max(a,b)<=limit,g['description']['identifier']
print('PASS ASSETS all model UV rectangles stay inside their source image or atlas cell')
print('4 showcase asset checks passed (packaged pixels and geometry; no Minecraft rendering)')
