// v1.1.705 店内BGM：店が入れ替わっても途切れない・オフは自分でオンにするまで続く
const assert=require('node:assert/strict');
const env=require('./test_smelt_sales.cjs');
const {run}=env;
let count=0;
function test(name,fn){fn();count++;console.log('PASS BGM '+name);}
run(`globalThis.bgmLog=[];globalThis.near=new Map();
 shopBgmNearbyKey=(p)=>near.get(p.id);shopBgmStoreRegistry=()=>({});shopBgmNoteParticle=()=>{};
 globalThis.mkP=id=>({id,dimension:{id:'minecraft:overworld'},playMusic:(t)=>bgmLog.push(id+':play:'+t),queueMusic:(t)=>bgmLog.push(id+':queue:'+t),stopMusic:()=>bgmLog.push(id+':stop')});
 globalThis.P=mkP('A');`);
function reset(){run(`bgmLog.length=0;near.clear();SH_BGM_LISTENERS.clear();SH_BGM_OFF.clear();active.clear();`);}
const tick=(key)=>run(`near.set('A',${JSON.stringify(key)});shopBgmPatrol([P]);`);
const plays=()=>JSON.parse(run(`JSON.stringify(bgmLog.filter(x=>x.includes(':play:')).length)`));
const stops=()=>JSON.parse(run(`JSON.stringify(bgmLog.filter(x=>x.endsWith(':stop')).length)`));
test('walking between nearby shops keeps the same song playing (no stop, no restart)',()=>{
 reset();tick('dim|0,64,0');assert.equal(plays(),1);
 for(const k of ['dim|5,64,0','dim|0,64,0','dim|9,64,3','dim|5,64,0'])tick(k);
 assert.equal(plays(),1);assert.equal(stops(),0);
});
test('stepping out of range for less than 5 seconds does not stop the song; longer does',()=>{
 reset();tick('dim|0,64,0');
 for(let i=0;i<4;i++)tick(undefined);
 tick('dim|0,64,0');assert.equal(plays(),1);assert.equal(stops(),0);
 for(let i=0;i<5;i++)tick(undefined);
 assert.equal(stops(),1);
});
test('turning it off stays off across shop changes and leaving, until turned on again',()=>{
 reset();tick('dim|0,64,0');
 run(`const v=SH_BGM_LISTENERS.get('A');shopBgmStop(P);v.bgmOn=false;v.disabled=true;SH_BGM_OFF.add('A');`);   // ボタンと同じ状態
 tick('dim|5,64,0');tick('dim|9,64,3');
 for(let i=0;i<6;i++)tick(undefined);
 tick('dim|0,64,0');tick('dim|0,64,0');
 assert.equal(plays(),1,'never restarted while off');
 run(`SH_BGM_OFF.delete('A');SH_BGM_LISTENERS.delete('A');`);tick('dim|0,64,0');
 assert.equal(plays(),2,'plays again after turning on');
});
test('the shop button shows ON in any shop screen while the song is playing',()=>{
 reset();tick('dim|0,64,0');
 run(`active.set('A',{dimensionId:'dim',x:5,y:64,z:0,shopMode:{bgmOn:false,expect:new Map()}});shopBgmSyncGui(P,SH_BGM_LISTENERS.get('A'));`);
 assert.equal(run(`active.get('A').shopMode.bgmOn`),true);
});
console.log(count+' bgm test groups passed');
