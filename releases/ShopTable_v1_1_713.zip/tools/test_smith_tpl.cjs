// v1.1.701 鍛冶台：鍛冶型の欄 27マス・各マスの最後の1個は残す・材料で複製して売る
const assert=require('node:assert/strict');
const env=require('./test_smelt_sales.cjs');
const {run,prep}=env;
let count=0;
function test(name,fn){fn();count++;console.log('PASS SMITH '+name);}
const T='minecraft:sentry_armor_trim_smithing_template';
function setup(slots){ // slots: {index: {id,n}}
 prep();
 run(`block.typeId='shopuilook2:panel_smith';const m=Array(54).fill(null);for(const [i,x] of Object.entries(${JSON.stringify(slots)}))m[i]=x;
  registry.stores.s1.smith={smv:2,mats:m,made:0};
  saveProductIndex(block,['t1']);saveProduct(block,{id:'t1',savedOnce:true,settings:{shop_sale_type:0},items:[{id:'${T}',key:'${T}',role:'sample',slot:17,count:1}],stock:[]});`);
}
const stock=()=>run(`fzStockCountPlain(loadProduct(block,'t1'),'${T}')`);
const mats=()=>JSON.parse(run(`JSON.stringify(registry.stores.s1.smith.mats)`));
test('a template slot with only one template is kept: nothing is sold (sold out) without materials',()=>{
 setup({18:{id:T,n:1}});run(`crCraft(block)`);
 assert.equal(stock(),0);assert.equal(mats()[18].n,1);
 assert.equal(run(`shopPurchaseRemaining(loadProduct(block,'t1'))`),0);
});
test('extra templates in a slot (all but the last one) go to the product stock',()=>{
 setup({18:{id:T,n:5},30:{id:T,n:3}});run(`crCraft(block)`);
 assert.equal(stock(),6);assert.equal(mats()[18].n,1);assert.equal(mats()[30].n,1);
});
test('with 7 diamonds + cobblestone one template is duplicated from the kept master (master stays)',()=>{
 setup({0:{id:'minecraft:diamond',n:14},1:{id:'minecraft:cobblestone',n:2},18:{id:T,n:1}});run(`crCraft(block)`);
 assert.equal(stock(),1);assert.equal(mats()[18].n,1);assert.equal(mats()[0].n,7);assert.equal(mats()[1].n,1);
 run(`crCraft(block)`);assert.equal(stock(),2);assert.equal(mats()[0],null);
 run(`crCraft(block)`);assert.equal(stock(),2,'no more diamonds');
});
test('no template in the template slots means no duplication even with materials',()=>{
 setup({0:{id:'minecraft:diamond',n:14},1:{id:'minecraft:cobblestone',n:2}});run(`crCraft(block)`);
 assert.equal(stock(),0);
});
test('trim and netherite upgrade never use the last template in a slot',()=>{
 setup({18:{id:T,n:1},19:{id:'minecraft:netherite_upgrade_smithing_template',n:1}});
 assert.equal(run(`smUse(registry.stores.s1.smith.mats,'${T}')`),undefined);
 run(`registry.stores.s1.smith.mats[18].n=2;`);
 assert.equal(run(`smUse(registry.stores.s1.smith.mats,'${T}')[18].n`),1);
 assert.equal(run(`JSON.stringify(crPlan(registry.stores.s1.smith.mats,[['i','minecraft:netherite_upgrade_smithing_template',1]],smReserve(registry.stores.s1.smith.mats)))`),undefined);
});
test('old layout (trim materials at 27-35) is moved to 45-53 when read',()=>{
 prep();
 run(`const m=Array(36).fill(null);m[0]={id:'minecraft:iron_ingot',n:5};m[20]={id:'${T}',n:2};m[27]={id:'minecraft:diamond',n:3};m[35]={id:'minecraft:redstone',n:4};
  registry.stores.s1.smith={mats:m,made:0};globalThis.cs=crState(registry.stores.s1,'smith');`);
 const m=JSON.parse(run(`JSON.stringify(cs.mats)`));
 assert.equal(m.length,54);assert.equal(m[0].n,5);assert.equal(m[20].id,T);
 assert.equal(m[27],null);assert.equal(m[45].id,'minecraft:diamond');assert.equal(m[53].id,'minecraft:redstone');
 assert.equal(run(`cs.smv`),2);
 assert.equal(run(`crState({smith:{smv:2,mats:cs.mats}},'smith').mats[45].id`),'minecraft:diamond','already-new data is not moved again');
});
test('slot rules: 18-44 templates only, 45-53 trim materials only',()=>{
 assert.equal(run(`smSlotOk(44,'${T}')`),true);assert.equal(run(`smSlotOk(44,'minecraft:diamond')`),false);
 assert.equal(run(`smSlotOk(45,'minecraft:diamond')`),true);assert.equal(run(`smSlotOk(45,'${T}')`),false);
 assert.equal(run(`SM_MAT_SLOTS.length`),54);assert.equal(new Set(JSON.parse(run(`JSON.stringify(SM_MAT_SLOTS)`))).size,54);
});
function setupGear(id,slots){
 prep();
 run(`block.typeId='shopuilook2:panel_smith';const m=Array(54).fill(null);for(const [i,x] of Object.entries(${JSON.stringify(slots)}))m[i]=x;
  registry.stores.s1.smith={smv:2,mats:m,made:0};
  saveProductIndex(block,['g1']);saveProduct(block,{id:'g1',savedOnce:true,settings:{shop_sale_type:0},items:[{id:'${'${id}'}',key:'${'${id}'}',role:'sample',slot:17,count:1}],stock:[]});`.replaceAll('${id}',id));
}
const gear=id=>run(`fzStockCountPlain(loadProduct(block,'g1'),'${'${id}'}')`.replaceAll('${id}',id));
test('plain weapons and armor are no longer crafted at the smithing table (left to the blast furnace)',()=>{
 setupGear('minecraft:diamond_sword',{0:{id:'minecraft:diamond',n:64},1:{id:'minecraft:stick',n:64}});run(`crCraft(block)`);
 assert.equal(gear('minecraft:diamond_sword'),0);
 setupGear('minecraft:iron_chestplate',{0:{id:'minecraft:iron_ingot',n:64}});run(`crCraft(block)`);
 assert.equal(gear('minecraft:iron_chestplate'),0);
});
test('netherite upgrade still works and keeps the last upgrade template in its slot',()=>{
 setupGear('minecraft:netherite_sword',{0:{id:'minecraft:diamond_sword',n:1},1:{id:'minecraft:netherite_ingot',n:2},18:{id:'minecraft:netherite_upgrade_smithing_template',n:2}});
 run(`crCraft(block)`);assert.equal(gear('minecraft:netherite_sword'),1);
 assert.equal(run(`registry.stores.s1.smith.mats[18].n`),1);
 run(`registry.stores.s1.smith.mats[0]={id:'minecraft:diamond_sword',n:1};crCraft(block)`);
 assert.equal(gear('minecraft:netherite_sword'),1,'only one template left: kept, no more upgrades');
});
console.log(count+' smith template test groups passed');
