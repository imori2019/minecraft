// v1.1.692 軽量化の確かめ（結果は前と同じで、読む回数だけ減っていること）
const assert=require('node:assert/strict');
const env=require('./test_smelt_sales.cjs');
const {run,prep,player}=env;
let count=0;
function test(name,fn){fn();count++;console.log('PASS PERF '+name);}
test('read-only store registry is reused until a save, then re-read',()=>{
 prep();
 run(`globalThis.regReads=0;globalThis.origLoad=loadStores;loadStores=()=>{regReads++;return origLoad();};STORE_RO={rev:-1,reg:undefined};`);
 run(`for(let i=0;i<50;i++)canEditBlock(player,block)`);assert.equal(run(`regReads`),1);
 run(`registry.stores.s1.name='改名テスト';STORE_REGISTRY_REVISION++;`);   // 本物の saveStores は保存の後にこれを1つ進める
 assert.equal(run(`loadStoresRO().stores.s1.name`),'改名テスト');assert.equal(run(`regReads`),2);
 run(`loadStores=origLoad;STORE_RO={rev:-1,reg:undefined};`);
 const src=require('node:fs').readFileSync(require('node:path').join(__dirname,'../behavior_pack/scripts/main.js'),'utf8');
 assert.match(src,/world\.setDynamicProperty\(STORE_REGISTRY_PROP, JSON\.stringify\(reg\)\);\n\s*STORE_REGISTRY_REVISION\+\+;/);
 assert.equal((src.match(/setDynamicProperty\(STORE_REGISTRY_PROP/g)||[]).length,1,'the registry is written only by saveStores');
});
test('owner keeps edit rights and a stranger does not, through the cached path',()=>{
 prep();
 assert.equal(run(`canEditBlock(player,block)`),true);
 assert.equal(run(`canEditBlock({id:'stranger',playerPermissionLevel:0},block)`),false);
});
test('heart curse watcher does nothing while the record has no curse and nothing expires',()=>{
 prep();
 run(`globalThis.hp2=new Map();globalThis.effCalls=0;globalThis.tp={id:'hp1',getDynamicProperty:k=>hp2.get(k),setDynamicProperty:(k,v)=>v===undefined?hp2.delete(k):hp2.set(k,v),getEffect:()=>{effCalls++;},addEffect:()=>{effCalls++;}};
  HEART_CURSE_CACHE.clear();hp2.set(HEART_LEDGER_PROP,JSON.stringify({speed:{amp:0,end:Date.now()+60000}}));
  for(let i=0;i<100;i++)heartMaintainCurses(tp);`);
 assert.equal(run(`effCalls`),0);
 run(`heartMaintainCurses(tp,Date.now()+61000)`);
 assert.deepEqual(JSON.parse(run(`hp2.get(HEART_LEDGER_PROP)`)),{},'expired entry is still removed');
});
test('heart curse watcher still re-applies a curse removed by milk',()=>{
 prep();
 run(`globalThis.eff=new Map();globalThis.hp3=new Map();globalThis.tq={id:'hp2',getDynamicProperty:k=>hp3.get(k),setDynamicProperty:(k,v)=>hp3.set(k,v),getEffect:id=>eff.get(id),addEffect:(id,d,o)=>eff.set(id,{duration:d,amplifier:o.amplifier})};
  HEART_CURSE_CACHE.clear();hp3.set(HEART_LEDGER_PROP,JSON.stringify({blindness:{amp:1,end:Date.now()+30000}}));heartMaintainCurses(tq);eff.clear();heartMaintainCurses(tq);`);
 assert.equal(run(`eff.get('blindness').amplifier`),1);
});
test('spawner wallet holders are found once and then tracked without scanning every property',()=>{
 prep();
 run(`globalThis.scans=0;const g=world.getDynamicPropertyIds;world.getDynamicPropertyIds=function(){scans++;return g?g.call(world):[];};SP_HOLDER_IDS=undefined;spHolderIds();spHolderIds();spHolderIds();`);
 assert.equal(run(`scans`),1);
});
console.log(count+' perf test groups passed');
