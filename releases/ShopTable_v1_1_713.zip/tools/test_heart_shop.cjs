const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const env=require('./test_smelt_sales.cjs');
const {run,ctx,prep,player,playerInv,shopInv,worldProps,ItemStack,Container}=env;
let count=0;
function test(name,fn){fn();count++;console.log('PASS HEART '+name);}
const plain=x=>JSON.parse(JSON.stringify(x));
Container.prototype.addItem=function(item){
 let remain=item.amount;
 for(let i=0;i<this.size&&remain>0;i++){
  const old=this.getItem(i);
  if(old&&(!old.isStackableWith(item)||old.amount>=old.maxAmount))continue;
  const n=Math.min(remain,(old?.maxAmount??item.maxAmount)-(old?.amount??0));
  const next=old??item.clone();next.amount=(old?.amount??0)+n;this.setItem(i,next);remain-=n;
 }
 if(remain){const left=item.clone();left.amount=remain;return left;}
};
run(`
globalThis.heartEffects={};globalThis.heartProps=new Map();globalThis.hp=20;globalThis.gaugeMax=20;globalThis.failGauge=false;globalThis.handItem=undefined;
globalThis.failEffect=false;
const originalComponent=player.getComponent;
player.getComponent=k=>k==='minecraft:health'?{get currentValue(){return hp;},get effectiveMax(){return gaugeMax+(heartEffects.health_boost?4*(heartEffects.health_boost.amplifier+1):0);},setCurrentValue(v){hp=v;}}
 :k==='minecraft:equippable'?{getEquipment:()=>handItem?.clone(),setEquipment:(_,v)=>{handItem=v?.clone();}}
 :originalComponent(k);
player.triggerEvent=id=>{
 if(failGauge){failGauge=false;throw Error('injected gauge event failure');}
 if(id==='shopuilook2:heart_gauge_reset')gaugeMax=20;
 else {const m=/^shopuilook2:heart_gauge_(\\d+)$/.exec(id);if(!m)throw Error('unknown event '+id);gaugeMax=Number(m[1])*2;}
 hp=Math.min(hp,gaugeMax);
};
player.getEffect=id=>heartEffects[id]?{...heartEffects[id]}:undefined;
player.addEffect=(id,duration,options)=>{
 if(failEffect){failEffect=false;throw Error('injected effect failure');}
 const amp=options?.amplifier??0;
 if(id==='instant_damage')hp-=6*2**amp;
 else if(id==='instant_health')hp=Math.min(20,hp+4*2**amp);
 else heartEffects[id]={duration,amplifier:amp};
};
player.removeEffect=id=>delete heartEffects[id];
player.getDynamicProperty=k=>heartProps.get(k);
player.setDynamicProperty=(k,v)=>{if(v===undefined)heartProps.delete(k);else heartProps.set(k,v);};
system.run=fn=>fn();
`);
function reset(type=5,clock=1500,level=1){
 prep();playerInv.items.clear();shopInv.items.clear();worldProps.clear();ctx.heartType=type;ctx.heartClock=clock;ctx.heartLevel=level;
 run(`active.clear();FZ_PRODUCT_EDITS.clear();setCurrentProduct(block,undefined);block.typeId='shopuilook2:panel_heart';hp=20;gaugeMax=20;failGauge=false;heartEffects={};heartProps.clear();handItem=undefined;failEffect=false;system.currentTick++;HEART_LAST_USE.clear();
 const r=base('p1','minecraft:porkchop');r.settings.shop_heart_product=true;r.settings.shop_heart_type=heartType;r.settings.heart_level=String(heartLevel);r.settings.heart_duration=String(heartClock);putProducts([r]);
 `);
}
test('all eleven debit and credit pairs plus health exist in the requested order',()=>{
 const expected=[['weakness','strength'],['slowness','speed'],['poison','regeneration'],['hunger','saturation'],['mining_fatigue','haste'],['blindness','night_vision'],['nausea','resistance'],['wither','water_breathing'],['bad_omen','village_hero'],['instant_damage','instant_health'],['levitation','slow_falling'],['','health_boost']];
 for(let i=0;i<expected.length;i++){
  reset(i);assert.equal(run(`heartSpec(loadProduct(block,'p1').settings).effect`),expected[i][0]);
  assert.equal(run(`HEART_BUFF[heartSpec(loadProduct(block,'p1').settings).buff].effect`),expected[i][1]);
 }
});
test('time keypad canonicalizes to 30-second steps and caps at exactly 60 minutes',()=>{
 for(const [input,expected]of [[0,30],[1,30],[29,30],[30,30],[45,100],[60,100],[130,130],[1510,1500],[1520,1530],[5959,6000],[6000,6000],[9999,6000]])assert.equal(ctx.heartClockClamp(input),expected);
});
test('heart prices have exactly one cost and ignore ordinary currency fields',()=>{
 reset();run(`const r=loadProduct(block,'p1');r.settings.price='999';r.settings.required_item='minecraft:diamond';r.settings.required_item_count='64';r.settings.shop_payment_method=2;saveProduct(block,r);globalThis.price=shopPurchasePrice(loadProduct(block,'p1'),registry.stores.s1,'d1',2,player.id);`);
 assert.equal(ctx.price.ok,true);assert.equal(ctx.price.entries.length,1);assert.equal(ctx.price.entries[0].k,'heart');
 assert.equal(ctx.price.items.size,0);assert.equal(ctx.price.xp,0);assert.equal(ctx.price.shopPts,0);
 assert.equal(ctx.price.heart.seconds,900);assert.equal(ctx.price.heart.units,2);
});
test('unconfigured legacy heart products cannot be purchased using normal money',()=>{
 reset();run(`const r=base('p1');putProducts([r]);globalThis.price=shopPurchasePrice(loadProduct(block,'p1'),registry.stores.s1,'d1',1,player.id);`);
 assert.equal(ctx.price.ok,false);assert.equal(run(`shopPayEntries(loadProduct(block,'p1'),['minecraft:emerald']).length`),0);
});
test('ordinary shops retain ordinary payment dropdowns and their existing prices',()=>{
 reset();run(`block.typeId='shopuilook2:panel_furnace';const r=base('p1');putProducts([r]);`);
 assert.equal(run(`isDropdownRuntimeActive(block,DROPDOWN_BY_ID.get('heart_type'))`),false);
 assert.equal(run(`isDropdownRuntimeActive(block,DROPDOWN_BY_ID.get('payment_method'))`),true);
 assert.equal(run(`shopPurchasePrice(loadProduct(block,'p1'),registry.stores.s1,'d1',1,player.id).entries[0].n2`),100);
});
test('blindness 15:00 times two applies 30:00 and stores two 15:00 night-vision rewards',()=>{
 reset(5,1500,2);run(`globalThis.result=shopPurchaseCommit(player,block,'p1',2);`);
 assert.equal(ctx.result.ok,true,ctx.result.message);
 assert.equal(run(`heartEffects.blindness.duration`),1800*20);assert.equal(run(`heartEffects.blindness.amplifier`),1);
 assert.equal(run(`loadProduct(block,'p1').stock[0].item.amount`),14);
 const items=plain(run(`shopProceedsRead('s1').items`));assert.deepEqual(items,{'heart@shopuilook2:buff_night_vision@900@2':2});
 assert.equal(playerInv.items.size,0);
});
test('the seller bonus never increases the number of timed power rewards',()=>{
 reset();run(`const price=shopPurchasePrice(loadProduct(block,'p1'),registry.stores.s1,'d1',2,player.id);globalThis.reward=shopProceedsForPurchase(price,{proceedsPct:100})`);
 assert.deepEqual(plain(run(`[...reward]`)),[['heart@shopuilook2:buff_night_vision@900@1',2]]);
});
test('timed effect purchases add to existing duration and cannot reduce an existing stronger debit',()=>{
 reset(5,1500,1);run(`heartEffects.blindness={duration:100,amplifier:2};globalThis.result=shopPurchaseCommit(player,block,'p1',1)`);
 assert.equal(ctx.result.ok,true);assert.equal(run(`heartEffects.blindness.duration`),18100);assert.equal(run(`heartEffects.blindness.amplifier`),2);
});
test('health payments can spend exactly nine hearts out of ten and leave one full heart',()=>{
 reset(11,1500,9);run(`globalThis.result=shopPurchaseCommit(player,block,'p1',1)`);
 assert.equal(ctx.result.ok,true,ctx.result.message);assert.equal(ctx.hp,2);
 assert.deepEqual(plain(run(`shopProceedsRead('s1').items`)),{'heart@shopuilook2:buff_health_boost@900@9':1});
});
test('health affordability rejects spending the last heart before any items or rewards move',()=>{
 reset(11,1500,10);run(`globalThis.result=shopPurchaseCommit(player,block,'p1',1)`);
 assert.equal(ctx.result.ok,false);assert.equal(ctx.hp,20);assert.equal(run(`loadProduct(block,'p1').stock[0].item.amount`),16);
 assert.deepEqual(plain(run(`shopProceedsRead('s1').items`)),{});
 reset(11,1500,1);run(`hp=3;globalThis.result=shopPurchaseCommit(player,block,'p1',1)`);assert.equal(ctx.result.ok,true);assert.equal(ctx.hp,3);assert.equal(ctx.gaugeMax,18);
});
test('quantity changes multiply the heart debit and preserve the minimum remaining heart',()=>{
 reset(11,1500,3);run(`globalThis.first=shopPurchasePrice(loadProduct(block,'p1'),registry.stores.s1,'d1',3,player.id);globalThis.second=shopPurchasePrice(loadProduct(block,'p1'),registry.stores.s1,'d1',4,player.id)`);
 assert.equal(ctx.first.ok,true);assert.equal(ctx.second.ok,false);
});
test('instant damage and healing use one hit each and no duration',()=>{
 reset(9,6000,1);run(`saveDropdownChoice(block,DROPDOWN_BY_ID.get('heart_type'),9);globalThis.result=shopPurchaseCommit(player,block,'p1',1)`);
 assert.equal(ctx.result.ok,true,ctx.result.message);assert.equal(ctx.hp,14);
 assert.deepEqual(plain(run(`shopProceedsRead('s1').items`)),{'heart@shopuilook2:buff_instant_health@0@1':1});
 assert.equal(run(`textFieldsForGroup(block,3).includes('heart_duration')`),false);
});
test('a duration of 60:00 is allowed per unit and larger aggregate times are not truncated',()=>{
 reset(0,6000,1);run(`globalThis.result=shopPurchaseCommit(player,block,'p1',2)`);
 assert.equal(ctx.result.ok,true);assert.equal(run(`heartEffects.weakness.duration`),7200*20);
});
test('invalid strengths and noncanonical or excessive saved durations are not sold',()=>{
 for(const [level,clock]of [[0,1500],[256,1500],[1,1501],[1,6030],[1,-1],[1,0]]){
  reset(5,clock,level);assert.equal(run(`shopPurchasePrice(loadProduct(block,'p1'),registry.stores.s1,'d1',1,player.id).ok`),false);
 }
});
test('the quote includes effect strength and catches stale confirmations',()=>{
 reset();run(`globalThis.quote=shopPurchaseQuote(shopPurchasePrice(loadProduct(block,'p1'),registry.stores.s1,'d1',1,player.id),1);const r=loadProduct(block,'p1');r.settings.heart_level='2';saveProduct(block,r);globalThis.result=shopPurchaseCommit(player,block,'p1',1,quote);`);
 assert.equal(ctx.result.ok,false);assert.deepEqual(plain(ctx.heartEffects),{});
});
test('delivery failure rolls back the debit, ledger, stock and seller rewards',()=>{
 reset();run(`heartEffects.blindness={duration:100,amplifier:0};heartProps.set(HEART_LEDGER_PROP,'{"blindness":{"amp":0,"end":123}}');shopInv.failSlot=SH_BOX_SLOTS[0];globalThis.result=shopPurchaseCommit(player,block,'p1',1)`);
 assert.equal(ctx.result.ok,false);assert.equal(run(`heartEffects.blindness.duration`),100);
 assert.equal(run(`heartProps.get(HEART_LEDGER_PROP)`),'{"blindness":{"amp":0,"end":123}}');
 assert.equal(run(`loadProduct(block,'p1').stock[0].item.amount`),16);assert.deepEqual(plain(run(`shopProceedsRead('s1').items`)),{});
});
test('health deductions are restored if delivery fails',()=>{
 reset(11,1500,3);run(`shopInv.failSlot=SH_BOX_SLOTS[0];globalThis.result=shopPurchaseCommit(player,block,'p1',1)`);
 assert.equal(ctx.result.ok,false);assert.equal(ctx.hp,20);assert.equal(run(`loadProduct(block,'p1').stock[0].item.amount`),16);
});
test('an effect API failure cancels the transaction instead of giving free goods',()=>{
 reset();run(`failEffect=true;globalThis.result=shopPurchaseCommit(player,block,'p1',1)`);
 assert.equal(ctx.result.ok,false);assert.equal(run(`loadProduct(block,'p1').stock[0].item.amount`),16);
 assert.equal([...shopInv.items.values()].some(x=>x.typeId==='minecraft:porkchop'),false);
});
test('different lengths or strengths remain distinct proceeds entries',()=>{
 reset();run(`shopPurchaseCommit(player,block,'p1',1);const r=loadProduct(block,'p1');r.settings.heart_duration='3000';r.settings.heart_level='2';saveProduct(block,r);shopPurchaseCommit(player,block,'p1',1);`);
 assert.deepEqual(plain(run(`shopProceedsRead('s1').items`)),{'heart@shopuilook2:buff_night_vision@900@1':1,'heart@shopuilook2:buff_night_vision@1800@2':1});
});
test('power items preserve length and strength without dynamic properties on stackable items',()=>{
 const old=ItemStack.prototype.setDynamicProperty;ItemStack.prototype.setDynamicProperty=function(){throw Error('stackable dynamic properties unsupported');};
 try{
  const item=ctx.heartRewardItem('heart@shopuilook2:buff_night_vision@900@2',2);
  assert.equal(item.typeId,'shopuilook2:buff_night_vision');assert.equal(item.amount,2);
  assert.equal(ctx.heartRewardKeyOf(item),'heart@shopuilook2:buff_night_vision@900@2');
  assert.match(item.nameTag,/15:00/);
 }finally{ItemStack.prototype.setDynamicProperty=old;}
});
test('the real proceeds grid materializes the correct typed power item',()=>{
 reset();run(`shopPurchaseCommit(player,block,'p1',2);for(const i of SH_BOX_SLOTS)shopInv.setItem(i,undefined);globalThis.proceedsRec={proceedsMode:{storeId:'s1',placed:Array(PROCEEDS_GRID_COUNT).fill(null),blocked:new Set()}};proceedsSync(player,proceedsRec,shopInv,true);`);
 const item=run(`shopInv.getItem(PROCEEDS_GRID_SLOTS[0])`);
 assert.equal(item.typeId,'shopuilook2:buff_night_vision');assert.equal(item.amount,2);
 assert.equal(ctx.heartRewardKeyOf(item),'heart@shopuilook2:buff_night_vision@900@1');
});
test('taking a power item from the proceeds grid decreases only its own stored entry',()=>{
 run(`shopInv.setItem(PROCEEDS_GRID_SLOTS[0],undefined);proceedsSync(player,proceedsRec,shopInv,false)`);
 assert.deepEqual(plain(run(`shopProceedsRead('s1').items`)),{});
});
test('taking all proceeds preserves typed item metadata',()=>{
 reset();run(`shopPurchaseCommit(player,block,'p1',2);proceedsTakeAll(player,'s1')`);
 const item=[...playerInv.items.values()].find(x=>x.typeId==='shopuilook2:buff_night_vision');
 assert.ok(item);assert.equal(item.amount,2);assert.equal(ctx.heartRewardKeyOf(item),'heart@shopuilook2:buff_night_vision@900@1');
 assert.deepEqual(plain(run(`shopProceedsRead('s1').items`)),{});
});
test('using one power item grants exactly its configured duration and strength and consumes one',()=>{
 reset();run(`handItem=heartRewardItem('heart@shopuilook2:buff_night_vision@900@2',2);heartUseBuff(player,handItem)`);
 assert.equal(run(`heartEffects.night_vision.duration`),18000);assert.equal(run(`heartEffects.night_vision.amplifier`),1);
 assert.equal(run(`handItem.amount`),1);
});
test('instant healing power is one heal and has no persisted duration',()=>{
 reset();run(`hp=8;handItem=heartRewardItem('heart@shopuilook2:buff_instant_health@0@1',1);heartUseBuff(player,handItem)`);
 assert.equal(ctx.hp,12);assert.equal(run(`handItem`),undefined);assert.equal(run(`heartEffects.instant_health`),undefined);
});
test('a failed power use preserves the item and does not grant an effect',()=>{
 reset();run(`handItem=heartRewardItem('heart@shopuilook2:buff_night_vision@900@2',1);failEffect=true;heartUseBuff(player,handItem)`);
 assert.equal(run(`handItem.amount`),1);assert.equal(run(`heartEffects.night_vision`),undefined);
});
test('shop cards, confirmation labels and tooltips expose time rather than numeric money',()=>{
 reset();run(`globalThis.rec=loadProduct(block,'p1');globalThis.price=shopPurchasePrice(rec,registry.stores.s1,'d1',2,player.id)`);
 assert.match(run(`shopPriceGlyphText(price.entries)`),/15:00/);
 assert.match(run(`shopCardPriceLines(price.entries)[0]`),/15:00/);
 assert.equal(run(`heartEntryText(price.entries[0],2)`),'30:00');
 assert.match(run(`transactionText(rec.settings)`),/盲目.*15:00/);
 assert.match(run(`tipTradeLineFromEntries(rec.settings,[],price.entries)`),/15:00/);
});
test('normal editor exposes only the heart picker and keypad inputs in the payment section',()=>{
 reset();run(`props.set(LAYOUT_MIGRATION_PROP,1);globalThis.rec=makeRecord(player,block,shopInv);rec.landing=true;active.set(player.id,rec);enterProduct(player,rec,block,shopInv,'p1');globalThis.rec=active.get(player.id);`);
 assert.equal(run(`shopInv.getItem(HEART_EDIT_SLOT).amount`),60);
 assert.deepEqual(plain(run(`textFieldsForGroup(block,3)`)),['heart_level','heart_duration']);
 assert.equal(run(`isDropdownRuntimeActive(block,DROPDOWN_BY_ID.get('payment_method'))`),false);
 assert.equal(run(`isDropdownRuntimeActive(block,DROPDOWN_BY_ID.get('heart_type'))`),true);
 assert.equal(run(`buildTextInputForm(block,3,player)`),undefined);
});
test('four-digit clock input uses the ordinary keypad and saves a canonical MMSS value',()=>{
 run(`kpOpen(rec,block,KP_BY_ID.get('heart_duration'));rec.kpBuf='1530';kpStore(rec,block);kpWriteAll(shopInv,block,rec,player)`);
 assert.equal(run(`getStringProp(block,'heart_duration','')`),'1530');
 assert.equal(run(`shopInv.getItem(217).amount`),2);
 assert.equal(run(`formatFieldDisplay('heart_duration','1530')`),'15:30');
 assert.equal(run(`TEXT_FIELD_NAMES.includes('heart_duration')`),true);
 assert.equal(run(`allSettingProps().includes('heart_level')`),true);
});
test('actual dropdown clicks select all twelve costs directly from one list',()=>{
 run(`globalThis.finishHeartVisual=()=>{for(let i=0;i<8&&rec.pendingVisual;i++){const fn=rec.pendingVisual.apply;rec.pendingVisual=null;system.currentTick+=10;fn(block,shopInv);}};finishHeartVisual();`);
 const slots=plain(run(`HEART_CHOICE_SLOTS`));assert.equal(slots.length,12);
 for(let target=0;target<12;target++){
  run(`finishHeartVisual();shopInv.setItem(42,undefined);tickSession(player,rec,block,shopInv);finishHeartVisual();`);
  assert.equal(run(`rec.openDropdown`),'heart_type');
  for(const slot of slots)assert.equal(run(`shopInv.getItem(${slot}).amount`),1);
  run(`shopInv.setItem(${slots[target]},undefined);tickSession(player,rec,block,shopInv);finishHeartVisual();`);
  assert.equal(run(`getChoiceById(block,'heart_type')`),target);
  assert.equal(run(`rec.openDropdown`),null);
  assert.equal(run(`shopInv.getItem(HEART_EDIT_SLOT).amount`),60);
  assert.equal(run(`HEART_CHOICE_EXTRA_SLOTS.every(x=>shopInv.getItem(x)===undefined)`),true);
 }
});
test('the transplanted dropdown closes outside, reopens, and accepts the same choice repeatedly',()=>{
 for(let attempt=0;attempt<2;attempt++){
  run(`shopInv.setItem(42,undefined);tickSession(player,rec,block,shopInv);finishHeartVisual();`);
  assert.equal(run(`rec.openDropdown`),'heart_type');
  run(`shopInv.setItem(HEART_CHOICE_SLOTS[11],undefined);tickSession(player,rec,block,shopInv);finishHeartVisual();`);
  assert.equal(run(`getChoiceById(block,'heart_type')`),11);assert.equal(run(`rec.openDropdown`),null);
 }
 run(`shopInv.setItem(42,undefined);tickSession(player,rec,block,shopInv);finishHeartVisual();shopInv.setItem(42,undefined);tickSession(player,rec,block,shopInv);finishHeartVisual();`);
 assert.equal(run(`rec.openDropdown`),null);assert.equal(run(`getChoiceById(block,'heart_type')`),11);
 assert.equal(run(`HEART_CHOICE_EXTRA_SLOTS.every(x=>shopInv.getItem(x)===undefined)`),true);
});
test('real keypad button clicks and the Save footer persist the heart product without forms',()=>{
 run(`finishHeartVisual();shopInv.setItem(200,undefined);kpHandleClick(player,rec,block,shopInv);shopInv.setItem(KP_DOT,undefined);kpHandleClick(player,rec,block,shopInv);`);
 for(const n of [1,5,3,0])run(`shopInv.setItem(KP_DIGIT_BASE+${n},undefined);kpHandleClick(player,rec,block,shopInv);`);
 assert.equal(run(`getStringProp(block,'heart_duration','')`),'1530');
 run(`shopInv.setItem(199,undefined);kpHandleClick(player,rec,block,shopInv);shopInv.setItem(KP_DOT,undefined);kpHandleClick(player,rec,block,shopInv);shopInv.setItem(KP_DIGIT_BASE+2,undefined);kpHandleClick(player,rec,block,shopInv);finishHeartVisual();shopInv.setItem(FOOTER_SAVE_SLOT,undefined);tickSession(player,rec,block,shopInv);`);
 assert.equal(run(`loadProduct(block,'p1').settings.heart_duration`),'1530');
 assert.equal(run(`loadProduct(block,'p1').settings.heart_level`),'2');
 assert.equal(run(`loadProduct(block,'p1').settings.shop_heart_type`),11);
 assert.equal(run(`loadProduct(block,'p1').settings.shop_heart_product`),true);
 assert.equal(run(`formOpenCount`),0);
});
test('heart duration controls are not active for instantaneous damage',()=>{
 run(`saveDropdownChoice(block,DROPDOWN_BY_ID.get('heart_type'),9)`);
 assert.equal(run(`KP_BY_ID.get('heart_duration').active(block)`),false);
 assert.deepEqual(plain(run(`textFieldsForGroup(block,3)`)),['heart_level']);
});
test('resource definitions include all twelve debit items and all paired buffs',()=>{
 for(const id of plain(run(`HEART_TYPES`))){
  assert.ok(fs.existsSync(path.join(__dirname,'../behavior_pack/items',id.split(':')[1]+'.json')));
  const buff=run(`HEART_PAY[${JSON.stringify(id)}].buff`);
  assert.ok(fs.existsSync(path.join(__dirname,'../behavior_pack/items',buff.split(':')[1]+'.json')));
 }
});
test('timed gauge payments reduce maximum hearts without spending current HP, then restore only the gauge',()=>{
 reset(11,30,2);run(`hp=8;globalThis.result=shopPurchaseCommit(player,block,'p1',1);globalThis.end=JSON.parse(heartProps.get(HEART_GAUGE_PROP)).entries[0].end`);
 assert.equal(ctx.result.ok,true,ctx.result.message);assert.equal(ctx.gaugeMax,16);assert.equal(ctx.hp,8);
 run(`heartGaugeRefresh(player,false,end-1)`);assert.equal(ctx.gaugeMax,16);
 run(`heartGaugeRefresh(player,false,end)`);assert.equal(ctx.gaugeMax,20);assert.equal(ctx.hp,8);
});
test('separate gauge payments expire independently at their configured times',()=>{
 reset(11,30,1);run(`shopPurchaseCommit(player,block,'p1',1);globalThis.end1=JSON.parse(heartProps.get(HEART_GAUGE_PROP)).entries[0].end;const r=loadProduct(block,'p1');r.settings.heart_duration='100';saveProduct(block,r);shopPurchaseCommit(player,block,'p1',1);globalThis.end2=Math.max(...JSON.parse(heartProps.get(HEART_GAUGE_PROP)).entries.map(x=>x.end))`);
 assert.equal(ctx.gaugeMax,16);run(`heartGaugeRefresh(player,false,end1)`);assert.equal(ctx.gaugeMax,18);
 run(`heartGaugeRefresh(player,false,end2)`);assert.equal(ctx.gaugeMax,20);
});
test('a respawn or reconnect reapplies only the still-active gauge entries',()=>{
 reset(11,30,2);run(`shopPurchaseCommit(player,block,'p1',1);globalThis.end=JSON.parse(heartProps.get(HEART_GAUGE_PROP)).entries[0].end;gaugeMax=20;hp=20;heartGaugeRefresh(player,true)`);
 assert.equal(ctx.gaugeMax,16);assert.equal(ctx.hp,16);
 run(`gaugeMax=20;hp=20;heartGaugeRefresh(player,true,end)`);assert.equal(ctx.gaugeMax,20);
});
test('health reward items add exactly the number of maximum hearts they carry, without healing',()=>{
 reset();run(`hp=7;handItem=heartRewardItem('heart@shopuilook2:buff_health_boost@30@3',1);heartUseBuff(player,handItem);globalThis.end=JSON.parse(heartProps.get(HEART_GAUGE_PROP)).entries[0].end`);
 assert.equal(ctx.gaugeMax,26);assert.equal(ctx.hp,7);assert.equal(run(`handItem`),undefined);
 assert.equal(run(`heartEffects.health_boost`),undefined);
 run(`heartGaugeRefresh(player,false,end)`);assert.equal(ctx.gaugeMax,20);assert.equal(ctx.hp,7);
});
test('a reward that exceeds maximum gauge capacity preserves the item and the existing gauge',()=>{
 reset();run(`gaugeMax=1024;handItem=heartRewardItem('heart@shopuilook2:buff_health_boost@30@1',1);heartUseBuff(player,handItem)`);
 assert.equal(ctx.gaugeMax,1024);assert.equal(run(`handItem.amount`),1);assert.equal(ctx.hp,20);
});
test('quantity multiplies donated gauge hearts and the restoration duration',()=>{
 reset(11,30,2);run(`globalThis.result=shopPurchaseCommit(player,block,'p1',2);globalThis.gauge=JSON.parse(heartProps.get(HEART_GAUGE_PROP))`);
 assert.equal(ctx.result.ok,true);assert.equal(ctx.gaugeMax,12);assert.equal(ctx.gauge.entries[0].delta,-8);
 assert.equal(ctx.gauge.entries[0].end-Date.now()<61000,true);
 assert.deepEqual(plain(run(`shopProceedsRead('s1').items`)),{'heart@shopuilook2:buff_health_boost@30@2':2});
});
test('a gauge event failure cancels delivery and seller proceeds',()=>{
 reset(11,30,1);run(`failGauge=true;globalThis.result=shopPurchaseCommit(player,block,'p1',1)`);
 assert.equal(ctx.result.ok,false);assert.equal(ctx.gaugeMax,20);assert.equal(ctx.hp,20);
 assert.equal(run(`loadProduct(block,'p1').stock[0].item.amount`),16);assert.deepEqual(plain(run(`shopProceedsRead('s1').items`)),{});
});
test('delivery failure restores the original maximum gauge and removes a new debit ledger',()=>{
 reset(11,30,1);run(`shopInv.failSlot=SH_BOX_SLOTS[0];globalThis.result=shopPurchaseCommit(player,block,'p1',1)`);
 assert.equal(ctx.result.ok,false);assert.equal(ctx.gaugeMax,20);assert.equal(run(`heartProps.get(HEART_GAUGE_PROP)`),undefined);
});
test('delivery failure preserves an already-active gauge debit and its exact expiry',()=>{
 reset(11,30,1);run(`shopPurchaseCommit(player,block,'p1',1);globalThis.priorGauge=heartProps.get(HEART_GAUGE_PROP);shopInv.failSlot=SH_BOX_SLOTS[0];globalThis.result=shopPurchaseCommit(player,block,'p1',1)`);
 assert.equal(ctx.result.ok,false);assert.equal(ctx.gaugeMax,18);assert.equal(run(`heartProps.get(HEART_GAUGE_PROP)`),ctx.priorGauge);
});
test('native buyer confirmation includes per-unit time and the multiplied total time',()=>{
 reset(5,1530,1);run(`globalThis.p=shopPurchasePrice(loadProduct(block,'p1'),registry.stores.s1,'d1',2,player.id);globalThis.sm={player,txt:new Map(),gen:new Map(),confirm:{id:'p1',qty:2}};shopConfirmCostWrite(shopInv,sm,p,2,registry.stores.s1)`);
 assert.equal(run(`shopInv.getItem(SH_CF_COST_SLOTS[0]).nameTag`),'31:00');
 assert.match(run(`shopCardPriceLines(p.entries)[0]`),/15:30/);
 reset(11,1530,1);run(`globalThis.p=shopPurchasePrice(loadProduct(block,'p1'),registry.stores.s1,'d1',2,player.id);globalThis.sm={player,txt:new Map(),gen:new Map(),confirm:{id:'p1',qty:2}};shopConfirmCostWrite(shopInv,sm,p,2,registry.stores.s1)`);
 assert.equal(run(`shopInv.getItem(SH_CF_COST_SLOTS[0]).nameTag`),'31:00');
});
test('five 30-second units produce a 2:30 debit and matching quantity confirmation for both gauge and effects',()=>{
 reset(11,30,1);run(`globalThis.p=shopPurchasePrice(loadProduct(block,'p1'),registry.stores.s1,'d1',5,player.id);globalThis.sm={player,txt:new Map(),gen:new Map(),confirm:{id:'p1',qty:5}};shopConfirmCostWrite(shopInv,sm,p,5,registry.stores.s1);globalThis.confirmText=shopInv.getItem(SH_CF_COST_SLOTS[0]).nameTag;globalThis.start=Date.now();globalThis.result=shopPurchaseCommit(player,block,'p1',5);globalThis.entry=JSON.parse(heartProps.get(HEART_GAUGE_PROP)).entries[0]`);
 assert.equal(ctx.confirmText,'2:30');assert.equal(ctx.result.ok,true);assert.equal(ctx.gaugeMax,10);assert.ok(ctx.entry.end-ctx.start>=150000&&ctx.entry.end-ctx.start<=150050);
 run(`heartGaugeRefresh(player,false,entry.end-1)`);assert.equal(ctx.gaugeMax,10);run(`heartGaugeRefresh(player,false,entry.end)`);assert.equal(ctx.gaugeMax,20);
 reset(5,30,1);run(`globalThis.result=shopPurchaseCommit(player,block,'p1',5)`);
 assert.equal(ctx.result.ok,true);assert.equal(run(`heartEffects.blindness.duration`),3000);
});
test('milk cannot clear a purchased curse and restoring it never extends the original deadline',()=>{
 reset(5,30,1);run(`shopPurchaseCommit(player,block,'p1',1);globalThis.debitRaw=heartProps.get(HEART_LEDGER_PROP);globalThis.end=JSON.parse(debitRaw).blindness.end;delete heartEffects.blindness;heartMaintainCurses(player,end-10000)`);
 assert.equal(run(`heartEffects.blindness.duration`),200);assert.equal(run(`heartProps.get(HEART_LEDGER_PROP)`),ctx.debitRaw);
 run(`delete heartEffects.blindness;heartMaintainCurses(player,end)`);
 assert.equal(run(`heartEffects.blindness`),undefined);assert.equal(run(`JSON.parse(heartProps.get(HEART_LEDGER_PROP)).blindness`),undefined);
});
test('the real milk-completion handler restores only the unpaid curse',()=>{
 reset(5,30,1);run(`shopPurchaseCommit(player,block,'p1',1);delete heartEffects.blindness`);
 const handler=env.handlers.find(fn=>fn.toString().includes('minecraft:milk_bucket')&&fn.toString().includes('heartMaintainCurses'));
 assert.ok(handler);handler({source:player,itemStack:new ItemStack('minecraft:milk_bucket',1)});
 assert.ok(run(`heartEffects.blindness.duration>590`));
});
test('buying after a milk clear adds the new time to the still-unpaid duration',()=>{
 reset(0,30,2);run(`shopPurchaseCommit(player,block,'p1',1);globalThis.oldEnd=JSON.parse(heartProps.get(HEART_LEDGER_PROP)).weakness.end;delete heartEffects.weakness;globalThis.result=shopPurchaseCommit(player,block,'p1',1);globalThis.newEnd=JSON.parse(heartProps.get(HEART_LEDGER_PROP)).weakness.end`);
 assert.equal(ctx.result.ok,true);assert.ok(ctx.newEnd-ctx.oldEnd>=29950);assert.equal(run(`heartEffects.weakness.amplifier`),1);
});
test('milk protection does not recreate unrelated effects, reward buffs or instant damage',()=>{
 reset();run(`heartEffects.poison={duration:600,amplifier:0};delete heartEffects.poison;heartMaintainCurses(player)`);assert.equal(run(`heartEffects.poison`),undefined);
 run(`handItem=heartRewardItem('heart@shopuilook2:buff_night_vision@30@1',1);heartUseBuff(player,handItem);delete heartEffects.night_vision;heartMaintainCurses(player)`);assert.equal(run(`heartEffects.night_vision`),undefined);
 reset(9,30,1);run(`shopPurchaseCommit(player,block,'p1',1);heartMaintainCurses(player);heartMaintainCurses(player)`);assert.equal(ctx.hp,14);
});
test('the actual buyer-list render publishes only the time (no heart count) in the first left-hand card',()=>{
 reset(11,30,1);run(`const r=loadProduct(block,'p1');r.items[0].id='minecraft:lava_bucket';r.items[0].key='minecraft:lava_bucket';r.stock[0].item.id='minecraft:lava_bucket';saveProduct(block,r);globalThis.buyerRec={};enterShopMode(player,buyerRec,block,shopInv);globalThis.leftSlot=shSlots(0).price[0];globalThis.leftPrice=shopInv.getItem(leftSlot).nameTag;`);
 assert.equal(ctx.leftPrice,run(`HEART_PAY['shopuilook2:pay_health'].glyph`)+'0:30');assert.equal(ctx.leftSlot,92);   // v1.1.703: 「1個」は出さない
});
console.log(`${count} heart test groups passed; ${env.getTestCount()+count} total test groups passed`);

module.exports={getHeartTestCount:()=>count};
