// v1.1.698 エンチャントテーブル：クローン元の本（5冊・減らない）からランダムで付ける
const assert=require('node:assert/strict');
const env=require('./test_smelt_sales.cjs');
const {run,prep}=env;
let count=0;
function test(name,fn){fn();count++;console.log('PASS CLONE '+name);}
run(`globalThis.origRestore=restoreItemStack;
 restoreItemStack=snap=>snap&&snap.tplEnch?{typeId:'minecraft:enchanted_book',amount:1,getComponent:k=>k==='minecraft:enchantable'?{getEnchantments:()=>snap.tplEnch.map(([id,level])=>({type:{id},level}))}:undefined}:origRestore(snap);
 globalThis.mkItem=(ok=()=>true)=>{const list=[];return {typeId:'minecraft:diamond_sword',amount:1,list,getComponent:k=>k==='minecraft:enchantable'?{getEnchantments:()=>list,canAddEnchantment:e=>ok(e)&&!list.some(x=>x.type.id===e.type.id),addEnchantment:e=>list.push(e)}:undefined};};
 globalThis.book=(...e)=>({id:'minecraft:enchanted_book',n:1,snap:{id:'minecraft:enchanted_book',amount:1,tplEnch:e}});`);
function setup(mats,levels){prep();run(`block.typeId='shopuilook2:panel_enchant';const m=Array(54).fill(null);for(const [i,x] of Object.entries(${mats}))m[i]=x;registry.stores.s1.enchant={auto:true,levels:${levels},mats:m,made:0};
 EnchantmentTypes.getAll=()=>[{id:'minecraft:looting',maxLevel:3}];`);}
test('only enchantments from the template books are used, at the book level; lapis = level sum, levels = half',()=>{
 for(let r=0;r<20;r++){
  setup(`{0:{id:'minecraft:lapis_lazuli',n:64},45:book(['minecraft:sharpness',5]),46:book(['minecraft:unbreaking',3],['minecraft:binding',1])}`,40);
  run(`globalThis.it=mkItem();globalThis.plan=enApply(registry.stores.s1,[it]);`);
  const got=JSON.parse(run(`JSON.stringify(it.list.map(e=>[e.type.id,e.level]))`));
  assert.ok(got.length>=1);
  for(const [id,lv] of got) assert.ok((id==='minecraft:sharpness'&&lv===5)||(id==='minecraft:unbreaking'&&lv===3),id);
  const sum=got.reduce((a,[,l])=>a+l,0);
  assert.equal(run(`plan.mats[0].n`),64-sum);assert.equal(run(`plan.levels`),40-Math.ceil(sum/2));
  assert.equal(run(`plan.mats[45].n+plan.mats[46].n`),2,'template books are not used up');
 }
});
test('the user example: level 5 + level 3 costs 8 lapis and 4 levels',()=>{
 assert.deepEqual(JSON.parse(run(`JSON.stringify(enCost(8))`)),{lapis:8,levels:4});
 assert.deepEqual(JSON.parse(run(`JSON.stringify(enCost(5))`)),{lapis:5,levels:3});
});
test('expensive enchantments are skipped when lapis or levels are short; nothing affordable leaves the item plain',()=>{
 for(let r=0;r<20;r++){
  setup(`{0:{id:'minecraft:lapis_lazuli',n:3},45:book(['minecraft:sharpness',5]),46:book(['minecraft:unbreaking',3])}`,2);
  run(`globalThis.it=mkItem();globalThis.plan=enApply(registry.stores.s1,[it]);`);
  assert.equal(run(`JSON.stringify(it.list.map(e=>e.type.id))`),'["minecraft:unbreaking"]');
  assert.equal(run(`plan.mats[0]`),null);assert.equal(run(`plan.levels`),0);
 }
 setup(`{0:{id:'minecraft:lapis_lazuli',n:2},45:book(['minecraft:sharpness',5])}`,10);
 run(`globalThis.it=mkItem();globalThis.plan=enApply(registry.stores.s1,[it]);`);
 assert.equal(run(`it.list.length`),0);assert.equal(run(`plan.short`),1);
});
test('the same enchantment in two books counts once, at the higher level; items that cannot take it stay plain',()=>{
 setup(`{0:{id:'minecraft:lapis_lazuli',n:64},45:book(['minecraft:sharpness',2]),47:book(['minecraft:sharpness',4])}`,40);
 assert.equal(run(`JSON.stringify(enTemplatePool(registry.stores.s1.enchant.mats).map(e=>[e.type.id,e.level]))`),'[["minecraft:sharpness",4]]');
 run(`globalThis.it=mkItem(e=>e.type.id!=='minecraft:sharpness');globalThis.plan=enApply(registry.stores.s1,[it]);`);
 assert.equal(run(`it.list.length`),0);assert.equal(run(`plan.short`),1);
});
test('lapis and books in the template row are not treated as materials',()=>{
 setup(`{45:book(['minecraft:unbreaking',1]),48:{id:'minecraft:lapis_lazuli',n:64}}`,40);
 run(`globalThis.it=mkItem();globalThis.plan=enApply(registry.stores.s1,[it]);`);
 assert.equal(run(`it.list.length`),0,'lapis outside the 45 material slots cannot be spent');
});
test('opening the owner screen moves old materials out of the template row (into free material slots)',()=>{
 setup(`{0:{id:'minecraft:lapis_lazuli',n:5},45:book(['minecraft:unbreaking',1]),48:{id:'minecraft:lapis_lazuli',n:7},52:{id:'minecraft:lapis_lazuli',n:9}}`,0);
 run(`globalThis.sm={storeId:'s1',fzKind:'enchant',texts:{}};try{crEnter(player,sm,shopInv,registry.stores.s1);}catch(e){}`);
 const mats=JSON.parse(run(`JSON.stringify(registry.stores.s1.enchant.mats)`));
 assert.equal(mats[45].id,'minecraft:enchanted_book');
 assert.equal(mats[48],null);assert.equal(mats[52],null);
 assert.deepEqual(mats.slice(0,45).filter(Boolean).map(m=>m.n).sort((a,b)=>a-b),[5,7,9]);
});
// ---- v1.1.699: 買う時に選ぶメニュー ----
function setupShop(lapis,levels){
 prep();
 run(`block.typeId='shopuilook2:panel_enchant';const m=Array(54).fill(null);m[0]={id:'minecraft:lapis_lazuli',n:${lapis}};
  m[45]=book(['minecraft:sharpness',5]);m[46]=book(['minecraft:unbreaking',3]);m[47]=book(['minecraft:looting',3]);
  registry.stores.s1.enchant={auto:true,levels:${levels},mats:m,made:0};SHOP_ENCH_ON.set(player.id,true);EN_PICK.clear();
  globalThis.rec1=loadProduct(block,'p1');globalThis.basePrice=shopPurchasePrice(rec1,registry.stores.s1,'d1',1,player.id);`);
}
const pick=(sel)=>run(`EN_PICK.set(player.id,{bk:blockKey(block),pid:'p1',sel:${JSON.stringify(sel)}});`);
const priceOf=(n=1)=>JSON.parse(run(`(()=>{const p=shopPurchasePrice(loadProduct(block,'p1'),registry.stores.s1,'d1',${n},player.id);return JSON.stringify({ok:p.ok,msg:p.message,items:p.ok?[...p.items]:[],chosen:p.enPick?.chosen?.map(e=>[e.type.id,e.level])??null,random:p.enPick?.random??null});})()`));
test('all random keeps the normal price; choosing an enchantment doubles every payment item',()=>{
 setupShop(64,40);
 const base=JSON.parse(run(`JSON.stringify([...basePrice.items])`));
 pick([null,null,null]);assert.deepEqual(priceOf().items,base);
 pick(['minecraft:sharpness',null,'none']);
 const p=priceOf();assert.equal(p.ok,true);
 assert.deepEqual(p.items,base.map(([id,n])=>[id,n*2]));
 assert.deepEqual(p.chosen,[['minecraft:sharpness',5]]);assert.equal(p.random,1);
});
test('a pick for another product, another shop, or with enchanting switched off does not change the price',()=>{
 setupShop(64,40);
 const base=JSON.parse(run(`JSON.stringify([...basePrice.items])`));
 run(`EN_PICK.set(player.id,{bk:blockKey(block),pid:'p2',sel:['minecraft:sharpness',null,null]});`);assert.deepEqual(priceOf().items,base);
 run(`EN_PICK.set(player.id,{bk:'elsewhere',pid:'p1',sel:['minecraft:sharpness',null,null]});`);assert.deepEqual(priceOf().items,base);
 pick(['minecraft:sharpness',null,null]);run(`SHOP_ENCH_ON.delete(player.id);`);assert.deepEqual(priceOf().items,base);
});
test('not enough lapis or stored levels for the chosen enchantments (times quantity) refuses the purchase',()=>{
 const two=['minecraft:sharpness','minecraft:unbreaking',null];   // 5+3=8 → lapis 8, levels 4 per item
 setupShop(7,40);pick(two);let p=priceOf();assert.equal(p.ok,false);assert.match(p.msg,/ラピス.*8/);
 setupShop(64,3);pick(two);p=priceOf();assert.equal(p.ok,false);assert.match(p.msg,/レベル.*4/);
 setupShop(8,4);pick(two);assert.equal(priceOf().ok,true);
 setupShop(15,40);pick(two);p=priceOf(2);assert.equal(p.ok,false);assert.match(p.msg,/16/);
 setupShop(16,8);pick(two);assert.equal(priceOf(2).ok,true);
});
test('chosen enchantments are always applied first; random slots add others from the books; cost follows the level-sum rule',()=>{
 for(let r=0;r<15;r++){
  setupShop(64,40);pick(['minecraft:sharpness','none',null]);
  run(`globalThis.p=shopPurchasePrice(loadProduct(block,'p1'),registry.stores.s1,'d1',1,player.id);globalThis.it=mkItem();globalThis.plan=enApply(registry.stores.s1,[it],p.enPick);`);
  const got=JSON.parse(run(`JSON.stringify(it.list.map(e=>[e.type.id,e.level]))`));
  assert.deepEqual(got[0],['minecraft:sharpness',5]);
  assert.ok(got.length===2,'one random slot adds exactly one more');
  assert.ok(['minecraft:unbreaking','minecraft:looting'].includes(got[1][0]));
  const sum=got.reduce((a,[,l])=>a+l,0);
  assert.equal(run(`plan.mats[0].n`),64-sum);assert.equal(run(`plan.levels`),40-Math.ceil(sum/2));
 }
});
test('extra button count: 20 while the pick menu is shown',()=>{
 assert.equal(run(`shExtraCount({fzKind:'enchant',enchOn:true,enMenu:true})`),20);
 assert.equal(run(`shExtraCount({fzKind:'enchant',enchOn:true})`),18);
});
test('the menu lists only book enchantments the product can take, plus random/none',()=>{
 setupShop(64,40);
 run(`globalThis.origIS=ItemStack.prototype.getComponent;ItemStack.prototype.getComponent=function(k){if(k==='minecraft:enchantable')return {canAddEnchantment:e=>e.type.id!=='minecraft:looting',getEnchantments:()=>[],addEnchantment:()=>{}};return origIS.call(this,k);};
  globalThis.smx={enchOn:true,confirm:{id:'p1'}};globalThis.act=enMenuActive(block,smx,registry.stores.s1);ItemStack.prototype.getComponent=origIS;`);
 assert.equal(run(`act`),true);
 assert.deepEqual(JSON.parse(run(`JSON.stringify(enMenuChoices(smx,1).map(c=>c.label))`)),['ランダム','なし','ダメージ増加 V','耐久力 III']);
 assert.deepEqual(JSON.parse(run(`JSON.stringify(enMenuChoices(smx,0).map(c=>c.v))`)),[null,'minecraft:sharpness','minecraft:unbreaking']);
});
test('enchantments that cannot go together with the other slots are removed from the choices (game rule via canAddEnchantment)',()=>{
 prep();
 run(`block.typeId='shopuilook2:panel_enchant';const m=Array(54).fill(null);m[0]={id:'minecraft:lapis_lazuli',n:64};
  m[45]=book(['minecraft:sharpness',5],['minecraft:smite',5]);m[46]=book(['minecraft:unbreaking',3],['minecraft:bane_of_arthropods',5]);
  registry.stores.s1.enchant={auto:true,levels:40,mats:m,made:0};SHOP_ENCH_ON.set(player.id,true);
  globalThis.origIS2=ItemStack.prototype.getComponent;
  const DMG=new Set(['minecraft:sharpness','minecraft:smite','minecraft:bane_of_arthropods']);
  ItemStack.prototype.getComponent=function(k){if(k!=='minecraft:enchantable')return origIS2.call(this,k);const self=this;self._en??=[];
   return {getEnchantments:()=>self._en,addEnchantment:e=>self._en.push(e),canAddEnchantment:e=>!self._en.some(x=>x.type.id===e.type.id||(DMG.has(x.type.id)&&DMG.has(e.type.id)))};};
  globalThis.smc={enchOn:true,confirm:{id:'p1'}};enMenuActive(block,smc,registry.stores.s1);`);
 const labels=k=>JSON.parse(run(`JSON.stringify(enMenuChoices(smc,${k}).map(c=>c.v))`));
 assert.deepEqual(labels(1),[null,'none','minecraft:sharpness','minecraft:smite','minecraft:unbreaking','minecraft:bane_of_arthropods']);
 run(`enMenuSel(smc)[0]='minecraft:sharpness';`);
 assert.deepEqual(labels(1),[null,'none','minecraft:unbreaking'],'smite/bane conflict with sharpness, sharpness itself is taken');
 assert.deepEqual(labels(0),[null,'minecraft:sharpness','minecraft:smite','minecraft:unbreaking','minecraft:bane_of_arthropods'],'its own slot still lists every choice');
 run(`enMenuSel(smc)[1]='minecraft:unbreaking';`);
 assert.deepEqual(labels(2),[null,'none'],'nothing else fits next to sharpness + unbreaking');
 assert.deepEqual(labels(0),[null,'minecraft:sharpness','minecraft:smite','minecraft:bane_of_arthropods'],'slot 1 may switch damage type; unbreaking is taken by slot 2');
 run(`ItemStack.prototype.getComponent=origIS2;`);
});
run(`restoreItemStack=origRestore;`);
console.log(count+' clone test groups passed');
