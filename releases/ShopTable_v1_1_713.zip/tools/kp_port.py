#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
テンキー移植ツール（ShopTable v1.1.468〜）

通貨の個数で動いているテンキー（入力欄＋スライドして出るキー）を、
商品設定の他の数値欄へ移植する。設定は tools/kp_fields.json だけ。

  python3 tools/kp_port.py            # kp_fields.json の内容に合わせる（追加・削除・作り直し）
  python3 tools/kp_port.py --scan     # 移植できる数値欄の一覧と、今の移植状況を表示
  python3 tools/kp_port.py --check    # 書き換えずに検査だけ

何度実行しても同じ結果になる（いったん全部外してから付け直す）。
書き換えるファイル:
  resource_pack/ui/data_driven_container_screen.json   画面
  behavior_pack/scripts/main.js                         <kp-fields:auto> の表だけ
  tools/kp_ports.lock.json                              外す時に元へ戻すための記録

1つの欄に対して行うこと
  1. 入力欄の押す所(click_area)を、テンキー用の入力欄ボタン(kp_in_btn_<id>)・専用スロットに差し替え
  2. 保存済みの文字(saved_overlay)を「入力欄が開いていない(2・4以外)時」だけ出す枠で包む
  3. 入力中の数字表示(kpd_<id>)を入力欄の上に重ねる（共通の6桁スロット 214〜219）
  4. 欄のすぐ下に、通貨1行目と同じテンキー(kp_open_<id> / kp_close_<id>)を差し込む

  3・4 の中身は共通部品 kpgen_*（通貨1行目のテンキーから毎回作り直す）。各欄は
  入力欄スロット(collection_index、数値で直接)と $kpb_<キー>（キーのボタン名）を渡すだけなので、
  通貨1行目の見た目を直せば、次の実行で全欄に反映される。
  5. キー15個と入力欄のボタン定義を、欄ごとに別名で作る（同名だとホバー等が連動するため）
"""
import copy
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
UI = ROOT / "resource_pack/ui/data_driven_container_screen.json"
JS = ROOT / "behavior_pack/scripts/main.js"
CFG = ROOT / "tools/kp_fields.json"
LOCK = ROOT / "tools/kp_ports.lock.json"

NS = "data_driven_container"
HEADER_POOL = list(range(192, 214))          # main.js KP_GENERIC_HEADER_POOL と同じ
# テンキーの種類（上限）。kp_fields.json の "type" で選ぶ。桁数は上限から自動（64→2桁、100・500→3桁）
KP_TYPES = {
    "64": {"min": 0, "max": 64},
    "100": {"min": 0, "max": 100},
    "500": {"min": 0, "max": 500},
}
DIGIT_SLOTS = [214, 215, 216]   # main.js KP_GENERIC_DIGIT_SLOTS と同じ（1桁目・2桁目・3桁目）
MAX_DIGITS = len(DIGIT_SLOTS)
KEY_SUFFIXES = [f"d{i}" for i in range(10)] + ["close", "back", "dot", "clear", "reset"]
# テンキーにしない欄（数値ではない／形式が別）
NOT_NUMERIC = re.compile(r"(_time_start|_time_end|_period|_name|_item(_\d+)?|message|summary|genre)$")
DIGIT_COLOR = [1, 1, 1]   # 閉じている時の文字(saved_overlay_text)と同じ白


def die(msg):
    print("エラー: " + msg)
    sys.exit(1)


# ------------------------------------------------------------------ 読み込み
def load_ui():
    return json.loads(UI.read_text(encoding="utf-8"))


def save_ui(d):
    UI.write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")


def js_text_channels(js):
    m = re.search(r"const TEXT_CHANNELS = (\[.*?\]);\n", js)
    if not m:
        die("main.js に TEXT_CHANNELS が見つかりません")
    return json.loads(m.group(1))


def js_text_field_names(js):
    m = re.search(r"const TEXT_FIELD_NAMES = (\[.*?\]);\n", js)
    return set(json.loads(m.group(1))) if m else set()


def scroll_root(d):
    return d["settings_scroll_content"]


def currency_template(d):
    """通貨1行目のテンキー（開く・閉じる）を雛形として取り出す"""
    found = {}

    def walk(o):
        if isinstance(o, dict):
            for k, v in o.items():
                if k in ("kp_open_0", "kp_close_0"):
                    found[k] = v
                walk(v)
        elif isinstance(o, list):
            for x in o:
                walk(x)
    walk(scroll_root(d))
    if len(found) != 2:
        die("雛形（通貨1行目の kp_open_0 / kp_close_0）が見つかりません")
    return copy.deepcopy(found["kp_open_0"]), copy.deepcopy(found["kp_close_0"])


def find_field(d, field):
    """欄のパネルと、それが入っている親の controls リスト・位置を返す"""
    hit = []

    def walk(o):
        if isinstance(o, dict):
            for k, v in o.items():
                if k == "controls" and isinstance(v, list):
                    for i, c in enumerate(v):
                        for kk, vv in c.items():
                            if kk == field and isinstance(vv, dict):
                                hit.append((v, i, vv))
                            walk(vv)
                elif isinstance(v, (dict, list)):
                    walk(v)
        elif isinstance(o, list):
            for x in o:
                walk(x)
    walk(scroll_root(d))
    return hit


def child(panel, key_pred):
    for c in panel.get("controls", []):
        for k, v in c.items():
            if key_pred(k):
                return c, k, v
    return None, None, None


def overlay_parts(panel, field):
    """saved_overlay → gate → body を返す"""
    _, _, ov = child(panel, lambda k: k == f"{field}_saved_overlay")
    if not ov:
        return None, None
    _, _, gate = child(ov, lambda k: k.endswith("_saved_overlay_gate"))
    _, _, body = child(gate or {}, lambda k: k.endswith("_saved_overlay_body"))
    return ov, body


def overlay_slot(panel, field):
    _, body = overlay_parts(panel, field)
    if not body:
        return None

    def walk(o):
        if isinstance(o, dict):
            for k, v in o.items():
                if k.endswith("_saved_overlay_text") and isinstance(v, dict):
                    return v.get("collection_index")
                r = walk(v)
                if r is not None:
                    return r
        elif isinstance(o, list):
            for x in o:
                r = walk(x)
                if r is not None:
                    return r
        return None
    return walk(body)


def signal_of(panel, field):
    _, _, area = child(panel, lambda k: k == f"{field}_click_area")
    if not area:
        return None, None
    _, k, sig = child(area, lambda k: k.endswith("_signal@common.container_item"))
    return k, sig


# ------------------------------------------------------------------ 部品の生成
def count_binding(name, slot_expr):
    return [
        {"binding_type": "collection", "binding_collection_name": "container_items",
         "binding_name": "#inventory_stack_count", "binding_name_override": name,
         "binding_condition": "always"},
        {"binding_type": "view", "source_property_name": slot_expr,
         "target_property_name": "#visible", "binding_condition": "always"},
    ]


def digit_label(text, anims=None):
    """閉じている時の文字(saved_overlay_text)と同じ書体・大きさ・色・基準位置のラベル"""
    lab = {"type": "label", "text": text, "localize": False, "color": DIGIT_COLOR,
           "font_type": "default", "font_size": "normal", "shadow": False,
           "anchor_from": "top_left", "anchor_to": "top_left", "offset": [0, 0], "layer": 2}
    if anims:
        lab["anims"] = anims
    return lab


def nonblank_expr(name):
    """数字スロットに数字が入っているか（個数2〜11）。空き(個数1)・スロットが空は false"""
    return "(" + " or ".join(f"({name} = '{n}')" for n in range(2, 12)) + ")"


def digit_templates(max_value):
    """入力中の数字。「52」なら「52」という1つのラベルを出す（閉じている時の文字と同じ字間になる）

    v1.1.468: collection_index を変数にすると表示条件が効かなかった → 変数は使わない。
    v1.1.469: 見えない部品も幅を取る → 詰めて並べる方式は使えない。
    v1.1.472: 1桁ずつ別のラベルにすると字間が実際の文字より広く空いた。
    → 通貨の個数と同じく、数字の並び全体を1つのラベルで出す。
      1桁目(214) ＞ 2桁目(215) ＞ 3桁目(216) と入れ子にし、その桁で終わる所(次の桁が空き)に
      「5」「52」「523」のような文字列を出す。作るのは 0〜max_value（付けた欄の上限の最大）だけ。
      入力中も上限を超えないようにスクリプト側でそろえるので、それより大きい数は出ない。
    """
    strings = [str(n) for n in range(0, max_value + 1)]
    want = set(strings)

    def cond(name, expr):
        return count_binding(name, expr)

    def node(prefix, depth):
        """prefix で始まる数字の部品。depth = 次に読む桁(0始まり)"""
        out = []
        nxt = DIGIT_SLOTS[depth] if depth < len(DIGIT_SLOTS) else None
        if prefix in want:
            lab = digit_label(prefix)
            if nxt is not None and any(x.startswith(prefix) and len(x) > len(prefix) for x in want):
                # 次の桁が空きの時だけ出す
                lab.update({"collection_index": nxt, "visible": False,
                            "bindings": cond("#kq_e", f"(not {nonblank_expr('#kq_e')})")})
            out.append({"t": lab})
        if nxt is not None:
            for d in range(10):
                p2 = prefix + str(d)
                if p2 == "0" + p2[1:] and len(p2) > 1:
                    continue
                if not any(x.startswith(p2) for x in want):
                    continue
                out.append({f"d{d}": {
                    "type": "collection_panel", "collection_name": "container_items",
                    "size": ["100%", "100%"], "collection_index": nxt, "visible": False,
                    "bindings": cond("#kq_v", f"(#kq_v = '{d + 2}')"),
                    "controls": node(p2, depth + 1)}})
        return out

    return {"kpgen_digit_text": {"type": "collection_panel", "collection_name": "container_items",
                                 "size": ["100%", "100%"], "controls": node("", 0)}}


def digits_instance(tag, header):
    """欄ごとの数字表示。閉じている時の文字と同じ位置・大きさ(offset [5,17] / 116x10)に重ねる。
    数字は 2(開)・4(閉じる途中) の間だけ。入力欄の番号はここに直接書く。「_」は出さない(v1.1.471)"""
    return {f"kpd_{tag}": {
        "type": "collection_panel", "collection_name": "container_items",
        "size": [116, 10], "anchor_from": "top_left", "anchor_to": "top_left",
        "offset": [5, 17], "layer": 30,
        "controls": [{"gate": {
            "type": "panel", "size": ["100%", "100%"], "collection_index": header, "visible": False,
            "bindings": count_binding("#kq_g", "((#kq_g = '2') or (#kq_g = '4'))"),
            "controls": [{"cp": {
                "type": "collection_panel", "collection_name": "container_items", "size": ["100%", "100%"],
                "controls": [{f"digits@{NS}.kpgen_digit_text": {}}]}}]}}]}}


def pad_template(tpl, kind):
    """通貨1行目のテンキーを共通部品にする。入力欄の番号は各欄の側で collection_index を
    数値で上書きする（変数にしない）。キーのボタン名だけ $kpb_<キー> で渡す。"""
    k = copy.deepcopy(tpl)
    old = "#ko_0" if kind == "open" else "#kc_0"
    for b in k.get("bindings", []):
        for key in ("binding_name_override", "source_property_name"):
            if key in b:
                b[key] = b[key].replace(old, "#kp_st")

    def walk(o):
        if isinstance(o, dict):
            for key, v in o.items():
                if key == "$button_ref" and isinstance(v, str) and v.startswith(f"{NS}.kp_k_0_"):
                    o[key] = "$kpb_" + v[len(f"{NS}.kp_k_0_"):]
                else:
                    walk(v)
        elif isinstance(o, list):
            for x in o:
                walk(x)
    walk(k)
    # 変数が渡されなかった時の既定値（通貨1行目と同じもの）
    if kind == "open":
        for x in KEY_SUFFIXES:
            k[f"$kpb_{x}|default"] = f"{NS}.kp_k_0_{x}"
    return k


def pad_instance(tag, header, kind):
    inst = {"collection_index": header}
    if kind == "open":   # 閉じるアニメ側は見た目だけ（押せるボタンを持たない）
        for x in KEY_SUFFIXES:
            inst[f"$kpb_{x}"] = f"{NS}.kp_k_{tag}_{x}"
    return {f"kp_{kind}_{tag}@{NS}.kpgen_pad_{kind}": inst}


def button_defs(d, tag):
    out = {}
    for s in KEY_SUFFIXES:
        src = d.get(f"kp_k_0_{s}@common.radio_toggle")
        if not src:
            die(f"雛形のキー定義 kp_k_0_{s} が見つかりません")
        b = copy.deepcopy(src)
        b["$toggle_name"] = f"kp_k_{tag}_{s}"
        out[f"kp_k_{tag}_{s}@common.radio_toggle"] = b
    src = d.get("kp_in_btn_0@common.radio_toggle")
    if not src:
        die("雛形の入力欄ボタン kp_in_btn_0 が見つかりません")
    b = copy.deepcopy(src)
    b["$toggle_name"] = f"kp_in_{tag}"
    out[f"kp_in_btn_{tag}@common.radio_toggle"] = b
    return out


# ------------------------------------------------------------------ 付ける・外す
def unport(d, field, lock_entry):
    tag = field
    for parent, i, panel in find_field(d, field):
        # 4. テンキーを外す
        parent[:] = [c for c in parent if not any(k.split("@")[0] in (f"kpw_{tag}", f"kp_open_{tag}", f"kp_close_{tag}") for k in c)]
        # 3. 数字表示を外す
        panel["controls"] = [c for c in panel["controls"] if not any(k.split("@")[0] == f"kpd_{tag}" for k in c)]
        # 2. 包みをほどく
        _, body = overlay_parts(panel, field)
        if body:
            _, _, g = child(body, lambda k: k == f"kpg_{tag}")
            if g:
                body["controls"] = g["controls"][0]["kpgc"]["controls"]
        # 1. 押す所を元に戻す
        _, sig = signal_of(panel, field)
        if sig and lock_entry:
            orig = copy.deepcopy(lock_entry["signal_original"])
            sig.clear()
            sig.update(orig)
    for name in list(d.keys()):
        if name.startswith(f"kp_k_{tag}_") or name.startswith(f"kp_in_btn_{tag}@"):
            del d[name]


def port(d, cfg):
    field, header, tag = cfg["field"], cfg["header"], cfg["field"]
    hits = find_field(d, field)
    if len(hits) != 1:
        die(f"{field}: 画面の欄が {len(hits)} 個見つかりました（1個のはず）")
    parent, idx, panel = hits[0]
    sig_key, sig = signal_of(panel, field)
    if not sig:
        die(f"{field}: 押す所（{field}_click_area）が見つかりません")
    ov, body = overlay_parts(panel, field)
    if not body:
        die(f"{field}: 保存済み文字（{field}_saved_overlay）が見つかりません")
    lock = {"signal_original": copy.deepcopy(sig)}
    # 1
    sig["collection_index"] = header
    sig["$button_ref"] = f"{NS}.kp_in_btn_{tag}"
    sig.pop("$highlight_control", None)
    # 2
    nm = f"#kqv_{tag}"
    body["controls"] = [{f"kpg_{tag}": {
        "type": "panel", "collection_index": header, "size": ["100%", "100%"], "visible": False,
        # 3 だけでなく「押して一瞬空になった時」も出したままにする（開く時に数字が一瞬消えないように）
        "bindings": count_binding(nm, f"(not (({nm} = '2') or ({nm} = '4')))"),
        "controls": [{"kpgc": {"type": "collection_panel", "collection_name": "container_items",
                               "size": ["100%", "100%"], "controls": body["controls"]}}]}}]
    # 3
    panel["controls"].append(digits_instance(tag, header))
    # 4
    # 親が collection_name を持たない場所（設定リスト直下など）でも個数を読めるよう、包みに入れる
    parent.insert(idx + 1, {f"kpw_{tag}": {
        "type": "stack_panel", "orientation": "vertical", "collection_name": "container_items",
        "size": [150, "100%c"], "anchor_from": "top_left", "anchor_to": "top_left",
        "controls": [pad_instance(tag, header, "open"), pad_instance(tag, header, "close")]}})
    # 5
    d.update(button_defs(d, tag))
    return lock


# ------------------------------------------------------------------ main.js の表
def write_js_table(js, entries):
    lines = ["// <kp-fields:auto>", "const KP_GENERIC_FIELDS = ["]
    for e in entries:
        e = {**KP_TYPES.get(str(e.get("type")), {}), **e}
        extra = (f', type: "{e["type"]}"' if "type" in e else "") + "".join(f", {k}: {json.dumps(e[k])}" for k in ("min", "max", "step") if k in e)
        lines.append(f'    {{ field: "{e["field"]}", header: {e["header"]}, overlay: {e["overlay"]}, group: {e["group"]}{extra} }},')
    lines.append("];")
    lines.append("// </kp-fields:auto>")
    new, n = re.subn(r"// <kp-fields:auto>.*?// </kp-fields:auto>", "\n".join(lines), js, flags=re.S)
    if n != 1:
        die("main.js に <kp-fields:auto> の目印が見つかりません")
    return new


# ------------------------------------------------------------------ 検査
def validate(cfgs, d, js):
    names = js_text_field_names(js)
    seen = set()
    used = set()

    def idx(o):
        if isinstance(o, dict):
            for k, v in o.items():
                if k == "collection_index" and isinstance(v, int):
                    used.add(v)
                idx(v)
        elif isinstance(o, list):
            for x in o:
                idx(x)
    idx(d)
    for c in cfgs:
        f, h = c.get("field"), c.get("header")
        if f not in names:
            die(f"{f}: main.js の TEXT_FIELD_NAMES にない欄です")
        if NOT_NUMERIC.search(f):
            die(f"{f}: 数値の欄ではないためテンキーにできません")
        if h not in HEADER_POOL:
            die(f"{f}: header は {HEADER_POOL[0]}〜{HEADER_POOL[-1]} から選んでください（{h}）")
        if h in seen:
            die(f"{f}: header {h} が他の欄と重複しています")
        t = c.get("type")
        if t is not None and str(t) not in KP_TYPES:
            die(f"{f}: type は {' / '.join(KP_TYPES)} のどれかです（{t}）")
        mx = c.get("max", KP_TYPES.get(str(t), {}).get("max", form_max(js).get(f)))
        if mx is None or len(str(mx)) > MAX_DIGITS:
            die(f"{f}: 上限 {mx} は{MAX_DIGITS}桁を超えるため表示できません。type か max を指定してください")
        seen.add(h)


def form_max(js):
    """main.js の FIELD_INPUTS から、フォームでの上限を読む（--scan の目安用）"""
    m = re.search(r"const FIELD_INPUTS = \{(.*?)\n\};", js, re.S)
    consts = {"POINT_SLIDER": 500, "RATE_SLIDER": 100, "ITEM_COUNT_SLIDER": 64}
    out = {}
    for name, val in re.findall(r"^\s+(\w+): (.+?),?$", m.group(1) if m else "", re.M):
        if val in consts:
            out[name] = consts[val]
            continue
        mm = re.search(r"max: (\d+)", val) or re.search(r"range\(\d+, (\d+)\)", val)
        if mm:
            out[name] = int(mm.group(1))
    return out


def scan(d, js, cfgs, lock):
    chans = {c["slot"]: c["group"] for c in js_text_channels(js)}
    ported = {c["field"]: c for c in cfgs}
    fmax = form_max(js)
    print("数値欄の一覧（○=移植済み）  種類=今の設定 / 目安=フォームの上限に合う種類")
    for name in sorted(js_text_field_names(js)):
        if NOT_NUMERIC.search(name) or name.startswith("price") or "required_count" in name or name.endswith("_item_count"):
            continue
        hits = find_field(d, name)
        if len(hits) != 1:
            continue
        ov = overlay_slot(hits[0][2], name)
        mark = "○" if name in lock else " "
        c = ported.get(name, {})
        fm = fmax.get(name)
        hint = str(fm) if str(fm) in KP_TYPES else f"なし(フォームの上限{fm})"
        print(f"  {mark} {name:28s} header={c.get('header', ''):<4} 種類={c.get('type', '-'):<4} 目安={hint}")


def main():
    args = set(sys.argv[1:])
    cfg = json.loads(CFG.read_text(encoding="utf-8"))
    cfgs = cfg.get("fields", [])
    lock = json.loads(LOCK.read_text(encoding="utf-8")) if LOCK.exists() else {}
    d = load_ui()
    js = JS.read_text(encoding="utf-8")

    if "--scan" in args:
        scan(d, js, cfgs, lock)
        return
    validate(cfgs, d, js)
    if "--check" in args:
        print(f"OK: 設定 {len(cfgs)} 欄 / 移植済み {len(lock)} 欄")
        return

    # いったん全部外す
    for field, entry in lock.items():
        unport(d, field, entry)
    for name in [n for n in d if n.startswith("kpgen_")]:
        del d[name]
    if cfgs:
        tpl_open, tpl_close = currency_template(d)
        d["kpgen_pad_open"] = pad_template(tpl_open, "open")
        d["kpgen_pad_close"] = pad_template(tpl_close, "close")
        top = max(int(c.get("max", KP_TYPES.get(str(c.get("type")), {}).get("max", form_max(js).get(c["field"], 0))))
                  for c in cfgs)
        d.update(digit_templates(top))
    chans = {c["slot"]: c["group"] for c in js_text_channels(js)}
    new_lock = {}
    js_entries = []
    for c in cfgs:
        hits = find_field(d, c["field"])
        ov = overlay_slot(hits[0][2], c["field"]) if len(hits) == 1 else None
        if ov not in chans:
            die(f"{c['field']}: 文字スロット {ov} が TEXT_CHANNELS にありません")
        new_lock[c["field"]] = port(d, c)
        js_entries.append({**c, "overlay": ov, "group": chans[ov]})
    save_ui(d)
    JS.write_text(write_js_table(js, js_entries), encoding="utf-8")
    LOCK.write_text(json.dumps(new_lock, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"完了: {len(cfgs)} 欄にテンキーを付けました（外した欄 {len(set(lock) - set(new_lock))}）")
    for e in js_entries:
        print(f"  {e['field']}: header={e['header']} 種類={e.get('type', 'フォームの範囲')} 文字={e['overlay']} グループ={e['group']}")


if __name__ == "__main__":
    main()
