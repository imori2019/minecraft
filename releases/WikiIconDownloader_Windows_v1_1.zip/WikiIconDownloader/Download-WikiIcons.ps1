﻿#requires -version 5.1
[CmdletBinding()]
param(
    [string]$ManifestPath = '',
    [string]$OutputDir = '',
    [string]$CustomUrlsPath = '',
    [string]$ScriptDirectory = '',
    [string[]]$OnlyId = @(),
    [ValidateRange(0,10000)][int]$Limit = 0,
    [ValidateRange(0,30)][double]$DelaySeconds = 0.4,
    [ValidateRange(0,3)][int]$Retries = 1,
    [ValidateRange(1,120)][int]$TimeoutSeconds = 20,
    [string]$BaseUrl = ''
)
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
Add-Type -AssemblyName System.Net.Http
Add-Type -AssemblyName System.IO.Compression.FileSystem
[Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12

function Read-JsonFile([string]$Path) {
    return ([IO.File]::ReadAllText($Path, [Text.Encoding]::UTF8) | ConvertFrom-Json)
}
function Write-Utf8([string]$Path, [string]$Text) {
    [IO.File]::WriteAllText($Path, $Text, (New-Object Text.UTF8Encoding($true)))
}
function Get-Sha256([byte[]]$Bytes) {
    $sha = [Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($sha.ComputeHash($Bytes))).Replace('-', '').ToLowerInvariant() }
    finally { $sha.Dispose() }
}
function Get-UInt32BE([byte[]]$Bytes, [int]$At) {
    return ([uint64]$Bytes[$At] * 16777216 + [uint64]$Bytes[$At+1] * 65536 + [uint64]$Bytes[$At+2] * 256 + [uint64]$Bytes[$At+3])
}
function Get-PngInfo([byte[]]$Bytes) {
    if ($Bytes.Length -lt 45 -or $Bytes.Length -gt 3145728) { return $null }
    if ([BitConverter]::ToString($Bytes, 0, 8) -ne '89-50-4E-47-0D-0A-1A-0A') { return $null }
    $at = 8; $width = 0; $height = 0; $hasData = $false
    while ($at + 12 -le $Bytes.Length) {
        $length = Get-UInt32BE $Bytes $at
        if ($length -gt 3145728 -or $at + 12 + $length -gt $Bytes.Length) { return $null }
        $kind = [Text.Encoding]::ASCII.GetString($Bytes, $at+4, 4)
        if ($at -eq 8) {
            if ($kind -ne 'IHDR' -or $length -ne 13) { return $null }
            $width = Get-UInt32BE $Bytes ($at+8); $height = Get-UInt32BE $Bytes ($at+12)
            if ($width -lt 1 -or $height -lt 1 -or $width -gt 256 -or $height -gt 256) { return $null }
        }
        if ($kind -eq 'IDAT' -and $length -gt 0) { $hasData = $true }
        if ($kind -eq 'IEND') {
            if ($length -eq 0 -and $at+12 -eq $Bytes.Length -and $hasData) {
                return [pscustomobject]@{ Width=$width; Height=$height }
            }
            return $null
        }
        $at += [int]$length + 12
    }
    return $null
}
function Write-AtomicBytes([string]$Path, [byte[]]$Bytes) {
    $temp = $Path + '.download'
    try { [IO.File]::WriteAllBytes($temp, $Bytes); Move-Item -LiteralPath $temp -Destination $Path -Force }
    finally { if (Test-Path -LiteralPath $temp) { Remove-Item -LiteralPath $temp -Force } }
}
function Get-CandidateUrls($Target, $Custom) {
    $id = [string]$Target.id; $short = $id.Split(':')[-1]
    if ($short -notmatch '^[a-z0-9_]+$') { throw ('Invalid item ID: ' + $id) }
    $customProperty = $Custom.PSObject.Properties[$id]
    if ($null -ne $customProperty -and $customProperty.Value) {
        $u = [string]$customProperty.Value
        if ($u -notmatch '^https://(ja\.)?minecraft\.wiki/images/') { throw ('Use a Minecraft Wiki image URL for ' + $id) }
        return $u
    }
    $aliases = @{
        'end_brick_stairs'=@('End_Stone_Brick_Stairs')
        'normal_stone_slab'=@('Stone_Slab')
        'normal_stone_stairs'=@('Stone_Stairs')
        'stone_stairs'=@('Cobblestone_Stairs')
        'prismarine_bricks_stairs'=@('Prismarine_Brick_Stairs')
        'mob_spawner'=@('Monster_Spawner','Spawner')
        'undyed_shulker_box'=@('Shulker_Box')
        'snow_layer'=@('Snow','Snow_Layer')
        'small_dripleaf_block'=@('Small_Dripleaf')
        'border_block'=@('Border','Border_Block')
        'allow'=@('Allow','Allow_Block')
        'deny'=@('Deny','Deny_Block')
    }
    $names = New-Object 'Collections.Generic.List[string]'
    if ($aliases.ContainsKey($short)) {
        foreach ($name in $aliases[$short]) { $names.Add($name) }
    }
    if ($short -match '^light_block_(\d+)$') {
        $level = $Matches[1]
        $names.Add(('Light_(' + $level + ')'))
        $names.Add(('Light_Block_(' + $level + ')'))
        $names.Add(('Light_' + $level))
        $names.Add(('Light_Block_' + $level))
    }
    # A confirmed Bedrock-to-Wiki alias is authoritative: Stone_Stairs is not
    # a fallback for Bedrock stone_stairs, whose item is Cobblestone_Stairs.
    if (-not $aliases.ContainsKey($short) -and $short -notmatch '^light_block_') {
        $name = (($short.Split('_') | ForEach-Object { $_.Substring(0,1).ToUpperInvariant() + $_.Substring(1) }) -join '_')
        $names.Add($name)
    }
    foreach ($name in ($names.ToArray() | Select-Object -Unique)) {
        'https://minecraft.wiki/images/' + [Uri]::EscapeDataString(('Invicon_' + $name + '.png'))
    }
}
function Resolve-RequestUrl([string]$Url) {
    if (-not $BaseUrl) { return $Url }
    $base = [Uri]$BaseUrl
    if ($base.Scheme -ne 'https' -and -not $base.IsLoopback) { throw 'An HTTP test mirror must be on localhost.' }
    return $BaseUrl.TrimEnd('/') + ([Uri]$Url).PathAndQuery
}
function New-FetchResult([string]$Status,[string]$Message,[string]$Url,[byte[]]$Data) {
    return [pscustomobject]@{ Status=$Status; Message=$Message; Url=$Url; Data=$Data }
}
function Fetch-Icon([string]$OriginalUrl, [Net.Http.HttpClient]$HttpClient) {
    $url = Resolve-RequestUrl $OriginalUrl
    for ($attempt=0; $attempt -le $Retries; $attempt++) {
        $response=$null
        $cancel=New-Object Threading.CancellationTokenSource
        $cancel.CancelAfter([TimeSpan]::FromSeconds($TimeoutSeconds))
        if ($DelaySeconds -gt 0) { Start-Sleep -Milliseconds ([int]($DelaySeconds*1000)) }
        try {
            $response=$HttpClient.GetAsync($url, [Net.Http.HttpCompletionOption]::ResponseHeadersRead, $cancel.Token).GetAwaiter().GetResult()
            $code=[int]$response.StatusCode
            if ($code -eq 404 -or $code -eq 410) { return (New-FetchResult 'missing' ('HTTP '+$code) $OriginalUrl $null) }
            if ($code -eq 403 -or $code -eq 401) { return (New-FetchResult 'blocked' ('HTTP '+$code+' - access denied') $OriginalUrl $null) }
            if ($code -eq 429 -or $code -ge 500) {
                $wait=2*($attempt+1)
                if ($null -ne $response.Headers.RetryAfter) {
                    if ($null -ne $response.Headers.RetryAfter.Delta) { $wait=[Math]::Ceiling($response.Headers.RetryAfter.Delta.TotalSeconds) }
                    elseif ($null -ne $response.Headers.RetryAfter.Date) { $wait=[Math]::Max(1,[Math]::Ceiling(($response.Headers.RetryAfter.Date-[DateTimeOffset]::UtcNow).TotalSeconds)) }
                }
                if ($attempt -lt $Retries -and $wait -le 30) {
                    $response.Dispose(); $response=$null
                    Start-Sleep -Seconds ([int][Math]::Max(1,$wait)); continue
                }
                return (New-FetchResult 'blocked' ('HTTP '+$code+' - retry later') $OriginalUrl $null)
            }
            if (-not $response.IsSuccessStatusCode) { return (New-FetchResult 'error' ('HTTP '+$code) $OriginalUrl $null) }
            if ($null -ne $response.Content.Headers.ContentLength -and $response.Content.Headers.ContentLength -gt 3145728) {
                return (New-FetchResult 'error' 'Image exceeds 3 MB limit' $OriginalUrl $null)
            }
            $stream=$response.Content.ReadAsStreamAsync().GetAwaiter().GetResult()
            $memory=New-Object IO.MemoryStream
            try {
                $buffer=New-Object byte[] 16384
                while (($n=$stream.ReadAsync($buffer,0,$buffer.Length,$cancel.Token).GetAwaiter().GetResult()) -gt 0) {
                    if ($memory.Length+$n -gt 3145728) { return (New-FetchResult 'error' 'Image exceeds 3 MB limit' $OriginalUrl $null) }
                    $memory.Write($buffer,0,$n)
                }
                $bytes=$memory.ToArray()
            } finally { $memory.Dispose(); $stream.Dispose() }
            if ($null -eq (Get-PngInfo $bytes)) {
                $head=[Text.Encoding]::UTF8.GetString($bytes,0,[Math]::Min($bytes.Length,4096))
                if ($head -match '(?i)<html|<!doctype|cloudflare|captcha') {
                    return (New-FetchResult 'blocked' 'HTML/challenge response instead of a PNG' $OriginalUrl $null)
                }
                return (New-FetchResult 'error' 'Not a complete small PNG image' $OriginalUrl $null)
            }
            return (New-FetchResult 'downloaded' '' $OriginalUrl $bytes)
        } catch {
            if ($attempt -eq $Retries) { return (New-FetchResult 'network_error' $_.Exception.Message $OriginalUrl $null) }
            Start-Sleep -Seconds (1+$attempt)
        } finally { if ($null -ne $response) { $response.Dispose() }; $cancel.Dispose() }
    }
}
function Write-CsvFile([string]$Path,[object[]]$Rows) {
    if ($Rows.Length -eq 0) { Write-Utf8 $Path '"id","name","status","file","url","sha256","width","height","error","candidates"'; return }
    Write-Utf8 $Path (($Rows | ConvertTo-Csv -NoTypeInformation) -join "`r`n")
}

$exitCode=0
$Client=$null
try {
    # Resolve defaults after parameter binding: PSScriptRoot may be empty in
    # some Windows launch contexts. The CMD launcher also supplies full paths.
    $toolRoot = $ScriptDirectory
    if ([string]::IsNullOrWhiteSpace($toolRoot)) { $toolRoot = $PSScriptRoot }
    if ([string]::IsNullOrWhiteSpace($toolRoot) -and -not [string]::IsNullOrWhiteSpace($PSCommandPath)) {
        $toolRoot = [IO.Path]::GetDirectoryName($PSCommandPath)
    }
    if ([string]::IsNullOrWhiteSpace($toolRoot)) { $toolRoot = (Get-Location).ProviderPath }
    $toolRoot = [IO.Path]::GetFullPath($toolRoot)
    if ([string]::IsNullOrWhiteSpace($ManifestPath)) { $ManifestPath = Join-Path $toolRoot 'BlockGlyphImages_manifest.json' }
    if ([string]::IsNullOrWhiteSpace($OutputDir)) { $OutputDir = Join-Path $toolRoot 'download_result' }
    if ([string]::IsNullOrWhiteSpace($CustomUrlsPath)) { $CustomUrlsPath = Join-Path $toolRoot 'custom_urls.json' }
    if (-not (Test-Path -LiteralPath $ManifestPath -PathType Leaf)) {
        throw 'The image list was not found. Extract the complete ZIP, then run START_DOWNLOAD.cmd.'
    }
    $manifest=Read-JsonFile $ManifestPath
    $targets=@($manifest.needed)
    if ($OnlyId.Length -gt 0) {
        foreach ($id in $OnlyId) { if ($id -notin @($targets | ForEach-Object { $_.id })) { throw ('Unknown item ID: '+$id) } }
        $targets=@($targets | Where-Object { $_.id -in $OnlyId })
    }
    if ($Limit -gt 0) { $targets=@($targets | Select-Object -First $Limit) }
    if ($targets.Length -eq 0) { throw 'No targets selected.' }
    $custom=[pscustomobject]@{}
    if (Test-Path -LiteralPath $CustomUrlsPath) { $custom=Read-JsonFile $CustomUrlsPath }
    $OutputDir=[IO.Path]::GetFullPath($OutputDir)
    $imageDir=Join-Path $OutputDir 'images'
    $null=New-Item -ItemType Directory -Path $imageDir -Force
    $sourcePath=Join-Path $OutputDir 'sources.json'
    $sources=@{}
    if (Test-Path -LiteralPath $sourcePath) {
        try { foreach ($source in @(Read-JsonFile $sourcePath)) { if ($source.id) { $sources[[string]$source.id]=$source } } }
        catch { Write-Host 'Previous source records could not be read; files will be downloaded again.' }
    }
    $handler=New-Object Net.Http.HttpClientHandler
    $handler.AutomaticDecompression=[Net.DecompressionMethods]::GZip -bor [Net.DecompressionMethods]::Deflate
    $Client=New-Object Net.Http.HttpClient($handler)
    $Client.Timeout=[TimeSpan]::FromSeconds($TimeoutSeconds)
    $null=$Client.DefaultRequestHeaders.TryAddWithoutValidation('User-Agent','ShopTableWikiIconDownloader/1.0 (Minecraft inventory icon collection)')
    $rows=New-Object 'Collections.Generic.List[object]'
    $stopped=''; $networkFailures=0; $index=0
    Write-Host ('対象: '+$targets.Length+' 種類 / 保存先: '+$imageDir)
    foreach ($target in $targets) {
        $index++; $id=[string]$target.id; $short=$id.Split(':')[-1]
        $urls=@(Get-CandidateUrls $target $custom)
        $file='images/'+$short+'.png'; $path=Join-Path $imageDir ($short+'.png')
        $row=[pscustomobject][ordered]@{ id=$id; name=[string]$target.'日本語名'; status='missing'; file=''; url=''; sha256=''; width=0; height=0; error=''; candidates=($urls -join ' | ') }
        if ((Test-Path -LiteralPath $path) -and $sources.ContainsKey($id)) {
            $bytes=[IO.File]::ReadAllBytes($path); $info=Get-PngInfo $bytes
            if ($null -ne $info -and (Get-Sha256 $bytes) -eq $sources[$id].sha256 -and $sources[$id].url -in $urls) {
                $row.status='cached'; $row.file=$file; $row.url=$sources[$id].url; $row.sha256=$sources[$id].sha256; $row.width=$info.Width; $row.height=$info.Height
            }
        }
        if ($row.status -ne 'cached') {
            if ($stopped) { $row.status='not_attempted'; $row.error=$stopped }
            else {
                foreach ($url in $urls) {
                    $result=Fetch-Icon $url $Client
                    $row.status=$result.Status; $row.url=$url; $row.error=$result.Message
                    if ($result.Status -eq 'downloaded') {
                        $info=Get-PngInfo $result.Data
                        Write-AtomicBytes $path $result.Data
                        $row.file=$file; $row.sha256=Get-Sha256 $result.Data; $row.width=$info.Width; $row.height=$info.Height
                        $sources[$id]=[pscustomobject]@{id=$id;name=$row.name;file=$file;url=$url;sha256=$row.sha256;width=$info.Width;height=$info.Height;license_info='https://minecraft.wiki/w/Minecraft_Wiki:Copyrights';retrieved_utc=[DateTime]::UtcNow.ToString('o')}
                        $networkFailures=0; break
                    }
                    if ($result.Status -eq 'blocked') { $stopped=$result.Message; break }
                    if ($result.Status -eq 'network_error') {
                        $networkFailures++
                        if ($networkFailures -ge 2) { $stopped='Network connection failed twice. Check connectivity before retrying.' }
                        break
                    }
                    $networkFailures=0
                }
            }
        }
        $rows.Add($row)
        Write-Host ('[{0}/{1}] {2}: {3}' -f $index,$targets.Length,$short,$row.status)
    }
    # Only include PNGs with matching provenance and hashes. An old or interrupted
    # file that was not successfully fetched is never packaged as a valid icon.
    $validSources=New-Object 'Collections.Generic.List[object]'
    foreach ($source in $sources.Values) {
        $p=Join-Path $OutputDir $source.file
        if ((Test-Path -LiteralPath $p) -and (Get-Sha256 ([IO.File]::ReadAllBytes($p))) -eq $source.sha256) { $validSources.Add($source) }
    }
    Write-Utf8 $sourcePath (ConvertTo-Json -InputObject @($validSources.ToArray() | Sort-Object id) -Depth 8)
    $resultRows=$rows.ToArray(); $missing=@($resultRows | Where-Object { $_.status -notin @('downloaded','cached') })
    Write-CsvFile (Join-Path $OutputDir 'download_results.csv') $resultRows
    Write-CsvFile (Join-Path $OutputDir 'missing.csv') $missing
    $summary=@('未取得: '+$missing.Length+' 種類','missing は画像名候補が見つからなかった項目、blocked は接続拒否、not_attempted は中断後の未試行です。','')
    foreach ($row in $missing) { $summary+=($row.id+' / '+$row.name+' / '+$row.status+' / '+$row.error); $summary+=('候補: '+$row.candidates) }
    Write-Utf8 (Join-Path $OutputDir 'missing.txt') ($summary -join "`r`n")
    Write-Utf8 (Join-Path $OutputDir 'README.txt') "Minecraft Wiki inventory icons. Images are unmodified PNG downloads.`r`nEach source URL, retrieval time and SHA256 are recorded in sources.json.`r`nWiki file pages may specify different licensing; source: https://minecraft.wiki/w/Minecraft_Wiki:Copyrights`r`nDownloaded or cached indicates an image response, not visual verification in Minecraft.`r`n"
    $zipPath=Join-Path (Split-Path $OutputDir -Parent) 'Wiki_Block_Icons.zip'
    $zipTemp=$zipPath+'.tmp'
    if (Test-Path -LiteralPath $zipTemp) { Remove-Item -LiteralPath $zipTemp -Force }
    $archive=[IO.Compression.ZipFile]::Open($zipTemp,[IO.Compression.ZipArchiveMode]::Create)
    try {
        foreach ($source in $validSources.ToArray()) {
            $null=[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,(Join-Path $OutputDir $source.file),$source.file,[IO.Compression.CompressionLevel]::Optimal)
        }
        foreach ($name in @('sources.json','download_results.csv','missing.csv','missing.txt','README.txt')) {
            $null=[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,(Join-Path $OutputDir $name),$name,[IO.Compression.CompressionLevel]::Optimal)
        }
    } finally { $archive.Dispose() }
    Move-Item -LiteralPath $zipTemp -Destination $zipPath -Force
    $ok=@($resultRows | Where-Object { $_.status -in @('downloaded','cached') }).Length
    Write-Host ('完了: 取得済み '+$ok+' / 未取得 '+$missing.Length)
    Write-Host ('送ってほしいZIP: '+$zipPath)
    if ($stopped) { Write-Host ('接続を停止しました: '+$stopped); Write-Host '時間を置いて再実行するか、missing.txt のURLをブラウザーで確認してください。' }
    if ($missing.Length -gt 0) { $exitCode=2 }
} catch {
    Write-Host ('エラー: '+$_.Exception.Message)
    Write-Host ('位置: '+$_.ScriptStackTrace)
    $exitCode=1
} finally { if ($null -ne $Client) { $Client.Dispose() } }
exit $exitCode
