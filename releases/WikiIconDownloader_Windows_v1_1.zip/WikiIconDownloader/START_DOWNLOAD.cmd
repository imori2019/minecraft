@echo off
setlocal
pushd "%~dp0."
if errorlevel 1 (
  echo Could not open the tool folder. Extract the complete ZIP first.
  pause
  exit /b 1
)
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Download-WikiIcons.ps1" -ScriptDirectory "%~dp0." -ManifestPath "%~dp0BlockGlyphImages_manifest.json" -OutputDir "%~dp0download_result" -CustomUrlsPath "%~dp0custom_urls.json"
set "wiki_tool_exit_code=%errorlevel%"
popd
echo.
pause
exit /b %wiki_tool_exit_code%
