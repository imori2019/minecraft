const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const d=JSON.parse(fs.readFileSync(path.join(__dirname,'../resource_pack/ui/data_driven_container_screen.json')));
const root=d.desktop_panel.controls.find(x=>x['root_panel@common.root_panel'])['root_panel@common.root_panel'];
const cursor=root.controls.find(x=>x['inventory_selected_icon_button@common.inventory_selected_icon_button'])['inventory_selected_icon_button@common.inventory_selected_icon_button'];
assert.equal(cursor.layer,undefined);assert.equal(cursor.button_mappings,undefined);assert.equal(cursor.controls.length,5);for(const c of cursor.controls)assert.deepEqual(Object.values(c)[0],{visible:false});
const visuals=d.desktop_panel.controls.filter(x=>x.shop_carried_foreground);assert.equal(visuals.length,1);const v=visuals[0].shop_carried_foreground;assert.equal(v.type,'panel');assert.equal(v.follows_cursor,true);assert.equal(v.layer,55000);for(const k of ['button_mappings','always_handle_pointer','default_control','hover_control','pressed_control'])assert.equal(v[k],undefined);
assert.deepEqual(v.controls[0],{'selected_item_icon@common.inventory_selected_icon':{layer:55000}});assert.deepEqual(v.controls[1],{'selected_stack_size_text@common.inventory_selected_stack_size_text':{layer:55001}});
console.log('PASS cursor: one noninteractive foreground sibling of root_panel; native input button has unchanged hit layer/mappings and no duplicate drawing (native rendering not executed)');
