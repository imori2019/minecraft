const assert=require('node:assert/strict'),fs=require('fs'),path=require('path');
const d=JSON.parse(fs.readFileSync(path.join(__dirname,'../resource_pack/ui/data_driven_container_screen.json'),'utf8'));
const controls=node=>Object.fromEntries(node.controls.flatMap(e=>Object.entries(e)));
const desktop=controls(d.desktop_panel),root=controls(desktop['root_panel@common.root_panel']),overlay=desktop.shop_cursor_overlay;
const button=root['inventory_selected_icon_button@common.inventory_selected_icon_button'];assert.ok(button);assert.equal(button.layer,-10);
assert.equal(button.always_handle_pointer,undefined,'vanilla catch-empty-space handling is retained at its original low layer');
assert.equal(button.button_mappings,undefined);assert.equal(button.follows_cursor,undefined);
for(const state of ['default','hover','pressed','durability_bar_grabbed','storage_bar_grabbed'])assert.ok(controls(button)[state+'@common.empty_panel'],'input button does not also render a second carried item');
assert.ok(root['gamepad_cursor@common.gamepad_cursor_button']);
console.log('PASS CURSOR pointer-handling buttons stay in the original root at the native input layer');
// These inherited controls are rendering-only in the native UI. Expand all local
// references in the foreground; any button/input_panel or unknown common control fails.
const visualNative=new Set(['common.inventory_selected_icon','common.inventory_selected_stack_size_text','common.inventory_selected_item_lock_overlay','common.durability_bar_grabbed','common.storage_bar_grabbed','common.flying_item_renderer']);
function visualOnly(o,name='overlay',seen=new Set()){
 assert.notEqual(o.type,'button',name);assert.notEqual(o.type,'input_panel',name);assert.notEqual(o.always_handle_pointer,true,name);
 const ref=name.split('@')[1];
 if(ref){
  if(ref.startsWith('common.'))assert.ok(visualNative.has(ref),'nonvisual or unknown foreground prototype: '+ref);
  else {const k=ref.replace('data_driven_container.','');assert.ok(d[k],ref);assert.ok(!seen.has(k));const next=new Set(seen);next.add(k);visualOnly(d[k],k,next);}
 }
 for(const e of o.controls??[])for(const[k,v]of Object.entries(e))visualOnly(v,k,seen);
}
visualOnly(overlay);assert.deepEqual(overlay.size,['100%','100%']);assert.equal(overlay.ignored,undefined);
console.log('PASS CURSOR foreground recursively contains only visual controls and cannot capture shop-button clicks');
const panel=d.shop_carried_visual,p=controls(panel),icon=p['selected_item_icon@common.inventory_selected_icon'],count=p['selected_stack_size_text@common.inventory_selected_stack_size_text'];
assert.equal(panel.type,'panel');assert.equal(panel.follows_cursor,true);assert.deepEqual(panel.size,[16,16]);assert.ok(icon.layer>=500);assert.equal(count.layer-icon.layer,3);assert.equal(icon.bindings,undefined);assert.equal(count.bindings,undefined);
assert.equal(panel.bindings[0].binding_name,'#inventory_selected_item');assert.equal(panel.bindings[0].binding_condition,'always');assert.equal(panel.bindings[1].target_property_name,'#visible');assert.ok(panel.bindings[1].source_property_name.includes('#shop_cursor_aux = 0'));assert.ok(panel.bindings[1].source_property_name.includes('#shop_cursor_aux = -1'));
console.log('PASS CURSOR carried icon/count retain native bindings and hide when no item is carried');
assert.ok(desktop['selected_item_details_factory@common.selected_item_details_factory'].layer>overlay.layer+count.layer);
assert.ok(controls(overlay)['flying_item_renderer@common.flying_item_renderer']);
console.log('PASS CURSOR tooltip order and flying-item feedback are retained');
// The v739 arrangement is the negative control: its inherited native button had
// always_handle_pointer=true above every shop button and must be rejected here.
assert.throws(()=>visualOnly({controls:[{'inventory_selected_icon_button@common.inventory_selected_icon_button':{layer:0}}]}));
console.log('PASS CURSOR regression guard rejects the v739 foreground input button');
console.log('5 cursor input/layering checks passed (UI structure; Minecraft pointer routing/rendering not executed)');
