// v1.1.800 セール画面の「この内容でクーポンを発行」
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');const {run,prep}=require('./test_smelt_sales.cjs');
let n=0;const test=(name,fn)=>{fn();n++;console.log('PASS COUPON '+name);};
const J=s=>JSON.parse(run(`JSON.stringify(${s})`));
async function main(){
 test('the button sits under "追加" in each section and borrows a slot that section does not show (global/daily 251, class 253)',()=>{
  const d=JSON.parse(fs.readFileSync(path.join(__dirname,'../resource_pack/ui/shop_layout_price.json'),'utf8'));
  const clicks=o=>new Set([...JSON.stringify(o).matchAll(/"signal@common.container_item":\{"collection_index":(\d+)/g)].map(m=>+m[1]));
  for(const [b,k,cs,cn] of [['global_body','g',251,252],['class_body','c',253,94],['daily_body','d',251,252]]){
   const body=d.pp_right_content.controls.find(c=>c[b])[b];const keys=body.controls.map(c=>Object.keys(c)[0]);
   const i=keys.indexOf(k+'_add');assert.deepEqual(keys.slice(i,i+6),[k+'_add',k+'_cp_sep',k+'_cpn','pp_kpw_'+k+'_cpn',k+'_cpn_sep',k+'_cp']);
   const s=JSON.stringify(body.controls[i+5]);assert.ok(JSON.stringify(body.controls[i+2]).includes('"collection_index":'+cn),k+': count field slot '+cn);assert.ok(s.includes('この内容でクーポンを発行'));assert.ok(s.includes('"collection_index":'+cs));
   const others=body.controls.filter((c,j)=>j!==i+5&&j!==i+2);assert.ok(!clicks(others).has(cs)&&!clicks(others).has(cn),k+': borrowed slots must not be other buttons in this section');
   assert.ok(s.includes('shop_layout_price.pp_btn_coupon')&&!s.includes('pp_btn_add_'),'coupon hover must not reuse the add button (it shows 追加/修正)');}
  const hv=JSON.stringify(d.pp_hover_coupon);assert.ok(!hv.includes('修正')&&!hv.includes('"追加"'));
  assert.equal(d['pp_btn_coupon@common.container_slot_button_prototype']['$highlight_control'],'shop_layout_price.pp_hover_coupon');
  assert.ok(!JSON.stringify(d).includes('"collection_index":638'),'638 never reached the script in game');
  assert.equal(run('ppCouponSlot({gOpen:true})'),251);assert.equal(run('ppCouponSlot({cOpen:true})'),253);assert.equal(run('ppCouponSlot({dailyOpen:true})'),251);
 });
 prep();
 run(`globalThis.mkInv=(items)=>({size:items.length,getItem:i=>items[i]});globalThis.slotInv=(it)=>({size:640,getItem:i=>i===SH_COUPON_SLOT?it:undefined});shopCouponContainer=p=>p?.shop;
  globalThis.st=registry.stores.s1;globalThis.rec={settings:{coupon_max_rate:'50',coupon_max_count:'3',shop_product_genre:'果物'}};
  globalThis.cAll=shopMakeCoupon(st,10);globalThis.cFloor=shopMakeCoupon(st,20,{floor:'d1',floorName:'食べ物'});
  globalThis.cGenre=shopMakeCoupon(st,30,{floor:'d1',floorName:'食べ物',genre:'野菜'});
  globalThis.withC=(it)=>({shop:slotInv(it),getComponent:k=>k==='minecraft:inventory'?{container:mkInv([cAll,cFloor,cGenre])}:undefined});`);
 test('a coupon from the class/daily sale only works in its floor (and genre); store-wide coupons work anywhere',()=>{
  assert.equal(run(`shopCouponPlan(withC(cAll),st,rec,'d2').pct`),10,'store-wide works anywhere');
  assert.equal(run(`shopCouponPlan(withC(cFloor),st,rec,'d1').pct`),20,'floor coupon on its floor');
  assert.equal(run(`shopCouponPlan(withC(cFloor),st,rec,'d2').pct`),0,'floor coupon on another floor');
  assert.equal(run(`shopCouponPlan(withC(cGenre),st,rec,'d1').pct`),0,'genre 野菜 does not match 果物');
  assert.equal(run(`shopCouponPlan(withC(cGenre),st,{settings:{...rec.settings,shop_product_genre:'野菜'}},'d1').pct`),30);
  assert.equal(run(`shopCouponPlan(withC(undefined),st,rec,'d1').pct`),0,'coupons only in the inventory are not used (only the coupon slot)');
  assert.equal(run(`shopCouponPlan({getComponent:()=>undefined},st,rec,'d1').pct`),0,'no buyer screen open: none');
  assert.ok(run(`cGenre.getLore()[0]`).includes('食べ物（野菜）'));assert.ok(run(`cAll.getLore()[0]`).includes('店全体'));
 });
 run(`globalThis.answers=[];globalThis.realShow=showFormWithRetry;showFormWithRetry=async()=>answers.shift();
  globalThis.given=[];globalThis.realGive=giveOrDrop;giveOrDrop=(p,it)=>given.push(it);
  const chain=class{constructor(){const p=new Proxy(this,{get:(t,k)=>k==='then'?undefined:()=>p});return p;}};globalThis.realModal=ModalFormData;ModalFormData=chain;
  globalThis.dimX={getBlock:()=>block};
  globalThis.pend=(ui,draft)=>{pricePending.set(player.id,{storeId:'s1',draft,committed:draft,ui:ppNewUi(ui),target:{kind:'coupon'},tick:0});};`);
 await run(`(async()=>{given.length=0;pend({gOpen:true},{globalDiscount:{method:'percent',value:15},classDiscounts:[]});answers=[{formValues:[4]}];await priceValueForm(player,dimX,{x:0,y:0,z:0});})()`);
 test('global sale content: 15% store-wide coupons, as many as chosen',()=>{
  assert.equal(run('given.reduce((n,i)=>n+i.amount,0)'),4);assert.equal(run('shopCouponInfo(given[0]).rate'),15);assert.equal(run('(shopCouponInfo(given[0])?.floor||undefined)'),undefined);
 });
 await run(`(async()=>{given.length=0;pend({gOpen:true},{globalDiscount:{method:'amount',value:5},classDiscounts:[]});answers=[{formValues:[2]}];await priceValueForm(player,dimX,{x:0,y:0,z:0});})()`);
 test('a fixed-amount sale cannot become a coupon',()=>{assert.equal(run('given.reduce((n,i)=>n+i.amount,0)'),0);});
 await run(`(async()=>{given.length=0;pend({psOpen:true,gOpen:false},{globalDiscount:{method:'percent',value:15},classDiscounts:[]});answers=[{formValues:[2]}];await priceValueForm(player,dimX,{x:0,y:0,z:0});})()`);
 test('point sale cannot become a coupon',()=>{assert.equal(run('given.reduce((n,i)=>n+i.amount,0)'),0);});
 await run(`(async()=>{globalThis.snd=[];player.playSound=(id,o)=>snd.push(id);given.length=0;pend({gOpen:true},{globalDiscount:{method:'percent',value:15},classDiscounts:[]});answers=[{formValues:[1]}];await priceValueForm(player,dimX,{x:0,y:0,z:0});})()`);
 test('issuing plays the same sound as registering a point card',()=>{assert.equal(run('given.reduce((n,i)=>n+i.amount,0)'),1);assert.deepEqual(JSON.parse(run('JSON.stringify(snd)')),['random.levelup']);});
 test('no rate / amount / point sale: the reason is given before the screen closes',()=>{
  assert.equal(run(`ppCouponProblem({gOpen:true},{method:'percent',value:0})`),'先に割引率（%）を決めてください');
  assert.equal(run(`ppCouponProblem({gOpen:true},{method:'amount',value:5})`),'割合（%）のセールだけクーポンにできます');
  assert.equal(run(`ppCouponProblem({psOpen:true},{method:'percent',value:5})`),'ポイント特売はクーポンにできません');
  assert.equal(run(`ppCouponProblem({cOpen:true},{method:'percent',value:20})`),'');
 });
 test('coupons stack: same content = same name and lore (hidden key only), up to 64; old item-property coupons still read',()=>{
  run(`globalThis.k1=shopMakeCoupon(st,12,{floor:'d1',floorName:'食べ物',genre:'野菜'},5);globalThis.k2=shopMakeCoupon(st,12,{floor:'d1',floorName:'食べ物',genre:'野菜'});globalThis.k3=shopMakeCoupon(st,13);`);
  assert.equal(run('k1.amount'),5);
  assert.equal(run('JSON.stringify(k1.getLore())===JSON.stringify(k2.getLore())&&k1.nameTag===k2.nameTag'),true);
  assert.equal(run('JSON.stringify(k1.getLore())===JSON.stringify(k3.getLore())'),false);
  assert.deepEqual(JSON.parse(run('JSON.stringify(shopCouponInfo(k1))')),{store:'s1',rate:12,floor:'d1',genre:'野菜'});
  const line=run('k1.getLore()[1]');assert.equal(line.replace(/§./g,''),'割引 12%','the key is invisible');assert.ok(line.length<=50,'lore line length '+line.length);
  assert.equal(run('ItemTypes?1:1'),1);
  assert.match(require('node:fs').readFileSync(require('node:path').join(__dirname,'../behavior_pack/items/coupon.json'),'utf8'),/"minecraft:max_stack_size": 64/);
  run(`globalThis.old=new ItemStack(SH_COUPON_ID,1);old.setDynamicProperty(SH_COUPON_STORE_PROP,'s1');old.setDynamicProperty(SH_COUPON_RATE_PROP,7);`);
  assert.equal(run('shopCouponInfo(old).rate'),7);
 });
 test('using coupons takes one per use from a stack, and the stack stays',()=>{
  run(`globalThis.cinv=new Map([[0,shopMakeCoupon(st,10,{},5)],[1,shopMakeCoupon(st,20,{},1)]]);globalThis.b3={size:2,getItem:i=>cinv.get(i),setItem:(i,v)=>v?cinv.set(i,v):cinv.delete(i)};`);
  assert.equal(run(`shopUseCoupons(b3,[0,0,1],'s1')`),3);assert.equal(run('cinv.get(0).amount'),3);assert.equal(run('cinv.has(1)'),false);
  assert.equal(run(`shopUseCoupons(b3,[0],'other')`),0);assert.equal(run('cinv.get(0).amount'),3);
 });
 test('products whose coupon settings were never entered accept coupons (up to 100%, 1 at a time); 0 turns them off',()=>{
  run(`globalThis.b4={shop:slotInv(shopMakeCoupon(st,25,{},3))};`);
  assert.deepEqual(JSON.parse(run(`JSON.stringify((({pct,count})=>({pct,count}))(shopCouponPlan(b4,st,{settings:{}},'d1')))`)),{pct:25,count:1});
  assert.equal(run(`shopCouponPlan(b4,st,{settings:{coupon_max_rate:'0'}},'d1').pct`),0);
  assert.equal(run(`shopCouponPlan(b4,st,{settings:{coupon_max_count:'0'}},'d1').pct`),0);
  assert.equal(run(`shopCouponPlan(b4,st,{settings:{coupon_max_rate:'10'}},'d1').pct`),10,'rate cap still applies');
 });
 test('a stack counts as that many coupons, up to the product max count',()=>{
  run(`globalThis.b2={shop:slotInv(shopMakeCoupon(st,10,{},5))};`);
  const plan=JSON.parse(run(`JSON.stringify(shopCouponPlan(b2,st,rec,'d1'))`));
  assert.equal(plan.count,3);assert.equal(plan.pct,30);assert.deepEqual(plan.slots,[234,234,234]);
 });
 run(`showFormWithRetry=realShow;giveOrDrop=realGive;ModalFormData=realModal;`);
 console.log(n+' coupon test groups passed (API simulation; no Minecraft runtime)');
}
main().catch(e=>{console.error(e);process.exit(1);});
