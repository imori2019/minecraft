// v1.1.823 店舗データ（全部の店の設定・材料庫）を、1つのワールドプロパティ（32767バイトまで）に入りきらない時は分けて保存する。
// 入りきらないと保存が全部失敗し、材料庫などに入れた物が保存されなかった
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const src=fs.readFileSync(path.join(__dirname,'../behavior_pack/scripts/main.js'),'utf8');
function fn(name){const i=src.indexOf(`function ${name}(`);assert.ok(i>=0,name);let d=0,j=src.indexOf('{',i);for(let k=j;k<src.length;k++){if(src[k]==='{')d++;else if(src[k]==='}'){d--;if(!d)return src.slice(i,k+1);}}}
function cst(name){const m=src.match(new RegExp(`(?:const|let) ${name} = [^\\n]*;`));assert.ok(m,name);return m[0];}
const props=new Map();let failRead=false;
const world={getDynamicProperty:k=>{if(failRead&&k.includes(':chunk:'))return undefined;return props.get(k);},
 setDynamicProperty:(k,v)=>{if(typeof v==='string'&&Buffer.byteLength(v,'utf8')>32767)throw new Error('too big');if(v===undefined)props.delete(k);else props.set(k,v);}};
const ctx=vm.createContext({world,JSON,Number,Object,Array,String,Error,Math});
vm.runInContext([cst('STORE_REGISTRY_PROP'),cst('SHOP_WORLD_CHUNK_PREFIX'),cst('SHOP_WORLD_MAX_BYTES'),cst('STORE_REGISTRY_READ_FAILED'),'let STORE_REGISTRY_REVISION = 0;',cst('STORE_RAW_CACHE'),
 ...['loadStores','saveStores','readShopWorldValue','writeShopWorldValue','shopChunkManifest','shopWorldChunkKey','splitShopUtf8','clearShopChunks','utf8Length'].map(fn),
 'globalThis.api={loadStores,saveStores};'].join('\n'),ctx);
const {loadStores,saveStores}=ctx.api;
const big=()=>{const reg={nextId:60,nextGroupId:1,groups:{},stores:{}};for(let s=0;s<40;s++)reg.stores['s'+s]={id:'s'+s,name:'お店'+s,departments:[],nextDeptId:1,
 fletch:{mats:Array.from({length:81},(_,i)=>({id:'minecraft:glass_bottle',n:i%64+1}))},enchant:{mats:Array.from({length:54},()=>({id:'minecraft:lapis_lazuli',n:64}))}};return reg;};
let n=0;const test=(t,f)=>{f();n++;console.log('PASS REGISTRY '+t);};
test('old single-property data still loads',()=>{props.set('shop_store_registry',JSON.stringify({nextId:2,stores:{s1:{id:'s1',name:'A',departments:[]}}}));assert.equal(loadStores().stores.s1.name,'A');});
test('a registry over the 32767-byte limit is saved in pieces and loads back the same',()=>{
 const reg=big();assert.ok(Buffer.byteLength(JSON.stringify(reg))>32767,'test data is over the limit');
 assert.equal(saveStores(reg),true,'saving no longer fails');
 assert.ok([...props.keys()].some(k=>k.startsWith('shop_store_registry:chunk:')));
 const back=loadStores();assert.equal(Object.keys(back.stores).length,40);assert.equal(JSON.stringify(back.stores.s7.fletch.mats[80]),JSON.stringify({id:'minecraft:glass_bottle',n:17}));
});
test('saving again (smaller) replaces the pieces cleanly',()=>{
 const reg=loadStores();for(const k of Object.keys(reg.stores))if(k!=='s1')delete reg.stores[k];assert.equal(saveStores(reg),true);
 assert.ok(![...props.keys()].some(k=>k.includes(':chunk:')),'old pieces removed');assert.equal(Object.keys(loadStores().stores).join(),'s1');
});
test('if the data cannot be read, saving does not overwrite it with empty data',()=>{
 assert.equal(saveStores(big()),true);vm.runInContext('STORE_RAW_CACHE={rev:-1,raw:undefined}',ctx);/* next session */failRead=true;const r=loadStores();assert.equal(JSON.stringify(r.stores),'{}');
 assert.equal(saveStores(r),false,'refused');failRead=false;assert.equal(Object.keys(loadStores().stores).length,40,'data kept');
});
test('v824: loading again before any save reuses the text (no world reads); a save refreshes it',()=>{
 assert.equal(saveStores(big()),true);let reads=0;const real=world.getDynamicProperty;world.getDynamicProperty=k=>{reads++;return real(k);};
 loadStores();loadStores();loadStores();assert.equal(reads,0,'cached after save');
 const r=loadStores();r.stores.s1.name='変更';assert.equal(saveStores(r),true);assert.equal(loadStores().stores.s1.name,'変更');
 world.getDynamicProperty=real;
});
console.log(n+' registry tests passed (32767-byte limit simulated)');
