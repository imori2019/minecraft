// v1.1.824 全部のショップの種類で、材料庫の画面・購入画面・見回りがエラーなく動くか
const T=require('./test_smelt_sales.cjs');const {run,prep,ctx,Container}=T;
const ids=JSON.parse(run('JSON.stringify(Object.keys(SHOP_BLOCK_LORE).filter(k=>k!=="shopuilook2:shop_remover"))'));
const out=[];
for(const id of ids){
 ctx.shopInv=new Container(640);prep();
 const r=run(`(()=>{block.typeId=${JSON.stringify(id)};getBlockStoreId=()=>'s1';const errs=[];const R={dimensionId:'minecraft:overworld',x:0,y:64,z:0};
  const t=(name,f)=>{try{f()}catch(e){errs.push(name+': '+String(e.stack||e).split('\\n').slice(0,2).join(' @ '))}};
  t('extra-enter',()=>enterExtraScreen(player,R,block,shopInv));for(const sl of Object.values(LX).filter(n=>typeof n==='number'))setProbe(shopInv,sl,1);lxHandleStatusClick=()=>false;screenLandingButtons=()=>false;
  for(let i=0;i<30&&R.extraMode;i++){system.currentTick++;t('extra-tick',()=>tickExtraScreen(player,R,block,shopInv));}
  const S={dimensionId:'minecraft:overworld',x:0,y:64,z:0};
  t('shop-enter',()=>enterShopMode(player,S,block,shopInv));active.set(player.id,S);
  for(let i=0;i<30&&S.shopMode;i++){system.currentTick++;t('shop-tick',()=>tickShopMode(player,S,block,shopInv));}
  active.delete(player.id);
  t('patrol',()=>{fzAutoCraft(block);fzSmokerBreed(block,5);fzSpawnerGrow(block,5);fzBarrelGrow(block,5);cpGrow(block,5);crCraft(block);if(fzKindOf(block)==='vault')vtDeadlines(block);});
  return JSON.stringify({kind:fzKindOf(block),stayed:!!R.extraMode,errs:[...new Set(errs)].slice(0,3)});})()`);
 out.push(id.replace('shopuilook2:','')+' '+r);
}
const bad=out.filter(x=>!x.includes('"errs":[]'));require('node:assert/strict').deepEqual(bad,[],bad.join('\n'));
console.log('PASS SMOKE '+ids.length+' shop types: storage screen, buyer screen and patrol run without errors');
