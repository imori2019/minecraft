// v1.1.766 矢細工台：ポーションの醸造・効能付きの矢
const assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path');
const env=require('./test_smelt_sales.cjs');
const {run,prep}=env;
let n=0;const test=(name,fn)=>{fn();n++;console.log('PASS FLETCH '+name);};
run(`globalThis.mkPotion=(id,effect,delivery)=>{const it=new ItemStack(id,1);it.maxAmount=1;it.getComponent=k=>k==='minecraft:potion'?{potionEffectType:{id:effect},potionDeliveryType:{id:delivery}}:undefined;return it;};
 Potions.resolve=(e,d)=>mkPotion(d==='Consume'?'minecraft:potion':d==='ThrownSplash'?'minecraft:splash_potion':'minecraft:lingering_potion',e,d);
 Potions.getEffectType=id=>({id});Potions.getDeliveryType=id=>({id});`);
const need=(eff,id)=>JSON.parse(run(`JSON.stringify(Object.fromEntries((flBrewNeed('${eff}','${id}')??[]).map(x=>[x[1].replace('minecraft:',''),x[2]])))`));
test('brew recipes follow vanilla ingredients and modifiers (3 potions per brew)',()=>{
 assert.deepEqual(need('minecraft:swiftness','minecraft:potion'),{glass_bottle:3,blaze_powder:1,nether_wart:1,sugar:1});
 assert.deepEqual(need('minecraft:long_swiftness','minecraft:splash_potion'),{glass_bottle:3,blaze_powder:1,nether_wart:1,sugar:1,redstone:1,gunpowder:1});
 assert.deepEqual(need('minecraft:strong_harming','minecraft:lingering_potion'),{glass_bottle:3,blaze_powder:1,nether_wart:1,glistering_melon_slice:1,fermented_spider_eye:1,glowstone_dust:1,gunpowder:1,dragon_breath:1});
 assert.deepEqual(need('minecraft:weakness','minecraft:potion'),{glass_bottle:3,blaze_powder:1,fermented_spider_eye:1},'weakness has no nether wart');
 assert.deepEqual(need('minecraft:water','minecraft:potion'),{glass_bottle:3});
 assert.deepEqual(need('minecraft:strength','minecraft:potion'),{glass_bottle:3,blaze_powder:2,nether_wart:1},'blaze powder is fuel and ingredient');
 assert.deepEqual(need('minecraft:wither','minecraft:potion'),{},'not brewable');
});
function setup(mats,products){
 prep();
 run(`autoSyncProducts=()=>0;`);/* v1.1.839: these checks cover brewing/growing only; auto products are tested in test_auto_products */
 run(`block.typeId='shopuilook2:panel_fletch';const m=Array(81).fill(null);for(const [i,x] of Object.entries(${JSON.stringify(mats)}))m[i]=x;
  registry.stores.s1.fletch={auto:true,mats:m,made:0};saveProductIndex(block,[]);registry.stores.s1.departments=registry.stores.s1.departments??[];
  for(const p of ${JSON.stringify(products)}){const ids=loadProductIndex(block);ids.push(p.id);saveProductIndex(block,ids);saveProduct(block,{id:p.id,savedOnce:true,settings:{shop_sale_type:0},items:[{id:p.item,key:p.key,role:'sample',slot:17,count:1}],stock:[]});}`);
}
const potionStock=(pid)=>run(`(loadProduct(block,'${pid}').stock??[]).reduce((a,r)=>a+(r.item.potion?r.item.amount:0),0)`);
const mat=(id)=>run(`registry.stores.s1.fletch.mats.reduce((a,m)=>a+(m?.id==='${id}'?m.n:0),0)`);
test('a potion listing is refilled by brewing 3 at a time; materials are used and the water bucket stays',()=>{
 setup({0:{id:'minecraft:water_bucket',n:1},1:{id:'minecraft:glass_bottle',n:6},2:{id:'minecraft:nether_wart',n:2},3:{id:'minecraft:blaze_powder',n:2},4:{id:'minecraft:sugar',n:2}},
  [{id:'pp',item:'minecraft:potion',key:'minecraft:potion|p=minecraft:swiftness/Consume'}]);
 run(`crCraft(block)`);assert.equal(potionStock('pp'),3);
 assert.equal(mat('minecraft:glass_bottle'),3);assert.equal(mat('minecraft:sugar'),1);assert.equal(mat('minecraft:water_bucket'),1);
 run(`crCraft(block)`);assert.equal(potionStock('pp'),6);assert.equal(mat('minecraft:glass_bottle'),0);
 run(`crCraft(block)`);assert.equal(potionStock('pp'),6,'target reached / no materials');
});
test('no water bucket, no brewing',()=>{
 setup({1:{id:'minecraft:glass_bottle',n:6},2:{id:'minecraft:nether_wart',n:2},3:{id:'minecraft:blaze_powder',n:2},4:{id:'minecraft:sugar',n:2}},
  [{id:'pp',item:'minecraft:potion',key:'minecraft:potion|p=minecraft:swiftness/Consume'}]);
 run(`crCraft(block)`);assert.equal(potionStock('pp'),0);
});
test('a lingering potion in storage creates a tipped-arrow listing and 8 arrows + 1 potion make 8 tagged arrows',()=>{
 setup({54:{id:'minecraft:arrow',n:16}},[]);
 run(`const lp=mkPotion('minecraft:lingering_potion','minecraft:poison','ThrownLingering');registry.stores.s1.fletch.mats[5]={id:'minecraft:lingering_potion',n:2,snap:snapshotItemStack(lp)};crCraft(block);`);
 const pid=run(`loadProductIndex(block).find(id=>loadProduct(block,id).items[0].key.includes('#tarrow:poison'))`);
 assert.ok(pid,'listing created');
 assert.equal(run(`loadProduct(block,'${pid}').settings.shop_product_name`),'毒の矢');
 assert.equal(run(`(loadProduct(block,'${pid}').stock).reduce((a,r)=>a+r.item.amount,0)`),8);
 assert.equal(mat('minecraft:arrow'),8);assert.equal(mat('minecraft:lingering_potion'),1);
 run(`crCraft(block)`);assert.equal(run(`(loadProduct(block,'${pid}').stock).reduce((a,r)=>a+r.item.amount,0)`),16);
 assert.equal(run(`loadProductIndex(block).length`),1,'no duplicate listing');
});
test('bought tagged arrows become real tipped arrows via loot (one command per arrow), with a plain-arrow fallback',()=>{
 run(`globalThis.cmds=[];globalThis.fp={id:'P9',runCommand:c=>{cmds.push(c);return {successCount:c.includes('poison')?1:0};}};
  const a=flArrowItem('minecraft:strong_poison',2);const b=flArrowItem('minecraft:bogus',1);globalThis.given=[];
  const g=giveOrDrop;giveOrDrop=(p,it)=>given.push(it.typeId);flGiveTipped(fp,[a,b]);giveOrDrop=g;`);
 assert.deepEqual(JSON.parse(run(`JSON.stringify(cmds)`)),['loot give @s loot "shopuilook2/tipped/strong_poison"','loot give @s loot "shopuilook2/tipped/strong_poison"','loot give @s loot "shopuilook2/tipped/bogus"']);
 assert.deepEqual(JSON.parse(run(`JSON.stringify(given)`)),['minecraft:arrow']);
 assert.equal(run(`flArrowName('minecraft:strong_poison')`),'毒の矢 II');assert.equal(run(`flArrowName('minecraft:long_nightvision')`),'暗視の矢 延長');
});
test('every tippable effect has a loot table using set_potion with the same id',()=>{
 const dir=path.join(__dirname,'../behavior_pack/loot_tables/shopuilook2/tipped');const files=fs.readdirSync(dir);
 assert.ok(files.length>=40);
 for(const f of files){const d=JSON.parse(fs.readFileSync(path.join(dir,f),'utf8'));assert.equal(d.pools[0].entries[0].functions[0].function,'set_potion');assert.equal(d.pools[0].entries[0].functions[0].id+'.json',f);}
});
test('potions with effects can be stored in fletching storage (kept with their effect)',()=>{
 setup({},[]);
 run(`globalThis.cont={slots:new Map(),getItem(i){return this.slots.get(i);},setItem(i,v){if(v)this.slots.set(i,v);else this.slots.delete(i);}};
  cont.setItem(CR_WIDE_SLOTS[40],mkPotion('minecraft:lingering_potion','minecraft:poison','ThrownLingering'));
  globalThis.smf={storeId:'s1',fzKind:'fletch',crKey:''};crSync(player,smf,cont);`);
 assert.equal(run(`registry.stores.s1.fletch.mats[40].snap.potion.effect`),'minecraft:poison');
});
console.log(n+' fletch potion test groups passed');
