const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');const env=require('./test_smelt_sales.cjs');const {run,ctx,Container,prep}=env;
let count=0;function test(name,fn){fn();count++;console.log('PASS RECOMMEND '+name);}
ctx.shopInv=new Container(640);prep();
run(`block.typeId='shopuilook2:panel';SHOP_BAKE_ON.clear();globalThis.realShopBestPrice=shopBestPrice;
 globalThis.recRates=[10,70,50,90,20,60,80,0,100];
 const list=recRates.map((rate,i)=>{const p=base('rec'+i,'minecraft:apple');p.testRate=rate;return p;});
 putProducts(list);for(const p of list) {if(p.testRate===100){p.stock=[];saveProduct(block,p);}setProductFloor(block,p.id,'d1');}
 globalThis.quoteRates=new Map(list.map(p=>[p.id,p.testRate]));
 shopBestPrice=(rec)=>{const rate=quoteRates.get(rec.id)??0;return {entries:[{k:'item',id:'minecraft:emerald',n:100,n2:100-rate}],discounted:rate>0,saving:rate};};
 globalThis.recMode={floorId:'d1',player,history:false,bakeOn:false,onlyAffordable:false,rowWindowIndex:0};`);
test('each floor has a single group of at most four products (cards below slot 256), ordered by effective discount rate',()=>{
 run(`globalThis.m=shopModel(recMode,block,registry.stores.s1);globalThis.recs=shopDealModel(recMode,block,m,pricePointSettingsForStore(registry.stores.s1),[],shopNow());`);
 assert.equal(run('recs.groups.length'),1);assert.deepEqual(JSON.parse(run('JSON.stringify(recs.groups[0].ids)')),['rec3','rec6','rec1','rec5']);
});
test('the affordable-only filter is respected before selecting the top six',()=>{
 run(`recMode.onlyAffordable=true;m.allowedIds=new Set(['rec0','rec1','rec3']);globalThis.filtered=shopDealModel(recMode,block,m,pricePointSettingsForStore(registry.stores.s1),[],shopNow());recMode.onlyAffordable=false;`);
 assert.deepEqual(JSON.parse(run('JSON.stringify(filtered.groups[0].ids)')),['rec3','rec1','rec0']);
});
test('discount rate takes priority over a large absolute reduction',()=>{
 assert.ok(run('shopRecommendationScore([{n:10,n2:2}]).rate')>run('shopRecommendationScore([{n:1000,n2:500}]).rate'));
 assert.deepEqual(JSON.parse(run('JSON.stringify(shopRecommendationScore([{n:100,n2:100}]))')),{rate:0,saving:0});
});
test('deal cards are written only to slots below 256 (game cannot use 256+)',()=>{
 run(`globalThis.recommendRec={};enterShopMode(player,recommendRec,block,shopInv);`);
 assert.ok(run('[...recommendRec.shopMode.dealCells.keys()].length')>0);
 assert.ok(run('[...recommendRec.shopMode.dealCells.keys()].every(s=>s<256)'));
 assert.ok(run('RP_B.every(g=>g.cells.every(d=>d.cell<256&&d.price<256&&d.set<256&&SH_DEAL_PROBE.get(d.cell)<256))'));
});
test('both recommendation groups have four usable image/price pairs and correct private probes',()=>{
 const ui=require('./read_price_ui.cjs')();
 for(let g=0;g<2;g++){
  const stack=ui.sh_rp_content.controls.find(x=>x['b_grp'+g])['b_grp'+g];
  for(let c=0;c<4;c++){
   const group=stack.controls[c<3?0:1][c<3?'top':'more'];
   const image=group.controls.find(x=>x['c_b'+g+'_'+c])['c_b'+g+'_'+c],price=group.controls.find(x=>x['pbox_b'+g+'_'+c])['pbox_b'+g+'_'+c];
   const refs=[];function walk(o){if(!o||typeof o!=='object')return;if(typeof o.collection_index==='number')refs.push(o.collection_index);Object.values(o).forEach(walk);}walk(image);
   assert.ok(refs.includes(run(`RP_B[${g}].cells[${c}].cell`)));assert.ok(refs.includes(run(`SH_DEAL_PROBE.get(RP_B[${g}].cells[${c}].cell)`)));
   assert.ok(price.offset[1]+price.size[1]<=group.size[1]);
  }
 }
});
test('v837: today\'s weekday deals join the top six cards after feature and limited items (no separate weekday box)',()=>{
 run(`globalThis.wm=shopModel(recMode,block,registry.stores.s1);weekdayDeal=(rec)=>rec.id==='rec2'?{today:true}:null;globalThis.wd=shopDealModel(recMode,block,wm,pricePointSettingsForStore(registry.stores.s1),[],shopNow());`);
 assert.ok(run(`wd.a.some(x=>x.id==='rec2'&&x.kind==='weekday')`));assert.equal(run('RP_W.cells.length'),0);
 assert.ok(run('[...SH_DEAL_PROBE.values()].every(p=>![18,27,28,29,46,47,51,53].includes(p))'));
});
test('v838: top-card prices are red for feature, yellow for limited, aqua for weekday',()=>{
 const d=t=>JSON.parse(run(`JSON.stringify([...shopCardPriceLines([{k:'item',id:'minecraft:emerald',n:120,n2:120}],true,SH_DEAL_KIND_THEME[${JSON.stringify(t)}])[0]].slice(1).map(c=>c.charCodeAt(0)))`));
 assert.deepEqual(d('feature'),[0xF7F1,0xF7F2,0xF7F0]);assert.deepEqual(d('limited'),[0xF761,0xF762,0xF760]);assert.deepEqual(d('weekday'),[0xF7D1,0xF7D2,0xF7D0]);
 const ui=require('fs').readFileSync(require('path').join(__dirname,'../resource_pack/ui/shop_layout_price.json'),'utf8');assert.ok(ui.includes('\uF7DC')||ui.includes('\\uF7DC'),'aqua digits are subtracted from the top-card icon labels');
});
console.log(count+' recommendation tests passed (API and UI simulation; no Minecraft runtime)');
