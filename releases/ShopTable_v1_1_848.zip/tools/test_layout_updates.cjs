const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {run}=require('./test_smelt_sales.cjs');
const read=f=>String(f).endsWith('shop_layout_price.json')?require('./read_price_ui.cjs')():(JSON.parse(fs.readFileSync(path.join(__dirname,'..','resource_pack/ui',f),'utf8')));
let n=0;const test=(name,fn)=>{fn();n++;console.log('PASS LAYOUT '+name);};
const controls=o=>Object.fromEntries(o.controls.flatMap(x=>Object.entries(x)));
(async()=>{
 test('genre choices preserve sixteen Japanese characters; header and rows fit the existing dropdown',()=>{
  run(`globalThis.longGenre='あいうえおかきくけこさしすせそた';genreChoices=()=>({page:0,choices:[{kind:'value',name:longGenre,label:longGenre}]});
    writeGenreDropdown(player,{},block,shopInv);`);
  assert.equal(run('shopInv.getItem(GENRE_LABEL_SLOTS[0]).nameTag'),run('longGenre'));
  const d=read('data_driven_container_screen.json'),basic=controls(d.settings_side_panel).basic_settings_group,b=controls(basic),g=controls(b.product_genre_group);
  const labels=[];function walk(x){if(x&&typeof x==='object'){if(x.type==='label'&&'collection_index'in x)labels.push(x);Object.values(x).forEach(walk);}}
  walk(b.product_genre_group);walk(b.genre_popup);assert.equal(labels.length,10);
  assert.ok(labels.every(x=>x.font_scale_factor===0.8));
  assert.ok(16*9*0.8<=126,'sixteen Japanese characters fit beside radio/delete controls');
 });
 test('enchant right column runs deposit level -> template books -> materials, keeping all original storage indices',()=>{
  const d=read('shop_proceeds_screen.json'),gate=controls(d.screen).gate,v=controls(controls(controls(gate).furnace_only).v),en=controls(controls(v.enchant_pen_cp).enchant_pen);
  for(let i=45;i<50;i++){
   // v1.1.764: 右の列に上から「預けるレベル → 複製元の本 → 材料」
   const b=en['cr_mat'+i];assert.ok(b.offset[0]>=189&&b.offset[0]+b.size[0]<=358,'template slot in the right column');
   assert.ok(b.offset[1]>=en.en_deposit_field.offset[1]+en.en_deposit_field.size[1],'below the deposit field');
   assert.ok(b.offset[1]+b.size[1]<=en.en_l_lapis.offset[1],'above the lapis heading');assert.equal(en.cr_head,undefined,'v822: no 材料 heading');
   assert.equal(Object.values(b.controls[0])[0].collection_index,44+i);
  }
  assert.ok(en.cr_toggle.offset[0]<180&&en.cr_toggle.offset[1]+en.cr_toggle.size[1]<=130,'toggle stays in the upper left box');
  assert.ok(en.en_tpl_head.offset[1]+en.en_tpl_head.size[1]<=en.cr_mat45.offset[1]);
  assert.ok(en.en_deposit.offset[1]+en.en_deposit.size[1]<=258);
 });
 test('deal groups use lower cards and keep their final row inside the group',()=>{
  const rp=read('shop_layout_price.json').sh_rp_content;
  /* v769: each deal group is a stack of the always-built top (title + 3 cards) and the 4-6 card row */
  const parts=[];for(const entry of rp.controls)for(const [key,g]of Object.entries(entry))if(key.startsWith('b_grp')){
   assert.equal(g.type,'stack_panel');for(const c of g.controls)parts.push(...Object.entries(c));}
  assert.equal(parts.length,4);
  for(const [key,g]of parts){
   assert.ok(g.size[1]<70);
   for(const child of g.controls)for(const [name,v]of Object.entries(child))if(name.startsWith('pbox')){
    assert.equal(v.size[1],14);assert.ok(v.offset[1]+v.size[1]<=g.size[1]);
    const primary=Object.values(controls(v)).find(x=>x.visible!==false);
    for(const variant of primary.controls){
     const priceRow=controls(controls(Object.values(variant)[0]).v).prow;
     const holder=controls(priceRow).t2;const t2=holder.controls?.[0]?.e??holder;
     assert.equal(t2.type,'label');assert.equal(t2.size[0],'default');
     assert.equal((holder.bindings??[]).some(x=>x.target_property_name==='#visible'),false);
     const gate=controls(Object.values(variant)[0]).v;
     const more=controls(gate)['price_more@shop_layout_price.sh_price_more_by_width'];
     assert.equal(more.offset[0],(priceRow.offset?.[0]??0)+controls(priceRow).ibox.size[0]);
     assert.equal(more.offset[1],0);
     {const row=read('shop_layout_price.json').sh_price_more_by_width.controls[0].row;
      const image={...row.controls.at(-1).mark,offset:row.offset};
      assert.equal(image.texture,'textures/shopuilook2/ui/price_more');
      assert.ok(image.offset[1]+image.size[1]<=v.size[1]);
     }
    }
   }
  }
 });
 test('deal cards show first price only, with an extra-payment marker only for multiple payments',()=>{
  run(`shopDealModel=()=>({floorOf:new Map([['p1','d1']]),floorName:()=> '売り場',best:new Map([['p1',{entries:dealPayments}]]),a:[{id:'p1',kind:'sale'}],groups:[],pages:1,point:'',weekday:[]});
    makeDealDisplayItem=()=>new ItemStack('minecraft:apple');shopBakeEntries=e=>e;shopCardPriceLines=()=>['FIRST','SECOND'];shopIsSoldOut=()=>false;
    globalThis.dealPayments=[{n:1,n2:1}];globalThis.priceWrites=[];
    globalThis.renderDeal=()=>{priceWrites=[];writeShopDeals(shopInv,{txt:new Map(),gen:new Map(),bPage:0},block,{records:new Map([['p1',{settings:{}}]])},{},[],0,new Map(),(...args)=>priceWrites.push(args));};renderDeal();`);
  assert.equal(run('priceWrites[0][1]'),'FIRST');assert.equal(run('priceWrites[1][1]'),'');assert.equal(run('priceWrites[1][6]'),false);
  run(`dealPayments.push({n:2,n2:2});renderDeal();`);
  assert.equal(run('priceWrites[0][1]'),'FIRST');assert.notEqual(run('priceWrites[1][1]'),'SECOND');assert.equal(run('priceWrites[1][6]'),true);
 });
 run(`globalThis.capturedBasicForm=null;
 ModalFormData=class{constructor(){this.fields=[];capturedBasicForm=this;}title(){return this;}textField(label){this.fields.push({label,kind:'text'});return this;}toggle(label){this.fields.push({label,kind:'toggle'});return this;}dropdown(){throw Error('unrelated point dropdown');}submitButton(){return this;}};
 canManageStore=()=>true;storeFormDone=()=>{};showFormWithRetry=async()=>({formValues:['新しい名前','新しい説明',false]});
 registry.stores.s1.customPoints=[{id:'keep',owner:'s1',name:'既存ポイント',shared:true}];
 registry.stores.s2={id:'s2',customPoints:[{id:'keep',owner:'s1',name:'既存ポイント',shared:true}]};`);
 const old=JSON.parse(run('JSON.stringify([registry.stores.s1.customPoints,registry.stores.s2.customPoints])'));
 await run(`showStoreInfoForm(player,block.dimension,block.location,'s1')`);
 test('saving store name edits basic fields while preserving own and shared custom points',()=>{
  assert.equal(run('capturedBasicForm.fields.length'),3);assert.equal(run('registry.stores.s1.name'),'新しい名前');assert.equal(run('registry.stores.s1.openToCustomers'),false);
  assert.deepEqual(JSON.parse(run('JSON.stringify([registry.stores.s1.customPoints,registry.stores.s2.customPoints])')),old);
 });
 console.log(n+' layout/form test groups passed (API and layout checks; no Minecraft rendering)');
})().catch(e=>{console.error(e);process.exitCode=1;});
