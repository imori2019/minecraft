// v1.1.839 自動で売り場に商品を作る（コンポスター・音符ブロック・クラフター・鍛冶台・大釜）
const assert=require('node:assert/strict');
const env=require('./test_smelt_sales.cjs');
const {run,prep,ctx,Container}=env;
let count=0;function test(name,fn){fn();count++;console.log('PASS AUTO '+name);}
const products=()=>JSON.parse(run(`JSON.stringify(loadProductIndex(block).map(id=>{const r=loadProduct(block,id);const fl=storeFloors(loadStores().stores.s1);return {id,auto:r.autoBy,sample:r.items?.[0]?.id,floor:fl.find(f=>f.id===productFloorId(block,id,fl))?.name??'未分類',price:shopPayEntries(r,pricePointSettingsForStore(loadStores().stores.s1).currencies).length,genre:r.settings?.shop_product_genre}}))`));
function reset(){ctx.shopInv=new Container(640);prep();run(`AUTO_SYNC_CACHE.clear();AUTO_INPUT_CACHE.clear();putProducts([]);registry.stores.s1.departments=[];`);}
test('crafter: every recipe the current materials can make becomes an unpriced product on its kind floor',()=>{
 reset();run(`block.typeId='shopuilook2:panel_crafter';registry.stores.s1.crafter={auto:true,mats:[{id:'minecraft:oak_planks',n:64},{id:'minecraft:stick',n:16},{id:'minecraft:iron_ingot',n:2}],made:0};crCraft(block);`);
 const ps=products();assert.ok(ps.length>5,'made several products');
 assert.ok(ps.every(p=>p.auto==='crafter'&&p.price===0),'auto + unpriced (準備中)');
 assert.ok(ps.some(p=>p.sample==='minecraft:oak_slab'&&p.floor==='建材売り場'));
 assert.ok(ps.some(p=>p.sample==='minecraft:shears'&&p.floor==='道具売り場'),JSON.stringify(ps.map(p=>p.sample+'@'+p.floor)));
 assert.ok(!ps.some(p=>p.sample==='minecraft:iron_block'),'nothing that needs missing materials');
});
test('crafter: a kind floor never holds more than 27 products; extra go to "○○売り場2"',()=>{
 reset();run(`block.typeId='shopuilook2:panel_crafter';registry.stores.s1.crafter={auto:true,mats:[{id:'minecraft:oak_planks',n:64},{id:'minecraft:spruce_planks',n:64},{id:'minecraft:birch_planks',n:64},{id:'minecraft:jungle_planks',n:64},{id:'minecraft:acacia_planks',n:64},{id:'minecraft:dark_oak_planks',n:64},{id:'minecraft:stick',n:64},{id:'minecraft:cobblestone',n:64},{id:'minecraft:stone',n:64}],made:0};crCraft(block);`);
 const ps=products();const by={};for(const p of ps)by[p.floor]=(by[p.floor]||0)+1;
 for(const [f,n] of Object.entries(by)) if(f!=='未分類') assert.ok(n<=27,f+' '+n);
 assert.ok(by['建材売り場2']>0,'second building floor: '+JSON.stringify(by));
});
test('crafter: an auto product that can no longer be made and has no stock is removed; priced ones stay',()=>{
 reset();run(`block.typeId='shopuilook2:panel_crafter';registry.stores.s1.crafter={auto:true,mats:[{id:'minecraft:oak_planks',n:64}],made:0};crCraft(block);`);
 assert.ok(products().some(p=>p.sample==='minecraft:oak_slab'));
 run(`for(const id of loadProductIndex(block)){const r=loadProduct(block,id);r.stock=[];saveProduct(block,r);}AUTO_SYNC_CACHE.clear();AUTO_INPUT_CACHE.clear();registry.stores.s1.crafter.mats=[{id:'minecraft:cobblestone',n:64}];crCraft(block);`);
 const ps=products();assert.ok(!ps.some(p=>p.sample==='minecraft:oak_slab'),'oak slab removed');assert.ok(ps.some(p=>p.sample==='minecraft:cobblestone_wall'));
});
test('note block: each disc in storage gets a record-floor product',()=>{
 reset();run(`block.typeId='shopuilook2:panel_note';registry.stores.s1.note={auto:true,mats:[{id:'minecraft:music_disc_cat',n:1},{id:'minecraft:coal',n:4}],made:0};crCraft(block);`);
 const ps=products();assert.ok(ps.some(p=>p.sample==='minecraft:music_disc_cat'&&p.floor==='レコード売り場'));
});
test('composter: planted crops, flowers and trees get products on 畑・花・木 floors',()=>{
 reset();run(`block.typeId='shopuilook2:panel_composter';registry.stores.s1.composter={grow:[{id:'minecraft:wheat_seeds',amount:4},{id:'minecraft:poppy',amount:2},{id:'minecraft:oak_sapling',amount:1}],mats:[{id:'minecraft:dirt',n:64},{id:'minecraft:water_bucket',n:1}],prog:{},made:0};cpGrow(block,1);`);
 const ps=products();
 assert.ok(ps.some(p=>p.sample==='minecraft:wheat'&&p.floor==='畑売り場'));
 assert.ok(ps.some(p=>p.sample==='minecraft:poppy'&&p.floor==='花売り場'));
 assert.ok(ps.some(p=>p.sample==='minecraft:oak_log'&&p.floor==='木の売り場'));
});
test('when all 7 floors are used, new auto products go to 未分類',()=>{
 reset();run(`registry.stores.s1.departments=Array.from({length:7},(_,i)=>({id:'d'+(i+1),name:'店主の売り場'+i}));block.typeId='shopuilook2:panel_note';registry.stores.s1.note={auto:true,mats:[{id:'minecraft:music_disc_cat',n:1}],made:0};crCraft(block);`);
 assert.ok(products().some(p=>p.sample==='minecraft:music_disc_cat'&&p.floor==='未分類'));
});
test('smithing table: netherite upgrades it can make and templates it holds get products',()=>{
 reset();run(`block.typeId='shopuilook2:panel_smith';const mats=Array(81).fill(null);mats[0]={id:'minecraft:diamond_sword',n:1};mats[1]={id:'minecraft:netherite_ingot',n:1};mats[27]={id:'minecraft:netherite_upgrade_smithing_template',n:2};mats[28]={id:'minecraft:coast_armor_trim_smithing_template',n:1};registry.stores.s1.smith={mats,made:0,smv:3};crCraft(block);`);
 const ps=products();
 assert.ok(ps.some(p=>p.sample==='minecraft:netherite_sword'&&p.floor==='ネザライト売り場'),JSON.stringify(ps));
 assert.ok(ps.some(p=>p.sample==='minecraft:coast_armor_trim_smithing_template'&&p.floor==='鍛冶型売り場'));
});
test('cauldron: brewable potions get products on the potion floors',()=>{
 reset();run(`Potions.resolve=(e,d)=>{const it=new ItemStack(d==='Consume'?'minecraft:potion':d==='ThrownSplash'?'minecraft:splash_potion':'minecraft:lingering_potion',1);it.getComponent=(c)=>c==='minecraft:potion'?{potionEffectType:{id:e},potionDeliveryType:{id:d}}:undefined;return it;};block.typeId='shopuilook2:panel_fletch';const mats=Array(81).fill(null);mats[0]={id:'minecraft:water_bucket',n:1};mats[27]={id:'minecraft:glass_bottle',n:6};mats[9]={id:'minecraft:blaze_powder',n:4};[['minecraft:nether_wart',4],['minecraft:sugar',2],['minecraft:gunpowder',2]].forEach(([id,n],i)=>mats[18+i]={id,n});registry.stores.s1.fletch={auto:true,mats,made:0};crCraft(block);`);
 const ps=products();
 assert.ok(ps.some(p=>p.sample==='minecraft:potion'&&p.floor==='ポーション売り場'),JSON.stringify(ps));
 assert.ok(ps.some(p=>p.sample==='minecraft:splash_potion'&&p.floor==='スプラッシュポーション売り場'));
 assert.ok(!ps.some(p=>p.sample==='minecraft:lingering_potion'),'no dragon breath, no lingering');
});
test('v840: wheat, beetroot, pumpkin and melon also yield their seeds (auto products on the farm floor)',()=>{
 reset();run(`block.typeId='shopuilook2:panel_composter';registry.stores.s1.composter={grow:[{id:'minecraft:wheat_seeds',amount:3},{id:'minecraft:melon_seeds',amount:2}],mats:[{id:'minecraft:dirt',n:64},{id:'minecraft:water_bucket',n:1}],prog:{},made:0};cpGrow(block,1);cpGrow(block,FZ_BREED_SECONDS);`);
 const ps=products();
 for(const id of ['wheat','wheat_seeds','melon_slice','melon_seeds'])assert.ok(ps.some(p=>p.sample==='minecraft:'+id&&p.floor==='畑売り場'),id);
 const st=id=>run(`(()=>{for(const pid of loadProductIndex(block)){const r=loadProduct(block,pid);if(r.items[0].id==='${id}')return fzStockCountPlain(r,'${id}');}return -1;})()`);
 assert.equal(st('minecraft:wheat'),3);assert.equal(st('minecraft:wheat_seeds'),6);assert.equal(st('minecraft:melon_slice'),8);assert.equal(st('minecraft:melon_seeds'),2);
});
console.log(count+' auto product tests passed (API simulation; no Minecraft runtime)');
