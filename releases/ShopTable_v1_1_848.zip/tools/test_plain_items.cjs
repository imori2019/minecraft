// v1.1.822 重ならない物（バケツ・レコードなど）も、何も付いていなければ材料庫・専用スロットに入る
const assert=require('node:assert/strict');const {run}=require('./test_smelt_sales.cjs');
const mk=o=>`({typeId:'${o.id??'minecraft:x'}',maxAmount:${o.max??1},nameTag:${JSON.stringify(o.name??'')},isStackableWith:()=>${o.stack?'true':'false'},getLore:()=>${JSON.stringify(o.lore??[])},getDynamicPropertyIds:()=>${JSON.stringify(o.props??[])},getComponent:k=>k==='minecraft:enchantable'?{getEnchantments:()=>${JSON.stringify(o.ench??[])}}:k==='minecraft:durability'?(${o.dmg??-1}>=0?{damage:${o.dmg??0}}:undefined):undefined})`;
const P=o=>run(`shopPlainItem(${mk(o)})`);
assert.equal(P({max:1}),true,'a plain water bucket / music disc (stack size 1) goes in');
assert.equal(P({max:64,stack:true}),true,'ordinary stackable item');
assert.equal(P({max:64,stack:false}),true,'v827: a plain stackable item the game reports as not stacking (e.g. compass) still goes in');
assert.equal(P({max:1,name:'名前'}),false);assert.equal(P({max:1,lore:['x']}),false);assert.equal(P({max:1,props:['a']}),false);
assert.equal(P({max:1,ench:[{id:'mending'}]}),false);assert.equal(P({max:1,dmg:3}),false);assert.equal(P({max:1,dmg:0}),true);
const fs=require('node:fs'),path=require('node:path');const js=fs.readFileSync(path.join(__dirname,'../behavior_pack/scripts/main.js'),'utf8');
assert.equal((js.match(/it\.isStackableWith\(new ItemStack\(it\.typeId, 1\)\)/g)||[]).length,1,'only inside shopPlainItem');
for(const id of ['minecraft:potion','minecraft:splash_potion','minecraft:white_shulker_box','minecraft:shulker_box','minecraft:tropical_fish_bucket','minecraft:red_banner','minecraft:filled_map','minecraft:enchanted_book'])assert.equal(P({max:1,id}),false,id+' keeps hidden data: not stored as a plain item');
assert.equal(P({max:64,id:'minecraft:compass'}),true,'compass');assert.equal(P({max:1,id:'minecraft:water_bucket'}),true);assert.equal(P({max:1,id:'minecraft:music_disc_cat'}),true);assert.equal(P({max:64,id:'minecraft:arrow'}),true,'plain arrows always go in (cauldron arrow slots)');
assert.equal(run(`shopIsTippedArrow({typeId:'minecraft:arrow',localizationKey:'item.arrow.effect.poison',getComponent:()=>undefined})`),true);
assert.equal(run(`shopIsTippedArrow({typeId:'minecraft:arrow',localizationKey:'item.arrow.name',getComponent:k=>k==='minecraft:potion'?{}:undefined})`),true);
assert.equal(run(`shopPlainItem({typeId:'minecraft:arrow',localizationKey:'item.arrow.effect.poison',maxAmount:64,isStackableWith:()=>true,getComponent:()=>undefined})`),false,'v828: tipped arrows stay out');
assert.equal(run(`shopIsTippedArrow(new ItemStack('minecraft:arrow',1))`),false,'plain arrow');
console.log('PASS PLAIN items with stack size 1 (buckets, records) are accepted when nothing is attached');
