// v1.1.694 コンポスター：木とキノコの木
const assert=require('node:assert/strict');
const env=require('./test_smelt_sales.cjs');
const {run,prep}=env;
let count=0;
function test(name,fn){fn();count++;console.log('PASS TREE '+name);}
// 売り場に、採れる物の商品（在庫0）を並べ、育てる欄・材料の欄を入れる
function prepCp(grow,mats,outs){
 prep();
 run(`autoSyncProducts=()=>0;`);/* v1.1.839: these checks cover brewing/growing only; auto products are tested in test_auto_products */
 run(`block.typeId='shopuilook2:panel_composter';
  putProducts(${JSON.stringify(outs)}.map((id,i)=>{const r=base('o'+i,id);r.stock=[];return r;}));
  registry.stores.s1.composter={grow:${JSON.stringify(grow)},mats:${JSON.stringify(mats)},prog:{},made:0};`);
}
const stock=id=>run(`(()=>{for(const pid of loadProductIndex(block)){const r=loadProduct(block,pid);if(r.items[0].id==='${id}')return fzStockCountPlain(r,'${id}');}return -1;})()`);
const grow=()=>run(`cpGrow(block,FZ_BREED_SECONDS)`);
test('an oak sapling on dirt with water grows logs, a sapling, sticks and an apple into listed products only',()=>{
 prepCp([{id:'minecraft:oak_sapling',amount:2}],[{id:'minecraft:dirt',n:2},{id:'minecraft:water_bucket',n:1}],['minecraft:oak_log','minecraft:apple']);
 grow();
 assert.equal(stock('minecraft:oak_log'),10);assert.equal(stock('minecraft:apple'),2);
 assert.equal(run(`registry.stores.s1.composter.made`),12);
 assert.equal(run(`registry.stores.s1.composter.grow[0].amount`),2,'saplings are not used up');
});
test('trees on dirt still need water',()=>{
 prepCp([{id:'minecraft:birch_sapling',amount:1}],[{id:'minecraft:dirt',n:1}],['minecraft:birch_log']);
 grow();assert.equal(stock('minecraft:birch_log'),0);
});
test('dark oak needs four saplings and four dirt for one tree',()=>{
 prepCp([{id:'minecraft:dark_oak_sapling',amount:3}],[{id:'minecraft:dirt',n:8},{id:'minecraft:water_bucket',n:1}],['minecraft:dark_oak_log']);
 grow();assert.equal(stock('minecraft:dark_oak_log'),0);
 prepCp([{id:'minecraft:dark_oak_sapling',amount:8}],[{id:'minecraft:dirt',n:6},{id:'minecraft:water_bucket',n:1}],['minecraft:dark_oak_log']);
 grow();assert.equal(stock('minecraft:dark_oak_log'),16,'6 dirt is enough for only one 2x2 tree');
});
test('mushrooms need mycelium (or podzol) and no water; dirt alone does not grow them',()=>{
 prepCp([{id:'minecraft:red_mushroom',amount:1}],[{id:'minecraft:dirt',n:4},{id:'minecraft:water_bucket',n:1}],['minecraft:red_mushroom_block','minecraft:mushroom_stem']);
 grow();assert.equal(stock('minecraft:red_mushroom_block'),0);
 prepCp([{id:'minecraft:red_mushroom',amount:1},{id:'minecraft:brown_mushroom',amount:1}],[{id:'minecraft:mycelium',n:1},{id:'minecraft:podzol',n:1}],['minecraft:red_mushroom_block','minecraft:brown_mushroom_block','minecraft:mushroom_stem']);
 grow();assert.equal(stock('minecraft:red_mushroom_block'),8);assert.equal(stock('minecraft:brown_mushroom_block'),10);assert.equal(stock('minecraft:mushroom_stem'),8);
});
test('nether fungi grow only on their own nylium',()=>{
 prepCp([{id:'minecraft:crimson_fungus',amount:1},{id:'minecraft:warped_fungus',amount:1}],[{id:'minecraft:crimson_nylium',n:1}],['minecraft:crimson_stem','minecraft:warped_stem','minecraft:shroomlight']);
 grow();assert.equal(stock('minecraft:crimson_stem'),6);assert.equal(stock('minecraft:warped_stem'),0);assert.equal(stock('minecraft:shroomlight'),1);
});
test('crops and trees share the dirt left to right, and mushrooms do not take dirt',()=>{
 prepCp([{id:'minecraft:wheat_seeds',amount:3},{id:'minecraft:oak_sapling',amount:3},{id:'minecraft:red_mushroom',amount:1}],[{id:'minecraft:dirt',n:4},{id:'minecraft:mycelium',n:1},{id:'minecraft:water_bucket',n:1}],['minecraft:wheat','minecraft:oak_log','minecraft:mushroom_stem']);
 assert.deepEqual(JSON.parse(run(`JSON.stringify([...cpPlots(registry.stores.s1.composter)])`)),[['minecraft:wheat_seeds',3],['minecraft:oak_sapling',1],['minecraft:red_mushroom',1]]);
 grow();assert.equal(stock('minecraft:wheat'),3);assert.equal(stock('minecraft:oak_log'),5);assert.equal(stock('minecraft:mushroom_stem'),4);
});
test('stock stops at 64 and a tree with nowhere to put anything waits fully grown',()=>{
 prepCp([{id:'minecraft:spruce_sapling',amount:64}],[{id:'minecraft:dirt',n:64},{id:'minecraft:water_bucket',n:1}],['minecraft:spruce_log']);
 grow();assert.equal(stock('minecraft:spruce_log'),64);
 grow();assert.equal(run(`registry.stores.s1.composter.prog['minecraft:spruce_sapling']`),300);
});
test('moss needs lava, water and bone meal (stone made from lava and water), and uses one bone meal per harvest',()=>{
 const outs=['minecraft:moss_block','minecraft:moss_carpet','minecraft:azalea'];
 for(const mats of [[{id:'minecraft:water_bucket',n:1},{id:'minecraft:bone_meal',n:3}],[{id:'minecraft:lava_bucket',n:1},{id:'minecraft:bone_meal',n:3}],[{id:'minecraft:lava_bucket',n:1},{id:'minecraft:water_bucket',n:1}]]){
  prepCp([{id:'minecraft:moss_block',amount:2}],mats,outs);grow();assert.equal(stock('minecraft:moss_block'),0,JSON.stringify(mats));
 }
 prepCp([{id:'minecraft:moss_block',amount:2}],[{id:'minecraft:lava_bucket',n:1},{id:'minecraft:water_bucket',n:1},{id:'minecraft:bone_meal',n:3}],outs);
 grow();assert.equal(stock('minecraft:moss_block'),4);assert.equal(stock('minecraft:moss_carpet'),4);assert.equal(stock('minecraft:azalea'),2);
 assert.equal(run(`cpMatCount(registry.stores.s1.composter,'minecraft:bone_meal')`),2);
 assert.equal(run(`cpMatCount(registry.stores.s1.composter,'minecraft:lava_bucket')`),1,'the lava bucket is not used up');
 assert.equal(run(`registry.stores.s1.composter.grow[0].amount`),2,'the moss block itself is not used up');
});
test('moss does not take any dirt from crops, and pale moss grows the same way',()=>{
 prepCp([{id:'minecraft:moss_block',amount:3},{id:'minecraft:wheat_seeds',amount:2}],[{id:'minecraft:dirt',n:2},{id:'minecraft:lava_bucket',n:1},{id:'minecraft:water_bucket',n:1},{id:'minecraft:bone_meal',n:3}],['minecraft:moss_carpet','minecraft:wheat']);
 assert.deepEqual(JSON.parse(run(`JSON.stringify([...cpPlots(registry.stores.s1.composter)])`)),[['minecraft:moss_block',3],['minecraft:wheat_seeds',2]]);
 grow();assert.equal(stock('minecraft:moss_carpet'),6);assert.equal(stock('minecraft:wheat'),2);
 prepCp([{id:'minecraft:pale_moss_block',amount:1}],[{id:'minecraft:lava_bucket',n:1},{id:'minecraft:water_bucket',n:1},{id:'minecraft:bone_meal',n:1}],['minecraft:pale_moss_carpet','minecraft:pale_hanging_moss']);
 grow();assert.equal(stock('minecraft:pale_moss_carpet'),2);assert.equal(stock('minecraft:pale_hanging_moss'),1);
});
test('stone blocks are no longer accepted as composter materials, lava buckets are',()=>{
 assert.equal(run(`CP_MAT_IDS.has('minecraft:cobblestone')`),false);assert.equal(run(`CP_MAT_IDS.has('minecraft:lava_bucket')`),true);
});
test('every tree, mushroom and soil id is a real item (Japanese name table or item icon list)',()=>{
 const bad=JSON.parse(run(`JSON.stringify([...Object.keys(CP_TREES),...Object.values(CP_TREES).flatMap(t=>t.out.map(o=>o[0])),...Object.values(CP_SOILS).flatMap(x=>x.ids)]
  .filter(id=>!(JA_ITEM_NAMES[id]||JA_ITEM_NAMES[id.slice(10)]||SHOP_ICON_NAMES.has(id.slice(10)))))`));
 assert.deepEqual(bad,[]);
});
console.log(count+' tree test groups passed');
