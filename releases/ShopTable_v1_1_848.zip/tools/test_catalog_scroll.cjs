const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const env=require('./test_smelt_sales.cjs');const {run,ctx,Container,prep}=env;
const read=p=>String(p).endsWith('shop_layout_price.json')?require('./read_price_ui.cjs')():(JSON.parse(fs.readFileSync(path.join(__dirname,'..',p),'utf8')));
let n=0;function test(name,fn){fn();n++;console.log('PASS CATALOG '+name);}
function reset(count,genres=1){ctx.shopInv=new Container(640);prep();run(`block.typeId='shopuilook2:panel';SHOP_BAKE_ON.clear();active.clear();PANEL_OCCUPANTS.clear();
 registry.stores.s1.departments=[{id:'d1',name:'商品売り場'},{id:'d2',name:'別の売り場'}];
 const list=Array.from({length:${count}},(_,i)=>{const p=base('catalog'+i,'minecraft:apple');p.settings.shop_product_genre='ジャンル'+(i%${genres});return p;});putProducts(list);
 globalThis.catalogMode={player,floorId:'d1',history:false,bakeOn:false,rowWindowIndex:0};`);}
test('only 9 rows (slots below 256) are shown at once; the rest page with the row-0 arrows',()=>{
 for(const genres of [1,3,9,27]){
  reset(27,genres);run('globalThis.catalogModel=shopModel(catalogMode,block,registry.stores.s1)');
  const rows=run('catalogModel.allVerticalRows.length');
  assert.equal(run('catalogModel.rows.length'),Math.min(9,rows));assert.equal(run('catalogModel.rowWindowCount'),Math.ceil(rows/9));
  assert.equal(run('catalogModel.hasMoreRows'),rows>9);
 }
});
test('buyer rendering never writes a product above slot 255 and shows the paging arrows',()=>{
 reset(27,27);run(`globalThis.catalogRec={};enterShopMode(player,catalogRec,block,shopInv)`);
 assert.equal(run('catalogRec.shopMode.cells.size'),9);
 assert.ok(run('[...catalogRec.shopMode.cells.keys()].every(slot=>slot<256)'));
 assert.notEqual(run('shopInv.getItem(89)'),undefined);assert.notEqual(run('shopInv.getItem(90)'),undefined);
 for(let row=0;row<9;row++){
  assert.equal(run(`catalogRec.shopMode.cells.get(shSlots(${row}).cell[0])`),'catalog'+row);
  assert.ok(run(`shopInv.getItem(shSlots(${row}).price[0])?.nameTag.length>0`));
 }
});
test('every product stays reachable: paging to the last window opens its purchase confirmation',()=>{
 reset(27,27);run(`globalThis.catalogRec={};enterShopMode(player,catalogRec,block,shopInv);system.currentTick+=30;
  catalogRec.pendingVisual=null;catalogRec.shopMode.initialTextRebindTick=0;
  catalogRec.shopMode.rowWindowIndex=2;shopRefreshFloorView(player,catalogRec,block,shopInv);system.currentTick+=30;
  catalogRec.pendingVisual=null;catalogRec.shopMode.initialTextRebindTick=0;
  shopInv.setItem(shSlots(8).cell[0],undefined);tickShopMode(player,catalogRec,block,shopInv);`);
 assert.equal(run('catalogRec.shopMode.confirm?.id'),'catalog26');
});
test('a large catalogue keeps every product reachable across windows',()=>{
 reset(82,1);const pages=run('shopModel(catalogMode,block,registry.stores.s1).rowWindowCount');const ids=[];
 for(let w=0;w<pages;w++){run(`catalogMode.rowWindowIndex=${w}`);ids.push(...JSON.parse(run('JSON.stringify(shopModel(catalogMode,block,registry.stores.s1).rows.flatMap(r=>r.ids))')));}
 assert.equal(new Set(ids).size,82);
});
test('native UI rows use their own slots (rows 1-9 below 256) and variables; product-list angle arrows are absent',()=>{
 const ui=read('resource_pack/ui/shop_layout_price.json'),content=ui.sh_content.controls;
 const framework=new Set(['#text','#font_type','#hover_text','#inventory_stack_count','#visible','#ignored','#enabled','#is_selected']);const all=new Set();
 for(let row=0;row<27;row++)for(const suffix of ['', '_continuation']){
  const k='sh_row'+row+suffix,g=content.find(x=>x[k])[k];assert.equal(g.collection_index,run(`shSlots(${row}).title`));if(row<9)assert.ok(g.collection_index<256);
  assert.ok(g.controls.every(x=>!('prev'in x)&&!('next'in x)));
  for(let c=0;c<3;c++){
   const box=g.controls.find(x=>x[`pbox_${row}_${c}`])[`pbox_${row}_${c}`];
   const first=Object.values(box.controls[0])[0],second=Object.values(box.controls[1])[0];
   const labels=[];function walk(o){if(!o||typeof o!=='object')return;if(o.type==='label'&&o.bindings?.some(b=>b.binding_name==='#hover_text'))labels.push(o);Object.values(o).forEach(walk);}walk(first);
   assert.ok(labels.some(x=>x.collection_index===run(`shSlots(${row}).price[${c}]`)));
   const secondLabels=[];const expected=run(`shSlots(${row}).line2[${c}]`);function slots(o){if(!o||typeof o!=='object')return;if(o.type==='label')secondLabels.push(o.collection_index);Object.values(o).forEach(slots);}slots(second);assert.ok(secondLabels.includes(expected),'row '+row+' line2');
  }
  if(!suffix){const vars=new Set((JSON.stringify(g).match(/#[A-Za-z_][A-Za-z0-9_]*/g)||[]).filter(v=>!framework.has(v)));for(const v of vars){assert.ok(!all.has(v),'shared cross-row property '+v);all.add(v);}}
 }
 assert.ok(content.some(x=>x.catalog_more));
 assert.equal(read('behavior_pack/entities/panel_ui.json')['minecraft:entity'].components['minecraft:inventory'].inventory_size,640);
});
test('legacy actors retain a bounded working catalogue until their inventory can be grown',()=>{
 reset(27,27);ctx.shopInv=new Container(256);run('globalThis.legacyModel=shopModel(catalogMode,block,registry.stores.s1)');assert.equal(run('legacyModel.rows.length'),9);assert.equal(run('legacyModel.rowWindowCount'),3);
});
console.log(n+' catalogue scroll tests passed (API and UI simulation; no Minecraft runtime)');
