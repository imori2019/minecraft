// v1.1.823 デバッグ：宝物庫（商品を消した・値段の物を変えた・締め切り後）と、大釜の残り物の戻し先
const assert=require('node:assert/strict');const {run,prep,playerInv,worldProps}=require('./test_smelt_sales.cjs');
let n=0;const test=(t,f)=>{f();n++;console.log('PASS DEBUG '+t);};
const setup=()=>{prep();run(`block.typeId='shopuilook2:panel_vault';registry.stores.s1.vault={};world.setDynamicProperty(VT_PENDING_PROP,undefined);globalThis.cnt=id=>[...playerInv.items.values()].filter(i=>i.typeId===id).reduce((n,i)=>n+i.amount,0);globalThis.msgs=[];tell=(p,m)=>msgs.push(m);`);};
test('a deleted product: the auction is cancelled and the bid comes back',()=>{
 setup();assert.equal(run(`vtBid(player,block,'p1',130)`),true);assert.equal(run('cnt(currency)'),62);
 run(`saveProductIndex(block,[]);getProps(block).set(productKey('p1'),undefined);vtDeadlines(block);`);
 assert.equal(run(`vtState(registry.stores.s1).auctions.p1`),undefined);assert.equal(run('cnt(currency)'),192,'refunded');
});
test('an index that fails to read does not cancel auctions (the product data is still there)',()=>{
 setup();assert.equal(run(`vtBid(player,block,'p1',130)`),true);
 run(`globalThis.realIdx=loadProductIndex;loadProductIndex=()=>[];vtDeadlines(block);loadProductIndex=realIdx;`);
 assert.equal(run(`vtState(registry.stores.s1).auctions.p1.top.n`),130);
});
test('price item changed during an auction: the earlier bidder gets back what they paid with',()=>{
 setup();assert.equal(run(`vtBid(player,block,'p1',130)`),true);
 run(`registry.stores.s1.vault.auctions.p1.cur={kind:'it',id:'minecraft:diamond',name:'ダイヤ'};playerInv.setItem(6,new ItemStack(currency,64));playerInv.setItem(7,new ItemStack(currency,64));`);
 // 前の入札はダイヤで預けた扱い。新しい入札（いまの通貨）で、前の人にはダイヤ120が返る
 const before=run(`cnt('minecraft:diamond')`);assert.equal(run(`vtBid(player,block,'p1',127)`),true,'starts again at the minimum (lower than the old top)');
 assert.equal(run(`cnt('minecraft:diamond')`)-before,130);
 assert.equal(run(`vtState(registry.stores.s1).auctions.p1.cur.id`),run('currency'));
});
test('no bids after the deadline',()=>{
 setup();run(`registry.stores.s1.vault={deadline:1,auctions:{}}`);assert.equal(run(`vtBid(player,block,'p1',130)`),true);
 run(`registry.stores.s1.vault.auctions.p1.firstAt=Date.now()-120000;`);
 assert.equal(run(`vtBid(player,block,'p1',140)`),false);assert.match(run('msgs.join()'),/締め切りました/);
});
test('cauldron leftovers (empty bucket, bottle) only go to slots that take them',()=>{
 prep();
 for(let i=0;i<81;i++){const ok=run(`crSlotTakes('fletch',${i},'minecraft:bucket')`);assert.equal(ok,run(`flSlotOk(${i},'minecraft:bucket')`));}
 assert.equal(run(`crSlotTakes('fletch',8,'minecraft:glass_bottle')`),false,'hidden slot 8');
 assert.equal(run(`crSlotTakes('fletch',4,'minecraft:bucket')`),false,'arrow slots');
 assert.equal(run(`crSlotTakes('fletch',27,'minecraft:glass_bottle')`),true,'bottle slots');
 assert.equal(run(`crSlotTakes('enchant',46,'minecraft:bucket')`),false,'enchant template books');
 assert.equal(run(`crSlotTakes('crafter',0,'minecraft:bucket')`),true);
});
test('crafting that leaves empty buckets runs (no error) and the buckets go back to storage',()=>{
 prep();const r=JSON.parse(run(`(()=>{CRAFT_RECIPES['minecraft:cake']=CRAFT_RECIPES['minecraft:cake']??[[1,[['i','minecraft:milk_bucket',3],['i','minecraft:sugar',2]]]];
  block.typeId='shopuilook2:panel_crafter';const realKind=fzKindOf;fzKindOf=()=>'crafter';
  const p=base('p1','minecraft:cake');p.stock=[];putProducts([p]);
  const m=Array(81).fill(null);m[0]={id:'minecraft:milk_bucket',n:1};m[1]={id:'minecraft:milk_bucket',n:1};m[2]={id:'minecraft:milk_bucket',n:1};m[3]={id:'minecraft:sugar',n:2};
  for(const id of (CRAFT_RECIPES['minecraft:cake'][0][1]).map(x=>x[1]))if(!m.some(x=>x?.id===id))m[m.findIndex(x=>!x)]={id,n:64};
  registry.stores.s1.crafter={auto:true,mats:m,made:0};let err='';try{crCraft(block)}catch(e){err=e.message}fzKindOf=realKind;
  return JSON.stringify({err,buckets:registry.stores.s1.crafter.mats.filter(x=>x?.id==='minecraft:bucket').reduce((a,x)=>a+x.n,0),stock:loadProduct(block,'p1').stock.length});})()`));
 assert.equal(r.err,'');assert.ok(r.stock>0,'cake made');assert.equal(r.buckets,3,'3 empty buckets back');
});
console.log(n+' debug tests passed (API simulation; no Minecraft runtime)');
// v1.1.824 古い売上の記録（31日より前）は、その日の最初の売上の時に消す
{
 const {run,prep,worldProps}=require('./test_smelt_sales.cjs');prep();
 run('world').getDynamicPropertyIds=()=>[...worldProps.keys()];
 const today=run('shopNow().date');const day=d=>new Date(Date.parse(today+'T00:00:00Z')-d*86400000).toISOString().slice(0,10);
 for(const d of [1,30,31,32,60])worldProps.set(`shop_sales_s1_${day(d)}`,'{}');worldProps.set(`shop_sales_s1_${day(60)}:chunk:A:0`,'x');worldProps.set(`shop_sales_s2_${day(60)}`,'{}');
 const removed=run(`shopSalePruneOld('s1','${today}')`);
 assert.equal(removed,2,'32 and 60 days ago');assert.ok(worldProps.has(`shop_sales_s1_${day(30)}`)&&worldProps.has(`shop_sales_s1_${day(31)}`));
 assert.equal(worldProps.get(`shop_sales_s1_${day(60)}`),undefined);assert.ok(worldProps.has(`shop_sales_s2_${day(60)}`),'other stores untouched');
 console.log('PASS DEBUG old sales days (older than 31 days) are pruned per store');
}
