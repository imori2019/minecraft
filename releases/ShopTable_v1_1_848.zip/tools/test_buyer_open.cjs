// v1.1.826 管理者（店主・OP）以外が開くと購入画面。店主はそのまま開くと店舗管理、スニークで購入画面
const assert=require('node:assert/strict');const {run,prep,ctx,Container}=require('./test_smelt_sales.cjs');
ctx.shopInv=new Container(640);prep();
const want=(who,sneak)=>run(`(()=>{const p=${who};p.isSneaking=${sneak};return !canEditBlock(p,block)||p.isSneaking===true;})()`);
run(`getBlockStoreId=()=>'s1';STORE_RO={rev:-1,reg:undefined};registry.stores.s1.owner={id:player.id,name:player.name};
 globalThis.guest={id:'G1',name:'Guest',isOp:()=>false,commandPermissionLevel:0,getComponent:player.getComponent};globalThis.realOp=isOperator;isOperator=p=>p.id==='OP1';
 globalThis.op={...guest,id:'OP1',name:'Op'};`);
assert.equal(want('guest',false),true,'a customer gets the buyer screen');
assert.equal(want('guest',true),true);
assert.equal(want('player',false),false,'the owner gets the store management screen');
assert.equal(want('player',true),true,'the owner sneaking gets the buyer screen');
assert.equal(want('op',false),false,'an operator can manage');
// 購入画面に入ると、店主用の画面（店舗管理・セール）は出ない
const r=JSON.parse(run(`(()=>{const R={dimensionId:'minecraft:overworld',x:0,y:64,z:0};enterShopMode(guest,R,block,shopInv);return JSON.stringify({shop:!!R.shopMode,price:!!R.priceMode,landing:!!R.landing,store:!!R.storeMode});})()`));
assert.deepEqual(r,{shop:true,price:false,landing:false,store:false});
run(`isOperator=realOp;`);
console.log('PASS BUYER non-managers (and the sneaking owner) open the buyer screen; owners and operators get management');
