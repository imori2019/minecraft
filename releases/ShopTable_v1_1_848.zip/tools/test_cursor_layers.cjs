const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const d=JSON.parse(fs.readFileSync(path.join(__dirname,'../resource_pack/ui/data_driven_container_screen.json')));
const root=d.desktop_panel.controls.find(x=>x['root_panel@common.root_panel'])['root_panel@common.root_panel'];
const cursor=root.controls.find(x=>x['inventory_selected_icon_button@common.inventory_selected_icon_button'])['inventory_selected_icon_button@common.inventory_selected_icon_button'];
assert.deepEqual(cursor,{layer:55000,always_handle_pointer:false,consume_hover_events:false});
let buttons=0,extra=0;function walk(x){if(!x||typeof x!=='object')return;for(const[k,v]of Object.entries(x)){if(k==='inventory_selected_icon_button@common.inventory_selected_icon_button')buttons++;if(k==='shop_carried_foreground'||k==='shop_carried_visual'||k==='shop_cursor_overlay')extra++;walk(v);}}walk(d);assert.equal(buttons,1);assert.equal(extra,0);
assert.equal(cursor.controls,undefined);assert.equal(cursor.bindings,undefined);assert.equal(cursor.offset,undefined);assert.equal(cursor.follows_cursor,undefined);assert.equal(cursor.visible,undefined);assert.equal(cursor.button_mappings,undefined);
console.log('PASS cursor: one complete native item/count control, no detached overlay or hidden visual states, foreground layer with pointer/hover passthrough (structure only)');
