// v1.1.825 デバッグ用のコマンドを消した（残すのはクーポン発行と、くじの直し）。欄に入れられない物は、メッセージなしで手持ちへ戻す
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {run,prep,ctx,Container,playerInv}=require('./test_smelt_sales.cjs');
const src=fs.readFileSync(path.join(__dirname,'../behavior_pack/scripts/main.js'),'utf8');
const ids=[...src.matchAll(/(?:ev|event)\.id [!=]== "(shoptable:[a-z_]+)"/g)].map(m=>m[1]);
assert.deepEqual([...new Set(ids)].sort(),['shoptable:coupon','shoptable:kujireset']);
console.log('PASS NODEBUG only the coupon and kuji-reset commands remain');
for(const [kind,slotIdx,id] of [['fletch',0,'minecraft:dirt'],['enchant',0,'minecraft:dirt'],['note',54,'minecraft:coal'],['cartography',0,'minecraft:compass']]){
 ctx.shopInv=new Container(640);prep();
 const r=JSON.parse(run(`(()=>{globalThis.msgs=[];tell=(p,m)=>msgs.push(m);const sm={storeId:'s1',fzKind:'${kind}',block};crEnter(player,sm,shopInv,registry.stores.s1);
  shopInv.setItem(crSlots('${kind}')[${slotIdx}],new ItemStack('${id}',3));crSync(player,sm,shopInv);
  return JSON.stringify({left:!!shopInv.getItem(crSlots('${kind}')[${slotIdx}]),msgs});})()`));
 assert.equal(r.left,false,kind+': item taken out');assert.deepEqual(r.msgs,[],kind+': no message');
 assert.ok([...playerInv.items.values()].some(i=>i.typeId===id),kind+': back in the inventory');
}
console.log('PASS NODEBUG wrong items go back to the inventory without any message (cauldron, enchant, note, cartography)');
