const assert=require('node:assert/strict'),fs=require('fs'),path=require('path');
const {run,ctx,prep,Container,playerInv,ItemStack,handlers}=require('./test_smelt_sales.cjs');
const read=p=>JSON.parse(fs.readFileSync(path.join(__dirname,'..',p),'utf8'));let count=0;
function test(n,f){f();count++;console.log('PASS POLISH '+n);}
function visit(o,f,p=''){if(Array.isArray(o))o.forEach(v=>visit(v,f,p));else if(o&&typeof o==='object'){f(o,p);for(const[k,v]of Object.entries(o))visit(v,f,p+'/'+k);}}
test('weapons, armor and horse armor never generate smelted variants, while ores and food still do',()=>{
 for(const kind of ['furnace','blast','smoker'])for(const id of ['iron_sword','golden_axe','iron_pickaxe','iron_helmet','golden_chestplate','chainmail_boots','iron_horse_armor','golden_horse_armor'])assert.equal(run(`fzSmeltOutput('minecraft:${id}','${kind}')`),'');
 assert.equal(run("fzSmeltOutput('minecraft:raw_iron','blast')"),'minecraft:iron_ingot');assert.equal(run("fzSmeltOutput('minecraft:porkchop','smoker')"),'minecraft:cooked_porkchop');
 ctx.shopInv=new Container(640);prep();run(`block.typeId='shopuilook2:panel_furnace';mode={player,bakeOn:true,floorId:'d1',history:false};putProducts([base('p1','minecraft:iron_sword'),base('p3','minecraft:beef')]);globalThis.polishModel=shopModel(mode,block,registry.stores.s1)`);
 assert.equal(run("polishModel.records.has('baked:furnace:p1')"),false);assert.equal(run("polishModel.records.has('baked:furnace:p3')"),true);
});
test('27 raw products plus their cooked counterparts page through 9-row windows; stock is shared',()=>{
 ctx.shopInv=new Container(640);prep();run(`block.typeId='shopuilook2:panel_furnace';mode={player,bakeOn:true,floorId:'d1',history:false};registry.stores.s1.furnace={enabled:true,pct:10,burn:64};putProducts(Array.from({length:27},(_,i)=>{const p=base('p'+(i+1));p.settings.shop_product_genre='ジャンル'+i;return p;}));for(const id of loadProductIndex(block))setProductFloor(block,id,'d1');globalThis.polishModel=shopModel(mode,block,registry.stores.s1)`);
 assert.equal(run('polishModel.records.size'),54);assert.equal(run('polishModel.rowWindowCount'),3);assert.equal(run('polishModel.rows.length'),9);assert.ok(run('polishModel.rows.flatMap(r=>r.ids).length')<=27);
 assert.equal(run("shopPurchaseRemaining(polishModel.records.get('baked:furnace:p1'))"),run("shopPurchaseRemaining(polishModel.records.get('p1'))"));
});
test('middle-picked upper halves normalize to usable whole-shop items with amount preserved and cannot be placed separately',()=>{
 playerInv.items.clear();for(const [upper,base]of [['panel_furnace_case','panel_furnace'],['panel_bulb_oxidized_case','panel_bulb_oxidized']]){
 playerInv.setItem(0,new ItemStack('shopuilook2:'+upper,3));assert.equal(run('shopNormalizeCaseItem(player,0)'),true);assert.equal(playerInv.getItem(0).typeId,'shopuilook2:'+base);assert.equal(playerInv.getItem(0).amount,3);
 }
 playerInv.setItem(1,new ItemStack('minecraft:diamond',5));assert.equal(run('shopNormalizeCaseItem(player,1)'),false);assert.equal(playerInv.getItem(1).amount,5);
 const blockHandler=handlers.find(f=>f.toString().includes('shopCaseBaseId(event.itemStack?.typeId)')&&f.toString().includes('event.cancel = true'));
 assert.ok(blockHandler);const event={itemStack:new ItemStack('shopuilook2:panel_furnace_case',1),player:ctx.player};blockHandler(event);assert.equal(event.cancel,true);
 assert.equal(run("shopCaseBaseId('shopuilook2:fake_case')"),'');
});
test('every shop inventory item renders its own upper-half geometry and material, preserving placed-block geometry',()=>{
 const dir=path.join(__dirname,'../behavior_pack/blocks');let n=0;
 for(const file of fs.readdirSync(dir)){
 if(!file.endsWith('_case.json'))continue;const baseFile=path.join(dir,file.replace('_case.json','.json'));if(!fs.existsSync(baseFile))continue;
 const base=JSON.parse(fs.readFileSync(baseFile))['minecraft:block'].components,upper=JSON.parse(fs.readFileSync(path.join(dir,file)))['minecraft:block'].components;
 assert.equal(base['minecraft:item_visual'].geometry,upper['minecraft:geometry']);assert.deepEqual(base['minecraft:item_visual'].material_instances,upper['minecraft:material_instances']);assert.notEqual(base['minecraft:geometry'],upper['minecraft:geometry']);n++;
 }assert.equal(n,fs.readdirSync(dir).filter(f=>f.endsWith('_case.json')&&fs.existsSync(path.join(dir,f.replace('_case.json','.json')))).length);assert.ok(n>=21);
});
test('genre choices use white text and product tooltips render above carried stack numbers',()=>{
 const d=read('resource_pack/ui/data_driven_container_screen.json');let genres=0,factory,carried,flying;
 visit(d,(o,p)=>{if(o.type==='label'&&(p.includes('/genre_popup/')||p.includes('/genre_option_hover_')&&p.includes('/hover_label_'))){assert.deepEqual(o.color,[1,1,1]);genres++;}if(p.endsWith('/selected_item_details_factory@common.selected_item_details_factory'))factory=o;if(p.endsWith('/inventory_selected_icon_button@common.inventory_selected_icon_button'))carried=o;if(p.endsWith('/flying_item_renderer@common.flying_item_renderer'))flying=o;});
 assert.ok(genres>=16);assert.ok(factory.layer>(carried.layer??-10));assert.ok(factory.layer>flying.layer);assert.equal(d['selected_item_details@common.selected_item_details'].layer,50000);
 assert.equal(run('SH_BGM_MUSIC_OPTIONS.volume'),0.5);
});
console.log(count+' shop polish groups passed (API/UI/asset checks; Minecraft rendering not executed)');
