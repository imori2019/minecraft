const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');const{run,prep,ctx,Container}=require('./test_smelt_sales.cjs');const ui=require('./read_price_ui.cjs')();const raw=JSON.parse(fs.readFileSync(path.join(__dirname,'../resource_pack/ui/shop_layout_price.json'),'utf8'));const ctl=x=>Object.assign({},...(x.controls??[]));let n=0;function test(name,f){f();n++;console.log('PASS RESTORE '+name)}
test('the description heads the one product scroll (v771: hidden variants only collapse inside scroll content), and all 27 row pairs remain',()=>{
 const page=ctl(ui.shop_page).shop_vis,parts=ctl(page),stack=parts.sh_catalog_view;assert.equal(stack.type,'stack_panel');assert.ok(!Object.keys(parts).some(k=>/^sh_scroll_mode_[1-4]$/.test(k)));assert.ok(!ui.sh_catalog_content);let productScrolls=0;
 function visit(x){if(!x||typeof x!=='object')return;if(x.$scrolling_content==='shop_layout_price.sh_content')productScrolls++;for(const y of Object.values(x))visit(y)}visit(page);assert.equal(productScrolls,1);assert.equal(ctl(stack).products_view.size[1],'fill');assert.deepEqual(Object.keys(ctl(stack)),['products_view']);
 assert.deepEqual(ui.sh_content.controls.slice(0,4).map(c=>Object.keys(c)[0]),['description_1','description_2','description_3','description_4']);
 for(let r=0;r<27;r++){assert.ok(ctl(ui.sh_content)['sh_row'+r]);assert.ok(ctl(ui.sh_content)['sh_row'+r+'_continuation'])}
});
test('short descriptions have plain labels without scroll controls, while the product viewport keeps its original position',()=>{
 const headers=ctl(ui.sh_content);for(let mode=1;mode<=4;mode++){
  const h=headers['description_'+mode],sep=ctl(h).separator;assert.equal(h.collection_index,78);assert.equal(h.size[1],12*mode+11);assert.equal(60+h.size[1],83+12*(mode-1));assert.equal(194-h.size[1],171-12*(mode-1));assert.equal(60+sep.offset[1],80+12*(mode-1));
  const plain=mode<4?ctl(h)['plain_description@shop_layout_price.sh_desc_scroll_content']:ctl(ctl(h).plain_gate)['plain_description@shop_layout_price.sh_desc_scroll_content'];assert.deepEqual(plain.size,[168,12*mode]);assert.deepEqual(plain.offset,[4,0]);
  const bind=h.bindings.find(b=>b.target_property_name==='#visible');assert.ok(bind.source_property_name.includes("'"+(2+4*(mode-1))+"'"));assert.ok(bind.source_property_name.includes("'"+(3+4*(mode-1))+"'"));assert.ok(h.bindings.some(b=>b.target_property_name==='#ignored'));
 }
});
test('only text exceeding four rows uses the long-description scroll state',()=>{
 prep();run(`globalThis.descState={txt:new Map(),gen:new Map()};globalThis.shortDesc=shopDescriptionLines('毎日お買い得！明日も明後日も！');shopDescriptionSecondLine(shopInv,descState,SH_DESC[1],shortDesc[1],shortDesc[2],shortDesc[3]);`);assert.equal(run('shortDesc[3]'),false);assert.ok([2,3].includes(run('shopInv.getItem(SH_DESC[1]).amount')));
 run(`globalThis.longDesc=shopDescriptionLines('あ'.repeat(100));shopDescriptionSecondLine(shopInv,descState,SH_DESC[1],longDesc[1],longDesc[2],longDesc[3]);`);assert.equal(run('longDesc[3]'),true);assert.ok([18,19].includes(run('shopInv.getItem(SH_DESC[1]).amount')));
 run('shopDescriptionSecondLine(shopInv,descState,SH_DESC[1],shortDesc[1],shortDesc[2],shortDesc[3])');assert.ok([2,3].includes(run('shopInv.getItem(SH_DESC[1]).amount')));
});
test('automatic description height follows 1, 2, 3, 4 and overflow rows, then shrinks again',()=>{
 prep();run('globalThis.autoDesc={txt:new Map(),gen:new Map()}');const area=Object.fromEntries(Object.entries(ctl(ui.sh_content)).filter(([k])=>k.startsWith('description_')));const trace=[];
 for(const lines of [1,2,3,4,5,3,1]){
  run(`const d=shopDescriptionLines('あ'.repeat(${lines}*17));shopDescriptionSecondLine(shopInv,autoDesc,SH_DESC[1],d[1],d[2],d[3]);`);
  const state=run('shopInv.getItem(SH_DESC[1]).amount');const visible=Object.values(area).filter(h=>{const expr=h.bindings.find(b=>b.target_property_name==='#visible').source_property_name;return [...expr.matchAll(/= '(\d+)'/g)].some(m=>Number(m[1])===state)});
  assert.equal(visible.length,1);const height=visible[0].size[1];assert.equal(height,12*Math.min(4,lines)+11);trace.push([lines,60+height,194-height]);
 }
 assert.deepEqual(trace.map(t=>t[1]),[83,95,107,119,119,107,83]);
});
test('ordinary inheritance references resolve without new expression variables or lazy grids',()=>{
 assert.ok(fs.statSync(path.join(__dirname,'../resource_pack/ui/shop_layout_price.json')).size<9_000_000);let refs=0;
 function visit(x){if(!x||typeof x!=='object')return;for(const[k,v]of Object.entries(x)){
  assert.ok(!k.startsWith('$u_'));if(k.includes('@shop_layout_price.shared_buyer_')){refs++;assert.ok(raw[k.split('.')[1]]);assert.ok(Object.keys(v).every(n=>n==='offset'||(n==='ignored'&&v[n]==='$shop_no_heart')));}
  assert.ok(!(k==='grid_item_template'&&String(v).includes('lazy_')));visit(v);
 }}visit(raw);assert.ok(refs>1000);
});
test('all products and prices are published with the v750 slot protocol, including 27 genres',()=>{
 ctx.shopInv=new Container(640);prep();run(`block.typeId='shopuilook2:panel';registry.stores.s1.pricePointSystem=normalizePricePointSystemSettings({});const list=Array.from({length:27},(_,i)=>{const p=base('p'+(100+i),'minecraft:apple');p.settings.shop_product_genre='分類'+i;return p});putProducts(list);globalThis.restored={};enterShopMode(player,restored,block,shopInv)`);assert.equal(run('restored.shopMode.cells.size'),9);
 for(let r=0;r<9;r++){assert.ok(run(`shopInv.getItem(shSlots(${r}).price[0])?.nameTag.length>0`));if(r>0){assert.equal(run(`shopInv.getItem(shSlots(${r}).prev)`),undefined);assert.equal(run(`shopInv.getItem(shSlots(${r}).next)`),undefined)}}
 assert.notEqual(run('shopInv.getItem(shSlots(0).next)'),undefined);assert.equal(run('restored.shopMode.model.rowWindowCount'),3);
});
console.log(n+' buyer restoration groups passed (native rendering and opening latency unmeasured)');
