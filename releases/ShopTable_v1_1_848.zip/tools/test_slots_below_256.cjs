// v1.1.829 ゲームの中ではショップのマスの256番より上が使えなかった。材料庫・画面の欄は全部256番より下にする
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {run}=require('./test_smelt_sales.cjs');const J=s=>JSON.parse(run(`JSON.stringify(${s})`));
const kinds={furnace:J(`fzFuelSlots('furnace')`),blast:J(`[...FZ_FUEL_SLOTS,...BLAST_MAT_SLOTS]`),smoker:J(`[...FZ_FUEL_SLOTS,...FZ_FEED_SLOTS,...FZ_PEN_SLOTS]`),
 barrel:J('BL_ALL_SLOTS'),composter:J('[...CP_GROW_SLOTS,...CP_MAT_SLOTS]'),spawner:J('SP_PEN_SLOTS')};
for(const k of ['crafter','smith','fletch','note','endframe','cartography','enchant'])kinds[k]=J(`crSlots('${k}')`);
const signals=new Set(J(`[...FZ_TEXT_SLOTS,FZ_KIND_SIG,FZ_CAPTURE,FZ_TOGGLE,FZ_KP_HEADER,...KP_KEY_SLOTS,...KP_GENERIC_DIGIT_SLOTS,SALE_LAYOUT_SLOT,...SH_REAL_SLOTS]`));
for(const [k,sl] of Object.entries(kinds)){
 assert.ok(sl.every(i=>i<256),k+' has a slot at 256 or above');
 assert.equal(new Set(sl).size,sl.length,k+' slots repeat');
 const clash=sl.filter(i=>signals.has(i));assert.deepEqual(clash,[],k+' storage overlaps a button/signal slot');
}
const ui=fs.readFileSync(path.join(__dirname,'../resource_pack/ui/shop_proceeds_screen.json'),'utf8');
assert.deepEqual([...ui.matchAll(/"collection_index":(\d+)/g)].map(m=>+m[1]).filter(i=>i>=256),[],'storage screen UI uses no slot >= 256');
console.log('PASS SLOTS<256 every storage slot of every shop type is below 256, unique, and clear of button/signal slots');
