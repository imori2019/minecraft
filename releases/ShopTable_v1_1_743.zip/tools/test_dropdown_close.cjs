const assert=require('node:assert/strict');const{run,prep,ctx,ItemStack}=require('./test_smelt_sales.cjs');let n=0;
const plain=x=>JSON.parse(JSON.stringify(x));function test(name,f){f();n++;console.log('PASS CLOSE '+name);}
function finish(){run(`for(let i=0;i<10&&dropRec.pendingVisual;i++){const fn=dropRec.pendingVisual.apply;dropRec.pendingVisual=null;system.currentTick+=10;fn(block,shopInv);}`);}
function reset(method=0){prep();run(`block.typeId='shopuilook2:panel';props.set(LAYOUT_MIGRATION_PROP,1);FZ_PRODUCT_EDITS.clear();active.clear();globalThis.dropRec=makeRecord(player,block,shopInv);dropRec.landing=true;active.set(player.id,dropRec);enterProduct(player,dropRec,block,shopInv,'p1');`);finish();run(`setNumberProp(block,'shop_payment_method',${method});setStringProp(block,'price','125');setStringProp(block,'required_item','minecraft:diamond');setStringProp(block,'required_item_count','2');setStringProp(block,'payment_custom_point_name','冒険ポイント');setStringProp(block,'payment_custom_points','12');
 for(const def of DROPDOWNS)if(isDropdownRuntimeActive(block,def))writeDropdownState(shopInv,def,false,getDropdownChoice(block,def));armSharedChoices(shopInv);armActions(shopInv,block);syncPaymentItemControls(shopInv,block);repairSettingsTextPayloads(block,shopInv);setProbe(shopInv,TEXT_GATE_SLOT,2);system.currentTick+=20;`);}
test('actual outside-close handler keeps each payment method open until text and icon payloads are ready',()=>{
 for(const method of [0,1,2,3]){
 reset(method);run(`shopInv.setItem(42,undefined);tickSession(player,dropRec,block,shopInv)`);finish();assert.equal(run('dropRec.openDropdown'),'payment_method');
 const expected=plain(run(`TEXT_CHANNELS.filter(c=>c.group===3).map(c=>[c.slot,channelText(block,c,new Set(textFieldsForGroup(block,3)))])`));
 // Client-visible stale unnamed payloads are modeled without removing the click-signal counts.
 run(`for(const c of TEXT_CHANNELS.filter(c=>c.group===3)){const it=shopInv.getItem(c.slot);if(it)shopInv.setItem(c.slot,new ItemStack(PROBE_ID,it.amount));}shopInv.setItem(42,undefined);tickSession(player,dropRec,block,shopInv)`);
 assert.equal(run('dropRec.openDropdown'),'payment_method','outside close must not reveal the branch immediately');assert.ok(run('dropRec.pendingVisual'));assert.equal(run('shopInv.getItem(42).amount'),run('OPEN_AMOUNT'));
 for(const[slot,text]of expected)assert.equal(run(`shopInv.getItem(${slot}).nameTag`),text||'未入力','every payload precedes the visibility change');
 finish();assert.equal(run('dropRec.openDropdown'),null);assert.equal(run("getChoiceById(block,'payment_method')"),method);assert.equal(run('shopInv.getItem(42).amount'),run(`CLOSED_BASE_AMOUNT+${method}`));
 for(const[slot,text]of expected)assert.equal(run(`shopInv.getItem(${slot}).nameTag`),text||'未入力');
 }
});
test('genre outside/header close republishes the caption and changes its cached-label generation',()=>{
 for(const signal of ['GENRE_OUTSIDE_SLOT','GENRE_HEADER_SLOT']){
 reset();run(`setStringProp(block,'shop_product_genre','探検家の地図');armGenreDropdown(player,dropRec,block,shopInv);dropRec.genreOpen=true;writeGenreDropdown(player,dropRec,block,shopInv);globalThis.capBefore=dropRec.genreCapGen??0;shopInv.setItem(10,new ItemStack(PROBE_ID,1));shopInv.setItem(${signal},undefined);handleGenreDropdown(player,dropRec,block,shopInv)`);
 assert.equal(run('dropRec.genreOpen'),true);assert.equal(run('shopInv.getItem(10).nameTag'),'探検家の地図');assert.equal(run('shopInv.getItem(GENRE_HEADER_SLOT).nameTag'),'探検家の地図');finish();assert.equal(run('dropRec.genreOpen'),false);assert.notEqual(run('dropRec.genreCapGen'),run('capBefore'));assert.equal(run("getStringProp(block,'shop_product_genre','')"),'探検家の地図');
 }
});
test('empty genre and message headers always have explicit placeholders rather than internal item names',()=>{
 reset();run(`setStringProp(block,'shop_product_genre','');setStringProp(block,'buyer_message','');shopInv.setItem(10,undefined);shopInv.setItem(49,undefined);armGenreDropdown(player,dropRec,block,shopInv);armMessageDropdown(player,dropRec,block,shopInv)`);
 for(const s of ['GENRE_HEADER_SLOT','MESSAGE_HEADER_SLOT',10,49])assert.equal(run(`shopInv.getItem(${s}).nameTag`),'なし');
 run(`dropRec.messageOpen=true;writeMessageDropdown(player,dropRec,block,shopInv);shopInv.setItem(MESSAGE_OUTSIDE_SLOT,undefined);handleMessageDropdown(player,dropRec,block,shopInv)`);assert.equal(run('dropRec.messageOpen'),true);finish();assert.equal(run('dropRec.messageOpen'),false);assert.equal(run('shopInv.getItem(49).nameTag'),'なし');
});
test('weekday outside-close restores shared payment payloads before showing the closed state',()=>{
 reset(2);run(`dropRec.weekdayOpen=true;dropRec.weekdaySeedDueTick=-1;armWeekdaySignals(shopInv);writeWeekdayState(shopInv,true);settleSettingsPopupClose(player,dropRec,block,shopInv,'weekday')`);assert.equal(run('dropRec.weekdayOpen'),true);finish();assert.equal(run('dropRec.weekdayOpen'),false);assert.equal(run('shopInv.getItem(33).nameTag'),run(`channelText(block,TEXT_CHANNELS.find(c=>c.slot===33),new Set(textFieldsForGroup(block,3)))`));
});
test('payload repair never overwrites real items and does not modify saved settings',()=>{
 reset();run(`globalThis.settingsBefore=JSON.stringify([...props]);shopInv.setItem(34,new ItemStack('minecraft:diamond',7));repairSettingsTextPayloads(block,shopInv)`);assert.equal(run('shopInv.getItem(34).typeId'),'minecraft:diamond');assert.equal(run('shopInv.getItem(34).amount'),7);assert.equal(run('JSON.stringify([...props])'),run('settingsBefore'));
});
console.log(n+' popup-close tests passed (actual API handlers; client rendering not executed)');
