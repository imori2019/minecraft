@echo off
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Download-WikiIcons.ps1"
echo.
pause
