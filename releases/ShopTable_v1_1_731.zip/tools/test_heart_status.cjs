const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
require('./test_heart_shop.cjs');
const env=require('./test_smelt_sales.cjs'),{run,prep,ctx,shopInv,playerInv}=env;
const source=fs.readFileSync(path.join(__dirname,'../behavior_pack/scripts/main.js'),'utf8');
const p=source.indexOf('function shopCanSellNow('),end=source.indexOf('\nfunction ',p+1);run(source.slice(p,end));
let count=0;const plain=x=>JSON.parse(JSON.stringify(x));function test(n,f){f();count++;console.log('PASS HEART STATUS '+n);}
function reset(){prep();run(`active.clear();playerInv.items.clear();shopInv.items.clear();heartEffects={};heartProps.clear();hp=20;gaugeMax=20;failEffect=false;
 block.typeId='shopuilook2:panel_heart';registry.stores.s1.openToCustomers=true;delete registry.stores.s1.manualOpen;registry.stores.s1.hours='00:00～23:59';registry.stores.s1.hoursTimeMode='real';registry.stores.s1.weekdays=127;
 const r=base('p1','minecraft:porkchop');r.settings={shop_heart_product:true,shop_heart_type:5,heart_level:'1',heart_duration:'30',shop_product_name:'生の豚肉'};putProducts([r]);
 globalThis.srec={};system.currentTick+=30;globalThis.repairStatus=()=>{const st=lxStoreOf(block);putNamedSignal(shopInv,LX.status,lxStatusSignalAmount(st),LX_STATUS_CLICK_TAG);setProbe(shopInv,LX.statusDisplay,lxStatusSignalAmount(st));};
 lastStoreStatusProbeArrivalTick.clear();repairStatus();`);}
test('a missing business-status probe does not close the store, even with a generic purchase probe arrival',()=>{
 reset();assert.equal(run(`shopCanSellNow(registry.stores.s1)`),true);
 run(`shopInv.setItem(LX.status,undefined);noteProbeArrival(player,new ItemStack(PROBE_ID,1));globalThis.result=lxHandleStatusClick(player,srec,block,shopInv);`);
 assert.equal(ctx.result,'repaired');assert.equal(run(`registry.stores.s1.manualOpen`),undefined);
 assert.equal(run(`shopInv.getItem(LX.status).nameTag`),run(`LX_STATUS_CLICK_TAG`));
 run(`system.currentTick+=13;lxHandleStatusClick(player,srec,block,shopInv)`);assert.equal(run(`shopCanSellNow(registry.stores.s1)`),true);
});
test('only the tagged status button can toggle the store, including delayed delivery after repairing its slot',()=>{
 reset();run(`shopInv.setItem(LX.status,undefined);lxHandleStatusClick(player,srec,block,shopInv);system.currentTick+=2;const it=new ItemStack(PROBE_ID,2);it.nameTag=LX_STATUS_CLICK_TAG;noteProbeArrival(player,it);globalThis.result=lxHandleStatusClick(player,srec,block,shopInv);`);
 assert.equal(ctx.result,'changed');assert.equal(run(`registry.stores.s1.manualOpen`),false);
 run(`lxHandleStatusClick(player,srec,block,shopInv)`);assert.equal(run(`registry.stores.s1.manualOpen`),false,'arrival is consumed once');
 run(`system.currentTick++;const it=shopInv.getItem(LX.status);shopInv.setItem(LX.status,undefined);noteProbeArrival(player,it);lxHandleStatusClick(player,srec,block,shopInv)`);assert.equal(run(`shopCanSellNow(registry.stores.s1)`),true);
});
test('foreign items and expired status-button arrivals are never interpreted as status changes',()=>{
 reset();run(`shopInv.setItem(LX.status,new ItemStack('minecraft:diamond',2));lxHandleStatusClick(player,srec,block,shopInv)`);
 assert.equal(run(`registry.stores.s1.manualOpen`),undefined);assert.equal([...playerInv.items.values()].filter(x=>x.typeId==='minecraft:diamond').reduce((n,x)=>n+x.amount,0),2);
 reset();run(`const it=shopInv.getItem(LX.status);noteProbeArrival(player,it);system.currentTick+=20;shopInv.setItem(LX.status,undefined);lxHandleStatusClick(player,srec,block,shopInv);system.currentTick+=13;lxHandleStatusClick(player,srec,block,shopInv)`);assert.equal(run(`registry.stores.s1.manualOpen`),undefined);
});
test('a heart purchase and a floor-picker toggle preserve the independent buyer business-status signal',()=>{
 reset();run(`enterShopMode(player,srec,block,shopInv);globalThis.sm=srec.shopMode;globalThis.statusBefore=shopInv.getItem(SH_STORE_INFO).amount;sm.listOpen=true;writeShopUI(shopInv,srec,block);`);
 assert.equal(run(`shopInv.getItem(SH_STORE_INFO).amount`),ctx.statusBefore);assert.equal(run(`shopInv.getItem(SH_FL_STATE).amount`),3);
 run(`sm.listOpen=false;globalThis.purchase=shopPurchaseCommit(player,block,'p1',5);writeShopUI(shopInv,srec,block)`);
 assert.equal(ctx.purchase.ok,true,ctx.purchase.message);assert.equal(run(`heartEffects.blindness.duration`),150*20);
 assert.equal(run(`registry.stores.s1.manualOpen`),undefined);assert.equal(run(`shopCanSellNow(registry.stores.s1)`),true);
 assert.ok([2,3].includes(run(`shopInv.getItem(SH_STORE_INFO).amount`)));
 assert.equal(run(`JSON.parse(player.getDynamicProperty(HEART_LEDGER_PROP)).blindness.amp`),0);
});
test('the buyer lamp repairs delayed item counts and missing signals without changing sales settings',()=>{
 reset();run(`enterShopMode(player,srec,block,shopInv);globalThis.sm=srec.shopMode;globalThis.info=shopInv.getItem(SH_STORE_INFO).nameTag;setProbe(shopInv,SH_STORE_INFO,5);shopSyncStoreStatus(shopInv,sm)`);
 assert.ok([2,3].includes(run(`shopInv.getItem(SH_STORE_INFO).amount`)));assert.equal(run(`shopInv.getItem(SH_STORE_INFO).nameTag`),ctx.info);
 run(`shopInv.setItem(SH_STORE_INFO,undefined);shopSyncStoreStatus(shopInv,sm)`);assert.ok([2,3].includes(run(`shopInv.getItem(SH_STORE_INFO).amount`)));
 run(`registry.stores.s1.manualOpen=false;writeShopUI(shopInv,srec,block)`);assert.ok([4,5].includes(run(`shopInv.getItem(SH_STORE_INFO).amount`)));
 assert.equal(run(`shopInv.getItem(SH_STORE_INFO).nameTag.startsWith('休業中')`),true);assert.equal(run(`registry.stores.s1.manualOpen`),false);
});
test('all three owner status handlers repair a missing probe without toggling the store',()=>{
 for(const mode of ['landing','price','money']){
  reset();run(`shopInv.setItem(LX.status,undefined);`);
  if(mode==='landing')run(`srec.lxReadyTick=0;tickLandingExtras(player,srec,block,shopInv)`);
  if(mode==='price')run(`setProbe(shopInv,LP.pricePoints,TEXT_GATE_SHOWN);setProbe(shopInv,LX.btnCard,1);tickPriceMode(player,srec,block,shopInv)`);
  if(mode==='money')run(`srec.proceedsMode={btnReadyTick:0};screenLandingButtons(player,srec,block,shopInv,'money')`);
  assert.equal(run(`registry.stores.s1.manualOpen`),undefined,mode);assert.equal(run(`shopInv.getItem(LX.status).nameTag`),run(`LX_STATUS_CLICK_TAG`),mode);
 }
});
test('the status guard never touches buyer receipt items in the shared owner-control slot',()=>{
 reset();run(`enterShopMode(player,srec,block,shopInv);shopInv.setItem(LX.status,new ItemStack('minecraft:porkchop',5));globalThis.result=lxHandleStatusClick(player,srec,block,shopInv)`);
 assert.equal(ctx.result,false);assert.equal(run(`shopInv.getItem(LX.status).typeId`),'minecraft:porkchop');assert.equal(run(`shopInv.getItem(LX.status).amount`),5);
});
test('the actual UI business lamps use slot 67 and their clickless tooltip, independently of the floor dropdown',()=>{
 const ui=JSON.parse(fs.readFileSync(path.join(__dirname,'../resource_pack/ui/shop_layout_price.json'),'utf8'));let lamps=0;
 function visit(x,p=''){if(!x||typeof x!=='object')return;if(x.collection_index!==undefined&&/sh_status_(open|closed)_readonly/.test(p)){assert.equal(x.collection_index,67);lamps++;}for(const[k,v]of Object.entries(x))visit(v,p+'/'+k);}
 visit(ui.shop_page);assert.equal(lamps,2);assert.deepEqual(ui['sh_status_hover_only@common.container_slot_button_prototype'].button_mappings,[]);
});
console.log(count+' heart status test groups passed (API/UI simulation; no Minecraft rendering)');
