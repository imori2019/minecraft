const assert=require('node:assert/strict'),fs=require('fs'),path=require('path');
const d=JSON.parse(fs.readFileSync(path.join(__dirname,'../resource_pack/ui/data_driven_container_screen.json'),'utf8'));
const ctl=n=>Object.fromEntries(n.controls.flatMap(e=>Object.entries(e)));
const desktop=ctl(d.desktop_panel),root=ctl(desktop['root_panel@common.root_panel']);
assert.equal(desktop.shop_cursor_overlay,undefined);assert.equal(d.shop_carried_visual,undefined);
const cursor=root['inventory_selected_icon_button@common.inventory_selected_icon_button'];assert.equal(cursor.layer,undefined,'native button hit layer is unchanged');assert.equal(cursor.controls.length,5);for(const c of cursor.controls.slice(0,3)){const v=Object.values(c)[0];assert.equal(v.layer,undefined);assert.deepEqual(v.controls[0],{'selected_item_icon@common.inventory_selected_icon':{layer:55000}});assert.deepEqual(v.controls[1],{'selected_stack_size_text@common.inventory_selected_stack_size_text':{layer:55001}});}
assert.deepEqual(root['gamepad_cursor@common.gamepad_cursor_button'],{});
assert.deepEqual(root['flying_item_renderer@common.flying_item_renderer'],{layer:54900});
let buttons=0;function walk(o){if(!o||typeof o!=='object')return;for(const[k,v]of Object.entries(o)){if(k==='inventory_selected_icon_button@common.inventory_selected_icon_button')buttons++;walk(v);}}walk(d);assert.equal(buttons,1);
console.log('PASS cursor controls keep native pointer controls and raise only draw layers (structure only; native pointer routing not executed)');
