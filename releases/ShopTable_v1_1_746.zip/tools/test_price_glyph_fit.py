from pathlib import Path
from PIL import Image
import json,re
r=Path(__file__).resolve().parents[1]
u=json.loads((r/'resource_pack/ui/shop_layout_price.json').read_text())
s=(r/'behavior_pack/scripts/main.js').read_text();m=json.loads(re.search(r'const SHOP_GLYPHS = (.*?);',s).group(1))
# Gold and iron fill their complete 32px font cell; emerald does not.
widths={}
for item in ['emerald','gold_ingot','iron_ingot','diamond']:
 cp=ord(m['minecraft:'+item]);im=Image.open(r/f'resource_pack/font/glyph_{cp>>8:02X}.png').convert('RGBA');z=im.width//16;i=cp&255;b=im.crop((i%16*z,i//16*z,(i%16+1)*z,(i//16+1)*z)).getbbox();assert b
 widths[item]=b[2]-b[0]
assert widths['gold_ingot']*.375>11 and widths['iron_ingot']*.375>11
n=0
# Include one pixel of glyph advance beyond a full cell when checking the canvas.
def walk(o,p=''):
 global n
 if isinstance(o,dict):
  if o.get('type')=='label' and p.endswith('/t') and any('/'+k+'/' in p for k in ['ibox','currency_box']):
   assert o['size'][0]>=(32+1)*o['font_scale_factor'],p
   assert o['font_type']=='classic';assert o['offset'][0]<0;n+=1
  for k,v in o.items():walk(v,p+'/'+k)
 elif isinstance(o,list):
  for v in o:walk(v,p)
walk(u);assert n>1000
print(f'PASS {n} primary/secondary currency glyph labels fit full-width gold/iron glyphs without narrowing the numeric column (asset/layout check; no native rendering)')
