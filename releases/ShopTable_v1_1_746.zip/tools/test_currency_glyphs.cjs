const assert=require('node:assert/strict');const fs=require('node:fs'),path=require('node:path');
const env=require('./test_smelt_sales.cjs');const {run}=env;let count=0;
function test(name,fn){fn();count++;console.log('PASS CURRENCY '+name);}
const addedRows=run('SH_ROWS')-5,addedRecommendations=run('RP_B.reduce((n,g)=>n+g.cells.length,0)')-8;
const expectedPriceLabels=208+addedRows*16+addedRecommendations*4;
const expectedIconHolders=264+addedRows*24+addedRecommendations*4;
const reg=JSON.parse(fs.readFileSync(path.join(__dirname,'currency_glyph_registry.json'),'utf8'));
const priceUI=JSON.parse(fs.readFileSync(path.join(__dirname,'../resource_pack/ui/shop_layout_price.json'),'utf8'));
function walk(node,fn){if(!node||typeof node!=='object')return;fn(node);for(const v of Object.values(node))walk(v,fn);}
function priceValue(row){const direct=row.controls.find(x=>x.t2);return direct?direct.t2:row.controls.find(x=>x.number_column).number_column.controls.find(x=>x.t2).t2;}
function subtract(expr,vars){const tokens=expr.match(/'[^']*'|#[A-Za-z0-9_]+/g)||[];const value=t=>t.startsWith("'")?t.slice(1,-1):(vars[t]??'');let result=value(tokens[0]??"''");for(const t of tokens.slice(1))result=result.split(value(t)).join('');return result;}
function update(label,payload,vars,visibleChanged){
 for(const b of label.bindings??[]){
  const active=['always','always_when_visible'].includes(b.binding_condition)||b.binding_condition==='visibility_changed'&&visibleChanged;
  if(!active)continue;
  if(b.binding_type==='collection'&&b.binding_name==='#hover_text')vars[b.binding_name_override]=payload;
  if(b.binding_type==='view'&&b.target_property_name!=='#visible'&&b.source_property_name?.includes(' - '))vars[b.target_property_name]=subtract(b.source_property_name,vars);
 }
}
test('new normal currency glyphs and icon references resolve for eggs, dyes, maps and the upgrade template',()=>{
 for(const id of ['minecraft:cow_spawn_egg','minecraft:white_dye','minecraft:red_dye','minecraft:empty_map','minecraft:filled_map','minecraft:netherite_upgrade_smithing_template','minecraft:command_block_minecart']){
  assert.ok(run(`SHOP_GLYPHS[${JSON.stringify(id)}]`),id);assert.notEqual(run(`itemIconPath(${JSON.stringify(id)})`),run(`SHOP_ICON_UNKNOWN`),id);
 }
 for(const id of reg.excluded_blocks)assert.equal(run(`SHOP_GLYPHS[${JSON.stringify(id)}]`),undefined,id+' block glyph removed');
 for(const id of Object.keys(reg.additions))assert.equal(run(`SHOP_GLYPHS[${JSON.stringify(id)}].codePointAt(0)`),parseInt(reg.additions[id].codepoint,16),id);
});
test('new ED glyphs retain small tooltip and block-price forms while normal-only overflow keeps the existing name fallback',()=>{
 const id=Object.keys(reg.additions).find(k=>reg.additions[k].codepoint.startsWith('ED'));assert.ok(id);
 const cp=parseInt(reg.additions[id].codepoint,16);assert.equal(run(`tipSmallGlyph(SHOP_GLYPHS[${JSON.stringify(id)}]).codePointAt(0)`),0xEF00+cp-0xED00);
 // Force block classification only for this shape variant, then restore it.
 const b=run(`SHOP_PRICE_BLOCK_CACHE.get(${JSON.stringify(id)})`);run(`SHOP_PRICE_BLOCK_CACHE.set(${JSON.stringify(id)},true)`);
 const out=run(`shopPriceSizedGlyphText({k:'item',id:${JSON.stringify(id)},n:12,n2:12},true,'light')`);assert.equal(out.codePointAt(0),0xEE00+cp-0xED00);
 run(`SHOP_PRICE_BLOCK_CACHE.${b===undefined?'delete':'set'}(${JSON.stringify(id)}${b===undefined?'':','+b})`);
});
test('visible buyer prices react when slot text arrives after the initial visibility event or changes while open',()=>{
 const labels=[];
 for(const key of ['sh_content','sh_rp_content'])walk(priceUI[key],node=>{
  if(node.controls?.some(x=>x.heart_price_native)){const row=node.controls.find(x=>x.prow).prow;labels.push(priceValue(row));}
 });
 assert.equal(labels.length,expectedPriceLabels,'cover both buyer lists and every primary width/point variant');
 const entries=[{k:'item',id:'minecraft:emerald',n:123,n2:123},{k:'item',id:'minecraft:white_dye',n:2500,n2:2000},{k:'pt',id:'minecraft:gold_ingot',n:60,n2:60}];
 for(const label of labels){
  const state={};update(label,'',state,true);
  for(const entry of entries){
   const raw=run(`shopPriceSizedGlyphText(${JSON.stringify(entry)},true,'light')`);update(label,raw,state,false);
   // The text must be refreshed without the card being hidden/reopened.
   assert.ok(state['#text']?.length,'numeric label is no longer frozen empty');
   assert.ok([...state['#text']].some(ch=>ch.codePointAt(0)>=0xF700&&ch.codePointAt(0)<=0xF7FF),'price digits survive icon extraction');
  }
 }
});
test('all three buyer columns use direct labels for every price variant, with matching price-slot references',()=>{
 const root=priceUI.sh_content;let cells=0;
 for(const rowControl of root.controls){
  const rowName=Object.keys(rowControl)[0];if(!/^sh_row[0-9]+(?:_continuation)?$/.test(rowName))continue;
  const row=rowControl[rowName];
  for(const cellControl of row.controls){
   const name=Object.keys(cellControl)[0];const m=/^pbox_(\d+)_(\d+)$/.exec(name);if(!m)continue;
   const r=Number(m[1]),c=Number(m[2]);if(c>=3)continue;cells++;
   const slot=run(`shSlots(${r}).price[${c}]`);const second=run(`[shSlots(${r}).price[3],shSlots(${r}).cell[3],shSlots(${r}).set[3]][${c}]`);let variants=0;
   walk(cellControl[name],node=>{
    if(node.type!=='stack_panel'||!node.controls?.some(x=>x.t2))return;
    const label=node.controls.find(x=>x.t2).t2;assert.equal(label.type,'label',name+' must not use an auto-sized wrapper');assert.ok([slot,second].includes(label.collection_index),name+' primary/secondary price slot');
    if(label.collection_index===slot){
     const readers=label.bindings.filter(b=>b.binding_type==='collection'&&b.binding_name==='#hover_text');
     assert.equal(readers.length,1,name+' reads the price once, as the working third column does');
     assert.equal(label.bindings.some(b=>b.target_property_name==='#visible'),false,name+' has no extra rule that hides ordinary digits');
    }
    if(label.collection_index===slot)for(const n of [1,5,10,125,9999]){
     const raw=run(`shopPriceSizedGlyphText({k:'item',id:'minecraft:emerald',n:${n},n2:${n}},true,'light')`);const state={};update(label,'',state,true);update(label,raw,state,false);assert.ok(state['#text']?.length,name+'/'+n);
    }
    variants++;
   });assert.ok(variants>=4,name);
  }
 }
 assert.equal(cells,run(`SH_ROWS`)*6,'all three columns checked in every heading and continuation row');
});
test('heart labels share one payload read and ordinary labels cannot render a duplicate ASCII duration',()=>{
 let count=0;
 for(const key of ['sh_content','sh_rp_content'])walk(priceUI[key],node=>{
  if(!node.controls?.some(x=>x.heart_price_native))return;
  const normal=priceValue(node.controls.find(x=>x.prow).prow);
  const native=node.controls.find(x=>x.heart_price_native).heart_price_native;
  const readers=native.bindings.filter(b=>b.binding_type==='collection'&&b.binding_name==='#hover_text');assert.equal(readers.length,1);assert.equal(readers[0].binding_condition,'always');
  const raw=run(`HEART_PAY['shopuilook2:pay_blindness'].glyph`)+"1:30";const a={},b={};update(normal,raw,a,true);update(native,raw,b,true);
  assert.equal(a['#text'],'');assert.equal(b['#text'],'1:30');count++;
 });assert.equal(count,expectedPriceLabels);
});
test('heart text glyphs are suppressed where native effect images now render',()=>{
 const icons=[];let readers=0;
 function visit(node,p=''){
  if(!node||typeof node!=='object')return;
  if(p.includes('/ibox/')&&/\/(t|tp)$/.test(p)&&node.type==='label'){
   const raw=node.bindings.filter(b=>b.binding_type==='collection'&&b.binding_name==='#hover_text');assert.equal(raw.length,1);assert.equal(raw[0].binding_condition,'always');readers++;
   if(p.endsWith('/t'))icons.push(node);
  }
  for(const[k,v]of Object.entries(node))visit(v,p+'/'+k);
 }
 for(const root of ['sh_content','sh_rp_content'])visit(priceUI[root]);
 assert.equal(readers,expectedIconHolders*2);assert.equal(icons.length,expectedIconHolders);
 for(let type=0;type<12;type++){
  const raw=run(`shopPriceSizedGlyphText(heartPayEntry({shop_heart_product:true,shop_heart_type:${type},heart_level:'1',heart_duration:'30'}),true,'light')`);
  const glyph=run(`HEART_PAY[HEART_TYPES[${type}]].glyph`);
  for(const icon of icons){
   assert.equal(icon.font_type,'classic');assert.equal(icon.property_bag['#font_type'],'classic');
   const state={};update(icon,'',state,true);update(icon,raw,state,false);assert.equal(state['#text'],'','heart icons must use native images, never a missing font glyph');
   update(icon,'',state,false);update(icon,raw,state,false);assert.equal(state['#text'],'','cursor changes must not reintroduce the text glyph');
  }
 }
});
test('all expanded price icon holders provide all twelve native effect images from their own price slots',()=>{
 const native=priceUI.sh_heart_price_marks;assert.equal(native.collection_name,'container_items');assert.equal(native.controls.length,12);let holders=0;
 const payIds=JSON.parse(JSON.stringify(run(`HEART_TYPES`)));
 for(const id of payIds){
  const kind=id.split(':pay_')[1],key='sh_heart_price_mark_'+kind,node=priceUI[key];
  assert.equal(node.type,'image');assert.equal(node.texture,run(`HEART_ICON_TEXTURES[${JSON.stringify(id)}]`));assert.equal(node.collection_index,'$heart_icon_slot');assert.equal(node.bilinear,false);
  assert.ok(fs.existsSync(path.join(__dirname,'../resource_pack',node.texture+'.png')));
  const reader=node.bindings.find(b=>b.binding_type==='collection'),view=node.bindings.find(b=>b.target_property_name==='#visible');assert.equal(reader.binding_condition,'always');assert.equal(view.binding_condition,'always');
  const glyph=run(`HEART_PAY[${JSON.stringify(id)}].glyph`),variable=reader.binding_name_override;
  assert.equal(view.source_property_name,`(not (${variable} = (${variable} - '${glyph}')))`);
  const raw=run(`shopPriceSizedGlyphText(heartPayEntry({shop_heart_product:true,shop_heart_type:${payIds.indexOf(id)},heart_level:'1',heart_duration:'30'}),true,'light')`);
  assert.notEqual(raw,subtract(`(${variable} - '${glyph}')`,{[variable]:raw}));assert.equal('',subtract(`(${variable} - '${glyph}')`,{[variable]:''}));
 }
 function visit(node,p=''){if(!node||typeof node!=='object')return;for(const[k,v]of Object.entries(node)){
  if(p.endsWith('/ibox')&&k==='controls'){
   const original=node.controls.find(x=>x.t).t,mark=node.controls.find(x=>x['heart_marks@shop_layout_price.sh_heart_price_marks'])?.['heart_marks@shop_layout_price.sh_heart_price_marks'];
   assert.ok(mark);assert.equal(mark.$heart_icon_slot,original.collection_index);assert.equal(mark.size[0],mark.size[1]);assert.equal(mark.size[0],node.size[0]);holders++;
  }
  visit(v,p+'/'+k);
 }}
 for(const key of ['sh_content','sh_rp_content'])visit(priceUI[key]);assert.equal(holders,expectedIconHolders);
});
console.log(count+' currency glyph/price UI tests passed (API and binding simulation; not Minecraft rendering)');
