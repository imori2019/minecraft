// v1.1.763 材料庫の拡張：左の持ち物の欄（y136〜）に重ならない・欄の数・前のデータの引き継ぎ
const assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path');
const env=require('./test_smelt_sales.cjs');
const {run}=env;
let n=0;const test=(name,fn)=>{fn();n++;console.log('PASS STORAGE '+name);};
const ui=JSON.parse(fs.readFileSync(path.join(__dirname,'../resource_pack/ui/shop_proceeds_screen.json'),'utf8'));
function find(o,key){if(o&&typeof o==='object'){for(const [k,v] of Object.entries(o)){if(k.split('@')[0]===key)return v;const r=find(v,key);if(r!==undefined)return r;}}}
const idx=v=>Number((JSON.stringify(v).match(/"collection_index":(\d+)/)||[])[1]);
function slots(pen){return find(ui,pen).controls.map(x=>Object.values(x)[0]).filter(v=>JSON.stringify(v.size)==='[18,18]');}
test('no owner-screen part of the expanded pens sits over the player inventory (left side below 130)',()=>{
 for(const pen of ['crafter_pen','endframe_pen','cartography_pen','note_pen','fletch_pen','smith_pen','composter_pen','barrel_pen','enchant_pen']){
  for(const x of find(ui,pen).controls){const [k,v]=Object.entries(x)[0];const o=v.offset,s=v.size;
   if(!o||!Array.isArray(s)||typeof s[1]!=='number'||/keypad/.test(k))continue;
   if(o[0]<180)assert.ok(o[1]+s[1]<=130,pen+' '+k);
   if(JSON.stringify(s)==='[18,18]')assert.ok(o[1]+18<=252&&o[0]+18<=358,pen+' '+k);}
 }
});
test('slot counts on screen match the storage size in the script',()=>{
 const want={crafter_pen:'CR_WIDE_SLOTS',endframe_pen:'CR_WIDE_SLOTS',cartography_pen:'CR_WIDE_SLOTS',note_pen:'CR_WIDE_SLOTS',fletch_pen:'CR_WIDE_SLOTS',smith_pen:'SM_MAT_SLOTS'};
 for(const [pen,c] of Object.entries(want)){const s=new Set(slots(pen).map(idx));JSON.parse(run(`JSON.stringify(${c})`)).forEach((i,n)=>{if(pen==='fletch_pen'&&n>=4&&n<9)return;/* v795: cauldron slots 4-8 unused */assert.ok(s.has(i),pen+' missing '+i);});}
 const cp=new Set(slots('composter_pen').map(idx));for(const i of JSON.parse(run(`JSON.stringify([...CP_GROW_SLOTS,...CP_MAT_SLOTS])`)))assert.ok(cp.has(i),'composter '+i);
 const bl=new Set(slots('barrel_pen').map(idx));for(const i of JSON.parse(run(`JSON.stringify(BL_ALL_SLOTS)`)))assert.ok(bl.has(i),'barrel '+i);
 assert.equal(run(`CP_GROW_SLOTS.length`),54);assert.equal(run(`CP_MAT_SLOTS.length`),27);assert.equal(run(`BL_GROW_SLOTS.length`),27);
 assert.equal(run(`BLAST_MAT_SLOTS.length`),54);assert.equal(run(`FZ_FEED_SLOTS.length`),27);assert.equal(run(`SM_MAT_SLOTS.length`),81);
});
test('old composter / barrel data keeps its order in the bigger storage',()=>{
 const st={composter:{grow:[{id:'minecraft:wheat_seeds',amount:3}],mats:[{id:'minecraft:dirt',n:5}]},barrel:{grow:[null,{id:'minecraft:kelp',amount:1}]}};
 assert.equal(run(`blState(${JSON.stringify(st)},'composter').grow.length`),54);
 assert.equal(run(`blState(${JSON.stringify(st)},'composter').mats[0].n`),5);
 assert.equal(run(`blState(${JSON.stringify(st)},'barrel').grow.length`),27);
 assert.equal(run(`blState(${JSON.stringify(st)},'barrel').grow[1].id`),'minecraft:kelp');
});
test('note records and fletch arrow materials only go in their own 27 slots',()=>{
 assert.equal(run(`crLeftOk('note','minecraft:music_disc_cat')`),true);assert.equal(run(`crLeftOk('note','minecraft:coal')`),false);
 /* v780: the cauldron (former fletching table) sorts by group instead */assert.equal(run(`flSlotOk(30,'minecraft:arrow')`),true);assert.equal(run(`flSlotOk(30,'minecraft:feather')`),false);assert.equal(run(`flSlotOk(0,'minecraft:feather')`),false);assert.equal(run(`flSlotOk(20,'minecraft:feather')`),true);
});
test('v1.1.765: furnace fuel is 81 slots (27 + 54 shown only for the furnace)',()=>{
 assert.equal(run(`fzFuelSlots('furnace').length`),81);assert.equal(run(`fzFuelSlots('blast').length`),27);
 assert.equal(run(`fzState({},'furnace').fuel.length`),81);
 const ff=find(ui,'furnace_fuel_more');const vis=ff.bindings.find(b=>b.target_property_name==='#visible').source_property_name;
 assert.match(vis,/= '2'/);const ids=new Set(ff.controls.map(x=>idx(Object.values(x)[0])));
 for(const i of JSON.parse(run(`JSON.stringify(FURNACE_FUEL_SLOTS.slice(27))`)))assert.ok(ids.has(i),'furnace fuel '+i);
});
test('v1.1.765: headings above slots use one font size, and no slot counts or item lists',()=>{
 const heads=['cr_xlabel','cp_xlabel','bl_mh','bl_wh','bl_bh','sm_lt','sm_lm','en_tpl_head','fz_hfuel','feed_head','fuel_head'];
 const seen=[];(function w(o){if(o&&typeof o==='object'){for(const [k,v] of Object.entries(o)){if(heads.includes(k.split('@')[0])&&v&&v.type==='label'){seen.push(k);assert.equal(v.font_scale_factor,0.75,k);assert.doesNotMatch(v.text,/マス|・/,k);}w(v);}}})(ui);
 assert.ok(seen.length>=10);
 const js=fs.readFileSync(path.join(__dirname,'../behavior_pack/scripts/main.js'),'utf8');
 assert.doesNotMatch(js,/FZ_MAT_HEAD, `[^`]*マス/);
 for(const m of js.matchAll(/"§e\[[^\]]*\]([^"]*入れられ[^"]*)"/g))if(!m[1].includes('名前・エンチャント'))assert.equal(m[1],' この欄には入れられません');
});
console.log(n+' storage layout test groups passed');
