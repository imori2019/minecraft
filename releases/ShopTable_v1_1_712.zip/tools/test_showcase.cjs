const assert=require('node:assert/strict');
const env=require('./test_smelt_sales.cjs');
const {run,prep,ctx,handlers}=env;
let count=0;
function test(name,fn){fn();count++;console.log('PASS SHOWCASE '+name);}
// 展示のモブ・ケース・コマンドの代わり
run(`
globalThis.scEnts=[];globalThis.scCase=true;
block.above=()=>({typeId:scCase?'shopuilook2:panel_furnace_case':'minecraft:air'});
block.dimension.getEntities=o=>o.type===SC_ID?scEnts.filter(e=>e.valid):[];
block.dimension.spawnEntity=(id,loc)=>{const p=new Map(),e={typeId:id,location:loc,valid:true,item:null,turn:0,
 getDynamicProperty:k=>p.get(k),setDynamicProperty:(k,v)=>p.set(k,v),remove(){this.valid=false;},
 runCommand(c){const m=/^replaceitem entity @s slot\\.weapon\\.mainhand 0 (\\S+) 1$/.exec(c);if(!m)throw Error(c);this.item=m[1];},
 pose:new Map(),getProperty:k=>k==='shopuilook2:turn'?e.turn:e.pose.get(k),setProperty:(k,v)=>{if(k==='shopuilook2:turn')e.turn=v;else e.pose.set(k,v);}};scEnts.push(e);return e;};
`);
function reset(ids){prep();run(`scEnts=[];scCase=true;scEmptyUntil.clear();system.currentTick=1000;putProducts(${JSON.stringify(ids)}.map((x,i)=>base('p'+(i+1),x)));`);}
const live=()=>JSON.parse(run(`JSON.stringify(scEnts.filter(e=>e.valid).map(e=>e.item))`));
test('one display entity shows the first product, and swaps only after a full 16-second turn',()=>{
 reset(['minecraft:porkchop','minecraft:raw_iron']);
 run(`scShowcase(block)`);assert.deepEqual(live(),['minecraft:porkchop']);
 const t0=run(`scEnts[0].turn`);
 run(`system.currentTick+=300;scShowcase(block)`);assert.deepEqual(live(),['minecraft:porkchop']);
 run(`system.currentTick+=20;scShowcase(block)`);assert.deepEqual(live(),['minecraft:raw_iron']);
 assert.notEqual(run(`scEnts[0].turn`),t0,'turn flips so the spin restarts facing front');
 run(`system.currentTick+=320;scShowcase(block)`);assert.deepEqual(live(),['minecraft:porkchop']);
 assert.equal(run(`scEnts.length`),1);
});
test('no case above or no products means no display',()=>{
 reset(['minecraft:porkchop']);run(`scShowcase(block);scCase=false;scShowcase(block)`);assert.deepEqual(live(),[]);
 reset([]);run(`saveProductIndex(block,[]);scShowcase(block)`);assert.deepEqual(live(),[]);
});
test('a product removed from sale disappears from the rotation',()=>{
 reset(['minecraft:porkchop','minecraft:raw_iron']);run(`scShowcase(block);deleteProduct(block,'p2');system.currentTick+=320;scShowcase(block)`);
 assert.deepEqual(live(),['minecraft:porkchop']);
});
test('an item the command rejects is skipped instead of freezing the rotation',()=>{
 reset(['minecraft:porkchop','minecraft:raw_iron','minecraft:apple']);
 run(`scShowcase(block);const e=scEnts[0];const orig=e.runCommand;e.runCommand=function(c){if(c.includes('raw_iron'))throw Error('bad item');return orig.call(this,c);};system.currentTick+=320;scShowcase(block)`);
 assert.deepEqual(live(),['minecraft:apple']);
 run(`system.currentTick+=320;scShowcase(block)`);assert.deepEqual(live(),['minecraft:porkchop']);
});
test('every glass case lets light through so the display is not drawn black',()=>{
 const fs=require('node:fs'),path=require('node:path');const dir=path.join(__dirname,'../behavior_pack/blocks');
 for(const f of fs.readdirSync(dir).filter(f=>f.endsWith('_case.json')))
  assert.equal(JSON.parse(fs.readFileSync(path.join(dir,f),'utf8'))['minecraft:block'].components['minecraft:light_dampening'],0,f);
});
test('item pose: defaults stand the item up (rx -75, measured on an armor stand), saved values are clamped and applied to display entities',()=>{
 prep();run(`world.setDynamicProperty(SC_POSE_PROP,undefined);`);
 assert.deepEqual(JSON.parse(run(`JSON.stringify(scPose())`)),{rx:-75,ry:0,rz:0,px:0,py:0,pz:0,rr:-20,fox:0,native:0});
 run(`world.setDynamicProperty(SC_POSE_PROP,JSON.stringify({rx:400,ry:-30,px:-100,pz:7,bad:1}));`);
 assert.deepEqual(JSON.parse(run(`JSON.stringify(scPose())`)),{rx:180,ry:-30,rz:0,px:-64,py:0,pz:7,rr:-20,fox:0,native:0});
 run(`globalThis.pe={props:new Map(),getProperty(k){return this.props.get(k);},setProperty(k,v){this.props.set(k,v);}};scApplyPose(pe);`);
 assert.equal(run(`pe.props.get('shopuilook2:rx')`),180);assert.equal(run(`pe.props.get('shopuilook2:pz')`),7);
 run(`world.setDynamicProperty(SC_POSE_PROP,undefined);`);
 const fs=require('node:fs'),path=require('node:path');
 const ent=JSON.parse(fs.readFileSync(path.join(__dirname,'../behavior_pack/entities/showcase_item.json'),'utf8'))['minecraft:entity'].description.properties;
 for(const k of ['rx','ry','rz','px','py','pz','rr','fox'])assert.ok(ent['shopuilook2:'+k],k);
 const an=JSON.parse(fs.readFileSync(path.join(__dirname,'../resource_pack/animations/showcase_item.animation.json'),'utf8'));
 const bones=an.animations['animation.shopuilook2.showcase_item.spin'].bones;
 assert.equal(bones.tilt.rotation[0],"q.property('shopuilook2:rx')");assert.equal(bones.rightItem.rotation,undefined,'the item bone only moves; tilting happens around the item centre');
 const geo=JSON.parse(fs.readFileSync(path.join(__dirname,'../resource_pack/models/entity/showcase_item.geo.json'),'utf8'))['minecraft:geometry'][0].bones;
 const by=Object.fromEntries(geo.map(b=>[b.name,b]));
 assert.equal(by.rightItem.parent,'block_unyaw');assert.equal(by.block_unyaw.parent,'block_untilt');assert.equal(by.block_untilt.parent,'tilt');assert.equal(by.tilt.parent,'roll');assert.equal(by.roll.parent,'offset');assert.equal(by.offset.parent,'spin');
 assert.deepEqual(bones.roll.rotation,[0,0,"q.property('shopuilook2:rr')"]);
 assert.equal(by.held_item.parent,'block_unyaw','fox attachment must also inherit angle corrections');
 assert.deepEqual(bones.offset.position,["q.property('shopuilook2:px') * 0.5","q.property('shopuilook2:py') * 0.5","q.property('shopuilook2:pz') * 0.5"],'position correction sits outside both item attachment paths');
 assert.equal(bones.held_item.scale,"q.property('shopuilook2:fox')");assert.equal(bones.rightItem.scale,"1 - q.property('shopuilook2:fox')");
 assert.deepEqual([by.tilt.pivot[0],by.tilt.pivot[2]],[0,0],'item centre sits on the spin axis');
 assert.deepEqual(by.rightItem.pivot,[-2.25,7.25,4],'grip offset measured on the armor stand (inward 2.25, up 0.75, forward 4)');
});
test('comparison mode: test cycles 6 orientations, center cycles 9 offsets around the chosen one, pick saves it',()=>{
 prep();run(`world.setDynamicProperty(SC_POSE_PROP,undefined);SC_TEST=null;`);
 run(`SC_TEST={mode:'rot',i:0,next:0,playerId:player.id,base:scPose()};`);
 const seen=[];for(let i=0;i<6;i++){run(`SC_TEST.i=${i};`);seen.push(JSON.parse(run(`JSON.stringify(scTestPose(SC_TEST))`)));}
 assert.equal(new Set(seen.map(p=>[p.rx,p.ry,p.rz].join())).size,6,'six different orientations');
 run(`SC_TEST.i=3;globalThis.picked=scTestPose(SC_TEST);world.setDynamicProperty(SC_POSE_PROP,JSON.stringify(picked));SC_TEST={mode:'center',i:0,next:0,playerId:player.id,base:scPose()};`);
 const c=[];for(let i=0;i<9;i++){run(`SC_TEST.i=${i};`);c.push(JSON.parse(run(`JSON.stringify(scTestPose(SC_TEST))`)));}
 assert.ok(c.every(p=>p.rx===-75&&p.rz===15),'center candidates keep the chosen orientation');
 assert.equal(new Set(c.map(p=>[p.px,p.pz].join())).size,9);
 assert.deepEqual([c[1].px,c[1].pz],[8,0]);
 run(`SC_TEST=null;world.setDynamicProperty(SC_POSE_PROP,undefined);`);
});
// Test the actual registered commands, native attachment hierarchy and automatic product swaps.
// The mock does not render Minecraft's native held-item transform.
const command=handlers.find(f=>f.toString().includes('ev.id !== "shoptable:showcase"'));
assert.ok(command);
const plain=x=>JSON.parse(JSON.stringify(x));
const nativeBlocks=ctx.BlockTypes.get;
const originalRun=ctx.system.run;
ctx.BlockTypes.get=id=>['minecraft:stone','shopuilook2:panel_furnace'].includes(id)?{id}:undefined;
ctx.system.run=f=>f();
run(`scKindCache.clear();world.getDimension=()=>block.dimension;player.typeId='minecraft:player';`);
function send(message){command({id:'shoptable:showcase',sourceEntity:env.player,message});}
function profile(target){return plain(run(`scPose(${JSON.stringify(target)})`));}
function clean(){prep();run(`SC_TEST=null;scKindCache.clear();world.setDynamicProperty(SC_POSE_PROP,undefined);world.setDynamicProperty(SC_PROFILES_PROP,undefined);`);}
test('block and flat item corrections are independent, saved across reads, and the prior calibration migrates',()=>{
 clean();run(`world.setDynamicProperty(SC_POSE_PROP,JSON.stringify({rx:-70,rr:-17,px:4}));`);
 assert.equal(profile('block').rx,0,'a cube does not inherit the old flat-item correction');assert.equal(profile('block').native,1);assert.equal(profile('item').rr,-17);
 send('block rx -30 ry 45 rz 10 rr 0 px 8 py 6 pz 4');
 send('item rx -75 ry 0 rz 0 rr -20 px 0 py 0 pz 0');
 assert.deepEqual([profile('block').rx,profile('block').ry,profile('block').px],[-30,45,8]);
 assert.deepEqual([profile('item').rx,profile('item').ry,profile('item').px],[-75,0,0]);
 assert.equal(profile('minecraft:stone').ry,45);assert.equal(profile('minecraft:apple').rr,-20);
 run(`scKindCache.clear();`);assert.equal(profile('minecraft:stone').ry,45,'fresh resolution keeps saved group');
});
test('the real product rotation selects the block/item corrections immediately on every swap',()=>{
 reset(['minecraft:apple','minecraft:stone']);
 send('item rx -75 rr -20 px 1');send('block rx 0 ry -45 rr 0 px 7');
 run(`scShowcase(block);`);
 assert.equal(run(`scEnts[0].pose.get('shopuilook2:rx')`),-75);
 assert.equal(run(`scCurrentItem(scEnts[0])`),'minecraft:apple');
 run(`system.currentTick+=320;scShowcase(block);`);
 assert.equal(run(`scCurrentItem(scEnts[0])`),'minecraft:stone');
 assert.equal(run(`scEnts[0].pose.get('shopuilook2:rx')`),0);
 assert.equal(run(`scEnts[0].pose.get('shopuilook2:block_item')`),1);
 assert.equal(run(`scEnts[0].pose.get('shopuilook2:ry')`),-45);
 assert.equal(run(`scEnts[0].pose.get('shopuilook2:px')`),7);
 run(`system.currentTick+=320;scShowcase(block);`);
 assert.equal(run(`scEnts[0].pose.get('shopuilook2:rx')`),-75);
 assert.equal(run(`scEnts[0].pose.get('shopuilook2:px')`),1);
 assert.equal(run(`scEnts[0].pose.get('shopuilook2:block_item')`),0);
});
test('special items override their group without changing other merchandise',()=>{
 clean();send('item rx -75 rr -20');send('minecraft:diamond_sword rx -20 rz 15 px 3');
 assert.equal(profile('minecraft:diamond_sword').rx,-20);
 assert.equal(profile('minecraft:diamond_sword').rz,15);
 assert.equal(profile('minecraft:apple').rx,-75);
 send('item rx -60');assert.equal(profile('minecraft:diamond_sword').rx,-20,'explicit item correction survives group edits');
 assert.equal(profile('minecraft:apple').rx,-60);
});
test('manual edits during comparison stop the timer and retain the visible candidate for just the selected group',()=>{
 clean();send('block test');run(`SC_TEST.i=3;`);send('block rr 25');
 assert.equal(run(`SC_TEST`),null,'comparison no longer overwrites the manual adjustment');
 assert.equal(profile('block').rz,15,'manual nudge starts from the visible preview');
 assert.equal(profile('block').rr,25);assert.equal(profile('item').rz,0);
});
test('pick and stop operate on the previewed group, and invalid picks or malformed edits do not save',()=>{
 clean();send('block test');send('pick 2');
 assert.equal(profile('block').rx,-15);assert.equal(profile('item').rx,-75);
 send('block center');run(`SC_TEST.i=1;`);send('stop');
 assert.equal(profile('block').px,0,'stop restores saved calibration');
 send('block test');const saved=run(`world.getDynamicProperty(SC_PROFILES_PROP)`);
 send('pick 0');assert.ok(run(`SC_TEST`));assert.equal(run(`world.getDynamicProperty(SC_PROFILES_PROP)`),saved);
 send('block rx 30 ry invalid');assert.equal(run(`world.getDynamicProperty(SC_PROFILES_PROP)`),saved,'invalid edits are atomic');
 send('stop');send('block rx');assert.equal(run(`world.getDynamicProperty(SC_PROFILES_PROP)`),saved);
});
test('fox and hand mode are separately selectable for each group and boolean mode never becomes negative',()=>{
 clean();send('block fox');assert.equal(profile('block').fox,1);assert.equal(profile('item').fox,0);
 send('block fox -9');assert.equal(profile('block').fox,1,'named command selects fox mode');
 run(`scSavePose('block',{...scPose('block'),fox:-1});`);assert.equal(profile('block').fox,0);
 send('item rx -65');assert.equal(profile('item').rx,-65);
});
test('both attachment paths inherit all angle axes and translation stays adjustable',()=>{
 const fs=require('node:fs'),path=require('node:path');
 const geo=JSON.parse(fs.readFileSync(path.join(__dirname,'../resource_pack/models/entity/showcase_item.geo.json')))['minecraft:geometry'][0].bones;
 const by=Object.fromEntries(geo.map(b=>[b.name,b]));
 for(const name of ['rightItem','held_item']){
  const parents=[];let b=by[name];while(b.parent){parents.push(b.parent);b=by[b.parent];assert.ok(b,'parent exists');}
  for(const required of ['tilt','roll','spin'])assert.ok(parents.includes(required),`${name} inherits ${required}`);
 }
});
test('cubes use the automatic inverse while food, raw ore and tools retain flat-item corrections',()=>{
 clean();
 for(const id of ['minecraft:apple','minecraft:raw_iron','minecraft:diamond_sword']){
  assert.equal(run(`scItemKind(${JSON.stringify(id)})`),'item');assert.equal(profile(id).native,0);
 }
 assert.equal(run(`scItemKind('minecraft:stone')`),'block');assert.equal(profile('minecraft:stone').native,1);
});
test('documented block rotations cancel in reverse order, not as one Euler-angle subtraction',()=>{
 const fs=require('node:fs'),path=require('node:path');
 const bones=JSON.parse(fs.readFileSync(path.join(__dirname,'../resource_pack/animations/showcase_item.animation.json'))).animations['animation.shopuilook2.showcase_item.spin'].bones;
 assert.deepEqual(bones.block_untilt.rotation,["q.property('shopuilook2:block_item') * -75",0,0]);
 assert.deepEqual(bones.block_unyaw.rotation,[0,"q.property('shopuilook2:block_item') * -45",0]);
 const rot=(v,axis,deg)=>{
  const a=deg*Math.PI/180,c=Math.cos(a),s=Math.sin(a),[x,y,z]=v;
  return axis==='x'?[x,y*c-z*s,y*s+z*c]:[x*c+z*s,y,-x*s+z*c];
 };
 for(const v of [[1,0,0],[0,1,0],[0,0,1],[3,-7,2]]){
  const native=rot(rot(v,'x',75),'y',45);
  const corrected=rot(rot(native,'y',-45),'x',-75);
  corrected.forEach((n,i)=>assert.ok(Math.abs(n-v[i])<1e-10,'all cube axes remain upright'));
 }
 const grip=[-2.25,7.25,4], shift=[2.25,-1.75,-4], nativeTranslation=[0,2.5,0];
 assert.deepEqual(grip.map((v,i)=>v+shift[i]+nativeTranslation[i]),[0,8,0],'cube centre matches the spin pivot');
});
test('custom block geometry can opt out of the default hand transform without changing vanilla cubes',()=>{
 clean();send('shopuilook2:panel_furnace native 0 rx -10');
 assert.equal(profile('shopuilook2:panel_furnace').native,0);
 assert.equal(profile('shopuilook2:panel_furnace').rx,-10);
 assert.equal(profile('minecraft:stone').native,1);
 assert.equal(profile('minecraft:stone').rx,0);
});
ctx.BlockTypes.get=nativeBlocks;ctx.system.run=originalRun;
console.log(count+' showcase test groups passed');
