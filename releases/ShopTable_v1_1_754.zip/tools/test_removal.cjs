const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const env=require('./test_smelt_sales.cjs');const {run,prep,ctx,worldProps,playerInv,shopInv}=env;ctx.worldProps=worldProps;ctx.messages=[];ctx.player.sendMessage=m=>ctx.messages.push(m);let count=0;
function test(n,f){f();count++;console.log('PASS REMOVAL '+n);}
run(`globalThis.removeFail='';globalThis.entityRemoved=false;globalThis.mainType='shopuilook2:panel_furnace';globalThis.caseType='shopuilook2:panel_furnace_case';
 globalThis.recoveryEntity={getComponent:k=>k==='minecraft:inventory'?{container:shopInv}:undefined,remove(){if(removeFail==='entity')throw Error('injected entity removal failure');entityRemoved=true;}};
 getPanelEntity=()=>recoveryEntity;
 block.above=()=>({get typeId(){return caseType;},get permutation(){return {typeId:caseType};},setType:id=>{caseType=id;},setPermutation:p=>{caseType=p.typeId;}});
 block.setType=id=>{if(removeFail==='block')throw Error('injected block failure');mainType=id;block.typeId=id;};
 block.setPermutation=p=>{mainType=p.typeId;block.typeId=p.typeId;};
 Object.defineProperty(block,'permutation',{get:()=>({typeId:mainType})});
 world.getDynamicPropertyIds=()=>[...worldProps.keys()].filter(k=>worldProps.get(k)!==undefined);
 const originalGetProps=getProps;
 globalThis.useWorldProps=()=>{getProps=()=>({get:k=>readShopWorldValue(shopWorldPropertyKey(block,k)),set:(k,v)=>writeShopWorldValue(shopWorldPropertyKey(block,k),v),entries:()=>world.getDynamicPropertyIds().filter(k=>k.startsWith(shopWorldBlockPrefix(block))).map(k=>[k.slice(shopWorldBlockPrefix(block).length),world.getDynamicProperty(k)])});};
 globalThis.restoreTestProps=()=>{getProps=originalGetProps;};`);
function reset(){run(`restoreTestProps()`);prep();run(`useWorldProps();worldProps.clear();active.clear();playerInv.items.clear();shopInv.items.clear();mainType='shopuilook2:panel_furnace';block.typeId=mainType;caseType='shopuilook2:panel_furnace_case';entityRemoved=false;removeFail='';setCurrentProduct(block,undefined);shopStashSetRec(block,undefined);
 const r=base('p1','minecraft:diamond',1,5);putProducts([r]);`);}
function qty(id){return [...playerInv.items.values()].filter(i=>i.typeId===id).reduce((n,i)=>n+i.amount,0);}
test('manual stock, physical receipts and the block return once, with custom names/lore retained',()=>{
 reset();run(`const r=loadProduct(block,'p1');r.stock[0].item.nameTag='名入り';r.stock[0].item.lore=['説明'];r.icon={id:'minecraft:diamond',amount:1};saveProduct(block,r);shopInv.setItem(223,new ItemStack('minecraft:apple',3));globalThis.ok=recoverShopPanel(player,block);`);
 assert.equal(ctx.ok,true,ctx.messages.join(" / "));assert.equal(qty('minecraft:diamond'),5);assert.equal(qty('minecraft:apple'),3);assert.equal(qty('shopuilook2:panel_furnace'),1);assert.equal(ctx.entityRemoved,true);assert.equal(ctx.caseType,'minecraft:air');assert.equal(run(`world.getDynamicPropertyIds().filter(k=>k.startsWith(shopWorldBlockPrefix(block))).length`),0);
 const gem=[...playerInv.items.values()].find(x=>x.typeId==='minecraft:diamond');assert.equal(gem.nameTag,'名入り');assert.deepEqual(gem.getLore(),['説明']);
});
test('only a free generated keepUnits sample is excluded; crafted stock and real breeding pairs return',()=>{
 reset();run(`const r=loadProduct(block,'p1');r.keepUnits=1;saveProduct(block,r);shopInv.setItem(90,makeLandingDisplayItem(r));setProbe(shopInv,91,3);globalThis.ok=recoverShopPanel(player,block)`);assert.equal(ctx.ok,true,ctx.messages.join(" / "));assert.equal(qty('minecraft:diamond'),4);assert.equal(qty(PROBE()),0);
 reset();run(`const r=loadProduct(block,'p1');r.keepPair=true;saveProduct(block,r);globalThis.ok=recoverShopPanel(player,block)`);assert.equal(ctx.ok,true,ctx.messages.join(" / "));assert.equal(qty('minecraft:diamond'),5);
});
function PROBE(){return run(`PROBE_ID`);}
test('a separately stored last-one prize is recovered exactly once',()=>{
 reset();run(`const r=loadProduct(block,'p1');r.lastOneItem={id:'minecraft:netherite_ingot',amount:1};r.items.push({id:'minecraft:netherite_ingot',role:'lastOne',count:1});saveProduct(block,r);globalThis.ok=recoverShopPanel(player,block)`);assert.equal(ctx.ok,true,ctx.messages.join(" / "));assert.equal(qty('minecraft:netherite_ingot'),1);assert.equal(qty('minecraft:diamond'),5);
});
test('full inventory, insufficient permission and an active session leave all stock and blocks intact',()=>{
 for(const failure of ['full','permission','active']){
  reset();if(failure==='full')run(`for(let i=0;i<playerInv.size;i++)playerInv.setItem(i,new ItemStack('minecraft:stone',64));`);
  if(failure==='permission')run(`registry.stores.s1.owner={id:'someone-else',name:'Other'};`);
  if(failure==='active')run(`active.set(player.id,{dimensionId:block.dimension.id,x:0,y:64,z:0});`);
  run(`globalThis.ok=recoverShopPanel(player,block)`);assert.equal(ctx.ok,false,failure);assert.equal(ctx.entityRemoved,false);assert.equal(ctx.mainType,'shopuilook2:panel_furnace');assert.equal(run(`loadProduct(block,'p1').stock[0].item.amount`),5);assert.equal(qty('minecraft:diamond'),0);
 }
});
test('entity and block failures roll back products, delivery inventory and physical items',()=>{
 for(const failure of ['entity','block']){
  reset();run(`shopInv.setItem(223,new ItemStack('minecraft:apple',3));removeFail=${JSON.stringify(failure)};globalThis.ok=recoverShopPanel(player,block);`);
  assert.equal(ctx.ok,false);assert.equal(qty('minecraft:diamond'),0);assert.equal(qty('minecraft:apple'),0);assert.equal(ctx.entityRemoved,false);assert.equal(ctx.mainType,'shopuilook2:panel_furnace');assert.equal(ctx.caseType,'shopuilook2:panel_furnace_case');assert.equal(run(`loadProduct(block,'p1').stock[0].item.amount`),5);assert.equal(shopInv.getItem(223).amount,3);
 }
});
test('a delivery write failure restores the original inventory without deleting stock',()=>{
 reset();playerInv.failSlot=1;run(`globalThis.ok=recoverShopPanel(player,block)`);assert.equal(ctx.ok,false);assert.equal(qty('minecraft:diamond'),0);assert.equal(ctx.entityRemoved,false);assert.equal(run(`loadProduct(block,'p1').stock[0].item.amount`),5);
});
test('orphan records are refused but ordinary saved product-name fields are not mistaken for records',()=>{
 reset();run(`getProps(block).set('shop_product_name','テスト商品');globalThis.ok=recoverShopPanel(player,block)`);assert.equal(ctx.ok,true,ctx.messages.join(" / "));
 reset();run(`getProps(block).set('shop_product_orphan',JSON.stringify({stock:[{item:{id:'minecraft:diamond',amount:7}}]}));globalThis.ok=recoverShopPanel(player,block)`);assert.equal(ctx.ok,false);assert.equal(qty('minecraft:diamond'),0);assert.equal(ctx.entityRemoved,false);
});
test('corrupt JSON, legacy ambiguous stock and orphan chunks never delete saved products',()=>{
 for(const mode of ['json','legacy','chunks']){
  reset();
  if(mode==='json')run(`getProps(block).set(productKey('p1'),'{broken');`);
  if(mode==='legacy')run(`getProps(block).set(productKey('p1'),JSON.stringify({items:[{id:'minecraft:diamond',role:'sample',count:1}]}));`);
  if(mode==='chunks')run(`world.setDynamicProperty(shopWorldBlockPrefix(block)+'shop_product_orphan:chunk:A:0','data');`);
  run(`globalThis.ok=recoverShopPanel(player,block)`);assert.equal(ctx.ok,false,mode);assert.equal(ctx.entityRemoved,false,mode);assert.equal(qty('minecraft:diamond'),0);
 }
});
test('description refresh preserves custom lore and follows the unified item text catalog',()=>{
 reset();run(`playerInv.setItem(0,new ItemStack('shopuilook2:panel_furnace',1));const named=new ItemStack('shopuilook2:panel_barrel',1);named.setLore(['自分の説明']);playerInv.setItem(1,named);shopRefreshItemDescriptions(player)`);
 assert.match(playerInv.getItem(0).getLore()[0],/できます。/);assert.deepEqual(playerInv.getItem(1).getLore(),['自分の説明']);
 const root=path.resolve(__dirname,'..');assert.ok(fs.existsSync(path.join(root,'resource_pack/textures/shop_icons/shears.png')));
 const item=JSON.parse(fs.readFileSync(path.join(root,'behavior_pack/items/shop_remover.json'),'utf8'));assert.equal(item['minecraft:item'].components['minecraft:max_stack_size'],1);
});
console.log(count+' removal tests passed (API simulation; no Minecraft runtime)');
