const assert=require('node:assert/strict'),fs=require('fs'),path=require('path');
const d=JSON.parse(fs.readFileSync(path.join(__dirname,'../resource_pack/ui/data_driven_container_screen.json'),'utf8'));
function controls(node){return Object.fromEntries(node.controls.flatMap(e=>Object.entries(e)));}
const desktop=controls(d.desktop_panel),root=controls(desktop['root_panel@common.root_panel']);
const overlay=desktop.shop_cursor_overlay,cursor=controls(overlay),button=cursor['inventory_selected_icon_button@common.inventory_selected_icon_button'];
for(const name of ['inventory_selected_icon_button@common.inventory_selected_icon_button','flying_item_renderer@common.flying_item_renderer','gamepad_cursor@common.gamepad_cursor_button']){
 assert.ok(cursor[name]);assert.equal(root[name],undefined,'no duplicate cursor control remains in shop layout');
}
assert.deepEqual(overlay.size,['100%','100%']);assert.ok(overlay.layer>desktop['root_panel@common.root_panel'].layer);assert.equal(overlay.visible,undefined);assert.equal(overlay.ignored,undefined);
console.log('PASS CURSOR carried items use one desktop overlay independent of owner/buyer/settings visibility');
const states=controls(button);for(const state of ['default','pressed','hover'])assert.ok(states[state+'@data_driven_container.shop_carried_icon_panel']);
assert.ok(states['durability_bar_grabbed@common.durability_bar_grabbed']);assert.ok(states['storage_bar_grabbed@common.storage_bar_grabbed']);
assert.equal(button.button_mappings,undefined,'native cursor-item click handling is inherited');assert.equal(button.follows_cursor,undefined,'native follows_cursor is inherited');
console.log('PASS CURSOR default, pressed and hover states retain native item actions and durability/storage bars');
const panel=controls(d['shop_carried_icon_panel@common.inventory_icon_panel']);
const icon=panel['selected_item_icon@common.inventory_selected_icon'],count=panel['selected_stack_size_text@common.inventory_selected_stack_size_text'];
assert.ok(icon.layer>=500,'actual custom item renderer has its own foreground layer');assert.equal(count.layer-icon.layer,3,'native item/count ordering preserved');assert.equal(icon.bindings,undefined);assert.equal(count.bindings,undefined,'native selected item count binding is inherited');
console.log('PASS CURSOR item renderer and count are raised together, rather than only changing the outer button');
const tips=desktop['selected_item_details_factory@common.selected_item_details_factory'];assert.ok(tips.layer>overlay.layer+count.layer);
assert.ok(overlay.layer+cursor['flying_item_renderer@common.flying_item_renderer'].layer>desktop['root_panel@common.root_panel'].layer);
console.log('PASS CURSOR tooltip remains above the carried item and native flying-item feedback is preserved');
console.log('4 cursor layering checks passed (UI structure; Minecraft rendering not executed)');
