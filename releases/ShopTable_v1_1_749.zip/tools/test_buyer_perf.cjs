const assert=require('node:assert/strict');const {run,prep,ctx,Container,ItemStack:envItem}=require('./test_smelt_sales.cjs');let n=0;const plain=x=>JSON.parse(JSON.stringify(x));
function test(name,f){f();n++;console.log('PASS BUYER PERF '+name);}
function reset(count=27){ctx.shopInv=new Container(640);prep();run(`block.typeId='shopuilook2:panel';active.clear();PANEL_OCCUPANTS.clear();registry.stores.s1.pricePointSystem=normalizePricePointSystemSettings({});registry.stores.s1.departments=[{id:'d1',name:'食品'},{id:'d2',name:'素材'}];const ps=Array.from({length:${count}},(_,i)=>{const p=base('perf'+i,'minecraft:apple');p.settings.price='100';p.settings.shop_product_genre='食品';return p;});putProducts(ps);globalThis.perfRec={};`);}
test('27-product opening reads floor assignments once and calculates each product price once',()=>{
 reset();run(`globalThis.perfCounts={floors:0,quotes:0,scan:0};globalThis.perfFloors=loadProductFloors;globalThis.perfQuote=shopBestPrice;globalThis.perfGet=shopInv.getItem;
 loadProductFloors=(...a)=>{perfCounts.floors++;return perfFloors(...a)};shopBestPrice=(...a)=>{perfCounts.quotes++;return perfQuote(...a)};shopInv.getItem=function(...a){perfCounts.scan++;return perfGet.apply(this,a)};
 enterShopMode(player,perfRec,block,shopInv);loadProductFloors=perfFloors;shopBestPrice=perfQuote;shopInv.getItem=perfGet;`);
 assert.equal(run('perfRec.shopMode.cells.size'),27);assert.equal(run('perfCounts.floors'),1);assert.equal(run('perfCounts.quotes'),27);assert.ok(run('perfCounts.scan')<800);console.log('opening operation counts:',plain(run('perfCounts')));
});
test('a fresh render immediately picks up saved prices, discounts and floor moves',()=>{
 reset();run(`enterShopMode(player,perfRec,block,shopInv);globalThis.oldPrice=shopInv.getItem(shSlots(0).price[0]).nameTag;
 const p=loadProduct(block,'perf0');p.settings.price='200';saveProduct(block,p);writeShopUI(shopInv,perfRec,block);`);
 assert.notEqual(run('shopInv.getItem(shSlots(0).price[0]).nameTag'),run('oldPrice'));
 run(`registry.stores.s1.pricePointSystem.globalDiscount={enabled:true,method:'percent',value:25};writeShopUI(shopInv,perfRec,block);`);
 assert.equal(run('shopHasDiscount(shopBestPrice(perfRec.shopMode.model.records.get("perf0"),pricePointSettingsForStore(registry.stores.s1).currencies,pricePointSettingsForStore(registry.stores.s1),"d1",shopNow()).entries)'),true);
 assert.ok(run('perfRec.shopMode.dealCells.size')>0);
 run(`setProductFloor(block,'perf0','d2');writeShopUI(shopInv,perfRec,block);`);assert.equal(run('perfRec.shopMode.model.floorOf.get("perf0")'),'d2');assert.equal(run('[...perfRec.shopMode.cells.values()].includes("perf0")'),false);
});
test('real purchases update stock on the next draw and payment is revalidated',()=>{
 reset(1);run(`enterShopMode(player,perfRec,block,shopInv);globalThis.beforeStock=shopPurchaseRemaining(perfRec.shopMode.model.records.get('perf0'));globalThis.buy1=shopPurchaseCommit(player,block,'perf0',1);writeShopUI(shopInv,perfRec,block);`);
 assert.equal(run('buy1.ok'),true);assert.equal(run('shopPurchaseRemaining(perfRec.shopMode.model.records.get("perf0"))'),run('beforeStock')-1);
 run(`playerInv.items.clear();for(const s of shopPaySlots(shopInv))shopInv.setItem(s,undefined);globalThis.noFunds=shopPurchaseCommit(player,block,'perf0',1);`);assert.equal(run('noFunds.ok'),false);assert.equal(run('loadProduct(block,"perf0").stock[0].item.amount'),15);
});
test('cooked catalogue quotes do not apply the surcharge twice and still share raw stock',()=>{
 reset(1);run(`block.typeId='shopuilook2:panel_furnace';const p=base('p900','minecraft:porkchop');p.settings.price='100';putProducts([p]);registry.stores.s1.furnace={enabled:true,pct:10,burn:64};enterShopMode(player,perfRec,block,shopInv);`);
 assert.equal(run('perfRec.shopMode.model.records.has("baked:furnace:p900")'),true);
 assert.equal(run('shopPurchasePrice(perfRec.shopMode.model.records.get("baked:furnace:p900"),registry.stores.s1,"d1",1,player.id).entries[0].n2'),110);
});
test('read scopes isolate item copies, re-read successful and failed writes, and never hide external changes on a new draw',()=>{
 const real=new Container(640);real.setItem(60,new envItem('minecraft:diamond',4));let reads=0;const get=real.getItem.bind(real);real.getItem=s=>{reads++;return get(s)};ctx.scopeReal=real;
 run('globalThis.scope=shopReadScope(scopeReal)');run('scope.getItem(60).amount=1;scope.getItem(60)');assert.equal(reads,1);assert.equal(run('scope.getItem(60).amount'),4);
 run('scope.setItem(60,new ItemStack("minecraft:diamond",7))');assert.equal(run('scope.getItem(60).amount'),7);assert.equal(reads,2);
 real.failSlot=60;assert.throws(()=>run('scope.setItem(60,new ItemStack("minecraft:apple",1))'),/injected/);assert.equal(run('scope.getItem(60).typeId'),'minecraft:diamond');assert.equal(reads,3);
 real.setItem(60,new envItem('minecraft:emerald',9));assert.equal(run('shopReadScope(scopeReal).getItem(60).amount'),9);
});
console.log(n+' buyer performance groups passed (API simulation; native opening time not measured)');
