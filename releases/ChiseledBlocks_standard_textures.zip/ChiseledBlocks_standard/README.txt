﻿模様入りブロック 標準テクスチャ
出典 Mojang公式 bedrock-samples main
取得日 2026-10-31 日本時間
PNGは元画像のままです。色・模様・解像度を変更していません。
up 上面 / down 底面 / side 側面 / north 正面 / all 全面
本棚の正面は空と本入りの2画像です。ゲーム内では各区画の状態に応じて使い分けます。
虫食い・錆止め版は元ブロックと同じ画像を参照します。
硫黄・辰砂も取得元のmainにあるため収録しています。古いゲーム版には存在しない場合があります。

模様入りの本棚 minecraft:chiseled_bookshelf
  down : textures/blocks/chiseled_bookshelf_top.png
  east : textures/blocks/chiseled_bookshelf_side.png
  north : textures/blocks/chiseled_bookshelf_empty.png, textures/blocks/chiseled_bookshelf_occupied.png
  south : textures/blocks/chiseled_bookshelf_side.png
  up : textures/blocks/chiseled_bookshelf_top.png
  west : textures/blocks/chiseled_bookshelf_side.png

模様入りの辰砂 minecraft:chiseled_cinnabar
  all : textures/blocks/chiseled_cinnabar.png

模様入りの銅 minecraft:chiseled_copper
  all : textures/blocks/chiseled_copper.png

模様入りの深層岩 minecraft:chiseled_deepslate
  all : textures/blocks/deepslate/chiseled_deepslate.png

模様入りのネザーレンガ minecraft:chiseled_nether_bricks
  all : textures/blocks/chiseled_nether_bricks.png

模様入りの磨かれたブラックストーン minecraft:chiseled_polished_blackstone
  all : textures/blocks/chiseled_polished_blackstone.png

模様入りのクォーツブロック minecraft:chiseled_quartz_block
  down : textures/blocks/quartz_block_chiseled_top.png
  side : textures/blocks/quartz_block_chiseled.png
  up : textures/blocks/quartz_block_chiseled_top.png

模様入りの赤い砂岩 minecraft:chiseled_red_sandstone
  down : textures/blocks/red_sandstone_top.png
  side : textures/blocks/red_sandstone_carved.png
  up : textures/blocks/red_sandstone_top.png

模様入りの樹脂レンガ minecraft:chiseled_resin_bricks
  all : textures/blocks/chiseled_resin_bricks.png

模様入りの砂岩 minecraft:chiseled_sandstone
  down : textures/blocks/sandstone_top.png
  side : textures/blocks/sandstone_carved.png
  up : textures/blocks/sandstone_top.png

模様入りの石レンガ minecraft:chiseled_stone_bricks
  all : textures/blocks/stonebrick_carved.png

模様入りの硫黄 minecraft:chiseled_sulfur
  all : textures/blocks/chiseled_sulfur.png

模様入りの凝灰岩 minecraft:chiseled_tuff
  down : textures/blocks/chiseled_tuff_top.png
  side : textures/blocks/chiseled_tuff.png
  up : textures/blocks/chiseled_tuff_top.png

模様入りの凝灰岩レンガ minecraft:chiseled_tuff_bricks
  down : textures/blocks/chiseled_tuff_bricks_top.png
  side : textures/blocks/chiseled_tuff_bricks.png
  up : textures/blocks/chiseled_tuff_bricks_top.png

風化した模様入りの銅 minecraft:exposed_chiseled_copper
  all : textures/blocks/exposed_chiseled_copper.png

虫食いの模様入り石レンガ minecraft:infested_chiseled_stone_bricks
  all : textures/blocks/stonebrick_carved.png

酸化した模様入りの銅 minecraft:oxidized_chiseled_copper
  all : textures/blocks/oxidized_chiseled_copper.png

錆止めされた模様入りの銅 minecraft:waxed_chiseled_copper
  all : textures/blocks/chiseled_copper.png

錆止めされた風化した模様入りの銅 minecraft:waxed_exposed_chiseled_copper
  all : textures/blocks/exposed_chiseled_copper.png

錆止めされた酸化した模様入りの銅 minecraft:waxed_oxidized_chiseled_copper
  all : textures/blocks/oxidized_chiseled_copper.png

錆止めされた錆びた模様入りの銅 minecraft:waxed_weathered_chiseled_copper
  all : textures/blocks/weathered_chiseled_copper.png

錆びた模様入りの銅 minecraft:weathered_chiseled_copper
  all : textures/blocks/weathered_chiseled_copper.png
