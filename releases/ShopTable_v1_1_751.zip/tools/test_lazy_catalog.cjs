const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {run,prep,ctx,Container,ItemStack}=require('./test_smelt_sales.cjs');
const raw=JSON.parse(fs.readFileSync(path.join(__dirname,'../resource_pack/ui/shop_layout_price.json'),'utf8'));const ctl=o=>Object.assign({},...(o.controls??[]));let n=0;const test=(name,f)=>{f();n++;console.log('PASS LAZY '+name)};
function reset(count,genres=1,size=640){ctx.shopInv=new Container(size);prep();run(`block.typeId='shopuilook2:panel';active.clear();PANEL_OCCUPANTS.clear();registry.stores.s1.departments=[{id:'d1',name:'食品'},{id:'d2',name:'素材'}];registry.stores.s1.pricePointSystem=normalizePricePointSystemSettings({});const a=Array.from({length:${count}},(_,i)=>{const p=base('p'+(100+i),'minecraft:apple');p.settings.shop_product_genre='分類'+(i%${genres});return p;});putProducts(a);globalThis.lazyRec={};enterShopMode(player,lazyRec,block,shopInv);`);}
const flags=()=>JSON.parse(run('JSON.stringify(SH_CATALOG_GATES.map(s=>isProbe(shopInv.getItem(s))?shopInv.getItem(s).amount:0))'));
test('exactly one description viewport gets a 1-item native grid, covering every description length',()=>{
 reset(27);for(let rows=1;rows<=4;rows++){run(`shopCatalogueGates(shopInv,${rows})`);assert.deepEqual(flags(),Array.from({length:4},(_,i)=>i===rows-1?1:0));}
 const root=ctl(raw.shop_page).shop_vis;
 for(let i=1;i<=4;i++){
  const parent=ctl(ctl(root)['sh_scroll_mode_'+i])['sh_scroll_mode_'+i+'_visibility'];const g=ctl(parent)['catalog_factory_'+i];assert.equal(g.type,'grid');assert.equal(g.maximum_grid_items,0);assert.equal(g.precached_grid_item_count,0);assert.deepEqual(g.grid_dimensions,[1,1]);assert.equal(g.grid_rescaling_type,'none');assert.equal(g.collection_index,[104,105,119,120][i-1]);assert.equal(g.bindings[0].binding_name_override,'#maximum_grid_items');
  const t=raw[g.grid_item_template.split('.')[1]];assert.ok(ctl(t)['sh_scroll_'+i+'@common.scrolling_panel']);assert.equal(ctl(t)['sh_scroll_'+i+'@common.scrolling_panel'].$scrolling_content,'shop_layout_price.sh_content');
 }
});
test('empty rows have no grid instances; each requested row selects only its normal or continuation template',()=>{
 for(const [count,genres]of [[1,1],[27,1],[27,27],[54,9]]){
  reset(count,genres);const rows=JSON.parse(run('JSON.stringify(lazyRec.shopMode.model.rows)'));assert.equal(run('lazyRec.shopMode.cells.size'),count);
  for(let i=3;i<27;i++){
   const row=rows[i];for(const [suffix,enabled]of [['',!!row&&!row.continued],['_continuation',!!row&&!!row.continued]]){
    const w=ctl(raw.sh_content)['sh_row'+i+suffix],g=ctl(w).row_factory;assert.equal(g.type,'grid');assert.equal(g.maximum_grid_items,0);assert.equal(g.precached_grid_item_count,0);assert.deepEqual(g.grid_dimensions,[1,1]);assert.equal(g.grid_rescaling_type,'none');
    assert.equal(run(`shopInv.getItem(${g.collection_index})?.amount??0`),enabled?1:0);const content=ctl(raw[g.grid_item_template.split('.')[1]])['sh_row'+i+suffix];assert.equal(content.collection_index,run(`shSlots(${i}).title`));assert.deepEqual(content.size,w.size);
   }
  }
 }
});
test('price refresh does not clear or rewrite active factory signals, while a floor change unloads unused rows',()=>{
 reset(27,27);run(`globalThis.changedGates=[];globalThis.lazySet=shopInv.setItem;globalThis.lazySlots=new Set([...SH_CATALOG_GATES,...Array.from({length:24},(_,i)=>shSlots(i+3)).flatMap(s=>[s.prev,s.next])]);shopInv.setItem=function(slot,item){if(lazySlots.has(slot))changedGates.push(slot);return lazySet.call(this,slot,item)};const p=loadProduct(block,'p100');p.settings.price='700';saveProduct(block,p);writeShopUI(shopInv,lazyRec,block);`);
 assert.deepEqual(JSON.parse(run('JSON.stringify(changedGates)')),[]);run('shopInv.setItem=lazySet');
 run(`for(const id of loadProductIndex(block))if(id!=='p100')setProductFloor(block,id,'d2');writeShopUI(shopInv,lazyRec,block)`);assert.equal(run('lazyRec.shopMode.cells.size'),1);
 for(let i=3;i<27;i++)assert.equal(run(`(shopInv.getItem(shSlots(${i}).prev)?.amount??0)+(shopInv.getItem(shSlots(${i}).next)?.amount??0)`),0);
});
test('legacy 256-slot panels keep the first-page continuation controls and use in-bounds gate slots',()=>{
 reset(27,27,256);assert.equal(run('lazyRec.shopMode.model.rows.length'),5);assert.equal(run('lazyRec.shopMode.model.hasMoreRows'),true);assert.equal(flags().filter(x=>x===1).length,1);assert.equal(run('shopInv.getItem(shSlots(0).next).amount'),2);
 run(`handleShopClick(player,lazyRec,shSlots(0).next,block,shopInv)`);assert.equal(run('lazyRec.shopMode.rowWindowIndex'),1);assert.equal(run('lazyRec.shopMode.cells.size'),5);
});
test('factory signals never overwrite existing real items or touch the delivery slots',()=>{
 reset(1);run(`shopInv.setItem(104,new ItemStack('minecraft:diamond',64));shopCatalogueGates(shopInv,1)`);assert.equal(run('shopInv.getItem(104).typeId'),'minecraft:diamond');assert.equal(run('shopInv.getItem(104).amount'),64);assert.ok(run('SH_CATALOG_GATES.every(s=>!SH_REAL_SLOTS.has(s))'));
});
test('shared price templates keep the UI file below 7 MB and pass unique slot/binding parameters to every price instance',()=>{
 const file=path.join(__dirname,'../resource_pack/ui/shop_layout_price.json');assert.ok(fs.statSync(file).size<7_000_000);const templates=Object.keys(raw).filter(k=>k.startsWith('price_unit_'));assert.equal(templates.length,54);let instances=0;
 function walk(x){if(!x||typeof x!=='object')return;for(const[k,v]of Object.entries(x)){
  if(k.includes('@shop_layout_price.price_unit_')){instances++;const def=raw[k.split('.')[1]];assert.ok(def);for(const name of Object.keys(def).filter(n=>/^\$u_[bs]\d+\|default$/.test(n))){const param=name.split('|')[0];assert.ok(param in v,'missing '+param);if(param.startsWith('$u_s'))assert.ok(Number.isInteger(v[param])&&v[param]>=0&&v[param]<640);else assert.match(v[param],/^#/);}}
  walk(v);
 }}walk(raw);assert.equal(instances,202);
 const resolved=require('./read_price_ui.cjs')(file,{keepLazy:true});assert.equal(JSON.stringify(resolved).includes('"$u_'),false,'all native price variables resolve before binding evaluation');
});
console.log(n+' lazy catalogue groups passed (native grid lifecycle/rendering needs Minecraft confirmation)');
