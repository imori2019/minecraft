const fs=require('node:fs'),path=require('node:path');
function expandPrices(ui){
 function value(x,vars,seen=new Set()){
  if(Array.isArray(x))return x.map(v=>value(v,vars));
  if(x&&typeof x==='object')return Object.fromEntries(Object.entries(x).map(([k,v])=>[k,value(v,vars)]));
  if(typeof x!=='string')return x;
  if(/^\$u_[a-z]+\d+$/.test(x)){
   if(seen.has(x))throw Error('cyclic price variable '+x);if(!(x in vars))throw Error('unbound price variable '+x);
   return value(vars[x],vars,new Set([...seen,x]));
  }
  if(/^\(\$u_/.test(x))return (x.match(/\$u_[a-z]+\d+/g)||[]).map(k=>String(value(k,vars,seen))).join('');
  return x;
 }
 function walk(x){
  if(Array.isArray(x))return x.map(walk);
  if(!x||typeof x!=='object')return x;
  const out={};for(const[k,v]of Object.entries(x)){
   const marker='@shop_layout_price.price_unit_';if(k.includes(marker)){
    const name=k.split('@')[0],ref=k.split('.')[1],def=ui[ref];if(!def)throw Error('missing '+ref);
    const vars={};for(const[n,val]of Object.entries(def))if(n.startsWith('$u_'))vars[n.split('|')[0]]=val;
    for(const[n,val]of Object.entries(v))if(n.startsWith('$u_'))vars[n]=val;
    const body=Object.fromEntries(Object.entries(def).filter(([n])=>!n.startsWith('$u_')));
    const overrides=Object.fromEntries(Object.entries(v).filter(([n])=>!n.startsWith('$u_')));
    out[name]=walk(value({...body,...overrides},vars));
   }else out[k]=walk(v);
  }return out;
 }
 const body=Object.fromEntries(Object.entries(ui).filter(([k])=>!k.startsWith('price_unit_')));return walk(body);
}
function read(file,options={}){
 const ui=expandPrices(JSON.parse(fs.readFileSync(file||path.join(__dirname,'../resource_pack/ui/shop_layout_price.json'),'utf8')));
 if(options.keepLazy)return ui;
 for(const entry of ui.sh_content.controls){
  const name=Object.keys(entry)[0],node=entry[name],grid=node.controls?.find(x=>x.row_factory)?.row_factory;
  if(!grid)continue;
  const template=ui[grid.grid_item_template.split('.')[1]];entry[name]=structuredClone(template.controls[0][name]);
 }
 for(const key of Object.keys(ui))if(key.startsWith('lazy_sh_row'))delete ui[key];
 return ui;
}
read.expandPrices=expandPrices;module.exports=read;
