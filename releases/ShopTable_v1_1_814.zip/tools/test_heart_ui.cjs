const assert=require('node:assert/strict');
const unwrapParity=n=>['panel','stack_panel'].includes(n?.type)&&n.controls?.length===2&&n.controls[0].e&&n.controls[1].o?n.controls[0].e:n;
const fs=require('node:fs');
const path=require('node:path');
const heartTests=require('./test_heart_shop.cjs');
const {run}=require('./test_smelt_sales.cjs');
const ui=JSON.parse(fs.readFileSync(path.join(__dirname,'../resource_pack/ui/data_driven_container_screen.json'),'utf8'));
let count=0;
function test(name,fn){fn();count++;console.log('PASS HEART UI '+name);}
function visit(value,fn,parent=null,key=''){
 if(Array.isArray(value)){for(const x of value)visit(x,fn,parent,key);return;}
 if(!value||typeof value!=='object')return;
 fn(value,parent,key);
 for(const [k,x]of Object.entries(value)){
  if(k==='controls'){for(const entry of x)for(const [name,node]of Object.entries(entry))visit(node,fn,value,name);}
 }
}
const root=ui.heart_type_dd_unit;
const stack=ui.settings_scroll_content.controls[0].settings_scroll_stack.controls;
const heart=stack.find(x=>x.heart_payment).heart_payment;
test('heart header, hover, radio visuals and native click mapping are transplanted from payment-method dropdown',()=>{
 const normalize=x=>JSON.parse(JSON.stringify(x).replaceAll('heart_type_dd','payment_method_dd'));
 for(const tail of ['closed_header_surface','radio_visuals','radio_visuals_checked@data_driven_container.heart_type_dd_radio_visuals','radio_visuals_unchecked@data_driven_container.heart_type_dd_radio_visuals','header_click_signal@common.radio_toggle','outside_close_button@common.container_slot_button_prototype']){
  const original=tail.replaceAll('heart_type_dd','payment_method_dd');assert.deepEqual(normalize(ui['heart_type_dd_'+tail]),ui['payment_method_dd_'+original]);
 }
 const template=ui['payment_method_dd_direct_select_button_0@common.radio_toggle'];
 for(let i=0;i<12;i++){
  const button=normalize(ui[`heart_type_dd_direct_select_button_${i}@common.radio_toggle`]);
  button.$radio_label_text=template.$radio_label_text;button.$toggle_group_default_selected=template.$toggle_group_default_selected;button.$toggle_group_forced_index=template.$toggle_group_forced_index;
  assert.deepEqual(button,template);
 }
});
test('the dropdown uses the existing scrolling panel with twelve original native rows and no page controls',()=>{
 const controls=ui.heart_type_dd_scroll_content.controls;assert.equal(controls.length,12);
 const slots=JSON.parse(JSON.stringify(run(`HEART_CHOICE_SLOTS`)));
 for(let i=0;i<12;i++){
  const row=controls[i][`heart_type_dd_cmd_row_${i}`];assert.equal(row.collection_name,'container_items');
  const native=Object.values(row.controls[0])[0];assert.equal(native.collection_index,slots[i]);assert.equal(native.$button_ref,`data_driven_container.heart_type_dd_direct_select_button_${i}`);
 }
 const original=ui.payment_method_dd_unit.controls.find(x=>x.payment_method_dd_count_dropdown_state).payment_method_dd_count_dropdown_state;
 const copied=root.controls.find(x=>x.heart_type_dd_count_dropdown_state).heart_type_dd_count_dropdown_state;
 assert.deepEqual(copied.size,original.size);assert.deepEqual(copied.controls[0].dropdown_state_case.controls[0],JSON.parse(JSON.stringify(original.controls[0].dropdown_state_case.controls[0]).replaceAll('payment_method_dd','heart_type_dd')));
 let panel;visit(root,(node,parent,key)=>{if(key==='options_scroll@common.scrolling_panel')panel=node;});
 const price=require('./read_price_ui.cjs')();
 const source=price.pp_right_content.controls[4].class_body.controls[1].c_dept.controls[1].dept_dd.controls[3].open.controls[0].v.controls[2]['dept_scroll@common.scrolling_panel'];
 const adjusted={...panel,$scrolling_content:source.$scrolling_content,$scroll_view_name:source.$scroll_view_name,layer:source.layer};assert.deepEqual(adjusted,source);
 assert.equal(JSON.stringify(root).includes('次へ'),false);assert.equal(JSON.stringify(root).includes('heart_page'),false);
 assert.equal(Object.keys(ui).some(k=>/^heart_type_choice_/.test(k)),false);
});
test('all twelve saved selections have the original restore and hover-label structure',()=>{
 const restore=root.controls.find(x=>x.heart_type_dd_restore_visual_state).heart_type_dd_restore_visual_state;
 const hover=ui.heart_type_dd_closed_header_hover_vanilla.controls.find(x=>x.current_text).current_text;
 assert.equal(restore.controls.length,12);assert.equal(hover.controls.length,12);
 for(let i=0;i<12;i++){
  const node=restore.controls[i][`restore_case_${i}`];assert.equal(node.collection_index,42);assert.ok(node.bindings[1].source_property_name.includes(`'${i+3}'`));
  assert.equal(node.controls[0][`restore_header_${i}`].controls[1].text.text,ui[`heart_type_dd_direct_select_button_${i}@common.radio_toggle`].$radio_label_text);
 }
});
test('the strength label caches its own named header until visibility changes',()=>{
 const found=new Set();
 visit(heart,(node,parent,key)=>{
  if(!key.endsWith('_saved_overlay_text'))return;
  assert.ok(key.startsWith('heart_'));
  const field=key.startsWith('heart_duration')?'heart_duration':'heart_level';found.add(field);
  assert.equal(node.collection_index,field==='heart_duration'?200:199);
  for(const b of node.bindings)assert.equal(b.binding_condition,'visibility_changed');
 });
 assert.deepEqual([...found].sort(),['heart_level']);
});
test('duration input and the opened keypad both use the four-digit clock renderer',()=>{
 let inline=0,pads=0;
 visit(heart,(_,parent,key)=>{
  if(key.startsWith('digits@data_driven_container.heart_clock_digit_text'))inline++;
  if(key==='kp_open_heart_duration@data_driven_container.heart_clock_pad_open')pads++;
 });
 assert.equal(inline,1);assert.equal(pads,1);
 let clockDigits=0;visit(ui.heart_clock_digit_text,node=>{if([165,166,167,168].includes(node.collection_index))clockDigits++;});assert.equal(clockDigits,40);
 assert.deepEqual(ui.heart_clock_pad_open.size,[150,'100%c']);
});
test('visible and clicked field headers always have the formatted value as their item name',()=>{
 run(`saveDropdownChoice(block,DROPDOWN_BY_ID.get('heart_type'),5);setStringProp(block,'heart_level','2');setStringProp(block,'heart_duration','1530');kpReset(rec);kpWriteAll(shopInv,block,rec,player);`);
 assert.equal(run(`shopInv.getItem(199).nameTag`),'2');assert.equal(run(`shopInv.getItem(200).nameTag`),'15:30');
 run(`kpOpen(rec,block,KP_BY_ID.get('heart_duration'));rec.kpBuf='3000';kpStore(rec,block);kpWriteAll(shopInv,block,rec,player)`);
 assert.equal(run(`shopInv.getItem(200).nameTag`),'30:00');assert.equal(run(`shopInv.getItem(200).amount`),2);
 run(`kpClose(player,rec,block,shopInv);finishHeartVisual();`);
 assert.equal(run(`shopInv.getItem(200).nameTag`),'30:00');assert.equal(run(`shopInv.getItem(200).amount`),3);
});
test('cursor hover-text resets do not clear or replace the cached strength value',()=>{
 // Simulate the binding invalidations caused by native inventory/cursor changes.
 // The bindings come from the shipped UI, not from a separately configured fixture.
 const labels=[];visit(heart,(node,parent,key)=>{if(key.endsWith('_saved_overlay_text'))labels.push(node);});
 assert.equal(labels.length,1);
 for(const node of labels){
  const value=node.collection_index===199?'2':'15:30';let visible=false,shown;
  function apply(nextVisible,hover){
   const changed=visible!==nextVisible;visible=nextVisible;
   const read=node.bindings[0];
   if(visible&&(read.binding_condition==='always'||changed))shown=hover;
   return shown;
  }
  assert.equal(apply(true,value),value);
  for(let pickup=0;pickup<6;pickup++){
   assert.equal(apply(true,''),value);
   assert.equal(apply(true,'item.shopuilook2:decision_probe.name'),value);
   assert.equal(apply(true,value),value);
  }
  // A real field edit hides then reveals the label and publishes the new value.
  apply(false,'');const edited=node.collection_index===199?'3':'30:00';
  assert.equal(apply(true,edited),edited);
 }
});
function renderedClock(){
 const clock=ui.heart_clock_digit_text;const result=[];
 for(let i=0;i<4;i++){
  const cell=clock.controls.find(x=>x[`digit_cell_${i}`])[`digit_cell_${i}`];
  assert.equal(cell.collection_name,'container_items');
  const visible=cell.controls.map(x=>Object.values(x)[0]).filter(label=>{
   const amount=run(`shopInv.getItem(${label.collection_index})?.amount`);
   return label.bindings[1].source_property_name.endsWith(`= '${amount}')`);
  });
  assert.equal(visible.length,1,`clock cell ${i} must render exactly one digit`);result.push(visible[0].text);
 }
 return result.slice(0,2).join('')+':'+result.slice(2).join('');
}
test('clock digits have their own collection scopes and fixed positions including the colon',()=>{
 const clock=ui.heart_clock_digit_text;
 assert.equal(clock.type,'panel');
 for(let i=0;i<4;i++){
  const cell=clock.controls.find(x=>x[`digit_cell_${i}`])[`digit_cell_${i}`];
  assert.equal(cell.type,'collection_panel');assert.equal(cell.collection_name,'container_items');
  assert.deepEqual(cell.size,[6,10]);assert.deepEqual(cell.offset,[[0,0],[6,0],[15,0],[21,0]][i]);
  for(const entry of cell.controls){const label=Object.values(entry)[0];assert.equal(label.collection_index,[165,166,167,168][i]);assert.deepEqual(label.size,[6,10]);assert.equal(label.font_type,'classic');assert.equal(label.property_bag['#font_type'],'classic');assert.match(label.text,/^[0-9]$/);}
 }
 assert.deepEqual(clock.controls.find(x=>x.colon).colon.offset,[12,0]);
 const colon=clock.controls.find(x=>x.colon).colon;assert.equal(colon.type,'panel');assert.equal(colon.controls.length,2);for(const dot of colon.controls){const image=Object.values(dot)[0];assert.equal(image.type,'image');assert.equal(image.texture,'textures/ui/White');assert.deepEqual(image.size,[1,1]);}
});
test('real keypad clicks start at 00:00 and display every raw digit with a stationary colon',()=>{
 run(`finishHeartVisual();kpReset(rec);setStringProp(block,'heart_duration','1530');kpWriteAll(shopInv,block,rec,player);shopInv.setItem(200,undefined);kpHandleClick(player,rec,block,shopInv)`);
 assert.equal(renderedClock(),'00:00');assert.equal(run(`getStringProp(block,'heart_duration','')`),'1530');
 for(const [digit,expected]of [[1,'00:01'],[5,'00:15'],[3,'01:53'],[0,'15:30']]){
  run(`shopInv.setItem(KP_DIGIT_BASE+${digit},undefined);kpHandleClick(player,rec,block,shopInv)`);assert.equal(renderedClock(),expected);
  assert.deepEqual(ui.heart_clock_digit_text.controls.find(x=>x.colon).colon.offset,[12,0]);
 }
 run(`kpClose(player,rec,block,shopInv);finishHeartVisual()`);
 assert.equal(run(`getStringProp(block,'heart_duration','')`),'1530');assert.equal(run(`shopInv.getItem(200).nameTag`),'15:30');
});
test('opening the zeroed clock without typing preserves the saved duration on close or field switch',()=>{
 run(`shopInv.setItem(200,undefined);kpHandleClick(player,rec,block,shopInv)`);assert.equal(renderedClock(),'00:00');
 run(`kpClose(player,rec,block,shopInv);finishHeartVisual()`);
 assert.equal(run(`getStringProp(block,'heart_duration','')`),'1530');
 run(`shopInv.setItem(200,undefined);kpHandleClick(player,rec,block,shopInv);shopInv.setItem(199,undefined);kpHandleClick(player,rec,block,shopInv);finishHeartVisual()`);
 assert.equal(run(`getStringProp(block,'heart_duration','')`),'1530');
 run(`kpClose(player,rec,block,shopInv);finishHeartVisual()`);
});
test('raw clock input rounds on confirmation and saved short times keep both minute digits',()=>{
 run(`kpOpen(rec,block,KP_BY_ID.get('heart_duration'));kpWriteAll(shopInv,block,rec,player)`);
 for(const d of [4,5])run(`shopInv.setItem(KP_DIGIT_BASE+${d},undefined);kpHandleClick(player,rec,block,shopInv)`);
 assert.equal(renderedClock(),'00:45');
 run(`kpClose(player,rec,block,shopInv);finishHeartVisual()`);assert.equal(run(`shopInv.getItem(200).nameTag`),'01:00');
 assert.equal(run(`formatFieldDisplay('heart_duration','30')`),'00:30');
 run(`kpOpen(rec,block,KP_BY_ID.get('heart_duration'));kpWriteAll(shopInv,block,rec,player)`);
 for(const d of [6,0,0,0])run(`shopInv.setItem(KP_DIGIT_BASE+${d},undefined);kpHandleClick(player,rec,block,shopInv)`);
 assert.equal(renderedClock(),'60:00');run(`kpClose(player,rec,block,shopInv);finishHeartVisual()`);
 assert.equal(run(`getStringProp(block,'heart_duration','')`),'6000');
});
test('configured heart products show only the effect glyph in the owner product list',()=>{
 const env=require('./test_smelt_sales.cjs');
 for(let type=0;type<12;type++){
  env.prep();run(`active.clear();setCurrentProduct(block,undefined);block.typeId='shopuilook2:panel_heart';const r=base('p1');r.settings.shop_heart_product=true;r.settings.shop_heart_type=${type};r.settings.heart_level='1';r.settings.heart_duration='1530';putProducts([r]);globalThis.lr={landingFloorId:'d1'};writeLanding(player,lr,block,shopInv);`);
  const text=run(`shopInv.getItem(LANDING_STOCK_COUNT_SLOTS[0]).nameTag`);
  assert.equal(text,run(`HEART_PAY[HEART_TYPES[${type}]].glyph`));assert.equal([...text].length,1);assert.equal(run(`shopInv.getItem(LANDING_STOCK_COUNT_SLOTS[0]).amount`),8+type);
  assert.match(run(`transactionText(loadProduct(block,'p1').settings)`),/代償/);
 }
 env.prep();run(`block.typeId='shopuilook2:panel_furnace';putProducts([base('p1')]);globalThis.lr={landingFloorId:'d1'};writeLanding(player,lr,block,shopInv)`);
 assert.equal(run(`shopInv.getItem(LANDING_STOCK_COUNT_SLOTS[0]).nameTag`),'100');
});
test('all product-list price/glyph labels explicitly force the classic font',()=>{
 const landing=JSON.parse(fs.readFileSync(path.join(__dirname,'../resource_pack/ui/shop_layout_landing.json'),'utf8'));let labels=0;
 visit(landing.landing_page,(node,parent,key)=>{
  if(!key.startsWith('count_')||node.type!=='label')return;
  assert.equal(node.font_type,'classic');assert.equal(node.property_bag['#font_type'],'classic');
  assert.ok(node.bindings.some(x=>x.source_property_name==='#font_type'&&x.target_property_name==='#font_type'));labels++;
 });assert.equal(labels,27);
});
test('clock position and renderer remain identical before, during and after editing, including another open field',()=>{
 let field;visit(heart,(node,parent,key)=>{if(key==='heart_duration')field=node;});
 assert.ok(field);assert.equal(field.controls.some(x=>x.heart_duration_saved_overlay),false);
 const display=field.controls.find(x=>x.kpd_heart_duration).kpd_heart_duration;
 assert.deepEqual(display.offset,[5,17]);assert.deepEqual(display.size,[116,10]);
 assert.deepEqual(display.controls,[{'digits@data_driven_container.heart_clock_digit_text':{}}]);
 const signature=JSON.stringify(display);
 // Restore an editor after the product-list checks above.
 run(`block.typeId='shopuilook2:panel_heart';kpReset(rec);setStringProp(block,'heart_duration','1530');saveDropdownChoice(block,DROPDOWN_BY_ID.get('heart_type'),5);kpWriteAll(shopInv,block,rec,player)`);
 assert.equal(renderedClock(),'15:30');
 run(`kpOpen(rec,block,KP_BY_ID.get('heart_duration'));kpWriteAll(shopInv,block,rec,player)`);assert.equal(renderedClock(),'00:00');
 for(const d of [1,5,3,0])run(`shopInv.setItem(KP_DIGIT_BASE+${d},undefined);kpHandleClick(player,rec,block,shopInv)`);
 assert.equal(renderedClock(),'15:30');run(`kpClose(player,rec,block,shopInv)`);assert.equal(renderedClock(),'15:30');
 run(`finishHeartVisual()`);assert.equal(renderedClock(),'15:30');
 run(`kpOpen(rec,block,KP_BY_ID.get('heart_level'));rec.kpBuf='7';kpStore(rec,block);kpWriteAll(shopInv,block,rec,player)`);
 assert.equal(renderedClock(),'15:30');assert.equal(JSON.stringify(display),signature);
 run(`kpClose(player,rec,block,shopInv);finishHeartVisual()`);
 assert.equal(renderedClock(),'15:30');
});
test('every product-list effect uses a static existing image and exactly one image matches each native state',()=>{
 const landing=JSON.parse(fs.readFileSync(path.join(__dirname,'../resource_pack/ui/shop_layout_landing.json'),'utf8'));let panels=0;
 const ids=JSON.parse(JSON.stringify(run(`HEART_TYPES`)));
 visit(landing.landing_page,(node,parent,key)=>{
  if(!key.startsWith('product_stock_overlay_'))return;panels++;
  const count=node.controls[0][Object.keys(node.controls[0])[0]];
  const marks=node.controls.filter(x=>Object.keys(x)[0].startsWith('heart_effect_')).map(x=>Object.values(x)[0]);assert.equal(marks.length,12);
  for(let type=0;type<12;type++){
   const visible=marks.filter(image=>image.bindings[1].source_property_name.endsWith(`= '${8+type}')`));assert.equal(visible.length,1);
   const image=visible[0];assert.equal(image.type,'image');assert.equal(image.collection_index,count.collection_index);assert.deepEqual(image.size,[8,8]);assert.deepEqual(image.offset,[-2,-2]);assert.equal(image.anchor_from,'bottom_right');assert.equal(image.anchor_to,'bottom_right');
   assert.equal(image.texture,run(`HEART_ICON_TEXTURES[${JSON.stringify(ids[type])}]`));
   assert.ok(fs.existsSync(path.join(__dirname,'../resource_pack',image.texture+'.png')));
   assert.equal(image.bindings.some(x=>x.binding_name==='#hover_text'),false);
  }
 });assert.equal(panels,27);
});
test('both buyer-list and deal-panel time labels are selected from raw heart data before text is available',()=>{
 const price=require('./read_price_ui.cjs')();
 const totals={sh_content:run('SH_ROWS')*4,sh_rp_content:(128+(run('RP_B.reduce((n,g)=>n+g.cells.length,0)')-8)*4)/4-6};
 for(const [key,expected]of Object.entries(totals)){
  let variants=0;
  visit(price[key],node=>{
   if(!node.controls?.some(x=>x.heart_price_native))return;
   const row=node.controls.find(x=>x.prow).prow;
   const glyph=unwrapParity(row.controls.find(x=>x.t2).t2),native=unwrapParity(node.controls.find(x=>x.heart_price_native).heart_price_native);
   assert.equal(glyph.type,'label');
   assert.equal(glyph.font_scale_factor,key==='sh_content'?0.375:0.36);
   assert.equal(native.font_scale_factor,0.88);assert.ok(['always','visibility_changed'].includes(native.bindings[0].binding_condition));
   const visible=native.bindings.find(x=>x.target_property_name==='#visible').source_property_name;
   assert.equal(visible.includes('#text'),false);assert.ok(visible.includes(native.bindings[0].binding_name_override));
   const text=native.bindings.find(x=>x.target_property_name==='#text').source_property_name;
   assert.equal(text.includes(' - \'0\''),false);assert.equal(text.includes(' - \':\''),false);variants++;
  });assert.equal(variants,expected,key);
 }
});
test('the exact first buyer-list card can reveal its time before its label text is populated',()=>{
 const price=require('./read_price_ui.cjs')();let label;
 visit(price.sh_content,(node,parent,key)=>{const u=unwrapParity(node);if(key==='heart_price_native'&&u?.collection_index===92&&!label)label=u;});assert.ok(label);
 const raw=run(`leftPrice`);assert.equal(typeof raw,'string');
 const condition=label.bindings.find(x=>x.target_property_name==='#visible').source_property_name;
 assert.equal(condition.includes('#text'),false);
 const literals=[...condition.matchAll(/'([^']*)'/g)].map(x=>x[1]);let stripped=raw;for(const x of literals)stripped=stripped.replaceAll(x,'');assert.notEqual(stripped,raw);
 const expression=label.bindings.find(x=>x.target_property_name==='#text').source_property_name;
 let shown=raw;for(const x of [...expression.matchAll(/'([^']*)'/g)].map(x=>x[1]))shown=shown.replaceAll(x,'');assert.equal(shown,'0:30');   // v1.1.703: 「1個」は出さない
});
test('gauge dropdown labels use words and player events define every bounded maximum while retaining vanilla events',()=>{
 assert.equal(ui['heart_type_dd_direct_select_button_11@common.radio_toggle'].$radio_label_text,'体力ゲージ');
 assert.equal(JSON.stringify(heart).includes('♥'),false);
 const entity=JSON.parse(fs.readFileSync(path.join(__dirname,'../behavior_pack/entities/player.json'),'utf8'))['minecraft:entity'];
 assert.equal(entity.description.identifier,'minecraft:player');
 for(const name of ['minecraft:clear_add_raid_omen','minecraft:remove_raid_trigger','minecraft:gain_raid_omen','minecraft:trigger_raid'])assert.ok(entity.events[name]);
 const names=entity.events['shopuilook2:heart_gauge_reset'].remove.component_groups;assert.equal(names.length,512);
 for(let hearts=1;hearts<=512;hearts++){
  const name='shopuilook2:heart_gauge_'+hearts;
  assert.deepEqual(entity.component_groups[name]['minecraft:health'],{value:hearts*2,max:hearts*2});
  assert.deepEqual(entity.events[name].add.component_groups,[name]);assert.ok(names.includes(name));
 }
});
test('UI control inheritance resolves for every new heart component',()=>{
 const definitions=new Set(Object.keys(ui).map(k=>k.split('@')[0]));
 visit(heart,(node,_,key)=>{
  if(key.includes('@data_driven_container.'))assert.ok(definitions.has(key.split('@data_driven_container.')[1]),key);
 });
});
console.log(`${count} heart UI test groups passed; ${require('./test_smelt_sales.cjs').getTestCount()+heartTests.getHeartTestCount()+count} total test groups passed (API simulation and UI structure; Minecraft rendering not executed)`);
