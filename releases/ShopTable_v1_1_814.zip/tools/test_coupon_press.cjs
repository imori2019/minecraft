// v1.1.804 枚数の欄（テンキー）も。v1.1.803 セール画面で「この内容でクーポンを発行」を押すと、フォームを出さずに1枚その場で発行（画面は閉じない）。元のボタンも壊さない
const assert=require('node:assert/strict');const {run,prep,shopInv}=require('./test_smelt_sales.cjs');
const setup=(mode,rate)=>{prep();shopInv.size=640;
 run(`globalThis.R={};getBlockStoreId=()=>'s1';globalThis.calls=[];openLandingForm=()=>calls.push('landing');forceCloseScreen=()=>true;tell=(p,m)=>calls.push('TELL '+m);globalThis.given=[];giveOrDrop=(p,it)=>given.push(it);player.playSound=id=>calls.push('SND '+id);lxHandleStatusClick=()=>false;pricePending.clear();
 const C=getContainer(block);setProbe(C,LP.pricePoints,TEXT_GATE_SHOWN);setProbe(C,LX.btnCard,1);setProbe(C,LP.salesManagement,2);for(const s of [LX.btnMoney,LX.btnReq,LX.btnExtra]) setProbe(C,s,2);
 enterPriceMode(player,R,block,C);const u=R.priceMode.ui;u.gOpen=u.cOpen=u.dailyOpen=false;u.${mode}=true;writePriceUI(C,R);for(let i=0;i<4;i++)tickPriceMode(player,R,block,C);
 ${rate?"ppKpStore(R.priceMode,ppContext(R.priceMode,loadStores().stores.s1,block),'"+rate+"');writePriceUI(C,R);":""}`);};
const press=slot=>{assert.ok(shopInv.items.get(slot),'probe at '+slot);shopInv.items.delete(slot);run(`const C=getContainer(block);for(let i=0;i<3&&R.priceMode;i++)tickPriceMode(player,R,block,C);`);};
const scopeOf=()=>run('(shopCouponInfo(given[0])?.floor||undefined)');
let n=0;
for(const [mode,slot] of [['gOpen',251],['cOpen',253],['dailyOpen',251]]){
 setup(mode,12);press(slot);
 assert.equal(run('given.reduce((n,i)=>n+i.amount,0)'),1,mode+': one coupon per press');assert.equal(run('shopCouponInfo(given[0]).rate'),12);assert.match(run('given[0].getLore().join()'),/X 0  Y 64  Z 0/,'native sale button records shop coordinates');
 assert.equal(scopeOf()===undefined,mode==='gOpen',mode+': store-wide only for the global sale');
 assert.equal(run('R.priceMode?1:0'),1,'no form: the screen stays open');assert.ok(!run('calls.includes("landing")'));
 assert.ok(run('calls.includes("SND random.levelup")'),'point card sound');assert.ok(shopInv.items.get(slot),'button is ready again');
 press(slot);assert.equal(run('given.reduce((n,i)=>n+i.amount,0)'),2,'press again for another');n++;
 setup(mode,0);press(slot);assert.equal(run('R.priceMode?1:0'),1,'stays open');assert.match(run('calls.join()'),/先に割引率/);assert.equal(run('given.reduce((n,i)=>n+i.amount,0)'),0);n++;
}
for(const [mode,slot,cnt] of [['gOpen',251,252],['cOpen',253,94],['dailyOpen',251,252]]){
 setup(mode,15);
 assert.match(run(`getContainer(block).getItem(${cnt})?.nameTag??''`),/1 枚/,mode+': count field shows 1 枚');
 press(cnt);assert.equal(run('R.priceMode.ui.kpTarget'),'cpcount',mode+': the count field opens the keypad');
 const key=d=>{press(run('PP_KP_KEY_DIGITS['+d+']'));};
 key(1);key(0);assert.equal(run('R.priceMode.ui.cpCount'),10);
 key(0);assert.equal(run('R.priceMode.ui.cpCount'),10,'two digits at most');
 const back=()=>press(run('PP_KP_KEY_BACK'));back();back();key(7);key(0);assert.equal(run('R.priceMode.ui.cpCount'),64,'capped at 64');
 back();back();key(5);assert.equal(run('R.priceMode.ui.cpCount'),5);
 run(`writePriceUI(getContainer(block),R)`);
 press(slot);assert.equal(run('given.reduce((n,i)=>n+i.amount,0)'),5,mode+': issues the typed count');assert.equal(run('R.priceMode.ui.kpOpen'),false);
 assert.match(run(`getContainer(block).getItem(${cnt})?.nameTag??''`),/5 枚/);
 n++;
}
setup('cOpen');press(251);assert.equal(run('R.priceMode.ui.kpTarget'),'pend','class end date still opens its keypad');n++;
setup('dailyOpen');press(253);assert.equal(run('R.priceMode.ui.cbOpen'),true,'daily time type still opens');n++;
setup('cOpen');press(252);assert.equal(run('R.priceMode.ui.kpTarget'),'hend','class hours end still opens its keypad');n++;
setup('dailyOpen');press(94);assert.equal(run('R.priceMode.ui.dayOpen'),true,'daily expiry-day dropdown still opens');n++;
setup('gOpen',10);press(252);run(`writePriceUI(getContainer(block),R)`);assert.equal(run('getContainer(block).getItem(PP_KP_HEADER).amount'),15,'keypad s15 is shown');n++;
console.log('PASS COUPON PRESS '+n+' checks (API simulation; no Minecraft runtime)');
