const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {run}=require('./test_smelt_sales.cjs');
const ui=require('./read_price_ui.cjs')();
const variants=Object.assign({},...ui.sh_price_more_by_width.controls);let checks=0;
for(const [old,fresh,sp,mid]of [[1,1],[10,10],[12,5],[125,5],[125,25],[9999,9999],[10000,5000],[123456,10000],[999999999,1234567],[100,20,true,40]]){
 const entry={k:'item',id:'minecraft:emerald',n:old,n2:fresh,sp,mid};
 const text=run(`shopPriceSizedGlyphText(${JSON.stringify(entry)},true,'dark')`);
 const code=2+run(`shopPriceMoreClass(${JSON.stringify(text)})`);const image=variants['w'+code];assert.ok(image,'width variant for '+old+'/'+fresh);
 const normal=run(`shopNum(${fresh})`);const crossed=sp&&mid!==old?String(mid):String(old);
 const count=old===fresh?normal.length:crossed.length+normal.length;const hasGap=old!==fresh;
 const expectedInkWidth=(16*count-1+(hasGap?2:0))*0.36;
 assert.ok(Math.abs(image.offset[0]+image.size[0]/2-expectedInkWidth/2)<0.00001,'center matches bitmap ink, '+old+'/'+fresh);
 checks++;
}
assert.equal(ui.sh_price_more_by_width.controls.length,60);
console.log('PASS '+checks+' price widths: one/two/many digits, crossed-out prices, popular discounts and k/M/+ use their own exact center');
