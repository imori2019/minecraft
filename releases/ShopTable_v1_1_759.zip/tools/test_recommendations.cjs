const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');const env=require('./test_smelt_sales.cjs');const {run,ctx,Container,prep}=env;
let count=0;function test(name,fn){fn();count++;console.log('PASS RECOMMEND '+name);}
ctx.shopInv=new Container(640);prep();
run(`block.typeId='shopuilook2:panel';SHOP_BAKE_ON.clear();globalThis.realShopBestPrice=shopBestPrice;
 globalThis.recRates=[10,70,50,90,20,60,80,0,100];
 const list=recRates.map((rate,i)=>{const p=base('rec'+i,'minecraft:apple');p.testRate=rate;return p;});
 putProducts(list);for(const p of list) {if(p.testRate===100){p.stock=[];saveProduct(block,p);}setProductFloor(block,p.id,'d1');}
 globalThis.quoteRates=new Map(list.map(p=>[p.id,p.testRate]));
 shopBestPrice=(rec)=>{const rate=quoteRates.get(rec.id)??0;return {entries:[{k:'item',id:'minecraft:emerald',n:100,n2:100-rate}],discounted:rate>0,saving:rate};};
 globalThis.recMode={floorId:'d1',player,history:false,bakeOn:false,onlyAffordable:false,rowWindowIndex:0};`);
test('each floor has a single group of at most six products, ordered by effective discount rate',()=>{
 run(`globalThis.m=shopModel(recMode,block,registry.stores.s1);globalThis.recs=shopDealModel(recMode,block,m,pricePointSettingsForStore(registry.stores.s1),[],shopNow());`);
 assert.equal(run('recs.groups.length'),1);assert.deepEqual(JSON.parse(run('JSON.stringify(recs.groups[0].ids)')),['rec3','rec6','rec1','rec5','rec2','rec4']);
});
test('the affordable-only filter is respected before selecting the top six',()=>{
 run(`recMode.onlyAffordable=true;m.allowedIds=new Set(['rec0','rec1','rec3']);globalThis.filtered=shopDealModel(recMode,block,m,pricePointSettingsForStore(registry.stores.s1),[],shopNow());recMode.onlyAffordable=false;`);
 assert.deepEqual(JSON.parse(run('JSON.stringify(filtered.groups[0].ids)')),['rec3','rec1','rec0']);
});
test('discount rate takes priority over a large absolute reduction',()=>{
 assert.ok(run('shopRecommendationScore([{n:10,n2:2}]).rate')>run('shopRecommendationScore([{n:1000,n2:500}]).rate'));
 assert.deepEqual(JSON.parse(run('JSON.stringify(shopRecommendationScore([{n:100,n2:100}]))')),{rate:0,saving:0});
});
test('the fifth and sixth recommendations use their own complete price and click-probe slots',()=>{
 run(`globalThis.recommendRec={};enterShopMode(player,recommendRec,block,shopInv);`);
 assert.equal(run('recommendRec.shopMode.dealCells.get(586)?.id'),'rec2');assert.equal(run('recommendRec.shopMode.dealCells.get(589)?.id'),'rec4');
 assert.equal(run('SH_DEAL_PROBE.get(586)'),598);assert.equal(run('SH_DEAL_PROBE.get(589)'),599);
 assert.ok(run('isProbe(shopInv.getItem(598))&&isProbe(shopInv.getItem(599))'));
 assert.ok(run('shopInv.getItem(587)?.nameTag.length>0&&shopInv.getItem(590)?.nameTag.length>0'));
});
test('both recommendation groups have six image/price pairs and correct private probes',()=>{
 const ui=require('./read_price_ui.cjs')();
 for(let g=0;g<2;g++){
  const group=ui.sh_rp_content.controls.find(x=>x['b_grp'+g+'_four'])['b_grp'+g+'_four'];
  for(let c=0;c<6;c++){
   const image=group.controls.find(x=>x['c_b'+g+'_'+c])['c_b'+g+'_'+c],price=group.controls.find(x=>x['pbox_b'+g+'_'+c])['pbox_b'+g+'_'+c];
   const refs=[];function walk(o){if(!o||typeof o!=='object')return;if(typeof o.collection_index==='number')refs.push(o.collection_index);Object.values(o).forEach(walk);}walk(image);
   assert.ok(refs.includes(run(`RP_B[${g}].cells[${c}].cell`)));assert.ok(refs.includes(run(`SH_DEAL_PROBE.get(RP_B[${g}].cells[${c}].cell)`)));
   assert.ok(price.offset[1]+price.size[1]<=group.size[1]);
  }
 }
});
console.log(count+' recommendation tests passed (API and UI simulation; no Minecraft runtime)');
