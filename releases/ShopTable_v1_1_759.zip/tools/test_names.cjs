// v1.1.697 店の名前の表示（最大24文字）が切れないこと・画面の部品が重ならないこと
const assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path');
const env=require('./test_smelt_sales.cjs');
const {run}=env;
let count=0;
function test(name,fn){fn();count++;console.log('PASS NAME '+name);}
const long='あいうえおかきくけこさしすせそたちつてとなにぬね';   // 全角24文字（店の名前の最大）
const src=fs.readFileSync(path.join(__dirname,'../behavior_pack/scripts/main.js'),'utf8');
test('a 24-character store name is shown in full where the name has room',()=>{
 assert.equal([...long].length,run(`STORE_NAME_MAX`));
 assert.equal(run(`displayStoreName(${JSON.stringify(long)},STORE_NAME_FULL_WIDTH)`),long);
 assert.equal(run(`fitWidth(${JSON.stringify(long)},STORE_NAME_FULL_WIDTH)`),long);
 assert.equal(run(`fitWidth(${JSON.stringify(long+'x')},STORE_NAME_FULL_WIDTH)`).endsWith('…'),true,'longer text is still cut');
 assert.match(src,/LX\.title, `§2Lv\.\$\{storeXpInfo\(store\)\.lv\} §8/);
 assert.match(src,/SH_TITLE, `§2Lv\.\$\{storeXpInfo\(store\)\.lv\} §8/);
});
test('store page dropdown shows 17 full-width characters (0.8x font) instead of 12',()=>{
 assert.equal([...run(`displayStoreName(${JSON.stringify(long)},STORE_DD_WIDTH)`)].length,17);
});
test('landing title row: level box, wide name box and the icons do not overlap',()=>{
 const L=JSON.parse(fs.readFileSync(path.join(__dirname,'../resource_pack/ui/shop_layout_landing.json'),'utf8'));
 const c=Object.fromEntries(L.landing_page.controls[0].landing_vis.controls.map(x=>{const k=Object.keys(x)[0];return [k.split('@')[0],x[k]];}));
 const r=k=>[c[k].offset[0],c[k].offset[0]+c[k].size[0]];
 assert.deepEqual(r('lxh11'),r('lxt12'),'level tooltip follows combined title');
 assert.equal(c.lxt1.ignored,true,'old separate level is hidden');
 assert.ok(r('lxt12')[1]<=r('lxc14')[0]);
 assert.ok(r('lxt12')[1]-r('lxt12')[0]>=24*9,'24 full-width glyphs (9px each) fit');
 assert.ok(r('lxc19')[1]<=362-8,'icons stay inside the panel');
 assert.equal(c.lxi13.offset[0]-c.lxc14.offset[0],3,'pencil keeps its place on its button');
});
test('store page text fields are widened to the free right side and stay inside the page',()=>{
 const d=JSON.parse(fs.readFileSync(path.join(__dirname,'../resource_pack/ui/shop_layout_store.json'),'utf8'));
 const body=JSON.stringify(d);
 for(const k of ['f_name','f_desc','f_owner','f_group']){const m=new RegExp('"'+k+'":\\s*\\{\\s*"type":\\s*"panel",\\s*"size":\\s*\\[330,\\s*34\\]').test(body);assert.ok(m,k);}
 assert.ok(9+330<=360);
});
test('heart health price shows only the time (no heart count), on one line like the other curses',()=>{
 assert.deepEqual(JSON.parse(run(`JSON.stringify(shopCardPriceLines([{k:'heart',id:'x',n:2,n2:2,heart:{health:true,level:2,seconds:60}}]))`)),['1:00','']);
 assert.equal(run(`heartEntryText({heart:{health:true,level:2,seconds:60}},2)`),'2:00','two units = double the time');
 assert.equal(run(`heartEntryText({n2:60,heart:{level:1,seconds:60}},2)`),'2:00');
});
console.log(count+' name test groups passed');
