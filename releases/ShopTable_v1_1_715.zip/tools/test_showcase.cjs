const assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path');
const env=require('./test_smelt_sales.cjs');
const {run,prep,ctx,handlers}=env;
let count=0;
function test(name,fn){fn();count++;console.log('PASS SHOWCASE '+name);}
const plain=v=>JSON.parse(JSON.stringify(v));
const read=f=>JSON.parse(fs.readFileSync(path.join(__dirname,'..',f),'utf8'));
run(`
globalThis.scEnts=[];globalThis.scCase=true;
block.above=()=>({typeId:scCase?'shopuilook2:panel_furnace_case':'minecraft:air'});
block.dimension.getEntities=o=>o.type===SC_ID?scEnts.filter(e=>e.valid):[];
block.dimension.spawnEntity=(id,loc)=>{const p=new Map(),e={typeId:id,location:loc,valid:true,turn:0,pose:new Map(),
 getDynamicProperty:k=>p.get(k),setDynamicProperty:(k,v)=>p.set(k,v),remove(){this.valid=false;},
 runCommand(){throw Error('showcase models must never equip a held item');},
 getProperty:k=>k==='shopuilook2:turn'?e.turn:e.pose.get(k),setProperty:(k,v)=>{if(k==='shopuilook2:turn')e.turn=v;else e.pose.set(k,v);}};scEnts.push(e);return e;};
world.getDimension=()=>block.dimension;
`);
function reset(ids){prep();run(`scEnts=[];scCase=true;SC_TEST=null;scEmptyUntil.clear();scKindCache.clear();system.currentTick=1000;putProducts(${JSON.stringify(ids)}.map((x,i)=>base('p'+(i+1),x)));`);}
const live=()=>plain(run(`scEnts.filter(e=>e.valid).map(e=>scCurrentItem(e))`));
const visual=id=>plain(run(`scVisual(${JSON.stringify(id)})`));
const prop=k=>run(`scEnts[0].getProperty('shopuilook2:${k}')`);
test('one centered display rotates products only after the full 16-second turn, without equipment commands',()=>{
 reset(['minecraft:porkchop','minecraft:stone']);run(`scShowcase(block)`);
 assert.deepEqual(live(),['minecraft:porkchop']);assert.equal(prop('shape'),0);
 const before=run(`scEnts[0].turn`);
 run(`system.currentTick+=300;scShowcase(block)`);assert.deepEqual(live(),['minecraft:porkchop']);
 run(`system.currentTick+=20;scShowcase(block)`);assert.deepEqual(live(),['minecraft:stone']);
 assert.equal(prop('shape'),1);assert.equal(prop('texture'),visual('minecraft:stone').texture);assert.notEqual(run(`scEnts[0].turn`),before);
 run(`system.currentTick+=320;scShowcase(block)`);assert.deepEqual(live(),['minecraft:porkchop']);assert.equal(prop('shape'),0);
 assert.equal(prop('texture'),visual('minecraft:porkchop').texture);assert.equal(run(`scEnts.length`),1);
});
test('no case or no sellable merchandise removes the showcase',()=>{
 reset(['minecraft:stone']);run(`scShowcase(block);scCase=false;scShowcase(block)`);assert.deepEqual(live(),[]);
 reset([]);run(`saveProductIndex(block,[]);scShowcase(block)`);assert.deepEqual(live(),[]);
});
test('removed merchandise disappears from the next revolution',()=>{
 reset(['minecraft:apple','minecraft:stone']);run(`scShowcase(block);deleteProduct(block,'p2');system.currentTick+=320;scShowcase(block)`);
 assert.deepEqual(live(),['minecraft:apple']);
});
test('a failed visual property update skips that item and continues the carousel',()=>{
 reset(['minecraft:stone','minecraft:raw_iron','minecraft:apple']);run(`scShowcase(block);const e=scEnts[0];const original=e.setProperty;e.setProperty=function(k,v){if(k==='shopuilook2:texture'&&v===scVisual('minecraft:raw_iron').texture)throw Error('injected property failure');return original.call(this,k,v);};system.currentTick+=320;scShowcase(block)`);
 assert.deepEqual(live(),['minecraft:apple']);
});
test('flat-item and block defaults are both level; all old hand-angle settings are ignored without being deleted',()=>{
 reset(['minecraft:stone']);run(`world.setDynamicProperty('shopuilook2:sc_pose3',JSON.stringify({rx:-75,rr:-20,fox:1}));world.setDynamicProperty('shopuilook2:sc_profiles_v1',JSON.stringify({block:{rx:80,ry:50},item:{rx:-60,rr:-15}}));`);
 const expected={rx:0,ry:0,rz:0,px:0,py:0,pz:0,rr:0};
 assert.deepEqual(plain(run(`scPose('block')`)),expected);assert.deepEqual(plain(run(`scPose('item')`)),expected);
 run(`scShowcase(block)`);for(const k of ['rx','ry','rz','rr','px','py','pz'])assert.equal(prop(k),0,k);
 assert.ok(run(`world.getDynamicProperty('shopuilook2:sc_pose3')`));
});
test('classic cubes, logs, front-facing furnaces and grass resolve to their own standalone textures',()=>{
 const ids=['minecraft:stone','minecraft:oak_log','minecraft:furnace','minecraft:grass_block'];
 const v=ids.map(visual);v.forEach(x=>{assert.equal(x.shape,1);assert.ok(x.texture>=0);});
 assert.equal(new Set(v.map(x=>x.texture)).size,ids.length);
});
test('slabs, stairs, carpets and trapdoors have explicit geometry; flowers and special blocks retain inventory pictures',()=>{
 for(const [id,shape] of [['oak_slab',2],['oak_stairs',3],['red_carpet',4],['oak_trapdoor',5]])assert.equal(visual('minecraft:'+id).shape,shape,id);
 for(const id of ['poppy','hopper','chest','lantern']){assert.equal(visual('minecraft:'+id).shape,0,id);assert.notEqual(visual('minecraft:'+id).texture,visual('otherpack:unregistered_item').texture,id);}
});
test('raw meat aliases, buckets, tools, spawn eggs and addon effect rewards select real icons',()=>{
 const unknown=visual('otherpack:unregistered_item').texture;
 for(const id of ['porkchop','beef','chicken','raw_iron','lava_bucket','diamond_sword','cow_spawn_egg']){
  const v=visual('minecraft:'+id);assert.equal(v.shape,0);assert.notEqual(v.texture,unknown,id);
 }
 assert.notEqual(visual('shopuilook2:buff_night_vision').texture,unknown);
 assert.notEqual(visual('shopuilook2:panel_furnace').texture,unknown);
});
const command=handlers.find(f=>f.toString().includes('ev.id !== "shoptable:showcase"'));
assert.ok(command);
const originalRun=ctx.system.run,nativeBlockGet=ctx.BlockTypes.get;
ctx.system.run=f=>f();ctx.BlockTypes.get=id=>['minecraft:stone','minecraft:oak_log'].includes(id)?{id}:undefined;
run(`player.typeId='minecraft:player';`);
function send(message){command({id:'shoptable:showcase',sourceEntity:env.player,message});}
const profile=t=>plain(run(`scPose(${JSON.stringify(t)})`));
test('manual group and item-specific adjustments remain independent and survive product swaps',()=>{
 reset(['minecraft:apple','minecraft:stone']);send('item rz 3');send('block ry 45');send('minecraft:stone py 2');
 run(`scShowcase(block)`);assert.equal(prop('rz'),3);assert.equal(prop('py'),0);
 run(`system.currentTick+=320;scShowcase(block)`);assert.equal(prop('rz'),0);assert.equal(prop('ry'),45);assert.equal(prop('py'),2);
 send('block ry 20');assert.equal(profile('minecraft:stone').ry,45,'explicit per-item record retains its calibration');
 assert.equal(profile('minecraft:oak_log').ry,20);
});
test('manual edits stop comparison and use the visible candidate; invalid input never saves partial changes',()=>{
 reset(['minecraft:stone']);send('block test');run(`SC_TEST.i=3`);send('block rr 2');
 assert.equal(run(`SC_TEST`),null);assert.equal(profile('block').rz,15);assert.equal(profile('block').rr,2);
 const saved=run(`world.getDynamicProperty(SC_PROFILES_PROP)`);send('block rx 30 ry invalid');assert.equal(run(`world.getDynamicProperty(SC_PROFILES_PROP)`),saved);
});
test('comparison pick saves only its group; stop restores saved values and reset returns a level model',()=>{
 reset(['minecraft:stone']);send('block test');send('pick 2');assert.equal(profile('block').rx,-15);assert.equal(profile('item').rx,0);
 send('block center');run(`SC_TEST.i=1`);send('stop');assert.equal(profile('block').px,0);
 send('block reset');assert.equal(profile('block').rx,0);
});
test('a v712 entity with an existing item id refreshes to the new mesh even before its next product turn',()=>{
 reset(['minecraft:stone']);run(`scShowcase(block);scEnts[0].pose.clear();scEnts[0].getDynamicProperty=(function(orig){return function(k){return k==='shopuilook2:home'?'0,64,0':orig.call(this,k);};})(scEnts[0].getDynamicProperty);block.dimension.getBlock=()=>block;scCleanup('minecraft:overworld');`);
 assert.equal(prop('shape'),1);assert.equal(prop('texture'),visual('minecraft:stone').texture);assert.equal(prop('rx'),0);
});
test('every authored mesh has the same bounding-box center and upright Y axis throughout a full rotation',()=>{
 const geos=read('resource_pack/models/entity/showcase_item.geo.json')['minecraft:geometry'];assert.equal(geos.length,6);
 for(const geo of geos){
  const bones=Object.fromEntries(geo.bones.map(b=>[b.name,b]));
  for(const b of geo.bones)assert.ok(!/rightitem|held_item|untilt|unyaw/i.test(b.name),'no native hand bone remains');
  for(const name of ['spin','offset','roll','tilt','display'])assert.deepEqual(bones[name].pivot,[0,8,0],`${geo.description.identifier}/${name}`);
  const pts=[];for(const box of bones.display.cubes)for(const x of [0,1])for(const y of [0,1])for(const z of [0,1])pts.push(box.origin.map((v,i)=>v+box.size[i]*[x,y,z][i]));
  const center=[0,1,2].map(i=>(Math.min(...pts.map(p=>p[i]))+Math.max(...pts.map(p=>p[i])))/2);assert.deepEqual(center,[0,8,0],geo.description.identifier);
  for(let angle=0;angle<360;angle+=15){
   const a=angle*Math.PI/180;const rotated=pts.map(([x,y,z])=>[x*Math.cos(a)-z*Math.sin(a),y,x*Math.sin(a)+z*Math.cos(a)]);
   for(const i of [0,2])assert.ok(Math.abs((Math.min(...rotated.map(p=>p[i]))+Math.max(...rotated.map(p=>p[i])))/2)<1e-10,'rotation never orbits the vertical centre');
  }
 }
});
test('client renderer binds every catalog entry to a valid model, standalone texture and synced property range',()=>{
 const entity=read('resource_pack/entity/showcase_item.entity.json')['minecraft:client_entity'].description;
 assert.notEqual(entity.enable_attachables,true);assert.equal(entity.render_controllers.length,1);
 const rc=read('resource_pack/render_controllers/showcase_item.render_controllers.json').render_controllers[entity.render_controllers[0]];
 const props=read('behavior_pack/entities/showcase_item.json')['minecraft:entity'].description.properties;
 const all=plain(run(`({blocks:SC_BLOCK_VISUALS,flats:SC_FLAT_VISUALS,info:SC_DISPLAY_INFO})`));
 assert.equal(rc.arrays.textures['Array.images'].length,all.info.textures);
 for(const id of [...Object.keys(all.blocks),...Object.keys(all.flats)]){
  const v=visual(id);for(const [k,n] of Object.entries(v)){assert.ok(Number.isInteger(n),id+'/'+k);const range=props['shopuilook2:'+k].range;assert.ok(n>=range[0]&&n<=range[1],id+'/'+k);}
  assert.ok(v.shape<rc.arrays.geometries['Array.models'].length);assert.ok(v.texture<rc.arrays.textures['Array.images'].length);
 }
 for(const name of rc.arrays.textures['Array.images'])assert.ok(entity.textures[name.replace('Texture.','')],name);
 for(const name of rc.arrays.geometries['Array.models'])assert.ok(entity.geometry[name.replace('Geometry.','')],name);
 assert.equal(read('behavior_pack/entities/showcase_item.json')['minecraft:entity'].components['minecraft:scale'].value,1,'the model pivot is not scaled below the case centre');
});
test('fixed face UVs never depend on unsupported dynamic atlas cropping, and items have silhouette sidewalls',()=>{
 const rc=read('resource_pack/render_controllers/showcase_item.render_controllers.json').render_controllers['controller.render.shopuilook2.showcase_model'];
 assert.equal(rc.uv_anim,undefined,'no dynamic crop can accidentally expose a global atlas');
 const entity=read('resource_pack/entity/showcase_item.entity.json')['minecraft:client_entity'].description;
 for(const [id,v] of Object.entries(plain(run(`SC_BLOCK_VISUALS`)))){
  const reference=rc.arrays.textures['Array.images'][v[0]].replace('Texture.','');
  assert.ok(entity.textures[reference].startsWith('textures/shopuilook2/showcase/blocks/b'),id);
 }
 const flat=read('resource_pack/models/entity/showcase_item.geo.json')['minecraft:geometry'][0];
 const cubes=flat.bones.find(b=>b.name==='display').cubes;
 assert.equal(cubes[0].size[2],.625,'one sprite pixel of thickness relative to a 16-pixel item');
 for(const face of ['east','west','up','down'])assert.ok(cubes.some(c=>c.uv[face]),face+' silhouette surface exists');
 assert.ok(cubes.length<100,'extrusion uses shared strips rather than one cube per pixel');
});
test('animation rotates around a fixed centre with only explicit user corrections, never hidden hand offsets',()=>{
 const bones=read('resource_pack/animations/showcase_item.animation.json').animations['animation.shopuilook2.showcase_item.spin'].bones;
 assert.deepEqual(Object.keys(bones).sort(),['offset','roll','spin','tilt']);assert.deepEqual(bones.spin.rotation,[0,'q.anim_time * 22.5',0]);assert.deepEqual(bones.spin.position,[0,0,0]);
 assert.deepEqual(bones.tilt.rotation,["q.property('shopuilook2:rx')","q.property('shopuilook2:ry')","q.property('shopuilook2:rz')"]);
});
test('glass cases continue to transmit light',()=>{
 const dir=path.join(__dirname,'../behavior_pack/blocks');for(const f of fs.readdirSync(dir).filter(f=>f.endsWith('_case.json')))assert.equal(read('behavior_pack/blocks/'+f)['minecraft:block'].components['minecraft:light_dampening'],0,f);
});
ctx.system.run=originalRun;ctx.BlockTypes.get=nativeBlockGet;
console.log(count+' showcase test groups passed (API and asset simulation; Minecraft renderer not executed)');
