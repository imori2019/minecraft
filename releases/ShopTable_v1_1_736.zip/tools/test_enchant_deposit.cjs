const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {run,prep}=require('./test_smelt_sales.cjs');let n=0;
const plain=x=>JSON.parse(JSON.stringify(x));
function test(name,fn){fn();n++;console.log('PASS DEPOSIT '+name);}
run(`globalThis.originalFzCommit=fzCommitText;deferVisualCommit=(p,r,apply)=>apply(block,shopInv);`);
function reset(){prep();run(`block.typeId='shopuilook2:panel_enchant';player.level=37;globalThis.sounds=[];player.playSound=(id)=>sounds.push(id);
 canManageStore=()=>true;fzCommitText=originalFzCommit;registry.stores.s1.enchant={levels:10,mats:[{id:'minecraft:lapis_lazuli',n:20}],auto:true};
 globalThis.dep={storeId:'s1',fzKind:'enchant',block,player,btnReadyTick:0,kpOpen:false,kpClosing:false,enDepositBuf:'0'};
 globalThis.depRec={extraMode:dep};system.currentTick=1000;crWriteScreen(shopInv,dep);fzCommitText(player,depRec);`);}
const tap=slot=>run(`shopInv.setItem(${slot},undefined);enDepositTick(player,depRec,block,shopInv)`);
test('native keypad accepts a chosen amount, shows all six digits, and Enter only closes the input',()=>{
 reset();tap(run('FZ_KP_HEADER'));assert.equal(run('dep.kpOpen'),true);
 for(const d of [1,2,3,4,5,6])tap(run('KP_DIGIT_BASE')+d);
 assert.equal(run('dep.enDepositBuf'),'123456');
 assert.equal(run('shopInv.getItem(FZ_FEE_TXT).nameTag'),'123456');
 assert.ok([2,3].includes(run('shopInv.getItem(FZ_FEE_TXT).amount')));
 tap(run('KP_CLEAR'));assert.equal(run('dep.kpClosing'),true);assert.equal(run('player.level'),37);assert.equal(run('crState(registry.stores.s1,"enchant").levels'),10);assert.equal(run('sounds.length'),0);
 run('depRec.pendingVisual.apply(block,shopInv)');assert.equal(run('dep.kpClosing'),false);assert.equal(run('shopInv.getItem(FZ_KP_HEADER).amount'),3);
});
test('deposit button moves exactly the typed levels and plays the XP sound once',()=>{
 reset();tap(run('FZ_KP_HEADER'));for(const d of [1,2])tap(run('KP_DIGIT_BASE')+d);
 tap(run('FZ_CAPTURE'));
 assert.equal(run('player.level'),25);assert.equal(run('crState(registry.stores.s1,"enchant").levels'),22);assert.deepEqual(plain(run('sounds')),['random.orb']);
 assert.equal(run('dep.enDepositBuf'),'0');assert.equal(run('crState(registry.stores.s1,"enchant").mats[0].n'),20);
 assert.equal(run('shopInv.getItem(FZ_FEE_TXT).nameTag'),'0');
});
test('zero, malformed, excessive or unavailable amounts never transfer or make a sound',()=>{
 for(const amount of ['0','-1','1.5','abc','1000000','38']){
  reset();run(`dep.enDepositBuf=${JSON.stringify(amount)};enDepositLevels(player,dep)`);
  assert.equal(run('player.level'),37);assert.equal(run('crState(registry.stores.s1,"enchant").levels'),10);assert.equal(run('sounds.length'),0);
 }
});
test('persistence failure refunds the player and never credits the shop or plays success audio',()=>{
 reset();run(`dep.enDepositBuf='12';failSaveStores=true;enDepositLevels(player,dep)`);
 assert.equal(run('player.level'),37);assert.equal(run('crState(registry.stores.s1,"enchant").levels'),10);assert.equal(run('sounds.length'),0);
});
test('level API failure, partial deduction, and lost ownership cannot create stored experience',()=>{
 reset();run(`globalThis.savedAddLevels=player.addLevels;dep.enDepositBuf='12';player.addLevels=()=>{throw Error('unavailable')};enDepositLevels(player,dep);player.addLevels=savedAddLevels`);
 assert.equal(run('player.level'),37);assert.equal(run('crState(registry.stores.s1,"enchant").levels'),10);
 reset();run(`dep.enDepositBuf='12';player.addLevels=function(amount){this.level+=amount;if(amount<0)throw Error('partial failure')};enDepositLevels(player,dep)`);
 assert.equal(run('player.level'),37);assert.equal(run('crState(registry.stores.s1,"enchant").levels'),10);
 reset();run(`canManageStore=()=>false;dep.enDepositBuf='12';enDepositLevels(player,dep)`);
 assert.equal(run('player.level'),37);assert.equal(run('crState(registry.stores.s1,"enchant").levels'),10);assert.equal(run('sounds.length'),0);
});
test('material slots always keep their working direct layout; the keypad has its own click shield',()=>{
 const ui=JSON.parse(fs.readFileSync(path.join(__dirname,'../resource_pack/ui/shop_proceeds_screen.json'),'utf8'));
 const ctl=x=>Object.assign({},...x.controls);const v=ctl(ctl(ctl(ctl(ui.screen).gate).furnace_only).v);const en=ctl(ctl(v.enchant_pen_cp).enchant_pen);
 const field=en.en_deposit_field;
 const materialSlots=Object.entries(en).filter(([k])=>/^cr_mat[0-9]+$/.test(k)&&Number(k.slice(6))<45);
 assert.equal(materialSlots.length,45);assert.equal(en.en_materials_grid,undefined,'no visibility gate can hide the material grid');
 for(const [,x]of materialSlots){assert.ok(x.offset[1]>=field.offset[1]+field.size[1]);assert.ok(x.offset[0]+x.size[0]<=358);assert.ok(x.offset[1]+x.size[1]<=190);}
 const mask=en.en_keypad_input_mask;
 assert.ok(mask.layer>Math.max(...materialSlots.map(([,x])=>x.layer))&&mask.layer<en.en_deposit_keypad.layer);
 assert.equal(ctl(mask).gate.collection_index,192);
 const shield=ctl(ctl(mask).gate)['input_mask@common.container_item'];
 assert.equal(shield.collection_index,192);
 assert.equal(shield.$button_ref,'shop_proceeds_screen.en_keypad_mask_button');
 assert.equal(ui['en_keypad_mask_button@data_driven_container.text_input_group_action'].$highlight_control,'common.empty_panel','transparent shield must not render a hover border');
 const native=JSON.parse(fs.readFileSync(path.join(__dirname,'../resource_pack/ui/data_driven_container_screen.json'),'utf8'));
 const keypadSize=native.kpgen_pad_open.controls[0].clip.controls[0].body.size;
 assert.deepEqual(mask.size,keypadSize);assert.deepEqual(shield.size,keypadSize);
 assert.ok(en.en_deposit.offset[0]>=field.offset[0]+field.size[0]);
 assert.ok(en.en_deposit.offset[1]+en.en_deposit.size[1]<=96);
 assert.equal(en.en_deposit_keypad.controls[0]['kp_open_fee@data_driven_container.kpgen_pad_open'].collection_index,192);
 const input=ctl(field);assert.ok(input['amount_digits@shop_proceeds_screen.en_deposit_digits']);
 const valueReaders=[];function visit(x){if(!x||typeof x!=='object')return;if(x.type==='label')valueReaders.push(x);Object.values(x).forEach(visit);}visit(ui.en_deposit_digits);
 assert.equal(valueReaders.length,2);assert.ok(valueReaders.every(x=>x.collection_index===128));
 assert.equal(input.fee_click_area.controls[0]['fee_signal@common.container_item'].$button_ref,'data_driven_container.text_input_group_action');
});
test('currency and point prices share the same numerical start in every right-hand card',()=>{
 const ui=JSON.parse(fs.readFileSync(path.join(__dirname,'../resource_pack/ui/shop_layout_price.json'),'utf8'));let rows=0;
 for(const entry of ui.sh_rp_content.controls)for(const group of Object.values(entry))for(const child of group.controls??[])for(const [key,box]of Object.entries(child)){
  if(!key.startsWith('pbox_')||!box.controls?.length)continue;
  const primary=Object.values(box.controls[0])[0];
  for(const variant of primary.controls??[]){const node=Object.values(variant)[0],gate=node.controls?.[0]?.v;if(!gate)continue;const row=gate.controls.find(x=>x.prow)?.prow;if(!row)continue;
   assert.equal(row.offset[0],9);assert.equal(row.controls.find(x=>x.ibox).ibox.size[0],11);rows++;
  }
 }
 assert.equal(rows,144);
});
console.log(n+' enchant deposit/UI tests passed (API simulation; no Minecraft runtime)');
