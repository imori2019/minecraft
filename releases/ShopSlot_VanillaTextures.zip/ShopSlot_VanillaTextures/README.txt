﻿専用スロット用 本家テクスチャ
出典：Mojang公式 bedrock-samples
https://github.com/Mojang/bedrock-samples

番号1〜13に対応する画像34枚です。PNGは取得した元画像のままで、拡大・着色・透過率の変更はしていません。
本は通常の本とエンチャント本、満たされたバケツは水と溶岩、地面ブロックは土と砂を用意しました。
エンチャント本の光る効果はゲーム側が重ねるため、この元画像だけには光るアニメーションはありません。
土と砂はブロック表面の16×16テクスチャです。立体アイコンの画像ではありません。
preview.pngは確認用の拡大一覧です。texturesフォルダーのPNGが元画像です。
アドオンの番号画像への差し替えは、まだ行っていません。
各画像の取得URLとSHA256はsources.jsonに記録しています。

 1 レコード : textures/01_record_cat.png
 2 本 : textures/02_book.png
 2 エンチャント本 : textures/02_book_enchanted.png
 3 ラピスラズリ : textures/03_lapis_lazuli.png
 4 水入りバケツ : textures/04_water_bucket.png
 4 溶岩入りバケツ : textures/04_lava_bucket.png
 5 空のバケツ : textures/05_empty_bucket.png
 6 土 : textures/06_dirt.png
 6 砂 : textures/06_sand.png
 7 骨粉 : textures/07_bone_meal.png
 8 紙 : textures/08_paper.png
 9 コンパス : textures/09_compass.png
10 矢 : textures/10_arrow.png
11 ブレイズパウダー : textures/11_blaze_powder.png
12 ガラス瓶 : textures/12_glass_bottle.png
13 ネザライト強化 : textures/13_smithing_templates/netherite_upgrade_smithing_template.png
13 略奪者風の装飾 : textures/13_smithing_templates/sentry_armor_trim_smithing_template.png
13 砂丘風の装飾 : textures/13_smithing_templates/dune_armor_trim_smithing_template.png
13 海洋風の装飾 : textures/13_smithing_templates/coast_armor_trim_smithing_template.png
13 密林風の装飾 : textures/13_smithing_templates/wild_armor_trim_smithing_template.png
13 監獄風の装飾 : textures/13_smithing_templates/ward_armor_trim_smithing_template.png
13 要塞風の装飾 : textures/13_smithing_templates/eye_armor_trim_smithing_template.png
13 ヴェックス風の装飾 : textures/13_smithing_templates/vex_armor_trim_smithing_template.png
13 潮流風の装飾 : textures/13_smithing_templates/tide_armor_trim_smithing_template.png
13 ブタの鼻風の装飾 : textures/13_smithing_templates/snout_armor_trim_smithing_template.png
13 あばら模様風の装飾 : textures/13_smithing_templates/rib_armor_trim_smithing_template.png
13 尖塔風の装飾 : textures/13_smithing_templates/spire_armor_trim_smithing_template.png
13 静寂風の装飾 : textures/13_smithing_templates/silence_armor_trim_smithing_template.png
13 先駆者風の装飾 : textures/13_smithing_templates/wayfinder_armor_trim_smithing_template.png
13 牧者風の装飾 : textures/13_smithing_templates/raiser_armor_trim_smithing_template.png
13 職人風の装飾 : textures/13_smithing_templates/shaper_armor_trim_smithing_template.png
13 主人風の装飾 : textures/13_smithing_templates/host_armor_trim_smithing_template.png
13 旋風の装飾 : textures/13_smithing_templates/flow_armor_trim_smithing_template.png
13 ネジ止め風の装飾 : textures/13_smithing_templates/bolt_armor_trim_smithing_template.png
