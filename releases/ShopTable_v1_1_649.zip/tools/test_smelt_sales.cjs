const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
// These tests simulate Bedrock APIs; they do not run Minecraft itself.
const root = require('node:path').resolve(__dirname, '..');
class ItemStack {
  constructor(id, amount = 1) { this.typeId = id; this.amount = amount; this.maxAmount = /_(sword|pickaxe|helmet)$/.test(id) ? 1 : 64; this.props = {}; this.lore = []; this.ench = []; }
  get localizationKey() { return `item.${this.typeId.replace('minecraft:', '')}.name`; }
  clone() { const out = new ItemStack(this.typeId, this.amount); Object.assign(out, structuredClone({...this})); return out; }
  getLore() { return [...this.lore]; }
  setLore(v) { this.lore = [...v]; }
  getDynamicProperty(k) { return this.props[k]; }
  getDynamicPropertyIds() { return Object.keys(this.props); }
  setDynamicProperty(k,v) { this.props[k] = v; }
  getComponent(k) { if(k === 'minecraft:enchantable') return {getEnchantments:()=>this.ench, addEnchantment:e=>this.ench.push(e)}; }
  isStackableWith(other) { const a = this.clone(), b = other.clone(); a.amount=b.amount=1; return JSON.stringify(a) === JSON.stringify(b); }
  hasTag() { return false; }
}
class Container {
  constructor(size) { this.size=size; this.items=new Map(); this.failSlot=null; }
  getItem(i) { return this.items.get(i)?.clone(); }
  setItem(i,item) { if(this.failSlot===i) {this.failSlot=null; throw Error('injected delivery failure');} if(item) this.items.set(i,item.clone()); else this.items.delete(i); }
}
class PriceModal {
 constructor(){this.fields=[];}
 title(value){this.titleText=value;return this;}
 toggle(label,options){this.toggleLabel=label;this.toggleOptions=options;return this;}
 textField(label,placeholder,options){this.fields.push({label,placeholder,...options});return this;}
 submitButton(){return this;}
}
const handlers=[], intervals=[];
const events=new Proxy({}, {get:()=>({subscribe:f=>handlers.push(f)})});
const props=new Map(), worldProps=new Map();
const playerInv=new Container(36), shopInv=new Container(256);
const player={id:'P1',name:'Player',level:0,getComponent:k=>k==='minecraft:inventory'?{container:playerInv}:undefined,
  getDynamicProperty:()=>undefined,setDynamicProperty:()=>{},sendMessage:()=>{},addLevels(n){this.level+=n;},addExperience:()=>{}};
const world={afterEvents:events,beforeEvents:events,getAllPlayers:()=>[player],getPlayers:()=>[player],
  getDynamicProperty:k=>worldProps.get(k),setDynamicProperty:(k,v)=>worldProps.set(k,v),getTimeOfDay:()=>6000};
const ctx=vm.createContext({console, ItemStack, world, system:{currentTick:1000,afterEvents:events,runInterval:f=>intervals.push(f),runTimeout:()=>{},run:()=>{}},
  ItemTypes:{get:id=>({id}),getAll:()=>[]},BlockTypes:{get:id=>({id})},EnchantmentTypes:{get:id=>({id})},
  BlockPermutation:{},EquipmentSlot:{},MolangVariableMap:class{},Potions:{},ActionFormData:class{},ModalFormData:PriceModal,FormCancelationReason:{},
  structuredClone,player,playerInv,shopInv,props});
for(const name of ['ja_names.js','craft_recipes.js','main.js']) {
  const code=fs.readFileSync(`${root}/behavior_pack/scripts/${name}`,'utf8').replace(/^import .*;\r?\n/gm,'').replace(/^export /gm,'');
  vm.runInContext(code,ctx,{filename:name,timeout:10000});
}
console.log(`PASS full script initialization (${handlers.length} event subscriptions, ${intervals.length} intervals registered; game callbacks not simulated)`);
const run=s=>vm.runInContext(s,ctx);
const plain=x=>JSON.parse(JSON.stringify(x));
run(`
globalThis.registry = {stores:{s1:{id:'s1',name:'Test',departments:[{id:'d1',name:'食品'},{id:'d2',name:'素材'}],
  furnace:{enabled:true,pct:10,burn:64},blast:{enabled:true,pct:10,burn:64},smoker:{enabled:true,pct:10,burn:64}}},groups:{}};
globalThis.block={typeId:'shopuilook2:panel_furnace',location:{x:0,y:64,z:0},dimension:{id:'minecraft:overworld'}};
getProps=()=>({get:k=>props.get(k),set:(k,v)=>props.set(k,v)});
getBlockStoreId=()=> 's1';
loadStores=()=>JSON.parse(JSON.stringify(registry));
globalThis.failSaveStores=false;
saveStores=r=>{if(failSaveStores){failSaveStores=false;return false;} registry=JSON.parse(JSON.stringify(r));return true;};
getContainer=()=>shopInv;
shopCanSellNow=()=>true;
shopClosedReason=()=>'';
storeNoticePush=()=>{};
shopPurchaseAwardStoreXp=()=>0;
shopDebugEvent=()=>{};
globalThis.saleLog = [];
shopSaleRecordSuccess=(...args)=>saleLog.push(args);
globalThis.base = (id,item='minecraft:beef',count=1,n=16)=>({id,savedOnce:true,
 settings:{shop_product_name:'生の牛肉',shop_product_genre:'食品',price:'100',shop_payment_method:0},
 items:[{id:item,key:item,count,role:'sample',slot:17}],stock:[{slot:0,item:{id:item,amount:n}}]});
globalThis.putProducts=(products)=>{saveProductIndex(block,products.map(r=>r.id));for(const r of products) {saveProduct(block,r);setProductFloor(block,r.id,r.id==='p2'?'d2':'d1');}};
globalThis.mode={player,bakeOn:true,floorId:'d1',history:false};
SHOP_BAKE_ON.set(player.id,'furnace');
`);
let tests=1;
function test(name,fn){fn();tests++;console.log('PASS '+name);}
test('all three cooking rule matrices',()=>{
 const cases=[['beef','cooked_beef','', 'cooked_beef'],['raw_iron','iron_ingot','iron_ingot',''],['sand','glass','',''],['cobblestone','stone','',''],['potato','baked_potato','','baked_potato'],['iron_sword','iron_nugget','iron_nugget',''],['oak_log','charcoal','',''],['ancient_debris','netherite_scrap','netherite_scrap',''],['diamond','','','']];
 for(const [id,...targets] of cases) for(const [i,kind] of ['furnace','blast','smoker'].entries())
  assert.equal(ctx.fzSmeltOutput(`minecraft:${id}`,kind),targets[i]?`minecraft:${targets[i]}`:'',`${kind}/${id}`);
});
test('same floor and genre, source and cooked shown together',()=>{
 run(`putProducts([base('p1'),base('p2','minecraft:raw_iron')]);globalThis.model=shopModel(mode,block,loadStores().stores.s1);`);
 assert.deepEqual(plain(run(`model.rows[0].ids`)),['p1','baked:furnace:p1']);
 assert.equal(run(`productFloorId(block,'baked:furnace:p1',storeFloors(registry.stores.s1))`),'d1');
 assert.equal(run(`model.records.get('baked:furnace:p1').items[0].id`),'minecraft:cooked_beef');
 assert.equal(run(`loadProduct(block,'p1').items[0].id`),'minecraft:beef');
});
test('toggle off, owner disabled and non-cooking shop hide cooked variants',()=>{
 for(const change of [`mode.bakeOn=false`,`mode.bakeOn=true;registry.stores.s1.furnace.enabled=false`,`registry.stores.s1.furnace.enabled=true;block.typeId='shopuilook2:panel_crafter'`]){
  run(change);assert.equal(run(`shopModel(mode,block,registry.stores.s1).records.has('baked:furnace:p1')`),false);
 }
 run(`block.typeId='shopuilook2:panel_furnace';mode.bakeOn=true;registry.stores.s1.furnace.enabled=true`);
});
test('smoker excludes ores; blast excludes food; all other shops unchanged',()=>{
 for(const [type,kind,yes,no] of [['smoker','smoker','p1','p2'],['blast_furnace','blast','p2','p1']]){
  run(`block.typeId='shopuilook2:panel_${type}';SHOP_BAKE_ON.set(player.id,'${kind}');globalThis.model=shopModel(mode,block,registry.stores.s1)`);
  assert.equal(run(`model.records.has('baked:${kind}:${yes}')`),true);assert.equal(run(`model.records.has('baked:${kind}:${no}')`),false);
 }
 for(const type of ['panel','panel_spawner','panel_barrel','panel_composter','panel_crafter','panel_smith','panel_bulb','panel_anchor','panel_lodestone','panel_heart']){
  run(`block.typeId='shopuilook2:${type}'`);assert.equal(run(`[...shopModel(mode,block,registry.stores.s1).records.keys()].some(id=>id.startsWith('baked:'))`),false);
 }
 run(`block.typeId='shopuilook2:panel_furnace';SHOP_BAKE_ON.set(player.id,'furnace')`);
});
test('fee included once; raw prices and records unchanged',()=>{
 run(`globalThis.raw=loadProduct(block,'p1');globalThis.view=loadProduct(block,'baked:furnace:p1');globalThis.st=loadStores().stores.s1;`);
 assert.equal(run(`shopPurchasePrice(raw,st,'d1',1,player.id).entries[0].n2`),100);
 assert.equal(run(`shopPurchasePrice(view,st,'d1',1,player.id).entries[0].n2`),110);
 assert.equal(run(`shopPurchasePrice(view,st,'d1',2,player.id).items.values().next().value`),220);
 assert.equal(run(`shopBakeEntries([{n:100,n2:100}],view,null)[0].n2`),110);
 assert.equal(run(`shopBakeEntries([{n:100,n2:100}],raw,{pct:10,cap:64,kind:'furnace'})[0].n2`),100);
 assert.equal(run(`saveProduct(block,view).ok`),false);
 assert.equal(run(`loadProduct(block,'p1').settings.shop_product_name`),'生の牛肉');
});
test('delivery consumes source stock and cooks exactly once',()=>{
 run(`globalThis.plan=shopPurchaseStockPlan(view,2)`);
 assert.equal(run(`plan.delivery[0].typeId`),'minecraft:cooked_beef');assert.equal(run(`plan.delivery[0].amount`),2);
 assert.equal(run(`plan.stock[0].item.id`),'minecraft:beef');assert.equal(run(`plan.stock[0].item.amount`),14);
 assert.equal(run(`plan.bakedCount`),2);
 run(`globalThis.stone=base('p3','minecraft:cobblestone');globalThis.stoneView=fzSaleVariant(stone,'furnace',fzState(st,'furnace'))`);
 assert.equal(run(`shopPurchaseStockPlan(stoneView,1).delivery[0].typeId`),'minecraft:stone');
});
test('named/enhanced sample is not replaced; named stock is preserved',()=>{
 run(`globalThis.named=base('p3');named.items[0].key+='|n=名前';named.items[0].name='名前'`);
 assert.equal(run(`fzSaleVariant(named,'furnace',fzState(st,'furnace'))`),undefined);
 run(`globalThis.mixed=base('p3');mixed.stock.unshift({slot:1,item:{id:'minecraft:beef',amount:3,nameTag:'大事な牛肉'}});globalThis.mixedView=fzSaleVariant(mixed,'furnace',fzState(st,'furnace'));globalThis.mixPlan=shopPurchaseStockPlan(mixedView,2)`);
 assert.equal(run(`mixPlan.delivery[0].typeId`),'minecraft:cooked_beef');assert.equal(run(`mixPlan.stock.find(r=>r.slot===1).item.nameTag`),'大事な牛肉');
 assert.equal(run(`shopPurchaseRemaining(mixedView)`),16);
});
test('fuel shortages reject; zero fee still needs fuel; stale toggle rejected',()=>{
 run(`registry.stores.s1.furnace.burn=1;globalThis.st=loadStores().stores.s1;globalThis.view=loadProduct(block,'baked:furnace:p1')`);
 assert.equal(run(`shopPurchaseRemaining(view)`),1);assert.equal(run(`shopPurchasePrice(view,st,'d1',2,player.id).ok`),false);
 run(`registry.stores.s1.furnace.pct=0;globalThis.st=loadStores().stores.s1`);
 assert.equal(run(`shopPurchasePrice(view,st,'d1',1,player.id).bake.need`),1);
 run(`SHOP_BAKE_ON.delete(player.id)`);assert.equal(run(`shopPurchasePrice(view,st,'d1',1,player.id).ok`),false);
 run(`SHOP_BAKE_ON.set(player.id,'blast')`);assert.equal(run(`shopPurchasePrice(view,st,'d1',1,player.id).ok`),false);
 run(`SHOP_BAKE_ON.set(player.id,'furnace');registry.stores.s1.furnace.pct=10;registry.stores.s1.furnace.burn=64`);
});
// Exercise the actual commit/payment/delivery/rollback functions. Only game storage,
// scheduler, player APIs and unrelated XP/reporting side effects are adapters above.
function prep(){
 props.clear();worldProps.clear();playerInv.items.clear();shopInv.items.clear();
  run(`block.typeId='shopuilook2:panel_furnace';putProducts([base('p1')]);registry.stores.s1.owner={id:player.id,name:player.name};registry.stores.s1.furnace={enabled:true,pct:10,burn:64};SHOP_BAKE_ON.set(player.id,'furnace');saleLog=[];globalThis.currency=pricePointSettingsForStore(registry.stores.s1).currencies[0];playerInv.setItem(0,new ItemStack(currency,64));playerInv.setItem(1,new ItemStack(currency,64));playerInv.setItem(2,new ItemStack(currency,64));`);
}
test('end-to-end cooked purchase pays 110, shares raw stock and uses one fuel',()=>{
 prep();run(`globalThis.result=shopPurchaseCommit(player,block,'baked:furnace:p1',1)`);
 assert.equal(ctx.result.ok,true,ctx.result.message);
 assert.equal(run(`loadProduct(block,'p1').stock[0].item.amount`),15);
 assert.equal(run(`fzCapacity(fzState(loadStores().stores.s1,'furnace'))`),63);
 assert.equal(run(`fzState(loadStores().stores.s1,'furnace').used.total`),1);
 assert.equal([...playerInv.items.values()].reduce((n,i)=>n+i.amount,0),82);
 assert.equal([...shopInv.items.values()].filter(i=>i.typeId==='minecraft:cooked_beef').reduce((n,i)=>n+i.amount,0),1);
 assert.equal(run(`loadProduct(block,'p1').buyers.P1`),1);
 assert.deepEqual(plain(run(`loadProductIndex(block)`)),['p1']);
 assert.equal(run(`loadProduct(block,'p1').settings.shop_product_name`),'生の牛肉');
});
test('end-to-end raw purchase remains raw even while toggle is on',()=>{
 prep();run(`globalThis.result=shopPurchaseCommit(player,block,'p1',1)`);
 assert.equal(ctx.result.ok,true,ctx.result.message);assert.equal([...playerInv.items.values()].reduce((n,i)=>n+i.amount,0),92);
 assert.equal([...shopInv.items.values()].some(i=>i.typeId==='minecraft:beef'),true);
 assert.equal(run(`fzCapacity(fzState(loadStores().stores.s1,'furnace'))`),64);
});
test('source per-buyer limit is shared by raw and cooked purchases',()=>{
 prep();run(`globalThis.r=loadProduct(block,'p1');r.settings.shop_type_bind_choice=2;r.settings.limited_per_player_count='1';saveProduct(block,r);globalThis.result=shopPurchaseCommit(player,block,'baked:furnace:p1',1)`);
 assert.equal(ctx.result.ok,true,ctx.result.message);assert.equal(run(`shopPurchaseCommit(player,block,'p1',1).ok`),false);
});
test('delivery failure rolls back payment, source stock, fuel and usage count',()=>{
 prep();run(`shopInv.failSlot=SH_BOX_SLOTS[0];globalThis.result=shopPurchaseCommit(player,block,'baked:furnace:p1',1)`);
 assert.equal(ctx.result.ok,false);assert.match(ctx.result.message,/取り消/);
 assert.equal(run(`loadProduct(block,'p1').stock[0].item.amount`),16);
 assert.equal(run(`fzCapacity(fzState(loadStores().stores.s1,'furnace'))`),64);
 assert.equal(run(`fzState(loadStores().stores.s1,'furnace').used.total`),0);
 assert.equal([...playerInv.items.values()].reduce((n,i)=>n+i.amount,0),192);assert.equal(shopInv.items.size,0);
});
test('fuel persistence failure cancels before payment and delivery',()=>{
 prep();run(`failSaveStores=true;globalThis.result=shopPurchaseCommit(player,block,'baked:furnace:p1',1)`);
 assert.equal(ctx.result.ok,false);assert.equal(run(`loadProduct(block,'p1').stock[0].item.amount`),16);
 assert.equal(run(`fzCapacity(fzState(loadStores().stores.s1,'furnace'))`),64);
 assert.equal([...playerInv.items.values()].reduce((n,i)=>n+i.amount,0),192);assert.equal(shopInv.items.size,0);
});
test('blast and smoker actual purchase deliver only their allowed outputs',()=>{
 for(const [type,kind,input,output] of [['blast_furnace','blast','raw_iron','iron_ingot'],['smoker','smoker','beef','cooked_beef']]){
  prep();run(`block.typeId='shopuilook2:panel_${type}';putProducts([base('p1','minecraft:${input}')]);SHOP_BAKE_ON.set(player.id,'${kind}');globalThis.result=shopPurchaseCommit(player,block,'baked:${kind}:p1',1)`);
  assert.equal(ctx.result.ok,true,ctx.result.message);assert.equal([...shopInv.items.values()].some(i=>i.typeId===`minecraft:${output}`),true);
  assert.equal(run(`fzCapacity(fzState(loadStores().stores.s1,'${kind}'))`),63);
 }
 run(`block.typeId='shopuilook2:panel_furnace'`);
});
test('price changes, owner disable, exhausted fuel, deleted product and wrong shop are rejected without charging',()=>{
 const changes=[`registry.stores.s1.furnace.pct=20`,`registry.stores.s1.furnace.enabled=false`,`registry.stores.s1.furnace.burn=0`,`saveProductIndex(block,[])`,`block.typeId='shopuilook2:panel_smoker'`];
 for(const change of changes){
  run(`block.typeId='shopuilook2:panel_furnace'`);prep();
  run(`globalThis.quote=shopPurchaseQuote(shopPurchasePrice(loadProduct(block,'baked:furnace:p1'),registry.stores.s1,'d1',1,player.id),1);${change};globalThis.result=shopPurchaseCommit(player,block,'baked:furnace:p1',1,quote)`);
  assert.equal(ctx.result.ok,false,change);assert.equal([...playerInv.items.values()].reduce((n,i)=>n+i.amount,0),192);assert.equal(shopInv.items.size,0);
 }
 run(`block.typeId='shopuilook2:panel_furnace'`);
});
test('mixed set preserves unprocessable items and never double-smelts stone',()=>{
 prep();run(`globalThis.r=base('p1','minecraft:cobblestone');r.settings.shop_sale_type=1;r.items.push({id:'minecraft:diamond',key:'minecraft:diamond',count:1,role:'sample',slot:18});r.stock.push({slot:1,item:{id:'minecraft:diamond',amount:16}});putProducts([r]);globalThis.result=shopPurchaseCommit(player,block,'baked:furnace:p1',1)`);
 assert.equal(ctx.result.ok,true,ctx.result.message);
 assert.equal([...shopInv.items.values()].some(i=>i.typeId==='minecraft:stone'),true);assert.equal([...shopInv.items.values()].some(i=>i.typeId==='minecraft:diamond'),true);
 assert.equal([...shopInv.items.values()].some(i=>i.typeId==='minecraft:smooth_stone'),false);
 assert.equal(run(`fzCapacity(fzState(loadStores().stores.s1,'furnace'))`),63);
});
test('full delivery slots merge with cooked product, not the raw source',()=>{
 prep();run(`for(const slot of SH_BOX_SLOTS) shopInv.setItem(slot,new ItemStack('minecraft:diamond',64));shopInv.setItem(SH_BOX_SLOTS[0],new ItemStack('minecraft:cooked_beef',63));globalThis.result=shopPurchaseCommit(player,block,'baked:furnace:p1',1)`);
 assert.equal(ctx.result.ok,true,ctx.result.message);assert.equal(run(`shopInv.getItem(SH_BOX_SLOTS[0]).amount`),64);
 prep();run(`for(const slot of SH_BOX_SLOTS) shopInv.setItem(slot,new ItemStack('minecraft:diamond',64));globalThis.result=shopPurchaseCommit(player,block,'baked:furnace:p1',1)`);
 assert.equal(ctx.result.ok,false);assert.equal([...playerInv.items.values()].reduce((n,i)=>n+i.amount,0),192);
 assert.equal(run(`fzCapacity(fzState(loadStores().stores.s1,'furnace'))`),64);
});
test('back-to-back purchases cannot reuse the last unit of fuel',()=>{
 prep();run(`registry.stores.s1.furnace.burn=1;globalThis.first=shopPurchaseCommit(player,block,'baked:furnace:p1',1);globalThis.second=shopPurchaseCommit(player,block,'baked:furnace:p1',1)`);
 assert.equal(ctx.first.ok,true);assert.equal(ctx.second.ok,false);
 assert.equal(run(`loadProduct(block,'p1').stock[0].item.amount`),15);assert.equal(run(`fzCapacity(fzState(loadStores().stores.s1,'furnace'))`),0);
});
test('cooked products do not appear recursively or accumulate on redraw',()=>{
 prep();for(let i=0;i<8;i++){
  assert.deepEqual(plain(run(`[...shopModel(mode,block,loadStores().stores.s1).records.keys()]`)),['p1','baked:furnace:p1']);
  assert.deepEqual(plain(run(`loadProductIndex(block)`)),['p1']);
 }
});
test('price rounds up, zero fee works, and 64-unit quantity validation remains enforced',()=>{
 prep();run(`globalThis.r=loadProduct(block,'p1');r.settings.price='1';saveProduct(block,r);globalThis.view=loadProduct(block,'baked:furnace:p1');`);
 assert.equal(run(`shopPurchasePrice(view,registry.stores.s1,'d1',1,player.id).entries[0].n2`),2);
 run(`registry.stores.s1.furnace.pct=0`);assert.equal(run(`shopPurchasePrice(view,registry.stores.s1,'d1',1,player.id).entries[0].n2`),1);
 for(const n of [0,-1,65,1.5,NaN]){ctx.invalidQty=n;assert.equal(run(`shopPurchasePrice(view,registry.stores.s1,'d1',invalidQty,player.id).ok`),false);}
});
test('lottery has no cooked counterpart; fuel and fee changes invalidate the displayed offer',()=>{
 prep();run(`globalThis.r=base('p1');r.settings.shop_sale_type=2;`);assert.equal(run(`fzSaleVariant(r,'furnace',fzState(registry.stores.s1,'furnace'))`),undefined);
 const before=run(`fzSaleSignature(block,registry.stores.s1)`);run(`registry.stores.s1.furnace.pct++`);assert.notEqual(run(`fzSaleSignature(block,registry.stores.s1)`),before);
});
test('actual UI writer places raw and cooked icons with distinct 100 / 110 prices',()=>{
 prep();run(`globalThis.ui={shopMode:{player,bakeOn:true,floorId:'d1',txt:new Map(),gen:new Map(),bgmOn:false}};writeShopUIInner(shopInv,ui,block);`);
 assert.equal(run(`shopInv.getItem(shSlots(0).cell[0]).typeId`),'minecraft:beef');
 assert.equal(run(`shopInv.getItem(shSlots(0).cell[1]).typeId`),'minecraft:cooked_beef');
 assert.equal(run(`ui.shopMode.cells.get(shSlots(0).cell[1])`),'baked:furnace:p1');
 assert.notEqual(run(`shopInv.getItem(shSlots(0).price[0]).nameTag`),run(`shopInv.getItem(shSlots(0).price[1]).nameTag`));
 run(`ui.shopMode.confirm={id:'baked:furnace:p1',qty:1};writeShopUIInner(shopInv,ui,block)`);
 assert.equal(run(`ui.shopMode.confirm.canBuy`),true);
 assert.equal(run(`ui.shopMode.confirm.quote`),run(`shopPurchaseQuote(shopPurchasePrice(loadProduct(block,'baked:furnace:p1'),registry.stores.s1,'d1',1,player.id),1)`));
});

test('opening a shop with the owner option enabled shows cooked pork without a buyer toggle click',()=>{
 for(const [type,kind,input,output] of [['furnace','furnace','porkchop','cooked_porkchop'],['smoker','smoker','porkchop','cooked_porkchop'],['blast_furnace','blast','raw_iron','iron_ingot']]) {
  prep();run(`block.typeId='shopuilook2:panel_${type}';putProducts([base('p1','minecraft:${input}')]);SHOP_BAKE_ON.delete(player.id);globalThis.openRec={};enterShopMode(player,openRec,block,shopInv);`);
  assert.equal(run(`openRec.shopMode.model.records.get('baked:${kind}:p1').items[0].id`),`minecraft:${output}`);
  assert.equal(run(`shopInv.getItem(shSlots(0).cell[1]).typeId`),`minecraft:${output}`);
  assert.equal(run(`SHOP_BAKE_ON.get(player.id)`),kind);
  assert.equal(run(`shopPurchasePrice(loadProduct(block,'baked:${kind}:p1'),registry.stores.s1,'d1',1,player.id).entries[0].n2`),110);
 }
 run(`block.typeId='shopuilook2:panel_furnace'`);
});
test('opening a disabled or unfueled shop does not enable cooking or reuse a previous shop kind',()=>{
 for(const change of ['registry.stores.s1.furnace.enabled=false','registry.stores.s1.furnace.burn=0']) {
  prep();run(`${change};SHOP_BAKE_ON.set(player.id,'smoker');globalThis.openRec={};enterShopMode(player,openRec,block,shopInv);`);
  assert.equal(run(`openRec.shopMode.bakeOn`),false);
  assert.equal(run(`openRec.shopMode.model.records.has('baked:furnace:p1')`),false);
  assert.equal(run(`SHOP_BAKE_ON.has(player.id)`),false);
 }
});
test('porkchops are never offered as cooked pork in a blast furnace shop',()=>{
 prep();run(`block.typeId='shopuilook2:panel_blast_furnace';putProducts([base('p1','minecraft:porkchop')]);globalThis.openRec={};enterShopMode(player,openRec,block,shopInv)`);
 assert.equal(run(`openRec.shopMode.model.records.has('baked:blast:p1')`),false);
 assert.equal(run(`openRec.shopMode.model.records.has('p1')`),true);
});
run(`globalThis.manualValues=(price)=>Object.fromEntries(fzSalePriceFields(loadProduct(block,'p1'),registry.stores.s1).map((f,i)=>[f.key,i?'0':String(price)]));`);
test('owner list automatically contains the cooked item in the same floor, even when fuel is temporarily empty',()=>{
 prep();run(`putProducts([base('p1','minecraft:porkchop')]);globalThis.landingRec={landingFloorId:'d1'};`);
 assert.deepEqual(plain(run(`landingModel(player,landingRec,block).pageEntries.map(e=>e.id||e.type)`)),['p1','baked:furnace:p1','plus']);
 run(`registry.stores.s1.furnace.burn=0`);
 assert.equal(run(`landingModel(player,landingRec,block).pageEntries[1].type`),'cooked');
 run(`registry.stores.s1.furnace.enabled=false`);assert.equal(run(`landingModel(player,landingRec,block).pageEntries.some(e=>e.type==='cooked')`),false);
});
test('manual cooked price is persisted and has no surcharge in owner, buyer and checkout prices',()=>{
 prep();assert.equal(run(`fzSetSalePrice(player,block,'baked:furnace:p1',manualValues(120)).ok`),true);
 run(`globalThis.view=loadProduct(block,'baked:furnace:p1');globalThis.st=loadStores().stores.s1`);
 assert.equal(run(`view._fzSale.manualPrice`),true);
 assert.equal(run(`shopPurchasePrice(view,st,'d1',1,player.id).entries[0].n2`),120);
 assert.equal(run(`shopBakeEntries(shopBestPrice(view,pricePointSettingsForStore(st).currencies,pricePointSettingsForStore(st),'d1',shopNow()).entries,view)[0].n2`),120);
 assert.equal(run(`landingSaleInfo(view,st,'d1').price`),120);
 assert.equal(run(`loadProduct(block,'p1').settings.price`),'100');
});
test('end-to-end manual-price purchase charges exactly 120 while consuming shared stock and fuel',()=>{
 prep();run(`fzSetSalePrice(player,block,'baked:furnace:p1',manualValues(120));globalThis.result=shopPurchaseCommit(player,block,'baked:furnace:p1',1)`);
 assert.equal(ctx.result.ok,true,ctx.result.message);assert.equal([...playerInv.items.values()].reduce((n,i)=>n+i.amount,0),72);
 assert.equal(run(`loadProduct(block,'p1').stock[0].item.amount`),15);assert.equal(run(`fzCapacity(fzState(loadStores().stores.s1,'furnace'))`),63);
 assert.equal(run(`loadProduct(block,'baked:furnace:p1').settings.price`),'120');
});
test('changing the source price or the fee never overwrites a manual cooked price',()=>{
 prep();run(`fzSetSalePrice(player,block,'baked:furnace:p1',manualValues(120));globalThis.r=loadProduct(block,'p1');delete r.cookedPrices;r.settings.price='200';saveProduct(block,r);registry.stores.s1.furnace.pct=50;globalThis.view=loadProduct(block,'baked:furnace:p1')`);
 assert.equal(run(`shopPurchasePrice(view,registry.stores.s1,'d1',1,player.id).entries[0].n2`),120);
 assert.equal(run(`loadProduct(block,'p1').settings.price`),'200');
 assert.equal(run(`fzSetSalePrice(player,block,'baked:furnace:p1',null).ok`),true);
 assert.equal(run(`shopPurchasePrice(loadProduct(block,'baked:furnace:p1'),registry.stores.s1,'d1',1,player.id).entries[0].n2`),300);
});
test('automatic owner price is 110 and follows source prices until manually changed',()=>{
 prep();assert.equal(run(`landingSaleInfo(loadProduct(block,'baked:furnace:p1'),registry.stores.s1,'d1').price`),110);
 run(`globalThis.r=loadProduct(block,'p1');r.settings.price='200';saveProduct(block,r)`);
 assert.equal(run(`landingSaleInfo(loadProduct(block,'baked:furnace:p1'),registry.stores.s1,'d1').price`),220);
});
test('manual prices reject invalid amounts, unauthorized users, stale methods and deleted sources',()=>{
 prep();for(const value of [-1,1.5,100000001,NaN,'',null]) {
  ctx.invalidPrice=value;assert.equal(run(`fzSetSalePrice(player,block,'baked:furnace:p1',{...manualValues(120),price:invalidPrice}).ok`),false);
 }
 assert.equal(run(`fzSetSalePrice({id:'guest'},block,'baked:furnace:p1',manualValues(120)).ok`),false);
 assert.equal(run(`fzSetSalePrice(player,block,'baked:furnace:p1',manualValues(120),1).ok`),false);
 run(`globalThis.values=manualValues(120);saveProductIndex(block,[])`);
 assert.equal(run(`fzSetSalePrice(player,block,'baked:furnace:p1',values).ok`),false);
});
test('manual prices cannot be saved for an incompatible cooking shop',()=>{
 prep();assert.equal(run(`fzSetSalePrice(player,block,'baked:smoker:p1',manualValues(120)).ok`),false);
 run(`block.typeId='shopuilook2:panel_blast_furnace'`);
 assert.equal(run(`fzSetSalePrice(player,block,'baked:blast:p1',manualValues(120)).ok`),false);
});
test('owner UI renders the cooked item and its editable manual price without touching source stock',()=>{
 prep();run(`putProducts([base('p1','minecraft:porkchop')]);fzSetSalePrice(player,block,'baked:furnace:p1',manualValues(120));globalThis.lr={landingFloorId:'d1'};writeLanding(player,lr,block,shopInv);`);
 assert.equal(run(`shopInv.getItem(LP.cells[1]).typeId`),'minecraft:cooked_porkchop');
 assert.equal(run(`shopInv.getItem(LANDING_STOCK_COUNT_SLOTS[1]).nameTag`),'120');
 assert.equal(run(`lr.landingCells.get(LP.cells[1]).type`),'cooked');
 assert.equal(run(`loadProduct(block,'p1').stock[0].item.amount`),16);
 assert.match(run(`shopInv.getItem(LP.cells[1]).getLore().join(' ')`),/手動価格/);
});
test('cooked item tooltips show the same automatic or manual price as checkout',()=>{
 prep();run(`globalThis.view=loadProduct(block,'baked:furnace:p1');globalThis.tooltip=makeLandingDisplayItem(view,true,pricePointSettingsForStore(registry.stores.s1).currencies);`);
 assert.match(run(`tooltip.getLore()[2]`),/110/);
 run(`fzSetSalePrice(player,block,'baked:furnace:p1',manualValues(120));globalThis.view=loadProduct(block,'baked:furnace:p1');globalThis.tooltip=makeLandingDisplayItem(view,true,pricePointSettingsForStore(registry.stores.s1).currencies);`);
 assert.match(run(`tooltip.getLore()[2]`),/120/);
 assert.equal(run(`shopPurchasePrice(view,registry.stores.s1,'d1',1,player.id).entries[0].n2`),120);
});
test('a saved manual price survives repeated source stock rewrites and cooked purchases',()=>{
 prep();run(`fzSetSalePrice(player,block,'baked:furnace:p1',manualValues(120));globalThis.r=loadProduct(block,'p1');saveProduct(block,{id:r.id,settings:r.settings,items:r.items,stock:r.stock,savedOnce:true});globalThis.r=loadProduct(block,'p1')`);
 assert.equal(run(`r.cookedPrices.furnace.values.price`),'120');
 assert.equal(run(`loadProduct(block,'baked:furnace:p1')._fzSale.manualPrice`),true);
 assert.deepEqual(plain(run(`loadProductIndex(block)`)),['p1']);
});
(async()=>{
 async function asyncTest(name,fn){await fn();tests++;console.log('PASS '+name);}
 run(`block.dimension.getBlock=()=>block;`);
 await asyncTest('editing only the amount in the actual form automatically selects manual pricing',async()=>{
  prep();run(`putProducts([base('p1','minecraft:porkchop')]);showFormWithRetry=async(p,form)=>({canceled:false,formValues:[true,...form.fields.map((field,i)=>i?field.defaultValue:'120')]});`);
  await run(`showFzSalePriceForm(player,block.dimension,block.location,'baked:furnace:p1')`);
  assert.equal(run(`loadProduct(block,'baked:furnace:p1')._fzSale.manualPrice`),true);
  assert.equal(run(`shopPurchasePrice(loadProduct(block,'baked:furnace:p1'),registry.stores.s1,'d1',1,player.id).entries[0].n2`),120);
 });
 await asyncTest('the actual form restores automatic pricing when explicitly enabled',async()=>{
  run(`showFormWithRetry=async(p,form)=>({canceled:false,formValues:[true,...form.fields.map(field=>field.defaultValue)]});`);
  await run(`showFzSalePriceForm(player,block.dimension,block.location,'baked:furnace:p1')`);
  assert.equal(run(`loadProduct(block,'baked:furnace:p1')._fzSale.manualPrice`),false);
  assert.equal(run(`shopPurchasePrice(loadProduct(block,'baked:furnace:p1'),registry.stores.s1,'d1',1,player.id).entries[0].n2`),110);
 });
 await asyncTest('canceling the actual price form leaves all saved prices untouched',async()=>{
  const before=run(`JSON.stringify(loadProduct(block,'p1'))`);run(`showFormWithRetry=async()=>({canceled:true});`);
  await run(`showFzSalePriceForm(player,block.dimension,block.location,'baked:furnace:p1')`);
  assert.equal(run(`JSON.stringify(loadProduct(block,'p1'))`),before);
 });
 await asyncTest('stock changes while the price form is open are preserved on save',async()=>{
  prep();run(`showFormWithRetry=async(p,form)=>{const r=loadProduct(block,'p1');r.stock[0].item.amount=11;saveProduct(block,r);return {canceled:false,formValues:[true,...form.fields.map((field,i)=>i?field.defaultValue:'120')]};};`);
  await run(`showFzSalePriceForm(player,block.dimension,block.location,'baked:furnace:p1')`);
  assert.equal(run(`loadProduct(block,'p1').stock[0].item.amount`),11);
  assert.equal(run(`loadProduct(block,'baked:furnace:p1').settings.price`),'120');
 });
 await asyncTest('payment method changes while the form is open prevent saving to the wrong currency',async()=>{
  prep();run(`showFormWithRetry=async(p,form)=>{const r=loadProduct(block,'p1');r.settings.shop_payment_method=1;saveProduct(block,r);return {canceled:false,formValues:[true,...form.fields.map((field,i)=>i?field.defaultValue:'120')]};};`);
  await run(`showFzSalePriceForm(player,block.dimension,block.location,'baked:furnace:p1')`);
  assert.equal(run(`loadProduct(block,'p1').cookedPrices`),undefined);
 });
 console.log(`${tests} test groups passed`);
})().catch(error=>{console.error(error);process.exitCode=1;});
