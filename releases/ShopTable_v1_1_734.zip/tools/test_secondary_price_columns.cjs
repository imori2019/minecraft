const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');const {run}=require('./test_smelt_sales.cjs');
const ui=JSON.parse(fs.readFileSync(path.join(__dirname,'../resource_pack/ui/shop_layout_price.json'),'utf8'));
const ctl=o=>Object.assign({},...o.controls);
function subtract(expr,state){const tokens=expr.match(/'[^']*'|#[A-Za-z0-9_]+/g)||[];const val=t=>t[0]==="'"?t.slice(1,-1).replace(/\\u([0-9a-f]{4})/gi,(_,hex)=>String.fromCharCode(parseInt(hex,16))):state[t]??'';let out=val(tokens.shift());for(const t of tokens)out=out.split(val(t)).join('');return out;}
function text(label,raw){const state={};for(const b of label.bindings){if(b.binding_type==='collection'&&b.binding_name==='#hover_text')state[b.binding_name_override]=raw;if(b.binding_type==='view'&&b.source_property_name.includes(' - '))state[b.target_property_name]=subtract(b.source_property_name,state);}return state['#text'];}
let variants=0,cases=0;
for(const entry of ui.sh_content.controls)for(const group of Object.values(entry))for(const child of group.controls??[])for(const [name,box]of Object.entries(child)){
 if(!name.startsWith('pbox_')||!box.controls?.length)continue;
 const [first,second]=box.controls.slice(0,2).map(x=>Object.values(x)[0]);if(!first?.controls||!second?.controls)continue;
 for(let i=0;i<first.controls.length;i++){
  const p=ctl(ctl(Object.values(first.controls[i])[0]).v).prow;
  const s=ctl(ctl(Object.values(second.controls[i])[0]).v).prow;
  const a=ctl(p),b=ctl(s);assert.equal(p.offset[0]+a.ibox.size[0],s.offset[0]+b.currency_box.size[0]);assert.equal(b.t2.type,'label');variants++;
  for(const n of [1,10,125,10000])for(const discounted of [false,true])for(const secondKind of ['item','pt']){
   const list=[{k:'item',id:'minecraft:emerald',n,n2:discounted?Math.max(0,n-1):n},{k:secondKind,id:secondKind==='pt'?'shop':'minecraft:gold_ingot',n,n2:discounted?Math.max(0,n-1):n}];
   const raw=JSON.parse(run(`JSON.stringify(shopCardPriceLines(${JSON.stringify(list)},true,'light'))`));
   const expected=text(a.t2,raw[0]),actual=text(b.t2,raw[1]);assert.equal(actual,expected,'currency width/gap must not move or alter secondary digits');assert.ok(!actual.includes(run('SH_GAP_GLYPH')));cases++;
  }
 }
}
assert.equal(variants,120);console.log(`PASS ${variants} secondary price variants keep a fixed numerical column across ${cases} currency/point/discount cases`);
