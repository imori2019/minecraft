const assert=require('node:assert/strict'),fs=require('fs'),path=require('path');const {run,prep,ctx}=require('./test_smelt_sales.cjs');let n=0;
const plain=x=>JSON.parse(JSON.stringify(x)),read=p=>JSON.parse(fs.readFileSync(path.join(__dirname,'..',p),'utf8'));function test(s,f){f();n++;console.log('PASS MINIMAL '+s);}
function reset(kind){prep();run(`globalThis.minimal={storeId:'s1',fzKind:'${kind}',block,player};block.typeId=FZ_KINDS['${kind}'].block;`);}
const status=()=>plain(run('FZ_STAT_SLOTS.map(s=>shopInv.getItem(s)?.nameTag?.trim()??"")'));
test('furnace, blast furnace and smoker show only fuel shortage, clearing it after replenishment',()=>{
 for(const k of ['furnace','blast','smoker']){
 reset(k);run(`registry.stores.s1.${k}={enabled:true,pct:0,burn:0,fuel:[],used:{total:12345,days:{}}};fzWriteScreen(shopInv,minimal,registry.stores.s1)`);assert.deepEqual(status(),['§c燃料がありません','','','']);
 run(`registry.stores.s1.${k}.burn=128;fzWriteScreen(shopInv,minimal,registry.stores.s1)`);assert.deepEqual(status(),['','','','']);assert.equal(run('shopInv.getItem(FZ_FEE_TXT).nameTag'),'0%');
 }
});
test('barrel shows only missing bone meal, without totals or water/sand explanations',()=>{
 reset('barrel');run(`registry.stores.s1.barrel={auto:true,grow:[],mats:[]};blWriteScreen(shopInv,minimal)`);assert.deepEqual(status(),['§c骨粉がありません','','','']);assert.equal(run('shopInv.getItem(FZ_MAT_HEAD).nameTag'),'育成スロット');
 run(`registry.stores.s1.barrel.mats=[{id:'minecraft:bone_meal',n:64}];blWriteScreen(shopInv,minimal)`);assert.deepEqual(status(),['','','','']);
});
test('spawner only describes the current day/night advantage and spawn egg hover gives the release action and count',()=>{
 reset('spawner');run(`world.getTimeOfDay=()=>6000;spWriteScreen(shopInv,minimal)`);assert.deepEqual(status(),['§e昼の時間帯は動物が生まれやすい','','','']);
 run(`world.getTimeOfDay=()=>18000;spWriteScreen(shopInv,minimal);spWritePen(shopInv,minimal,[{egg:'minecraft:cow_spawn_egg',n:64}])`);assert.deepEqual(status(),['§9夜の時間帯はモンスターが生まれやすい','','','']);assert.match(run('shopInv.getItem(SP_PEN_SLOTS[0]).nameTag'),/を逃がす\n§7現在64匹$/);
 const name=run("fzPenItem('cow',130).nameTag");assert.match(name,/を逃がす\n§7現在130匹$/);assert.equal(run("fzPenItem('cow',130).amount"),64);assert.equal(name.includes('\\n'),false);run('world.getTimeOfDay=()=>6000');
});
test('cartography shows only automatic map creation while enabled and no crafting totals',()=>{
 reset('cartography');run(`registry.stores.s1.cartography={auto:true,mats:[],made:54321};crWriteScreen(shopInv,minimal)`);assert.deepEqual(status(),['§a自動で地図を作っています','','','']);assert.equal(run('shopInv.getItem(FZ_MAT_HEAD).nameTag'),'材料');
 run(`registry.stores.s1.cartography.auto=false;crWriteScreen(shopInv,minimal)`);assert.deepEqual(status(),['','','','']);
});
test('all description scroll bars and instruction notes are removed; slot and action labels are short',()=>{
 const u=read('resource_pack/ui/shop_proceeds_screen.json');let pane=0;const text=[];function walk(o,p=''){if(Array.isArray(o))return o.forEach(v=>walk(v,p));if(!o||typeof o!=='object')return;assert.ok(!p.endsWith('/shop_help_scroll@common.scrolling_panel'));assert.ok(!Object.keys(o).some(k=>k.startsWith('shop_help_content_')));if(o.type==='label'&&typeof o.text==='string')text.push(o.text);if(p.endsWith('/minimal_status'))pane++;for(const[k,v]of Object.entries(o))walk(v,p+'/'+k);}walk(u);assert.equal(pane,6);assert.ok(text.includes('水バケツ'));assert.ok(text.includes('空のバケツ'));assert.ok(text.includes('砂と骨粉'));assert.equal(text.some(t=>t.startsWith('・')||t.includes('卵を押す')),false);
});
test('other feature pages retain their own essential account labels',()=>{
 assert.equal(run("shopFunctionText({fzKind:'vault'},FZ_MAT_HEAD,'預かったレベル')"),'預かったレベル');
});
console.log(n+' minimal function UI groups passed (API/UI checks; native rendering not executed)');
