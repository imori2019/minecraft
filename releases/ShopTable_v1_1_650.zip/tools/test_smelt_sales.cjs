const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
// These tests simulate Bedrock APIs; they do not run Minecraft itself.
const root = require('node:path').resolve(__dirname, '..');
class ItemStack {
  constructor(id, amount = 1) { this.typeId = id; this.amount = amount; this.maxAmount = /_(sword|pickaxe|helmet|bucket)$/.test(id) ? 1 : id === 'minecraft:bucket' ? 16 : 64; this.props = {}; this.lore = []; this.ench = []; }
  get localizationKey() { return `item.${this.typeId.replace('minecraft:', '')}.name`; }
  clone() { const out = new ItemStack(this.typeId, this.amount); Object.assign(out, structuredClone({...this})); return out; }
  getLore() { return [...this.lore]; }
  setLore(v) { this.lore = [...v]; }
  getDynamicProperty(k) { return this.props[k]; }
  getDynamicPropertyIds() { return Object.keys(this.props); }
  setDynamicProperty(k,v) { this.props[k] = v; }
  getComponent(k) { if(k === 'minecraft:enchantable') return {getEnchantments:()=>this.ench, addEnchantment:e=>this.ench.push(e)}; }
  isStackableWith(other) { const a = this.clone(), b = other.clone(); a.amount=b.amount=1; return JSON.stringify(a) === JSON.stringify(b); }
  hasTag() { return false; }
}
class Container {
  constructor(size) { this.size=size; this.items=new Map(); this.failSlot=null; }
  getItem(i) { return this.items.get(i)?.clone(); }
  setItem(i,item) { if(this.failSlot===i) {this.failSlot=null; throw Error('injected delivery failure');} if(item) this.items.set(i,item.clone()); else this.items.delete(i); }
}
class PriceModal {
 constructor(){this.fields=[];}
 title(value){this.titleText=value;return this;}
 toggle(label,options){this.toggleLabel=label;this.toggleOptions=options;return this;}
 textField(label,placeholder,options){this.fields.push({label,placeholder,...options});return this;}
 submitButton(){return this;}
}
const handlers=[], intervals=[];
const events=new Proxy({}, {get:()=>({subscribe:f=>handlers.push(f)})});
const props=new Map(), worldProps=new Map();
const playerInv=new Container(36), shopInv=new Container(256);
const player={id:'P1',name:'Player',level:0,getComponent:k=>k==='minecraft:inventory'?{container:playerInv}:undefined,
  getDynamicProperty:()=>undefined,setDynamicProperty:()=>{},sendMessage:()=>{},addLevels(n){this.level+=n;},addExperience:()=>{}};
const world={afterEvents:events,beforeEvents:events,getAllPlayers:()=>[player],getPlayers:()=>[player],
  getDynamicProperty:k=>worldProps.get(k),setDynamicProperty:(k,v)=>worldProps.set(k,v),getTimeOfDay:()=>6000};
const ctx=vm.createContext({console, ItemStack, world, system:{currentTick:1000,afterEvents:events,runInterval:f=>intervals.push(f),runTimeout:()=>{},run:()=>{}},
  ItemTypes:{get:id=>({id}),getAll:()=>[]},BlockTypes:{get:id=>({id})},EnchantmentTypes:{get:id=>({id})},
  BlockPermutation:{},EquipmentSlot:{},MolangVariableMap:class{},Potions:{},ActionFormData:class{},ModalFormData:PriceModal,FormCancelationReason:{},
  structuredClone,player,playerInv,shopInv,props});
for(const name of ['ja_names.js','craft_recipes.js','main.js']) {
  const code=fs.readFileSync(`${root}/behavior_pack/scripts/${name}`,'utf8').replace(/^import .*;\r?\n/gm,'').replace(/^export /gm,'');
  vm.runInContext(code,ctx,{filename:name,timeout:10000});
}
console.log(`PASS full script initialization (${handlers.length} event subscriptions, ${intervals.length} intervals registered; game callbacks not simulated)`);
const run=s=>vm.runInContext(`{${s}}`,ctx);
const plain=x=>JSON.parse(JSON.stringify(x));
run(`
globalThis.registry = {stores:{s1:{id:'s1',name:'Test',departments:[{id:'d1',name:'食品'},{id:'d2',name:'素材'}],
  furnace:{enabled:true,pct:10,burn:64},blast:{enabled:true,pct:10,burn:64},smoker:{enabled:true,pct:10,burn:64}}},groups:{}};
globalThis.block={typeId:'shopuilook2:panel_furnace',location:{x:0,y:64,z:0},dimension:{id:'minecraft:overworld'}};
getProps=()=>({get:k=>props.get(k),set:(k,v)=>props.set(k,v)});
getBlockStoreId=()=> 's1';
loadStores=()=>JSON.parse(JSON.stringify(registry));
globalThis.failSaveStores=false;
saveStores=r=>{if(failSaveStores){failSaveStores=false;return false;} registry=JSON.parse(JSON.stringify(r));return true;};
getContainer=()=>shopInv;
shopCanSellNow=()=>true;
shopClosedReason=()=>'';
storeNoticePush=()=>{};
shopPurchaseAwardStoreXp=()=>0;
shopDebugEvent=()=>{};
globalThis.saleLog = [];
shopSaleRecordSuccess=(...args)=>saleLog.push(args);
globalThis.base = (id,item='minecraft:beef',count=1,n=16)=>({id,savedOnce:true,
 settings:{shop_product_name:'生の牛肉',shop_product_genre:'食品',price:'100',shop_payment_method:0},
 items:[{id:item,key:item,count,role:'sample',slot:17}],stock:[{slot:0,item:{id:item,amount:n}}]});
globalThis.putProducts=(products)=>{saveProductIndex(block,products.map(r=>r.id));for(const r of products) {saveProduct(block,r);setProductFloor(block,r.id,r.id==='p2'?'d2':'d1');}};
globalThis.mode={player,bakeOn:true,floorId:'d1',history:false};
SHOP_BAKE_ON.set(player.id,'furnace');
`);
let tests=1;
function test(name,fn){fn();tests++;console.log('PASS '+name);}
test('all three cooking rule matrices',()=>{
 const cases=[['beef','cooked_beef','', 'cooked_beef'],['raw_iron','iron_ingot','iron_ingot',''],['sand','glass','',''],['cobblestone','stone','',''],['potato','baked_potato','','baked_potato'],['iron_sword','iron_nugget','iron_nugget',''],['oak_log','charcoal','',''],['ancient_debris','netherite_scrap','netherite_scrap',''],['diamond','','','']];
 for(const [id,...targets] of cases) for(const [i,kind] of ['furnace','blast','smoker'].entries())
  assert.equal(ctx.fzSmeltOutput(`minecraft:${id}`,kind),targets[i]?`minecraft:${targets[i]}`:'',`${kind}/${id}`);
});
test('same floor and genre, source and cooked shown together',()=>{
 run(`putProducts([base('p1'),base('p2','minecraft:raw_iron')]);globalThis.model=shopModel(mode,block,loadStores().stores.s1);`);
 assert.deepEqual(plain(run(`model.rows[0].ids`)),['p1','baked:furnace:p1']);
 assert.equal(run(`productFloorId(block,'baked:furnace:p1',storeFloors(registry.stores.s1))`),'d1');
 assert.equal(run(`model.records.get('baked:furnace:p1').items[0].id`),'minecraft:cooked_beef');
 assert.equal(run(`loadProduct(block,'p1').items[0].id`),'minecraft:beef');
});
test('toggle off, owner disabled and non-cooking shop hide cooked variants',()=>{
 for(const change of [`mode.bakeOn=false`,`mode.bakeOn=true;registry.stores.s1.furnace.enabled=false`,`registry.stores.s1.furnace.enabled=true;block.typeId='shopuilook2:panel_crafter'`]){
  run(change);assert.equal(run(`shopModel(mode,block,registry.stores.s1).records.has('baked:furnace:p1')`),false);
 }
 run(`block.typeId='shopuilook2:panel_furnace';mode.bakeOn=true;registry.stores.s1.furnace.enabled=true`);
});
test('smoker excludes ores; blast excludes food; all other shops unchanged',()=>{
 for(const [type,kind,yes,no] of [['smoker','smoker','p1','p2'],['blast_furnace','blast','p2','p1']]){
  run(`block.typeId='shopuilook2:panel_${type}';SHOP_BAKE_ON.set(player.id,'${kind}');globalThis.model=shopModel(mode,block,registry.stores.s1)`);
  assert.equal(run(`model.records.has('baked:${kind}:${yes}')`),true);assert.equal(run(`model.records.has('baked:${kind}:${no}')`),false);
 }
 for(const type of ['panel','panel_spawner','panel_barrel','panel_composter','panel_crafter','panel_smith','panel_bulb','panel_anchor','panel_lodestone','panel_heart']){
  run(`block.typeId='shopuilook2:${type}'`);assert.equal(run(`[...shopModel(mode,block,registry.stores.s1).records.keys()].some(id=>id.startsWith('baked:'))`),false);
 }
 run(`block.typeId='shopuilook2:panel_furnace';SHOP_BAKE_ON.set(player.id,'furnace')`);
});
test('fee included once; raw prices and records unchanged',()=>{
 run(`globalThis.raw=loadProduct(block,'p1');globalThis.view=loadProduct(block,'baked:furnace:p1');globalThis.st=loadStores().stores.s1;`);
 assert.equal(run(`shopPurchasePrice(raw,st,'d1',1,player.id).entries[0].n2`),100);
 assert.equal(run(`shopPurchasePrice(view,st,'d1',1,player.id).entries[0].n2`),110);
 assert.equal(run(`shopPurchasePrice(view,st,'d1',2,player.id).items.values().next().value`),220);
 assert.equal(run(`shopBakeEntries([{n:100,n2:100}],view,null)[0].n2`),110);
 assert.equal(run(`shopBakeEntries([{n:100,n2:100}],raw,{pct:10,cap:64,kind:'furnace'})[0].n2`),100);
 assert.equal(run(`saveProduct(block,view).ok`),false);
 assert.equal(run(`loadProduct(block,'p1').settings.shop_product_name`),'生の牛肉');
});
test('delivery consumes source stock and cooks exactly once',()=>{
 run(`globalThis.plan=shopPurchaseStockPlan(view,2)`);
 assert.equal(run(`plan.delivery[0].typeId`),'minecraft:cooked_beef');assert.equal(run(`plan.delivery[0].amount`),2);
 assert.equal(run(`plan.stock[0].item.id`),'minecraft:beef');assert.equal(run(`plan.stock[0].item.amount`),14);
 assert.equal(run(`plan.bakedCount`),2);
 run(`globalThis.stone=base('p3','minecraft:cobblestone');globalThis.stoneView=fzSaleVariant(stone,'furnace',fzState(st,'furnace'))`);
 assert.equal(run(`shopPurchaseStockPlan(stoneView,1).delivery[0].typeId`),'minecraft:stone');
});
test('named/enhanced sample is not replaced; named stock is preserved',()=>{
 run(`globalThis.named=base('p3');named.items[0].key+='|n=名前';named.items[0].name='名前'`);
 assert.equal(run(`fzSaleVariant(named,'furnace',fzState(st,'furnace'))`),undefined);
 run(`globalThis.mixed=base('p3');mixed.stock.unshift({slot:1,item:{id:'minecraft:beef',amount:3,nameTag:'大事な牛肉'}});globalThis.mixedView=fzSaleVariant(mixed,'furnace',fzState(st,'furnace'));globalThis.mixPlan=shopPurchaseStockPlan(mixedView,2)`);
 assert.equal(run(`mixPlan.delivery[0].typeId`),'minecraft:cooked_beef');assert.equal(run(`mixPlan.stock.find(r=>r.slot===1).item.nameTag`),'大事な牛肉');
 assert.equal(run(`shopPurchaseRemaining(mixedView)`),16);
});
test('fuel shortages reject; zero fee still needs fuel; stale toggle rejected',()=>{
 run(`registry.stores.s1.furnace.burn=1;globalThis.st=loadStores().stores.s1;globalThis.view=loadProduct(block,'baked:furnace:p1')`);
 assert.equal(run(`shopPurchaseRemaining(view)`),1);assert.equal(run(`shopPurchasePrice(view,st,'d1',2,player.id).ok`),false);
 run(`registry.stores.s1.furnace.pct=0;globalThis.st=loadStores().stores.s1`);
 assert.equal(run(`shopPurchasePrice(view,st,'d1',1,player.id).bake.need`),1);
 run(`SHOP_BAKE_ON.delete(player.id)`);assert.equal(run(`shopPurchasePrice(view,st,'d1',1,player.id).ok`),false);
 run(`SHOP_BAKE_ON.set(player.id,'blast')`);assert.equal(run(`shopPurchasePrice(view,st,'d1',1,player.id).ok`),false);
 run(`SHOP_BAKE_ON.set(player.id,'furnace');registry.stores.s1.furnace.pct=10;registry.stores.s1.furnace.burn=64`);
});
// Exercise the actual commit/payment/delivery/rollback functions. Only game storage,
// scheduler, player APIs and unrelated XP/reporting side effects are adapters above.
function prep(){
 props.clear();worldProps.clear();playerInv.items.clear();shopInv.items.clear();
  run(`block.typeId='shopuilook2:panel_furnace';putProducts([base('p1')]);registry.stores.s1.owner={id:player.id,name:player.name};registry.stores.s1.furnace={enabled:true,pct:10,burn:64};SHOP_BAKE_ON.set(player.id,'furnace');saleLog=[];globalThis.currency=pricePointSettingsForStore(registry.stores.s1).currencies[0];playerInv.setItem(0,new ItemStack(currency,64));playerInv.setItem(1,new ItemStack(currency,64));playerInv.setItem(2,new ItemStack(currency,64));`);
}
test('end-to-end cooked purchase pays 110, shares raw stock and uses one fuel',()=>{
 prep();run(`globalThis.result=shopPurchaseCommit(player,block,'baked:furnace:p1',1)`);
 assert.equal(ctx.result.ok,true,ctx.result.message);
 assert.equal(run(`loadProduct(block,'p1').stock[0].item.amount`),15);
 assert.equal(run(`fzCapacity(fzState(loadStores().stores.s1,'furnace'))`),63);
 assert.equal(run(`fzState(loadStores().stores.s1,'furnace').used.total`),1);
 assert.equal([...playerInv.items.values()].reduce((n,i)=>n+i.amount,0),82);
 assert.equal([...shopInv.items.values()].filter(i=>i.typeId==='minecraft:cooked_beef').reduce((n,i)=>n+i.amount,0),1);
 assert.equal(run(`loadProduct(block,'p1').buyers.P1`),1);
 assert.deepEqual(plain(run(`loadProductIndex(block)`)),['p1']);
 assert.equal(run(`loadProduct(block,'p1').settings.shop_product_name`),'生の牛肉');
});
test('end-to-end raw purchase remains raw even while toggle is on',()=>{
 prep();run(`globalThis.result=shopPurchaseCommit(player,block,'p1',1)`);
 assert.equal(ctx.result.ok,true,ctx.result.message);assert.equal([...playerInv.items.values()].reduce((n,i)=>n+i.amount,0),92);
 assert.equal([...shopInv.items.values()].some(i=>i.typeId==='minecraft:beef'),true);
 assert.equal(run(`fzCapacity(fzState(loadStores().stores.s1,'furnace'))`),64);
});
test('source per-buyer limit is shared by raw and cooked purchases',()=>{
 prep();run(`globalThis.r=loadProduct(block,'p1');r.settings.shop_type_bind_choice=2;r.settings.limited_per_player_count='1';saveProduct(block,r);globalThis.result=shopPurchaseCommit(player,block,'baked:furnace:p1',1)`);
 assert.equal(ctx.result.ok,true,ctx.result.message);assert.equal(run(`shopPurchaseCommit(player,block,'p1',1).ok`),false);
});
test('delivery failure rolls back payment, source stock, fuel and usage count',()=>{
 prep();run(`shopInv.failSlot=SH_BOX_SLOTS[0];globalThis.result=shopPurchaseCommit(player,block,'baked:furnace:p1',1)`);
 assert.equal(ctx.result.ok,false);assert.match(ctx.result.message,/取り消/);
 assert.equal(run(`loadProduct(block,'p1').stock[0].item.amount`),16);
 assert.equal(run(`fzCapacity(fzState(loadStores().stores.s1,'furnace'))`),64);
 assert.equal(run(`fzState(loadStores().stores.s1,'furnace').used.total`),0);
 assert.equal([...playerInv.items.values()].reduce((n,i)=>n+i.amount,0),192);assert.equal(shopInv.items.size,0);
});
test('fuel persistence failure cancels before payment and delivery',()=>{
 prep();run(`failSaveStores=true;globalThis.result=shopPurchaseCommit(player,block,'baked:furnace:p1',1)`);
 assert.equal(ctx.result.ok,false);assert.equal(run(`loadProduct(block,'p1').stock[0].item.amount`),16);
 assert.equal(run(`fzCapacity(fzState(loadStores().stores.s1,'furnace'))`),64);
 assert.equal([...playerInv.items.values()].reduce((n,i)=>n+i.amount,0),192);assert.equal(shopInv.items.size,0);
});
test('blast and smoker actual purchase deliver only their allowed outputs',()=>{
 for(const [type,kind,input,output] of [['blast_furnace','blast','raw_iron','iron_ingot'],['smoker','smoker','beef','cooked_beef']]){
  prep();run(`block.typeId='shopuilook2:panel_${type}';putProducts([base('p1','minecraft:${input}')]);SHOP_BAKE_ON.set(player.id,'${kind}');globalThis.result=shopPurchaseCommit(player,block,'baked:${kind}:p1',1)`);
  assert.equal(ctx.result.ok,true,ctx.result.message);assert.equal([...shopInv.items.values()].some(i=>i.typeId===`minecraft:${output}`),true);
  assert.equal(run(`fzCapacity(fzState(loadStores().stores.s1,'${kind}'))`),63);
 }
 run(`block.typeId='shopuilook2:panel_furnace'`);
});
test('price changes, owner disable, exhausted fuel, deleted product and wrong shop are rejected without charging',()=>{
 const changes=[`registry.stores.s1.furnace.pct=20`,`registry.stores.s1.furnace.enabled=false`,`registry.stores.s1.furnace.burn=0`,`saveProductIndex(block,[])`,`block.typeId='shopuilook2:panel_smoker'`];
 for(const change of changes){
  run(`block.typeId='shopuilook2:panel_furnace'`);prep();
  run(`globalThis.quote=shopPurchaseQuote(shopPurchasePrice(loadProduct(block,'baked:furnace:p1'),registry.stores.s1,'d1',1,player.id),1);${change};globalThis.result=shopPurchaseCommit(player,block,'baked:furnace:p1',1,quote)`);
  assert.equal(ctx.result.ok,false,change);assert.equal([...playerInv.items.values()].reduce((n,i)=>n+i.amount,0),192);assert.equal(shopInv.items.size,0);
 }
 run(`block.typeId='shopuilook2:panel_furnace'`);
});
test('mixed set preserves unprocessable items and never double-smelts stone',()=>{
 prep();run(`globalThis.r=base('p1','minecraft:cobblestone');r.settings.shop_sale_type=1;r.items.push({id:'minecraft:diamond',key:'minecraft:diamond',count:1,role:'sample',slot:18});r.stock.push({slot:1,item:{id:'minecraft:diamond',amount:16}});putProducts([r]);globalThis.result=shopPurchaseCommit(player,block,'baked:furnace:p1',1)`);
 assert.equal(ctx.result.ok,true,ctx.result.message);
 assert.equal([...shopInv.items.values()].some(i=>i.typeId==='minecraft:stone'),true);assert.equal([...shopInv.items.values()].some(i=>i.typeId==='minecraft:diamond'),true);
 assert.equal([...shopInv.items.values()].some(i=>i.typeId==='minecraft:smooth_stone'),false);
 assert.equal(run(`fzCapacity(fzState(loadStores().stores.s1,'furnace'))`),63);
});
test('full delivery slots merge with cooked product, not the raw source',()=>{
 prep();run(`for(const slot of SH_BOX_SLOTS) shopInv.setItem(slot,new ItemStack('minecraft:diamond',64));shopInv.setItem(SH_BOX_SLOTS[0],new ItemStack('minecraft:cooked_beef',63));globalThis.result=shopPurchaseCommit(player,block,'baked:furnace:p1',1)`);
 assert.equal(ctx.result.ok,true,ctx.result.message);assert.equal(run(`shopInv.getItem(SH_BOX_SLOTS[0]).amount`),64);
 prep();run(`for(const slot of SH_BOX_SLOTS) shopInv.setItem(slot,new ItemStack('minecraft:diamond',64));globalThis.result=shopPurchaseCommit(player,block,'baked:furnace:p1',1)`);
 assert.equal(ctx.result.ok,false);assert.equal([...playerInv.items.values()].reduce((n,i)=>n+i.amount,0),192);
 assert.equal(run(`fzCapacity(fzState(loadStores().stores.s1,'furnace'))`),64);
});
test('back-to-back purchases cannot reuse the last unit of fuel',()=>{
 prep();run(`registry.stores.s1.furnace.burn=1;globalThis.first=shopPurchaseCommit(player,block,'baked:furnace:p1',1);globalThis.second=shopPurchaseCommit(player,block,'baked:furnace:p1',1)`);
 assert.equal(ctx.first.ok,true);assert.equal(ctx.second.ok,false);
 assert.equal(run(`loadProduct(block,'p1').stock[0].item.amount`),15);assert.equal(run(`fzCapacity(fzState(loadStores().stores.s1,'furnace'))`),0);
});
test('cooked products do not appear recursively or accumulate on redraw',()=>{
 prep();for(let i=0;i<8;i++){
  assert.deepEqual(plain(run(`[...shopModel(mode,block,loadStores().stores.s1).records.keys()]`)),['p1','baked:furnace:p1']);
  assert.deepEqual(plain(run(`loadProductIndex(block)`)),['p1']);
 }
});
test('price rounds up, zero fee works, and 64-unit quantity validation remains enforced',()=>{
 prep();run(`globalThis.r=loadProduct(block,'p1');r.settings.price='1';saveProduct(block,r);globalThis.view=loadProduct(block,'baked:furnace:p1');`);
 assert.equal(run(`shopPurchasePrice(view,registry.stores.s1,'d1',1,player.id).entries[0].n2`),2);
 run(`registry.stores.s1.furnace.pct=0`);assert.equal(run(`shopPurchasePrice(view,registry.stores.s1,'d1',1,player.id).entries[0].n2`),1);
 for(const n of [0,-1,65,1.5,NaN]){ctx.invalidQty=n;assert.equal(run(`shopPurchasePrice(view,registry.stores.s1,'d1',invalidQty,player.id).ok`),false);}
});
test('lottery has no cooked counterpart; fuel and fee changes invalidate the displayed offer',()=>{
 prep();run(`globalThis.r=base('p1');r.settings.shop_sale_type=2;`);assert.equal(run(`fzSaleVariant(r,'furnace',fzState(registry.stores.s1,'furnace'))`),undefined);
 const before=run(`fzSaleSignature(block,registry.stores.s1)`);run(`registry.stores.s1.furnace.pct++`);assert.notEqual(run(`fzSaleSignature(block,registry.stores.s1)`),before);
});
test('actual UI writer places raw and cooked icons with distinct 100 / 110 prices',()=>{
 prep();run(`globalThis.ui={shopMode:{player,bakeOn:true,floorId:'d1',txt:new Map(),gen:new Map(),bgmOn:false}};writeShopUIInner(shopInv,ui,block);`);
 assert.equal(run(`shopInv.getItem(shSlots(0).cell[0]).typeId`),'minecraft:beef');
 assert.equal(run(`shopInv.getItem(shSlots(0).cell[1]).typeId`),'minecraft:cooked_beef');
 assert.equal(run(`ui.shopMode.cells.get(shSlots(0).cell[1])`),'baked:furnace:p1');
 assert.notEqual(run(`shopInv.getItem(shSlots(0).price[0]).nameTag`),run(`shopInv.getItem(shSlots(0).price[1]).nameTag`));
 run(`ui.shopMode.confirm={id:'baked:furnace:p1',qty:1};writeShopUIInner(shopInv,ui,block)`);
 assert.equal(run(`ui.shopMode.confirm.canBuy`),true);
 assert.equal(run(`ui.shopMode.confirm.quote`),run(`shopPurchaseQuote(shopPurchasePrice(loadProduct(block,'baked:furnace:p1'),registry.stores.s1,'d1',1,player.id),1)`));
});

test('opening a shop with the owner option enabled shows cooked pork without a buyer toggle click',()=>{
 for(const [type,kind,input,output] of [['furnace','furnace','porkchop','cooked_porkchop'],['smoker','smoker','porkchop','cooked_porkchop'],['blast_furnace','blast','raw_iron','iron_ingot']]) {
  prep();run(`block.typeId='shopuilook2:panel_${type}';putProducts([base('p1','minecraft:${input}')]);SHOP_BAKE_ON.delete(player.id);globalThis.openRec={};enterShopMode(player,openRec,block,shopInv);`);
  assert.equal(run(`openRec.shopMode.model.records.get('baked:${kind}:p1').items[0].id`),`minecraft:${output}`);
  assert.equal(run(`shopInv.getItem(shSlots(0).cell[1]).typeId`),`minecraft:${output}`);
  assert.equal(run(`SHOP_BAKE_ON.get(player.id)`),kind);
  assert.equal(run(`shopPurchasePrice(loadProduct(block,'baked:${kind}:p1'),registry.stores.s1,'d1',1,player.id).entries[0].n2`),110);
 }
 run(`block.typeId='shopuilook2:panel_furnace'`);
});
test('opening a disabled or unfueled shop does not enable cooking or reuse a previous shop kind',()=>{
 for(const change of ['registry.stores.s1.furnace.enabled=false','registry.stores.s1.furnace.burn=0']) {
  prep();run(`${change};SHOP_BAKE_ON.set(player.id,'smoker');globalThis.openRec={};enterShopMode(player,openRec,block,shopInv);`);
  assert.equal(run(`openRec.shopMode.bakeOn`),false);
  assert.equal(run(`openRec.shopMode.model.records.has('baked:furnace:p1')`),false);
  assert.equal(run(`SHOP_BAKE_ON.has(player.id)`),false);
 }
});
test('porkchops are never offered as cooked pork in a blast furnace shop',()=>{
 prep();run(`block.typeId='shopuilook2:panel_blast_furnace';putProducts([base('p1','minecraft:porkchop')]);globalThis.openRec={};enterShopMode(player,openRec,block,shopInv)`);
 assert.equal(run(`openRec.shopMode.model.records.has('baked:blast:p1')`),false);
 assert.equal(run(`openRec.shopMode.model.records.has('p1')`),true);
});
run(`globalThis.manualValues=(price)=>Object.fromEntries(fzSalePriceFields(loadProduct(block,'p1'),registry.stores.s1).map((f,i)=>[f.key,i?'0':String(price)]));`);
test('owner list automatically contains the cooked item in the same floor, even when fuel is temporarily empty',()=>{
 prep();run(`putProducts([base('p1','minecraft:porkchop')]);globalThis.landingRec={landingFloorId:'d1'};`);
 assert.deepEqual(plain(run(`landingModel(player,landingRec,block).pageEntries.map(e=>e.id||e.type)`)),['p1','baked:furnace:p1','plus']);
 run(`registry.stores.s1.furnace.burn=0`);
 assert.equal(run(`landingModel(player,landingRec,block).pageEntries[1].type`),'cooked');
 run(`registry.stores.s1.furnace.enabled=false`);assert.equal(run(`landingModel(player,landingRec,block).pageEntries.some(e=>e.type==='cooked')`),false);
});
test('manual cooked price is persisted and has no surcharge in owner, buyer and checkout prices',()=>{
 prep();assert.equal(run(`fzSetSalePrice(player,block,'baked:furnace:p1',manualValues(120)).ok`),true);
 run(`globalThis.view=loadProduct(block,'baked:furnace:p1');globalThis.st=loadStores().stores.s1`);
 assert.equal(run(`view._fzSale.manualPrice`),true);
 assert.equal(run(`shopPurchasePrice(view,st,'d1',1,player.id).entries[0].n2`),120);
 assert.equal(run(`shopBakeEntries(shopBestPrice(view,pricePointSettingsForStore(st).currencies,pricePointSettingsForStore(st),'d1',shopNow()).entries,view)[0].n2`),120);
 assert.equal(run(`landingSaleInfo(view,st,'d1').price`),120);
 assert.equal(run(`loadProduct(block,'p1').settings.price`),'100');
});
test('end-to-end manual-price purchase charges exactly 120 while consuming shared stock and fuel',()=>{
 prep();run(`fzSetSalePrice(player,block,'baked:furnace:p1',manualValues(120));globalThis.result=shopPurchaseCommit(player,block,'baked:furnace:p1',1)`);
 assert.equal(ctx.result.ok,true,ctx.result.message);assert.equal([...playerInv.items.values()].reduce((n,i)=>n+i.amount,0),72);
 assert.equal(run(`loadProduct(block,'p1').stock[0].item.amount`),15);assert.equal(run(`fzCapacity(fzState(loadStores().stores.s1,'furnace'))`),63);
 assert.equal(run(`loadProduct(block,'baked:furnace:p1').settings.price`),'120');
});
test('changing the source price or the fee never overwrites a manual cooked price',()=>{
 prep();run(`fzSetSalePrice(player,block,'baked:furnace:p1',manualValues(120));globalThis.r=loadProduct(block,'p1');delete r.cookedPrices;r.settings.price='200';saveProduct(block,r);registry.stores.s1.furnace.pct=50;globalThis.view=loadProduct(block,'baked:furnace:p1')`);
 assert.equal(run(`shopPurchasePrice(view,registry.stores.s1,'d1',1,player.id).entries[0].n2`),120);
 assert.equal(run(`loadProduct(block,'p1').settings.price`),'200');
 assert.equal(run(`fzSetSalePrice(player,block,'baked:furnace:p1',null).ok`),true);
 assert.equal(run(`shopPurchasePrice(loadProduct(block,'baked:furnace:p1'),registry.stores.s1,'d1',1,player.id).entries[0].n2`),300);
});
test('automatic owner price is 110 and follows source prices until manually changed',()=>{
 prep();assert.equal(run(`landingSaleInfo(loadProduct(block,'baked:furnace:p1'),registry.stores.s1,'d1').price`),110);
 run(`globalThis.r=loadProduct(block,'p1');r.settings.price='200';saveProduct(block,r)`);
 assert.equal(run(`landingSaleInfo(loadProduct(block,'baked:furnace:p1'),registry.stores.s1,'d1').price`),220);
});
test('manual prices reject invalid amounts, unauthorized users, stale methods and deleted sources',()=>{
 prep();for(const value of [-1,1.5,100000001,NaN,'',null]) {
  ctx.invalidPrice=value;assert.equal(run(`fzSetSalePrice(player,block,'baked:furnace:p1',{...manualValues(120),price:invalidPrice}).ok`),false);
 }
 assert.equal(run(`fzSetSalePrice({id:'guest'},block,'baked:furnace:p1',manualValues(120)).ok`),false);
 assert.equal(run(`fzSetSalePrice(player,block,'baked:furnace:p1',manualValues(120),1).ok`),false);
 run(`globalThis.values=manualValues(120);saveProductIndex(block,[])`);
 assert.equal(run(`fzSetSalePrice(player,block,'baked:furnace:p1',values).ok`),false);
});
test('manual prices cannot be saved for an incompatible cooking shop',()=>{
 prep();assert.equal(run(`fzSetSalePrice(player,block,'baked:smoker:p1',manualValues(120)).ok`),false);
 run(`block.typeId='shopuilook2:panel_blast_furnace'`);
 assert.equal(run(`fzSetSalePrice(player,block,'baked:blast:p1',manualValues(120)).ok`),false);
});
test('owner UI renders the cooked item and its editable manual price without touching source stock',()=>{
 prep();run(`putProducts([base('p1','minecraft:porkchop')]);fzSetSalePrice(player,block,'baked:furnace:p1',manualValues(120));globalThis.lr={landingFloorId:'d1'};writeLanding(player,lr,block,shopInv);`);
 assert.equal(run(`shopInv.getItem(LP.cells[1]).typeId`),'minecraft:cooked_porkchop');
 assert.equal(run(`shopInv.getItem(LANDING_STOCK_COUNT_SLOTS[1]).nameTag`),'120');
 assert.equal(run(`lr.landingCells.get(LP.cells[1]).type`),'cooked');
 assert.equal(run(`loadProduct(block,'p1').stock[0].item.amount`),16);
 assert.match(run(`shopInv.getItem(LP.cells[1]).getLore().join(' ')`),/手動価格/);
});
test('cooked item tooltips show the same automatic or manual price as checkout',()=>{
 prep();run(`globalThis.view=loadProduct(block,'baked:furnace:p1');globalThis.tooltip=makeLandingDisplayItem(view,true,pricePointSettingsForStore(registry.stores.s1).currencies);`);
 assert.match(run(`tooltip.getLore()[2]`),/110/);
 run(`fzSetSalePrice(player,block,'baked:furnace:p1',manualValues(120));globalThis.view=loadProduct(block,'baked:furnace:p1');globalThis.tooltip=makeLandingDisplayItem(view,true,pricePointSettingsForStore(registry.stores.s1).currencies);`);
 assert.match(run(`tooltip.getLore()[2]`),/120/);
 assert.equal(run(`shopPurchasePrice(view,registry.stores.s1,'d1',1,player.id).entries[0].n2`),120);
});
test('a saved manual price survives repeated source stock rewrites and cooked purchases',()=>{
 prep();run(`fzSetSalePrice(player,block,'baked:furnace:p1',manualValues(120));globalThis.r=loadProduct(block,'p1');saveProduct(block,{id:r.id,settings:r.settings,items:r.items,stock:r.stock,savedOnce:true});globalThis.r=loadProduct(block,'p1')`);
 assert.equal(run(`r.cookedPrices.furnace.values.price`),'120');
 assert.equal(run(`loadProduct(block,'baked:furnace:p1')._fzSale.manualPrice`),true);
 assert.deepEqual(plain(run(`loadProductIndex(block)`)),['p1']);
});

function prepBarrel(auto=true,id='minecraft:axolotl_bucket',amount=1){
 prep();ctx.barrelAuto=auto;ctx.seedId=id;ctx.seedAmount=amount;
 run(`block.typeId='shopuilook2:panel_barrel';saveProductIndex(block,[]);registry.stores.s1.departments=[];registry.stores.s1.barrel={auto:barrelAuto,grow:Array.from({length:seedAmount},()=>({id:seedId,amount:1})),water:[],mats:[],buckets:[],prog:{},made:0};`);
}
run(`globalThis.barrelProducts=()=>loadProductIndex(block).map(id=>loadProduct(block,id));`);
test('one axolotl bucket registers its color listings before breeding and without any resources',()=>{
 prepBarrel();run(`fzBarrelGrow(block,5)`);
 assert.equal(run(`barrelProducts().filter(r=>r.items[0]?.id==='minecraft:axolotl_bucket').length`),5);
 assert.deepEqual(new Set(plain(run(`barrelProducts().map(r=>blVariantOf(restoreItemStack(r.stock[0].item)))`))),new Set(['ピンク','茶色','黄色','水色','青']));
 assert.equal(run(`registry.stores.s1.barrel.made`),0);
});

function openCookedEditor(){
 prep();run(`const r=loadProduct(block,'p1');r.settings.price='10';saveProduct(block,r);props.set(LAYOUT_MIGRATION_PROP,1);active.clear();FZ_PRODUCT_EDITS.clear();globalThis.formOpenCount=0;ModalFormData=class{constructor(){formOpenCount++;}};globalThis.editor=makeRecord(player,block,shopInv);editor.landing=true;editor.landingFloorId='d1';active.set(player.id,editor);enterProduct(player,editor,block,shopInv,'baked:furnace:p1');globalThis.editor=active.get(player.id);`);
}
test('cooked product opens the normal editor with no modal form',()=>{
 openCookedEditor();
 assert.equal(run(`formOpenCount`),0);
 assert.equal(run(`getCurrentProduct(block)`),'baked:furnace:p1');
 assert.equal(run(`props.get('price')`),'11');
 assert.equal(run(`isProbe(shopInv.getItem(FOOTER_SAVE_SLOT))`),true);
 assert.equal(run(`isProbe(shopInv.getItem(FOOTER_CANCEL_SLOT))`),true);
 assert.equal(run(`isDisplayClone(shopInv.getItem(17))`),true);
 assert.equal(run(`shopInv.getItem(17).typeId`),'minecraft:cooked_beef');
});

test('normal keypad edit and normal Save store a manual price with no surcharge',()=>{
 openCookedEditor();run(`kpOpen(editor,block,KP_BY_ID.get('price_1'));editor.kpBuf='12';kpStore(editor,block);kpReset(editor);runProductExit(player,editor,block,shopInv,'save');`);
 assert.equal(run(`getCurrentProduct(block)`),undefined);
 assert.equal(run(`loadProduct(block,'p1').settings.price`),'10');
 assert.equal(run(`loadProduct(block,'p1').stock[0].item.amount`),16);
 assert.equal(run(`fzCapacity(fzState(loadStores().stores.s1,'furnace'))`),64);
 assert.equal(run(`shopPurchasePrice(loadProduct(block,'baked:furnace:p1'),registry.stores.s1,'d1',1,player.id).entries[0].n2`),12);
 assert.equal(run(`formOpenCount`),0);
});
test('normal Cancel discards edited prices and preserves source stock and fuel',()=>{
 openCookedEditor();run(`kpOpen(editor,block,KP_BY_ID.get('price_1'));editor.kpBuf='12';kpStore(editor,block);kpReset(editor);runProductExit(player,editor,block,shopInv,'cancel');`);
 assert.equal(run(`loadProduct(block,'baked:furnace:p1')._fzSale.manualPrice`),false);
 assert.equal(run(`loadProduct(block,'p1').stock[0].item.amount`),16);
 assert.equal(run(`fzCapacity(fzState(loadStores().stores.s1,'furnace'))`),64);
 assert.equal(run(`FZ_PRODUCT_EDITS.size`),0);
});
test('normal Save without changing the displayed automatic price keeps it automatic',()=>{
 openCookedEditor();run(`runProductExit(player,editor,block,shopInv,'save');`);
 assert.equal(run(`loadProduct(block,'baked:furnace:p1')._fzSale.manualPrice`),false);
 run(`const r=loadProduct(block,'p1');r.settings.price='20';saveProduct(block,r)`);
 assert.equal(run(`shopPurchasePrice(loadProduct(block,'baked:furnace:p1'),registry.stores.s1,'d1',1,player.id).entries[0].n2`),22);
});
test('normal editing supports cooked product names and payment methods without changing the source',()=>{
 openCookedEditor();run(`setStringProp(block,'shop_product_name','特製ステーキ');setPersistedNumberProp(block,'shop_payment_method',1);setStringProp(block,'required_xp','3');runProductExit(player,editor,block,shopInv,'save');`);
 assert.equal(run(`loadProduct(block,'baked:furnace:p1').settings.shop_product_name`),'特製ステーキ');
 assert.equal(run(`shopPurchasePrice(loadProduct(block,'baked:furnace:p1'),registry.stores.s1,'d1',1,player.id).xp`),3);
 assert.equal(run(`loadProduct(block,'p1').settings.shop_payment_method`),0);
 assert.equal(run(`loadProduct(block,'p1').settings.shop_product_name`),'生の牛肉');
});
test('shared stock previews are locked and cannot turn into real cooked inventory',()=>{
 openCookedEditor();run(`globalThis.before=JSON.stringify(loadProduct(block,'p1').stock);globalThis.previewCopy=shopInv.getItem(17);shopInv.setItem(17,undefined);playerInv.setItem(10,previewCopy);clearProbeFromPlayer(player,true);fzGuardProductPreview(player,block,shopInv);`);
 assert.equal(playerInv.getItem(10),undefined);
 assert.equal(run(`shopInv.getItem(17).lockMode`),'slot');
 assert.equal(run(`isDisplayClone(shopInv.getItem(17))`),true);
 assert.equal(run(`JSON.stringify(loadProduct(block,'p1').stock)`),ctx.before);
});
test('real items put into the linked stock grid are returned instead of being overwritten',()=>{
 openCookedEditor();run(`shopInv.setItem(0,new ItemStack('minecraft:diamond',3));fzGuardProductPreview(player,block,shopInv);`);
 assert.equal([...playerInv.items.values()].filter(i=>i.typeId==='minecraft:diamond').reduce((n,i)=>n+i.amount,0),3);
 assert.equal(run(`loadProduct(block,'p1').stock[0].item.amount`),16);
 assert.equal(run(`isDisplayClone(shopInv.getItem(0))`),true);
});
test('saving after source inventory changes does not write an old inventory snapshot back',()=>{
 openCookedEditor();run(`const r=loadProduct(block,'p1');r.stock[0].item.amount=11;saveProduct(block,r);setStringProp(block,'price','12');runProductExit(player,editor,block,shopInv,'save');`);
 assert.equal(run(`loadProduct(block,'p1').stock[0].item.amount`),11);
 assert.equal(run(`loadProduct(block,'baked:furnace:p1').settings.price`),'12');
});
test('closing a cooked editor cancels pending changes without opening a form',()=>{
 openCookedEditor();run(`setStringProp(block,'price','12');fzFinishProductEdit(player,editor,block,shopInv,false,false)`);
 assert.equal(run(`getCurrentProduct(block)`),undefined);
 assert.equal(run(`FZ_PRODUCT_EDITS.size`),0);
 assert.equal(run(`loadProduct(block,'baked:furnace:p1')._fzSale.manualPrice`),false);
 assert.equal(run(`formOpenCount`),0);
});
test('clearing the normal price fields returns an existing manual price to automatic calculation',()=>{
 openCookedEditor();run(`fzSetSalePrice(player,block,'baked:furnace:p1',manualValues(12));fzFinishProductEdit(player,editor,block,shopInv,false,false);globalThis.rec2=makeRecord(player,block,shopInv);rec2.landing=true;active.set(player.id,rec2);enterProduct(player,rec2,block,shopInv,'baked:furnace:p1');globalThis.editor=active.get(player.id);for(const key of fzSalePriceKeys({shop_payment_method:0})) setStringProp(block,key,'0');runProductExit(player,editor,block,shopInv,'save');`);
 assert.equal(run(`loadProduct(block,'baked:furnace:p1')._fzSale.manualPrice`),false);
 assert.equal(run(`shopPurchasePrice(loadProduct(block,'baked:furnace:p1'),registry.stores.s1,'d1',1,player.id).entries[0].n2`),11);
});
test('single axolotl bucket with grouped mode registers exactly one unsellable placeholder',()=>{
 prepBarrel(false);run(`fzBarrelGrow(block,5)`);
 assert.equal(run(`barrelProducts().length`),1);
 assert.equal(run(`shopPurchaseRemaining(barrelProducts()[0])`),0);
 assert.equal(run(`registry.stores.s1.barrel.grow[0].amount`),1);
});
test('color listings are idempotent and a seed alone never creates sellable animals',()=>{
 prepBarrel();for(let i=0;i<5;i++)run(`fzBarrelGrow(block,5)`);
 assert.equal(run(`barrelProducts().length`),5);
 assert.equal(run(`barrelProducts().every(r=>shopPurchaseRemaining(r)===0)`),true);
 assert.equal(run(`registry.stores.s1.barrel.made`),0);
});
test('aquatic products use the water floor and the axolotl genre',()=>{
 prepBarrel();run(`fzBarrelGrow(block,5)`);
 assert.equal(run(`barrelProducts().every(r=>r.settings.shop_product_genre==='ウーパールーパー')`),true);
 assert.equal(run(`barrelProducts().every(r=>{const fid=productFloorId(block,r.id,storeFloors(registry.stores.s1));return registry.stores.s1.departments.find(f=>f.id===fid)?.name==='水生売り場'})`),true);
});
test('tropical fish color mode registers all 22 patterns before breeding',()=>{
 prepBarrel(true,'minecraft:tropical_fish_bucket');run(`fzBarrelGrow(block,5)`);
 assert.equal(run(`barrelProducts().filter(r=>r.items[0]?.id==='minecraft:tropical_fish_bucket').length`),22);
});
test('registration-only updates never consume breeding supplies even if progress was already mature',()=>{
 prepBarrel(true,'minecraft:axolotl_bucket',2);run(`registry.stores.s1.barrel.water=[{id:'minecraft:water_bucket',n:1},{id:'minecraft:water_bucket',n:1}];registry.stores.s1.barrel.mats=[{id:'minecraft:bone_meal',n:3}];registry.stores.s1.barrel.buckets=[{id:'minecraft:bucket',n:4}];registry.stores.s1.barrel.prog={'minecraft:axolotl_bucket':300};fzBarrelGrow(block,0,true);`);
 assert.equal(run(`registry.stores.s1.barrel.mats[0].n`),3);assert.equal(run(`registry.stores.s1.barrel.buckets[0].n`),4);
 assert.equal(run(`registry.stores.s1.barrel.made`),0);
});
test('real breeding consumes one empty bucket and one bone meal and creates one sellable child',()=>{
 run(`const old=Math.random;Math.random=()=>0.5;try{fzBarrelGrow(block,5);}finally{Math.random=old;}`);
 assert.equal(run(`registry.stores.s1.barrel.mats[0].n`),2);assert.equal(run(`registry.stores.s1.barrel.buckets[0].n`),3);
 assert.equal(run(`registry.stores.s1.barrel.water.filter(Boolean).length`),2);
 assert.equal(run(`registry.stores.s1.barrel.grow.reduce((n,x)=>n+(x?.amount||0),0)`),2);
 assert.equal(run(`registry.stores.s1.barrel.made`),1);
 assert.equal(run(`barrelProducts().reduce((n,r)=>n+shopPurchaseRemaining(r),0)`),1);
});
test('putting a bucket into the live grow slot immediately registers listings while the screen is open',()=>{
 prepBarrel();run(`registry.stores.s1.barrel.grow=[];shopInv.setItem(BL_GROW_SLOTS[0],new ItemStack('minecraft:axolotl_bucket',1));globalThis.sm={storeId:'s1',block};blSync(player,sm,shopInv);`);
 assert.equal(run(`barrelProducts().length`),5);
 assert.equal(run(`shopInv.getItem(BL_GROW_SLOTS[0]).typeId`),'minecraft:axolotl_bucket');
 assert.equal(run(`registry.stores.s1.barrel.grow[0].id`),'minecraft:axolotl_bucket');
});
test('mode changes remove unused placeholders but preserve manually priced listings',()=>{
 prepBarrel();run(`fzBarrelGrow(block,0,true);const p=barrelProducts()[0];p.settings.price='12';saveProduct(block,p);globalThis.keptId=p.id;registry.stores.s1.barrel.auto=false;fzBarrelGrow(block,0,true);`);
 assert.equal(run(`loadProductIndex(block).includes(keptId)`),true);
 assert.equal(run(`loadProduct(block,keptId).settings.price`),'12');
 assert.equal(run(`barrelProducts().filter(r=>r.items[0].key===r.items[0].id).length`),1);
 assert.equal(run(`barrelProducts().length`),2);
});

test('real keypad click signals and the real Save footer work for cooked items without a form',()=>{
 openCookedEditor();run(`if(editor.pendingVisual){const commit=editor.pendingVisual.apply;editor.pendingVisual=null;commit(block,shopInv);}const field=KP_BY_ID.get('price_1');shopInv.setItem(field.header,undefined);kpHandleClick(player,editor,block,shopInv);shopInv.setItem(KP_DOT,undefined);kpHandleClick(player,editor,block,shopInv);shopInv.setItem(KP_DIGIT_BASE+1,undefined);kpHandleClick(player,editor,block,shopInv);shopInv.setItem(KP_DIGIT_BASE+2,undefined);kpHandleClick(player,editor,block,shopInv);shopInv.setItem(FOOTER_SAVE_SLOT,undefined);tickSession(player,editor,block,shopInv);`);
 assert.equal(run(`loadProduct(block,'baked:furnace:p1').settings.price`),'12');
 assert.equal(run(`loadProduct(block,'baked:furnace:p1')._fzSale.manualPrice`),true);
 assert.equal(run(`formOpenCount`),0);
});
test('a failed normal Save keeps the editor open and preserves source inventory',()=>{
 openCookedEditor();run(`setStringProp(block,'price','12');globalThis.realProps=getProps;getProps=()=>({get:k=>props.get(k),set:(k,v)=>{if(k===productKey('p1'))throw Error('injected price save failure');props.set(k,v);}});globalThis.failedSave=leaveProduct(player,editor,block,shopInv);getProps=realProps;`);
 assert.equal(ctx.failedSave,false);
 assert.equal(run(`getCurrentProduct(block)`),'baked:furnace:p1');
 assert.equal(run(`loadProduct(block,'p1').stock[0].item.amount`),16);
 assert.equal(run(`loadProduct(block,'baked:furnace:p1')._fzSale.manualPrice`),false);
 assert.equal(run(`FZ_PRODUCT_EDITS.size`),1);
});
console.log(`${tests} test groups passed`);
